using System;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for AppStudio.
    /// </summary>
    public class AppStudio
    {
        public AppStudio()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private static TabControl FindParentTab(Control parent)
        {
            do
            {
                if (parent.Parent != null)
                {
                    parent = parent.Parent;
                }
                else
                {
                    throw new ApplicationException("Cannot find Tab Control in the current window.");
                }
            }
            while (parent.GetType() != typeof(TabControl));

            return parent as TabControl;
        }

        public static void OpenDialog(Control control)
        {
            System.Windows.Forms.Form form = new Form();
            form.Controls.Add(control);
            form.Show();
        }

        public static void OpenTab(Control parent, UserControl child)
        {
            TabControl tabControl = FindParentTab(parent);

            OpenTab(tabControl, child);
        }

        public static void OpenTab(TabControl tab, UserControl control)
        {
            TabPage currentPage = ContainsTab(tab, control);

            if (currentPage == null)
            {
                TFxAppUI tfxAppUI = new TFxAppUI();
                tfxAppUI.Location = new System.Drawing.Point(0, 0);
                tfxAppUI.Dock = System.Windows.Forms.DockStyle.Fill;
                tfxAppUI.Controls.Add(control);
                control.Parent = tfxAppUI;

                System.Windows.Forms.TabPage controlTab = new System.Windows.Forms.TabPage();
                controlTab.Location = new System.Drawing.Point(4, 22);
                controlTab.Name = control.GetType().Name + "Tab";
                controlTab.Size = new System.Drawing.Size(528, 407);
                controlTab.TabIndex = tab.Controls.Count + 1;
                controlTab.Text = control.Name;

                control.Dock = System.Windows.Forms.DockStyle.Fill;
                tfxAppUI.Parent = controlTab;

                controlTab.Controls.Add(tfxAppUI);

                tab.Controls.Add(controlTab);
                tab.SelectedTab = controlTab;
            }
            else
            {
                tab.SelectedTab = currentPage;
            }
        }

        public static TabPage ContainsTab(TabControl tab, UserControl control)
        {
            Control userControl = null;
            userControl = control;

            foreach (TabPage page in tab.TabPages)
            {
                foreach (Control pageControl in page.Controls)
                {
                    if (pageControl is TFxAppUI)
                    {
                        if (pageControl.Controls.Count > 0)
                        {
                            userControl = pageControl.Controls[0];
                        }
                    }

                    if (userControl != null && userControl.GetType() == control.GetType())
                    {
                        return page;
                    }
                }
            }

            return null;
        }

        public static bool isAppPage(Control control)
        {
            TFxAppUI appUI = new TFxAppUI();

            if (control.GetType() == appUI.GetType())
            {
                return true;
            }

            return false;
        }

        public static TabPage ContainsTab(TabControl tab, string controlName)
        {
            if (controlName != null)
            {
                foreach (TabPage page in tab.TabPages)
                {
                    //foreach(Control pageControl in page.Controls)
                    //{
                    if (page.Text.CompareTo(controlName) == 0)
                    {
                        return page;
                    }
                    //}
                }
            }

            return null;
        }

        public static void CloseTab(Control parent, UserControl control)
        {
            CloseTab(parent, control, true);
        }

        public static void CloseTab(Control parent, UserControl control, bool autoDisposed)
        {
            TabControl tabControl = FindParentTab(parent);

            if (control.Parent != null && control.Parent.GetType() == typeof(TabPage))
            {
                CloseTab(tabControl, control.Parent as TabPage, autoDisposed);
            }
            else
            {
                throw new ApplicationException("Cannot find TabPage or TabControl");
            }
        }

        public static void CloseTab(TabControl tab, TabPage page, bool autoDisposed)
        {
            if (tab.Contains(page))
            {
                if (autoDisposed)
                {
                    page.Dispose();
                }


                tab.Controls.Remove(page);
            }
        }

        public static void CloseCurrentTabPage(TabControl tab)
        {
            CloseTab(tab, tab.SelectedTab, true);
        }
    }
}
