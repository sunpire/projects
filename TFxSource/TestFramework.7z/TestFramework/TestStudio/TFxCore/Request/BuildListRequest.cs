using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for BuildListRequest.
	/// </summary>
	public class BuildListRequest : ListRequest
	{
		
		public BuildListRequest()
		{
		
		}

		public TestRelease Release;
		
	}
}
