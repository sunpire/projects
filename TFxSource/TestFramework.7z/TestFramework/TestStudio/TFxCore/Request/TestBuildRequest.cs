using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TestBuildRequest.
	/// </summary>
	public class TestBuildRequest: RepositoryRequest
	{
		public TestBuildRequest(RepositoryRequestType requestType) : base(requestType)
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public TestBuild Build;
		public string BuildName;
		public BuildType BuildType;
		public string Release;
		public int BitAvailable=1;
	}
}
