using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ListObjectRequest.
	/// </summary>
	public class ListRequest : RepositoryRequest
	{
		protected string[] m_objects;
		public string[] Objects
		{
			get
			{
				if(m_objects == null)
				{
					m_objects = new string[0];
				}
				return m_objects;
			}
			set
			{
				m_objects = value;
			}
		}

		public ListRequest() : base(RepositoryRequestType.Get)
		{
		}
	}
}
