using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for BuildPublishRequest.
	/// </summary>
	public class BuildPublishRequest: RepositoryRequest
	{
		public BuildPublishRequest(RepositoryRequestType type): base(type)
		{
			//
			// TODO: Add constructor logic here
			//
		}
		public RepositoryChangelist ChangeList;
		public TestBuild PublishBuild;
	}
}
