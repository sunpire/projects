using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for AppConfigRequest.
	/// </summary>
	public class AppConfigRequest : RepositoryRequest
	{
		public AppConfig AppConfig;
		public bool DevMode;
		public AppConfigRequest(RepositoryRequestType requestType):base(requestType)
		{
			
		}
	}
}
