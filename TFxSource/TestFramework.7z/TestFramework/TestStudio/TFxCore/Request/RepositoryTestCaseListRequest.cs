using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for RepositoryTestCaseListRequest.
    /// Comments:	Changed related testid to releated testgid, int to GUID
	/// </summary>
	public class TestCaseListRequest : RepositoryRequest
	{
		public TestArea []TestAreaRoots;
		public string BuildName;
		public string ModuleName;
		public Guid RelatedTestGid=Guid.Empty;
        public string ReleaseName;

		public TestCaseListRequest(RepositoryRequestType requestType) : base(requestType)
		{
		}
	}
}
