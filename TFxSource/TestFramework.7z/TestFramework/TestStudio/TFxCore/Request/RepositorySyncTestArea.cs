using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for RepositorySyncTestArea.
	/// </summary>
	public class RepositorySyncTestArea: RepositorySync
	{
		public RepositorySyncTestArea(RepositoryRequestType requestType) : base(requestType)
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public TestArea TestAreaToSync;
		public string Release;
	}
}
