using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ReleaseListRequest.
	/// </summary>
	public class ReleaseListRequest: ListRequest
	{
		public ReleaseListRequest()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
