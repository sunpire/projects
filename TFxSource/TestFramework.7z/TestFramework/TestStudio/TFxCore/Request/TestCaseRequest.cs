using System;
using System.Collections.Generic;
using System.Text;

namespace Expedia.Test.Framework
{
    public class TestCaseRequest : RepositoryRequest
    {
        public TestInfo ManualTest;
        public string ReleaseName;

        public TestCaseRequest(RepositoryRequestType request): base(request)
        {
        }
    }
}
