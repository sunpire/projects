using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ConfigListRequest.
	/// </summary>
	public class ConfigListRequest : ListRequest
	{
		public ConfigListRequest()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
