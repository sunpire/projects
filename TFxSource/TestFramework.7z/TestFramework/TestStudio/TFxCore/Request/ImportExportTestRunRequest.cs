using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ImportExportTestRunRequest.
	/// </summary>
	public class ImportExportTestRunRequest : LabRunRequest
	{
		public ImportExportTestRunRequest(RepositoryRequestType requestType):base(requestType)
		{
			//
			// TODO: Add constructor logic here
			//
		}
		
	}
}
