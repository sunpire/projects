using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for FilterListRequest.
	/// </summary>
	public class FilterListRequest : ListRequest
	{
		public Type FilterType;

		public FilterListRequest()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
