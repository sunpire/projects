using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TestBuildModuleRequest.
	/// </summary>
	public class TestBuildModuleRequest: RepositoryRequest
	{
		public TestBuildModuleRequest(RepositoryRequestType requestType):base(requestType)
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public string ReleaseName;
		public BuildType BuildType;
		public string BuildName;
		public string ModuleName;

		public TestBuildModule Module;
	}
}
