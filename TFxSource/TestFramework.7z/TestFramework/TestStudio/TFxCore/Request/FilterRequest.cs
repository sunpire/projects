using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for FilterRequest.
	/// </summary>
	public class FilterRequest : RepositoryRequest
	{
		public Type FilterType;
		public string InstanceName;
		public FieldExpressionData Filter;		

		public FilterRequest(RepositoryRequestType requestType) : base(requestType)
		{
		}
	}
}
