using System;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for LabRunRequest.
    /// Comments: Changed the Buildid from int to GUID
    /// </summary>
    public class LabRunRequest : RepositoryRequest
    {
        public string UserName;
        public LabRun LabRun;
        public string LabRunName;
        public Guid ManagerGid;
        public Guid BuildGid;
        public LabRunStatusType Status;
        public Guid LabRunGid;
        public bool isAssignmentCollectionChanged = false;
        public string OldLabRunName;
        public string HintFilePath;
        public bool GetResult = false;

        public LabRunRequest(RepositoryRequestType requestType)
            : base(requestType)
        {
            //
            // TODO: Add constructor logic here
            //
        }
    }
}
