using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ProfileRequest.
	/// </summary>
	/// 
	public enum ProfileName
	{
		DefaultProfile
	}

	public class ProfileRequest : RepositoryRequest
	{
		public Profile Profile;
		public string ProfileName;
		
		public ProfileRequest(RepositoryRequestType requestType):base(requestType)
		{
			
		}
	}
}
