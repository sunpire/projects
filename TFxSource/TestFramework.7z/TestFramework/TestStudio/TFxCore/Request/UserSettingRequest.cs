using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for GetUserSettingRequest.
	/// </summary>
	public class UserSettingRequest : RepositoryRequest
	{
		public UsersSetting Settings;
		public ApplicationMode Mode = ApplicationMode.TestPlayer;


		public UserSettingRequest(RepositoryRequestType requestType) : base(requestType)
		{
		}

		public UserSettingRequest(UsersSetting setting, RepositoryRequestType requestType) : base(requestType)
		{
			this.Settings = setting;
		}
	}
}
