using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ManagerRequest.
	/// </summary>
	public class ManagerRequest : RepositoryRequest
	{
		public TFxUser[] ManagersList;
		public ManagerRequest(RepositoryRequestType requestType): base(requestType)
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
