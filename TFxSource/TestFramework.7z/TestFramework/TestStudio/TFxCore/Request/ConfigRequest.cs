using System;
using System.Data;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ConfigRequest.
	/// </summary>
	public class ConfigRequest: RepositoryRequest
	{
		public string InstanceName;
		
		private FieldExpression m_expression;
		public FieldExpression  Expression
		{
			get
			{
				if(this.m_configExpression != null)
				{
					DataSet ds = m_configExpression.GetDataSet();
					if(ds != null && ds.Tables.Count >= 1)
					{
						m_expression.ExpressionDataTable = ds.Tables[0];
					}					
				}
				return m_expression;
				
				
			}
			set
			{
				m_expression = value;
			}
		}

		private ConfigData m_configData;

		public ConfigData ConfigData
		{
			get
			{
				if(this.m_configExpression != null)
				{
					DataSet ds = m_configExpression.GetDataSet();
					if(ds != null && ds.Tables.Count >= 2)
					{
						m_configData.ConfigTable = ds.Tables[1];
					}				
				}
				return m_configData;	
				
			}
			set
			{
				m_configData = value;
			}
		}
		
		private ConfigExpressionData m_configExpression;
		public ConfigExpressionData ConfigExpression
		{
			get
			{
				if(m_configExpression == null)
				{
					m_configExpression =  new ConfigExpressionData(this.InstanceName,this.m_expression.ExpressionDataTable, this.m_configData.ConfigTable);
				}
				
				return m_configExpression;
			}
			set
			{
				m_configExpression = value;
			}
			
		}
		
		public ConfigRequest(RepositoryRequestType requestType): base(requestType)
		{
			Expression = new FieldExpression();
			ConfigData = new ConfigData();
		}

		public ConfigData Data()
		{
			DataSet ds = null;
			

			//Get the config data, we need the config data so that we can generate the assignments with it
			if(ConfigExpression != null)
			{
				//Get the Filed Expression
				ConfigEngin engin = new ConfigEngin();	
				ds = this.ConfigExpression.GetDataSet();

				if(ds!= null && ds.Tables.Count >= 1)
				{					
					engin.InitConfigData(this.ConfigData, Expression);
					ConfigData = engin.Evaluate(Expression);
					return ConfigData;														
				}												
			}
			return null;
		}
	}
}
