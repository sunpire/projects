//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: FilterOperator.cs 
// 
// Desc: 
// 
// Note: 
// 
// History: 
// 
//========================================================================== 
using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for FilterOperators.
	/// </summary>
	public enum FilterOperator
	{
		Equals,
		NotEqual,
		LessThan,
		LessThanEquals,
		GreaterThan,
		GreaterThanEquals,
		Contains,
		NotContains
	}
}
