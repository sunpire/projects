//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: IFilter.cs 
// 
// Desc: 
// 
// Note: 
// 
// History: 
// 
//========================================================================== 
using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for IFilter.
	/// </summary>
	public interface IFilter
	{
		bool Filter(object obj);

		IFilter[] Fields
		{
			get;
		}

		FilterOperator[] SupportedOperators
		{
			get;
		}

		FilterOperator Operator
		{
			get;
			set;
		}

		object[] SupportedValues
		{
			get;
		}

		object Value
		{
			get;
			set;
		}


		bool IsRestrictedToValueList
		{
			get;			
		}

		FilterExpressionElementType[] SupportedFilterExpressionElementType
		{
			get;
		}

		string Name
		{
			get;
			set;
		}
	}
}
