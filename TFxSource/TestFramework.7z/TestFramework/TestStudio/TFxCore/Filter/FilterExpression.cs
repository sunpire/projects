//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: FilterExpression.cs 
// 
// Desc: 
// 
// Note: 
// 
// History: 
// 
//========================================================================== 
using System;
using System.Collections;
using System.Reflection;
using System.Xml;
using System.Xml.Serialization;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for FilterExpression.
	/// </summary>
	/// 
	[Serializable]
	[XmlInclude(typeof(FilterExpression))]
	public class FilterExpression : IFilter
	{
		private ArrayList m_fields;
		private ArrayList m_elements;
		private Type m_filterType;
		private string m_name;

		public FilterExpression()
		{
			this.m_fields = new ArrayList();
			this.m_elements = new ArrayList();
			this.m_name = String.Empty;
			this.InitializeFields();
		}

		public FilterExpression(Type filterType)
		{
			this.m_fields = new ArrayList();
			this.m_elements = new ArrayList();
			this.m_filterType = filterType;
			this.m_name = String.Empty;
			this.InitializeFields();
		}

		public bool Filter(object obj)
		{
			if(this.Elements.Length > 0)
			{
				bool result = this.Elements[0].Field.Filter(obj);
				for(int i = 1;i < this.Elements.Length;i++)
				{
					bool elementResult = this.Elements[i].Field.Filter(obj);
					switch(this.Elements[i - 1].ElementType)
					{
						case FilterExpressionElementType.And:
							result = result && elementResult;
							break;
						case FilterExpressionElementType.Or:
							result = result || elementResult;
							break;
					}
				}
				return result;
			}
			else
			{
				return false;
			}
		}

		public void AddElement(FilterExpressionElement element)
		{
			this.m_elements.Add(element);
		}

		public void InsertElementAt(FilterExpressionElement element, int index)
		{
			this.m_elements.Insert(index, element);
		}

		public FilterExpressionElement GetElement(int index)
		{
			return (FilterExpressionElement)this.m_elements[index];
		}

		public void SetElement(FilterExpressionElement element, int index)
		{
			this.m_elements[index] = element;
		}

		public void RemoveElement(FilterExpressionElement element)
		{
			this.m_elements.Remove(element);
		}

		public IFilter[] Fields
		{
			get
			{
				ArrayList fields = new ArrayList();
				foreach(IFilter field in this.m_fields)
				{
					fields.AddRange(field.Fields);
				}
				return (IFilter [])fields.ToArray(typeof(IFilter));
			}
		}

		public FilterExpressionElement[] Elements
		{
			get
			{
				return (FilterExpressionElement [])this.m_elements.ToArray(typeof(FilterExpressionElement));
			}
		}


		public FilterOperator[] SupportedOperators
		{
			get
			{
				ArrayList operators = new ArrayList();
				foreach(IFilter field in this.m_fields)
				{
					foreach(FilterOperator oper in field.SupportedOperators)
					{
						if(!operators.Contains(oper))
						{
							operators.Add(oper);
						}
					}
				}
				return (FilterOperator [])operators.ToArray(typeof(FilterOperator));
			}
		}

		public object[] SupportedValues
		{
			get
			{
				ArrayList values = new ArrayList();
				foreach(IFilter field in this.m_fields)
				{
					foreach(object obj in field.SupportedValues)
					{
						if(!values.Contains(obj))
						{
							values.Add(obj);
						}
					}
				}
				return values.ToArray();
			}
		}

		public bool IsRestrictedToValueList
		{
			get
			{
				return true;
			}
				
		}
		public ConfigFieldInfo FindField(string fieldname)
		{
			ConfigFieldInfo fi = new ConfigFieldInfo();

			ArrayList operators = new ArrayList();
			foreach(IFilter field in this.m_fields)
			{
				if(field.Name.CompareTo(fieldname) == 0)
				{
					fi.Name = field.Name;
					fi.IsRestrictedToValueList = field.IsRestrictedToValueList;
					
					foreach(object obj in field.SupportedOperators)
					{
						if(!operators.Contains(obj))
						{
							operators.Add(obj);
						}
					}

					fi.SupportedOperators = operators;
					return fi;
				}
			}

			return null;

		}

		public ArrayList GetSupportedValues(string fieldname)
		{
			ArrayList values = new ArrayList();
			foreach(IFilter field in this.m_fields)
			{
				if(field.Name.CompareTo(fieldname) == 0)
				{
					foreach(object obj in field.SupportedValues)
					{
						if(!values.Contains(obj))
						{
							values.Add(obj);
						}
					}
					return values;					
				}
			}
			return null;
		}

		public FilterExpressionElementType[] SupportedFilterExpressionElementType
		{
			get
			{
				ArrayList types = new ArrayList();
				foreach(IFilter field in this.m_fields)
				{
					foreach(FilterExpressionElementType type in field.SupportedFilterExpressionElementType)
					{
						if(!types.Contains(type))
						{
							types.Add(type);
						}
					}
				}
				return (FilterExpressionElementType [])types.ToArray(typeof(FilterExpressionElementType));
			}
		}

		public FilterOperator Operator
		{
			get
			{
				throw new NotImplementedException("Operator is not implemented in FilterExpression.");
			}
			set
			{
				throw new NotImplementedException("Operator is not implemented in FilterExpression.");
			}
		}

		public object Value
		{
			get
			{
				throw new NotImplementedException("Value is not implemented in FilterExpression.");
			}
			set
			{
				throw new NotImplementedException("Value is not implemented in FilterExpression.");
			}
		}

		
		public Type FilterType
		{
			get
			{
				return this.m_filterType;
			}
			set
			{
				this.m_filterType = value;
				this.InitializeFields();
			}
		}

		public string Name
		{
			get
			{
				return this.m_name;
			}
			set
			{
				this.m_name = value;
			}
		}

		private void InitializeFields()
		{
			//Assembly a = Assembly.GetAssembly(typeof(IFilter));
			this.m_fields.Clear();

			Assembly [] assemblies = AppDomain.CurrentDomain.GetAssemblies();
			foreach(Assembly a in assemblies)
			{
				foreach(Type t in a.GetTypes())
				{
					Type []interfaces = t.GetInterfaces();
					for(int i=0; i < interfaces.GetLength(0); i++)
					{
						if(interfaces[i] == typeof(IFilter))
						{
							foreach(SupportedTypeAttribute typeAttribute in t.GetCustomAttributes(typeof(SupportedTypeAttribute), false))
							{
								if(typeAttribute.SupportedType == this.FilterType)
								{
									this.m_fields.Add(Activator.CreateInstance(t));
								}
							}
						}
					}
				}
			}
		}

		public override string ToString()
		{
			string s = String.Empty;

			for(int i = 0;i < this.Elements.Length - 1;i++)
			{
				s += String.Format("({0} {1} {2}) {3} ",
					this.Elements[i].Field.ToString(),
					this.Elements[i].Field.Operator,
					this.Elements[i].Field.Value,
					this.Elements[i].ElementType);
			}
			if(this.Elements.Length > 0)
			{
				s += String.Format("({0} {1} {2})",
					this.Elements[this.Elements.Length - 1].Field.ToString(),
					this.Elements[this.Elements.Length - 1].Field.Operator,
					this.Elements[this.Elements.Length - 1].Field.Value);
			}

			return s;
		}


		public FieldExpression GenerateFieldExpression(FilterExpression expression)
		{
			FieldExpression field = new FieldExpression();

			for(int index =0 ; index < expression.Elements.Length; index++)
			{
				field.SetField(index, expression.Elements[index].Field.Name);
				field.SetOperator(index, expression.Elements[index].Field.Operator.ToString());
				field.SetValue(index, expression.Elements[index].Field.Value.ToString());
				field.SetAndOr(index, expression.Elements[index].ElementType.ToString());
			}
			return field;		

		}
		
		public FilterExpression GenerateFilterExpression(FieldExpression expression)
		{
			FilterExpression filter = new FilterExpression(this.FilterType);

			//Create a new FilterExpressionElement for each of the rows of the expression datatable
			for(int i =0; i< expression.RowCount; i++)
			{
				string name = expression.GetField(i);
				foreach(IFilter field in this.m_fields)
				{
					if(field.Name.CompareTo(name)==0)
					{
						//Operator
						foreach(FilterOperator operators in field.SupportedOperators)
						{
							if(expression.GetOperator(i).CompareTo(operators.ToString()) == 0)
							{
								field.Operator = operators;
								break;
							}
						}

						//Value

						if(!field.IsRestrictedToValueList)
						{
							field.Value = expression.GetValue(i);
						}

						foreach(object values in field.SupportedValues)
						{						
							if(expression.GetValue(i).CompareTo(values.ToString()) == 0)
							{
								field.Value = values;
								break;
							}						
							
						}						

						//FilterExpressionElementType
						FilterExpressionElementType element = FilterExpressionElementType.And;
						foreach(FilterExpressionElementType elementType in field.SupportedFilterExpressionElementType)
						{
							if(expression.GetAndOr(i).CompareTo(elementType.ToString()) == 0)
							{
								element = elementType;
								break;

							}
						}
						//Add to the Filter
						filter.AddElement(new FilterExpressionElement(field,element));						
					}
				}				
			}
			return filter;
		}
	}
}
