//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: FilterExpressionElement.cs 
// 
// Desc: 
// 
// Note: 
// 
// History: 
// 
//========================================================================== 
using System;

namespace Expedia.Test.Framework
{
	public enum FilterExpressionElementType
	{
		And,
		Or
	}

	/// <summary>
	/// Summary description for FilterExpressionElement.
	/// </summary>
	public class FilterExpressionElement
	{
		private IFilter m_field;
		private FilterExpressionElementType m_type;

		public FilterExpressionElement(IFilter field, FilterExpressionElementType type)
		{
			this.m_field = field;
			this.m_type = type;
		}

		public IFilter Field
		{
			get
			{
				return this.m_field;
			}
			set
			{
				this.m_field = value;
			}
		}

		public FilterExpressionElementType ElementType
		{
			get
			{
				return this.m_type;
			}
			set
			{
				this.m_type = value;
			}
		}
	}
}
