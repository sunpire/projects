//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: SupportedTypeAttribute.cs 
// 
// Desc: 
// 
// Note: 
// 
// History: 
// 
//========================================================================== 
using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for SupportedTypeAttribute.
	/// </summary>
	[AttributeUsage(AttributeTargets.Class, AllowMultiple=true)]
	public class SupportedTypeAttribute : Attribute
	{
		private Type m_type = null;

		public SupportedTypeAttribute()
		{
		}

		public SupportedTypeAttribute(Type supportedType)
		{
			this.m_type = supportedType;
		}

		public Type SupportedType
		{
			get
			{
				return this.m_type;
			}
			set
			{
				this.m_type = value;
			}
		}
	}
}
