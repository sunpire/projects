using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Expedia.Test.Framework;

namespace Expedia.Test.Framework
{
    public class TFxUIListiners
    {
        Hashtable notificationListeners = Hashtable.Synchronized(new Hashtable());

        public TFxUIListiners()
        {

        }
        public NotificationListener AddListener(Type type, NotificationRequestHandler handler)
        {
            if (!notificationListeners.ContainsKey(type))
            {
                NotificationListener listener = new NotificationListener(type);

                notificationListeners.Add(type, listener);
            }

            ((NotificationListener)notificationListeners[type]).AddListener(handler);

            return notificationListeners[type] as NotificationListener;
        }

        //public NotificationListener GetListiner(Type type)
        //{
        //    return notificationListeners[type] as NotificationListener;
        //}

        public void Invoke(NotificationRequest request)
        {
            NotificationListener listener;

            if (notificationListeners.Contains(request.GetType()))
            {
                listener = notificationListeners[request.GetType()] as NotificationListener;
                listener.Invoke(request);
            }
        }

        public void RemoveListener(Type type, NotificationRequestHandler handler)
        {
            NotificationListener listener;

            if (notificationListeners.ContainsKey(type))
            {
                listener = notificationListeners[type] as NotificationListener;
                listener.RemoveListener(handler);
                notificationListeners.Remove(type);
            }
        }

    }

}
