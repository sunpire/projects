using System;
using System.Collections;
using System.Reflection;
using System.Data;
using System.Data.SqlClient;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for SQLConfigDriver.
	/// </summary>
	public class SQLConfigDriver : IConfigDriver
	{
		[FieldInfo(false, "is", Required=true)]
		public FieldInstance ConnectString = new FieldInstance("server=TFx;database=TFx;uid=TFxLabRunManager;pwd=lrm;", "is");

		[FieldInfo(false, "is", Required=true)]
		public FieldInstance SelectStatement = new FieldInstance("SELECT * FROM GlobalConfig;", "is");

		public SQLConfigDriver()
		{
		}


		public bool IsFilterable
		{
			get
			{
				return true;
			}
		}

		public bool IsEditable
		{
			get
			{
				return false;
			}
		}


		public override string ToString()
		{
			return "SQLConfig";
		}

		public virtual ConfigData GetData()
		{
			try
			{
				using(SqlConnection con = new SqlConnection())
				{
					con.ConnectionString = this.ConnectString.Value;
					con.Open();
					using (SqlDataAdapter da = new SqlDataAdapter(this.SelectStatement.Value, con))
					{
						DataTable dt = new DataTable();						
						da.Fill(dt);
						ConfigData data = new ConfigData();
						data.Append(dt);
						return data;
					}
				}
			}
			catch(Exception e)
			{
				System.Diagnostics.Debug.Write(e.ToString());
			}
			return new ConfigData();
		}

		GenericConfigEditor m_eidtor;
		public IConfigEditor Editor(int rowOffset)
		{
			if(m_eidtor == null)
			{
				m_eidtor = new GenericConfigEditor(this, rowOffset);
			}
			return m_eidtor;
		}

		public void InitConfigData(ConfigData data)
		{

		}

		public void UpdateConfig(int rowOffset, FieldExpression exp)
		{
			for(int i=0; i < exp.RowCount; i++)
			{
				switch(exp.GetField(i))
				{
					case "ConnectString":
						this.ConnectString.Value = exp.GetValue(i);
						this.ConnectString.Operator  = exp.GetOperator(i);
						break;
						
					case "SelectStatement":
						this.SelectStatement.Value = exp.GetValue(i);
						this.SelectStatement.Operator = exp.GetOperator(i);
						break;
				}
			}
		}

		public ArrayList GetDynamicFields(int rowOffset, FieldExpression exp)
		{
			return null;
		}

	}

}
