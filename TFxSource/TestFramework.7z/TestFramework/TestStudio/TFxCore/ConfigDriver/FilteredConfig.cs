using System;
using System.Collections;
using System.Data;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for FilteredConfig.
	/// </summary>
	public class FilteredConfig : IConfigDriver
	{
		
		public ConfigData SourceConfig;
		
		string m_selectStatement;
		public FilteredConfig()
		{
			m_selectStatement = "";
		}


		public bool IsFilterable
		{
			get
			{
				return true;
			}
		}

		public bool IsEditable
		{
			get
			{
				return false;
			}
		}


		GenericConfigEditor m_eidtor;
		public IConfigEditor Editor(int rowOffset)
		{
			if(m_eidtor == null)
			{
				m_eidtor = new GenericConfigEditor(this, rowOffset);
			}
			return m_eidtor;
		}
		
		public void InitConfigData(ConfigData data)
		{

		}


		public void UpdateConfig(int rowOffset, FieldExpression exp)
		{
			string c_StartCharacter = "[";
			string c_EndCharacter = "]";
			string c_SpaceCharacter = " ";
			string c_fieldName = "";

			m_selectStatement = "";

			for(int i=0; i < exp.RowCount; i++)
			{
				if(exp.GetField(i).StartsWith(c_StartCharacter))
				{
					c_fieldName = exp.GetField(i).TrimStart(c_StartCharacter.ToCharArray()).TrimEnd(c_EndCharacter.ToCharArray());
					if(exp.GetValue(i) != "")
					{
						m_selectStatement = m_selectStatement + c_SpaceCharacter + c_fieldName + c_SpaceCharacter + exp.GetOperator(i) + "'"+ exp.GetValue(i)+ "'" + c_SpaceCharacter + exp.GetAndOr(i);

					}
					else
					{
						m_selectStatement = "";
					}				
				}
			}
		}

		public ArrayList GetDynamicFields(int rowOffset, FieldExpression exp)
		{
			//GetList of fields for filtered config
			ArrayList list = new ArrayList();
			this.UpdateConfig(rowOffset, exp);
			ConfigData data = this.GetData();
			if(data != null && data.ConfigTable != null)
			{
				ArrayList stringOperators = new ArrayList();
				stringOperators.AddRange(new string[]{"=", "!=", ">", "<", "Contains"});
				foreach(DataColumn col in data.ConfigTable.Columns)
				{
					string name = string.Format("[{0}]", col.ColumnName);
					ConfigFieldInfo fi = new ConfigFieldInfo(name, false, stringOperators);
					list.Add(fi);
				}
			}
			return list;
		}

		public virtual ConfigData GetData()
		{
			DataTable copyTable = null;
			string c_AndString = "And";
			string c_OrString = "Or";

			if(SourceConfig != null)
			{
				if(SourceConfig.ConfigTable != null)
				{
					copyTable = this.SourceConfig.ConfigTable.Copy();
					copyTable.Rows.Clear();
					copyTable.AcceptChanges();
				
				
					if(m_selectStatement != "")
					{
						if(m_selectStatement.EndsWith(c_AndString))
						{
							m_selectStatement = m_selectStatement.TrimEnd(c_AndString.ToCharArray());
						}

						if(m_selectStatement.EndsWith(c_OrString))
						{
							m_selectStatement = m_selectStatement.TrimEnd(c_OrString.ToCharArray());
						}

						try
						{
							DataRow[] rows = this.SourceConfig.ConfigTable.Select(m_selectStatement);

							if((rows != null) &&(rows.Length >0))
							{
								for(int i =0; i < rows.Length ; i++)
								{
									copyTable.ImportRow(rows[i]);
								}
							}
						}
						catch(Exception e)
						{
							// invalid statement
							System.Diagnostics.Debug.WriteLine(e);
							System.Diagnostics.Debug.WriteLine(m_selectStatement);
						}
						SourceConfig.ConfigTable = copyTable;
						return SourceConfig;
					}
					return SourceConfig;
				}
				
			}
			return SourceConfig;
		}

		public ConfigFieldInfo GetFieldInfo(string fieldName, FieldExpression exp)
		{
			ConfigData data = this.GetData();

			if(data != null && data.ConfigTable != null)
			{
				ArrayList stringOperators = new ArrayList();
				stringOperators.AddRange(new string[]{"=", "!=", ">", "<", "Contains"});
				foreach(DataColumn col in data.ConfigTable.Columns)
				{
					if(col.ColumnName.CompareTo(fieldName.TrimEnd(']').TrimStart('[')) == 0)
					{
						string name = string.Format("[{0}]", col.ColumnName);
						ConfigFieldInfo fi = new ConfigFieldInfo(name, true, stringOperators);
						return fi;
					}			
				
				}
			}

			return null;

		}

		public ArrayList GetValues(string fieldName, FieldExpression exp)
		{
			ArrayList values = new ArrayList();

			ConfigData data = this.SourceConfig;

			if(data != null && data.ConfigTable != null)
			{

				foreach(DataColumn col in data.ConfigTable.Columns)
				{
					if(col.ColumnName.CompareTo(fieldName.TrimEnd(']').TrimStart('[')) == 0)
					{
						foreach(DataRow row in data.ConfigTable.Rows)
						{
							if(!values.Contains(row[col]))
							{
								values.Add(row[col]);
							}							
							
						}						
						return values;
					}							
				}
			}

			return new ArrayList();

		}



		

	}
}
