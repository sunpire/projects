using System;
using System.Collections;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for FieldInfoAttribute.
	/// </summary>
	[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple=false)]
	public class FieldInfoAttribute : Attribute
	{
//		public FieldInfoAttribute(bool restrictedvalue, string[] supportedOperators)
//		{
//			this.SupportedOperators.AddRange(supportedOperators);
//			this.ValueRestricted = restrictedvalue;
//		}

		public FieldInfoAttribute(bool restrictedvalue,  params string[] operators)
		{
			this.SupportedOperators.AddRange(operators);
			this.ValueRestricted = restrictedvalue;
		}

		public FieldInfoAttribute(bool restrictedvalue, string oper) : this(restrictedvalue, new string[]{oper})
		{
		}
		public bool ValueRestricted
		{
			get
			{
				return Info.IsRestrictedToValueList;
			}
			set
			{
				Info.IsRestrictedToValueList = value;
			}
		}

		public ArrayList SupportedOperators
		{
			get
			{
				return Info.SupportedOperators;
			}
			set
			{
				Info.SupportedOperators = value;
			}
		}

		public bool Required
		{
			get
			{
				return Info.Required;
			}
			set
			{
				Info.Required = value;
			}
		}
		public string Name;

		public ConfigFieldInfo Info = new ConfigFieldInfo();

	}
}
