using System;
using System.Data;
using System.IO;
using System.Xml;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ConfigExpressionData.
	/// </summary>
	/// 

	
	[Serializable]
	public class ConfigExpressionData
	{
		public string dataset; //TODO: remove this after few months (now=Dec05) when users have updated their old config files
		public DataSet m_dataset;

		public ConfigExpressionData()
		{

		}
		public ConfigExpressionData(string dataset, DataTable fieldExpression, DataTable configData)
		{
			UpdateDataSet(fieldExpression, configData);					
		}

		public void UpdateDataSet(DataTable fieldExpression, DataTable configData)
		{
			if (m_dataset == null) {
				m_dataset = new DataSet();
			}
			m_dataset.Tables.Clear();

			DataTable dataTable = null;
			if(fieldExpression != null)
			{
				dataTable = fieldExpression.Copy();
				//dataTable.TableName = "FieldExpression";
				m_dataset.Tables.Add(dataTable);


				if(configData != null && (string)fieldExpression.Rows[0]["Values"] != "SQLConfig")
				{
					dataTable = configData.Copy();
					//dataTable.TableName = "ConfigData";
					m_dataset.Tables.Add(dataTable);
				}
			}						
		}

		public DataSet GetDataSet()
		{
			if (this.dataset != null) //TODO: remove this after few months (now=Dec05)
				return GetDataSet(this.dataset);

			return this.m_dataset;
		}

		//TODO: remove this after few months (now=Dec05)
		public DataSet GetDataSet(string data)
		{
			DataSet ds = new DataSet();			
			StringReader strReader = new StringReader(data);
			XmlTextReader reader = new XmlTextReader(strReader);
			ds.ReadXml(reader);
			return ds;
		}
		
	}
}
