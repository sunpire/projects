using System;
using System.Collections;
using System.Data;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for MultiConfig.
	/// </summary>
	public class MultiConfig : IConfigDriver
	{
		public MultiConfig()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public bool IsFilterable
		{
			get
			{
				return true;
			}
		}

		public bool IsEditable
		{
			get
			{
				return false;
			}
		}

		[FieldInfo(false, "is", Required=true)]
		public FieldInstance SourceConfig;

		[FieldInfo(false, "Join", Required=false)]
		public FieldInstance []Link;

		GenericConfigEditor m_eidtor;
		public IConfigEditor Editor(int rowOffset)
		{
			if(m_eidtor == null)
			{
				m_eidtor = new GenericConfigEditor(this, rowOffset);
			}
			return m_eidtor;
		}

		public ConfigData GetData()
		{
			return null;
		}

		public override string ToString()
		{
			return "MultiConfig";
		}

		public void InitConfigData(ConfigData data)
		{

		}

		public void UpdateConfig(int rowOffset, FieldExpression exp)
		{
			for(int i=0; i < exp.RowCount; i++)
			{
			}
		}

		public ArrayList GetDynamicFields(int rowOffset, FieldExpression exp)
		{
			return null;
		}
	}
}
