using System;
using System.Reflection;
using System.Collections;

namespace  Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for GenericConfigEditor.
	/// </summary>
	public class GenericConfigEditor : IConfigEditor
	{
		FilteredConfig m_filteredConfig;
		IConfigDriver m_config;
		int m_rowOffset;

		public GenericConfigEditor(IConfigDriver config, int rowOffset)
		{
			m_config = config;
			m_rowOffset = rowOffset;
			m_filteredConfig = new FilteredConfig();
		}

		public ArrayList GetFields(int currRow, Expedia.Test.Framework.FieldExpression exp)
		{
			
			ArrayList requiredFields = GenericConfigEditor.GetFields(m_config, true, false);

			//Return the first value
			if(requiredFields.Count > Row(currRow))
			{
				ArrayList list = new ArrayList();
				list.Add(requiredFields[Row(currRow)]);
				return list;
			}
			ArrayList list2  = new ArrayList();

			if(ShouldAllowConfigFields(currRow, exp))
			{
				list2.AddRange (GenericConfigEditor.GetFields(m_config, false, true));
				ArrayList listDyanamic = m_config.GetDynamicFields(this.m_rowOffset, exp);
				if(listDyanamic != null)
				{
					list2.AddRange(listDyanamic);
				}
			}
			
			{
				//get list from filterd config
				this.m_config.UpdateConfig(m_rowOffset, exp);
				ConfigData config = m_config.GetData();
				this.m_filteredConfig.SourceConfig = config;
				if (m_config.IsFilterable)
				{
					m_filteredConfig.UpdateConfig(m_rowOffset, exp);
					list2.AddRange(this.m_filteredConfig.GetDynamicFields(this.m_rowOffset, exp));

				}

			}

			return list2;
		}
		bool ShouldAllowConfigFields(int currRow, FieldExpression exp)
		{
			if(currRow - m_rowOffset <= 0) //its a first row
			{
				return true;			
			}

			if(currRow - m_rowOffset - 1 > 0) //there are more than one row for this config
			{
				string fieldName = exp.GetField(currRow - 1);
				ConfigFieldInfo fi = FindField(fieldName, exp);
				return (fi != null);
			}

			return true;
		}
		bool ShouldAllowOptionalFields(int currRow, FieldExpression exp)
		{
			ArrayList optional = GenericConfigEditor.GetFields(m_config, false, true);
			if(optional.Count > 0)
			{
				
			}
			return false;
		}

		public void UpdateConfig(int rowOffset, FieldExpression exp)
		{
			m_config.UpdateConfig(rowOffset, exp);
		}

		ConfigFieldInfo Find(string fieldName, ArrayList list)
		{
			if(fieldName != null && list != null)
			{
				foreach(object obj in list)
				{
					ConfigFieldInfo fi = obj as ConfigFieldInfo;
					if(fi != null && fi.Name == fieldName)
					{
						return fi;
					}
				}
			}
			return null;
		}

		public ConfigFieldInfo FindField(string fieldName, Expedia.Test.Framework.FieldExpression exp)
		{
			ConfigFieldInfo  fi = Find(fieldName,GenericConfigEditor.GetFields(m_config, true, true));
			if(fi == null)
			{
				ArrayList requiredFields = GenericConfigEditor.GetFields(m_config, true, false);
				if(requiredFields.Count <= exp.RowCount - m_rowOffset)
				{
					fi = Find(fieldName, m_config.GetDynamicFields(this.m_rowOffset, exp));					
				}

				if(fi == null)
				{
					//Get the fields from the filtered config
					this.m_config.UpdateConfig(m_rowOffset, exp);

					ConfigData config = m_config.GetData();
					this.m_filteredConfig.SourceConfig = config;
					if (m_config.IsFilterable)
					{
						m_filteredConfig.UpdateConfig(m_rowOffset, exp);

					}
					fi = this.m_filteredConfig.GetFieldInfo(fieldName, exp);
				}
			}

			return fi;
		}

		public System.Collections.ArrayList GetValues(string fieldName, Expedia.Test.Framework.FieldExpression exp)
		{
			//Get the values from the Filtered Config
			this.m_config.UpdateConfig(m_rowOffset, exp);

			ConfigData config = m_config.GetData();
			this.m_filteredConfig.SourceConfig = config;
//			this.m_filteredConfig.SourceConfig.ConfigTable = config.ConfigTable.Copy();

			if (m_config.IsFilterable)
			{
				m_filteredConfig.UpdateConfig(m_rowOffset, exp);

			}
				return this.m_filteredConfig.GetValues(fieldName, exp);

		
			//return new ArrayList();
		}

		public int RowOffset
		{
			get
			{
				return m_rowOffset;
			}
			set
			{
				m_rowOffset = value;
			}
		}

		int Row(int row)
		{
			return row - RowOffset;
		}

		public static ArrayList GetFields(object obj, bool includeRequired, bool includeOptional)
		{
			ArrayList list = new ArrayList();
			Type myType = obj.GetType();
			MemberInfo[] myMembers = myType.GetMembers(BindingFlags.GetField | BindingFlags.GetProperty | BindingFlags.Instance | BindingFlags.Public);

			for(int i = 0; i < myMembers.Length; i++)
			{
				if(myMembers[i].IsDefined(typeof(FieldInfoAttribute), false))
				{
					object[] myAttributes = myMembers[i].GetCustomAttributes(typeof(FieldInfoAttribute), false);
					if(myAttributes.GetLength(0) >= 1 && myAttributes[0] is FieldInfoAttribute)
					{
						ConfigFieldInfo info = ((FieldInfoAttribute) myAttributes[0]).Info;
						if(info.Required && includeRequired || !info.Required && includeOptional)
						{
							if(info.Name == null)
							{
								info.Name = myMembers[i].Name;
							}

							list.Add(info);
						}
					}
				}
			}
		
			return list;
		}


		public ConfigData GetData(FieldExpression exp)
		{
			this.m_config.UpdateConfig(m_rowOffset, exp);
			ConfigData config = this.m_config.GetData();

			ArrayList requiredFields = GenericConfigEditor.GetFields(m_config, true, false);

			if(this.m_config.IsFilterable && (exp.RowCount - m_rowOffset > requiredFields.Count ))
			{
				//this.m_config.UpdateConfig(m_rowOffset, exp);

				this.m_filteredConfig.SourceConfig = new ConfigData();
				this.m_filteredConfig.SourceConfig.Append(config);
			
				this.m_filteredConfig.UpdateConfig(m_rowOffset, exp);
				
				return this.m_filteredConfig.GetData();

			}
			return config;
		}

		public void InitConfigData(ConfigData data, FieldExpression exp)
		{
			this.m_config.UpdateConfig(m_rowOffset, exp);

			if (data !=null)
			{
				this.m_config.InitConfigData(data);
			}
		}

		public bool IsEditable()
		{
			return this.m_config.IsEditable;
		}
	}
}
