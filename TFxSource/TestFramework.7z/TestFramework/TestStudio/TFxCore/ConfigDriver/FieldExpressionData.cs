using System;
using System.Data;
using System.IO;
using System.Xml;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for FieldData.
	/// </summary>
	/// 

	[Serializable]
	public class FieldExpressionData
	{
		public string dataset;
		public string type;

		public FieldExpressionData()
		{
			
		}

		public FieldExpressionData(string data,string type,DataTable fieldDataTable)
		{
			this.dataset = data;
			this.type = type;
			UpdateDataSet(fieldDataTable);
			
		}

		void UpdateDataSet(DataTable fieldDataTable)
		{
			DataSet data = new DataSet();			
			data.Tables.Add(fieldDataTable.Copy());
			StringWriter sw = new StringWriter();
			XmlTextWriter xt = new XmlTextWriter( sw );
			data.WriteXml(xt,XmlWriteMode.IgnoreSchema);
			this.dataset = sw.ToString();		
			
		}

		public DataSet GetDataSet()
		{
			return this.GetDataSet(this.dataset);
		}

		public DataSet GetDataSet(string data)
		{
			DataSet ds = new DataSet();
			StringReader strReader = new StringReader(data);
			XmlTextReader reader = new XmlTextReader(strReader);
			ds.ReadXml(reader);
			return ds;
		}

		
	}
}
