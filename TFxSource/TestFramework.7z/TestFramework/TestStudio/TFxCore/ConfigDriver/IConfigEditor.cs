using System;
using System.Collections;
using System.Data;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ConfigEngin.
	/// </summary>
	public interface IConfigEditor
	{
		int RowOffset{get; set;}
		ArrayList GetFields(int currRow, FieldExpression exp);
		ConfigFieldInfo FindField(string fieldName, FieldExpression exp);
		ArrayList GetValues(string fieldName, FieldExpression exp);
		void UpdateConfig(int rowOffset, FieldExpression exp);
		void InitConfigData(ConfigData data, FieldExpression exp);
		bool IsEditable();
		ConfigData GetData(FieldExpression exp);
	}
}
