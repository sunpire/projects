using System;
using System.Collections;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ConfigFieldInfo.
	/// </summary>
	public class ConfigFieldInfo
	{
		public ConfigFieldInfo()
		{
		}

		public ConfigFieldInfo(string name, bool restricted, ArrayList operators)
		{
			this.Name = name;
			this.IsRestrictedToValueList = restricted;
			this.SupportedOperators = operators;
		}

		public ConfigFieldInfo(string name, bool restricted, string oper)
		{
			this.Name = name;
			this.IsRestrictedToValueList = restricted;
			this.SupportedOperators.Add(oper);
		}


		public bool m_isRestrictedToValueList = true;
		public virtual bool IsRestrictedToValueList
		{
			get
			{
				return m_isRestrictedToValueList;
			}
			set
			{
				m_isRestrictedToValueList = value;
			}
		}

		public string m_name;
		public virtual string Name
		{
			get
			{
				return m_name;
			}
			set
			{
				m_name = value;
			}
		}

		ArrayList m_supportedOperators = new ArrayList();
		public ArrayList SupportedOperators
		{
			get
			{
				return m_supportedOperators;
			}
			set
			{
				m_supportedOperators = value;
			}
		}

		public override string ToString()
		{
			return this.Name;
		}

		public bool Required = false;
		public bool IsDynamic = false;
		public bool IsSingular = true;
	}

	public class FieldInstance
	{
		public string Value;
		public string Operator;
		public string AndOr = "And";

		public FieldInstance()
		{
		}

		public FieldInstance(string val, string op) :this(val, op, "And")
		{
		}

		public FieldInstance(string val, string op, string andor)
		{
			Value = val;
			Operator = op;
			this.AndOr = andor;
		}
	}
}
