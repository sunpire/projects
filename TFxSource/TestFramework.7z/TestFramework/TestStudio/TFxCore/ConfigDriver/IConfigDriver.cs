using System;
using System.Collections;
using System.Data;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for IConfigDriver.
	/// </summary>
	public interface IConfigDriver
	{
		bool IsFilterable
		{
			get;
		}

		bool IsEditable
		{
			get;
		}
		ConfigData GetData();
		IConfigEditor Editor(int rowOffset);
		void UpdateConfig(int rowOffset, FieldExpression exp);
		void InitConfigData(ConfigData data);
		ArrayList GetDynamicFields(int rowOffset, FieldExpression exp);		
	}
}
