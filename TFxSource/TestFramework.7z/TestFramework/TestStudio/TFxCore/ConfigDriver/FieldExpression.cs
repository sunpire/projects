using System;
using System.Data;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for FieldExpression.
    /// </summary>
    /// 
    [Serializable]
    public class FieldExpression
    {
        [NonSerialized]
        DataTable m_expressionDataTable;
        public DataTable ExpressionDataTable
        {
            get
            {
                if (m_expressionDataTable == null)
                {
                    this.SetupDataTable();
                }
                return m_expressionDataTable;
            }
            set
            {
                m_expressionDataTable = value;

                //this.UpdateDataTable(value);
            }
        }

        public FieldExpression()
        {
        }

        const string c_FieldName = "FieldName";
        const string c_Operators = "Operators";
        const string c_Values = "Values";
        const string c_AndOr = "AndOr";
        void SetupDataTable()
        {
            this.m_expressionDataTable = new DataTable("Filter Properties");
            this.m_expressionDataTable.Columns.Add(c_FieldName, typeof(object));
            this.m_expressionDataTable.Columns.Add(c_Operators, typeof(object));
            this.m_expressionDataTable.Columns.Add(c_Values, typeof(object));
            this.m_expressionDataTable.Columns.Add(c_AndOr, typeof(object));
        }

        void UpdateDataTable(DataTable data)
        {
            //			if(data != null)
            {
                this.ExpressionDataTable.Clear();
                this.ExpressionDataTable.AcceptChanges();
                foreach (DataRow row in data.Rows)
                {
                    ExpressionDataTable.ImportRow(row);
                }
            }
        }

        public int RowCount
        {
            get
            {
                return ExpressionDataTable.Rows.Count;
            }
            set
            {
            }
        }

        string GetStringColumn(string name, int row)
        {
            if (row < this.RowCount && row < this.ExpressionDataTable.Rows.Count)
            {

                //ExpressionDataTable.AcceptChanges();

                //Make sure that the column actually exists
                foreach (DataColumn col in this.ExpressionDataTable.Columns)
                {
                    if (col.ColumnName.CompareTo(name) == 0)
                    {
                        if (this.ExpressionDataTable.Rows[row].RowState != DataRowState.Deleted)
                        {
                            object objVal = this.ExpressionDataTable.Rows[row][name];
                            string val = objVal as string;
                            if (val != null)
                            {
                                return (string)val;
                            }
                        }
                    }
                }

            }
            return string.Empty;
        }

        void SetStringColumn(string columnname, string name, int row)
        {
            //Need to add the row to the DataTable
            if (row == this.RowCount)
            {
                DataRow newRow = this.ExpressionDataTable.NewRow();
                this.ExpressionDataTable.Rows.InsertAt(newRow, row);
                this.ExpressionDataTable.AcceptChanges();
            }
            else if (row > this.RowCount)
            {
                return;
            }

            foreach (DataColumn col in this.ExpressionDataTable.Columns)
            {
                if (col.ColumnName.CompareTo(columnname) == 0)
                {
                    this.ExpressionDataTable.Rows[row][columnname] = name;
                    break;
                }
            }
        }

        public string GetField(int row)
        {
            return GetStringColumn(c_FieldName, row);
        }

        public void SetField(int row, string name)
        {
            SetStringColumn(c_FieldName, name, row);
        }

        public string GetOperator(int row)
        {
            return GetStringColumn(c_Operators, row);
        }

        public void SetOperator(int row, string name)
        {
            SetStringColumn(c_Operators, name, row);
        }

        public string GetValue(int row)
        {
            return GetStringColumn(c_Values, row);
        }

        public void SetValue(int row, string name)
        {
            SetStringColumn(c_Values, name, row);
        }

        public string GetAndOr(int row)
        {
            return GetStringColumn(c_AndOr, row);
        }

        public void SetAndOr(int row, string name)
        {
            SetStringColumn(c_AndOr, name, row);
        }

    }
}
