using System;
using System.Collections;
using System.Data;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ConfigEngin.
	/// </summary>
	public class ConfigEngin
	{
		public ConfigEngin()
		{

		}
		ArrayList list;
		public IConfigDriver[] Drivers
		{
			get
			{
				//TODO shoudl find out types dynamically and return types rather than objects
				if(list == null)
				{
					list = new ArrayList();
					//list.Add(new SiteConfig());
					//list.Add(new MultiConfig());
					list.Add(new ManualConfig());
					list.Add(new SQLConfigDriver());
				}
				return (IConfigDriver[]) list.ToArray(typeof(IConfigDriver));
			}
		}

		public ArrayList GetConfigNames()
		{
			ArrayList listDrivers = new ArrayList();
			foreach(IConfigDriver driver in this.Drivers)
			{
				listDrivers.Add(driver.ToString());
			}
			return listDrivers;
		}

		public IConfigDriver GetSelectedConfig(FieldExpression exp)
		{
			if(exp.RowCount >= 1)
			{
				foreach(IConfigDriver driver in this.Drivers)
				{
					if((string) exp.GetValue(0) == driver.ToString())
					{
						return driver;
					}
				}
			}
			return Drivers[0];
		}

		const string c_ConfigType = "ConfigType";
		static readonly ArrayList RowzeroFields = new ArrayList(new ConfigFieldInfo[]{ new ConfigFieldInfo( "ConfigType", true, "is")});
		public ArrayList GetFields(int currRow, FieldExpression exp)
		{
			if(currRow == 0)
			{
				return RowzeroFields;
			}

			IConfigDriver driver = GetSelectedConfig(exp);
			return driver.Editor(1).GetFields(currRow, exp);
		}

		public ConfigFieldInfo FindField(string fieldName, FieldExpression exp)
		{
			if(fieldName == c_ConfigType)
			{
				return RowzeroFields[0] as ConfigFieldInfo;
			}

			IConfigDriver driver = GetSelectedConfig(exp);
			return driver.Editor(1).FindField(fieldName, exp);
		}
 
		public ConfigData Evaluate(FieldExpression exp)
		{
			
			if(exp.RowCount > 1)
			{
				IConfigDriver driver = GetSelectedConfig(exp);
				driver.Editor(1).UpdateConfig(1, exp);
				//return driver.GetData();

				return driver.Editor(1).GetData(exp);				
				
			}	
		
			return null;
					
		}

		public ArrayList GetValues(string fieldName, FieldExpression exp)
		{
			if(fieldName == c_ConfigType)
			{
				return this.GetConfigNames();
			}
			IConfigDriver driver = GetSelectedConfig(exp);
			return driver.Editor(1).GetValues(fieldName, exp);			
		}

		public void InitConfigData(ConfigData data, FieldExpression exp)
		{

			if (data !=null && exp !=null)
			{
				IConfigDriver driver = GetSelectedConfig(exp);
				
				driver.Editor(1).InitConfigData(data, exp);
				
			}

		}

		public bool IsEditable(FieldExpression exp)
		{
			if(exp.RowCount > 1)
			{
				IConfigDriver driver = GetSelectedConfig(exp);
				return driver.Editor(1).IsEditable();				
			}	
		
			return false;
		}

	}
}
