using System;
using System.Collections;
using System.Data;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ManualConfig.
	/// </summary>
	public class ManualConfig : IConfigDriver
	{
		private ConfigData Config;
		private ArrayList m_columnValues;

		public ManualConfig()
		{
			m_columnValues = new ArrayList();
		}

		public bool IsFilterable
		{
			get
			{
				return false;
			}
		}

		public bool IsEditable
		{
			get
			{
				return true;
			}
		}

		public ArrayList ColumnValues
		{
			get
			{
				return m_columnValues;
			}
			set
			{
				m_columnValues = value;
			}
		}

		public IConfigEditor m_editor;
		public IConfigEditor Editor(int rowOffset)
		{
			if(m_editor == null)
			{
				m_editor = new GenericConfigEditor(this, rowOffset);
			}
			return m_editor;
		}


		public ArrayList GetOperators(string fieldName)
		{
			return m_fields;
		}
		public void SetField(string name, string val)
		{
		
		}

		public override  string ToString()
		{
			return "ManualConfig";
		}

		ArrayList m_fields = new ArrayList( );
		public ArrayList GetDynamicFields(int rowOffset, FieldExpression exp)
		{
			if(m_fields.Count < 1)
			{
				ConfigFieldInfo fi = new ConfigFieldInfo();
				fi.Name = "AddVairable";
				fi.SupportedOperators.Add("WithName");
				fi.IsRestrictedToValueList = false;
				m_fields.Add(fi);
			}
			return m_fields;
		}


		public void InitConfigData(ConfigData data)
		{
			
			if(this.Config == null)
			{
				this.Config = new ConfigData();
				this.Config.ConfigTable = new DataTable("Config");			
			}

			Config.ConfigTable.Rows.Clear();
			Config.ConfigTable.AcceptChanges();
			

			if (data !=null && data.ConfigTable !=null && data.ConfigTable.Rows.Count > 0)
			{
				foreach (DataRow row in data.ConfigTable.Rows)
				{
					this.Config.ConfigTable.ImportRow(row);							
				}

				this.Config.ConfigTable.AcceptChanges();
			}

		}

		void SyncConfigColumns(ArrayList varList)
		{

			if (this.Config !=null && this.Config.ConfigTable !=null && varList !=null)
			{

				
				ArrayList list = new ArrayList();

				foreach (DataColumn col in Config.ConfigTable.Columns)
				{
					if (!varList.Contains(col.ColumnName))
					{
						list.Add(col);
					}
				}

				foreach (DataColumn col in list)
				{	
					this.Config.ConfigTable.Columns.Remove(col);
				}


				this.Config.ConfigTable.AcceptChanges();

				if (this.Config.ConfigTable.Columns.Count == 0)
				{
					this.Config.ConfigTable.Rows.Clear();
				}
			
			}

		

		}


		public void UpdateConfig(int rowOffset, FieldExpression exp)
		{

			ArrayList varList = new ArrayList();
				
			if(exp.RowCount > 0)
			{
				for(int index = 0 ;index < exp.RowCount; index++)
				{
					switch(exp.GetField(index))
					{
						case "AddVairable":
							if(this.Config == null)
							{
								this.Config = new ConfigData();
								this.Config.ConfigTable = new DataTable("Config");
							}

							if(exp.GetValue(index) != "")
							{
								varList.Add(exp.GetValue(index));
								if(this.ColumnDoesNotExists(exp.GetValue(index)))
								{
									this.Config.ConfigTable.Columns.Add(exp.GetValue(index));
								}

							}							
							break;
						default:
							break;
					}
				}

				SyncConfigColumns(varList);

			}

		}	

		public ConfigData GetData()
		{
	//		ConfigData data = new Conf
			return Config;
		}

		

		private bool ColumnDoesNotExists(string str)

		{
			if(Config != null && Config.ConfigTable != null)
			{
				foreach(DataColumn col in Config.ConfigTable.Columns)
				{
					if(str.CompareTo(col.ColumnName) ==0)

						return false;
				}
			}

			return true;

		}
	}
}
