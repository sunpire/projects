using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for AppConfig.
	/// </summary>
	/// 

	public enum ApplicationMode
	{
		LabRun,
		TestPlayer
	}


	public class AppConfig
	{		
		public ApplicationMode Mode;	
		public bool DevMode = false;
		public AppConfig()
		{
			
		}
	}
}
