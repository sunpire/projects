//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: TFxUI.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//==========================================================================
using System;
using System.Collections;
using System.Threading;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TFxUI.
	/// </summary>
	public abstract class TFxUI : System.Windows.Forms.UserControl, ITFxUI
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

        public TFxUI()
        {
            AsyncNotificationHandler = new NotificationRequestHandler(this.NotifyUI);
            DataAsyncNotificationHandler = new DataNotificationRequestHandler(this.TempNotifyUI);

            InitializeComponent();
        }

        #region Data
        internal DataNotificationRequestHandler DataAsyncNotificationHandler;

		public abstract void GetData(RepositoryRequest request);

		public void GetDataAsync(RepositoryRequest request, NotificationRequestHandler handler)
		{
			DataWorker worker = new DataWorker(request, handler, this);
			worker.Start();
		}

		class DataWorker
		{
			TFxUI m_ui;
			RepositoryRequest m_request; 
			NotificationRequestHandler m_handler;

			public void Start()
			{
				System.Threading.Thread thread = new Thread(new ThreadStart(this.Run));
				thread.Start();
			}

			void Run()
			{
				m_ui.GetData(m_request);

				DataNotification notification = new DataNotification();
				notification.Request = m_request;
                try
                {
                    m_ui.Invoke(m_ui.DataAsyncNotificationHandler, new object[] { notification, m_handler });
                }
                catch (Exception)
                { 
                    //TODO: it sounds like ui is closing 
                }
			}


			public DataWorker(RepositoryRequest request, NotificationRequestHandler handler, TFxUI ui)
			{
				m_ui = ui;
				m_request = request;
				m_handler = handler;
			}
		}

		public void TempNotifyUI(NotificationRequest request, NotificationRequestHandler handler)
		{
			handler(request);
        }
        #endregion

        #region Component Designer generated code
        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
        }
        #endregion

        public abstract NotificationListener AddNotificationHandler(Type type, NotificationType notifyType, NotificationRequestHandler handler);
       	public abstract void RemoveNotificationHandler(Type type, NotificationRequestHandler handler);
		public abstract void NotifyUI(NotificationRequest request);

	
		private NotificationRequestHandler AsyncNotificationHandler;
			
		public IAsyncResult NotifyUIAsync(NotificationRequest request)
		{

			IAsyncResult result = this.BeginInvoke(this.AsyncNotificationHandler, new object[]{request});

			return result;
		}

        public virtual NotificationListener AddNotificationHandler(Type type, NotificationRequestHandler handler)
        {
            return this.AddNotificationHandler(type, NotificationType.Global, handler);
        }

		

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				
			}
			base.Dispose( disposing );
		}
    }
}
