using System;
using System.Collections;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections.Generic;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for TFxFileRepository.
    /// </summary>
    public class FileRepository : Repository
    {
        public class InitFileRepositoryRequest : RepositoryRequest
        {
            public string RootFolder;

            public InitFileRepositoryRequest(string rootFolder)
                : base(RepositoryRequestType.Get)
            {
                this.RootFolder = rootFolder;
            }
        }

        public string RootFolder;
        public FileRepository()
        {
        }

        public void ProcessRequest(InitFileRepositoryRequest request)
        {
            this.RootFolder = request.RootFolder;
            if (this.RootFolder.EndsWith("/"))
            {
                this.RootFolder = this.RootFolder.Substring(0, this.RootFolder.Length - 1);
            }

            if (this.RootFolder.EndsWith(@"\"))
            {
                this.RootFolder = this.RootFolder.Substring(0, this.RootFolder.Length - 1);
            }

            this.CheckRootFolder();
        }

        public void ProcessRequest(FilterRequest request)
        {
            switch (request.RequestType)
            {
                case RepositoryRequestType.Create:
                    if (request.Filter != null)
                    {
                        SaveObject(request.Filter, request.InstanceName, "TestCaseFilter");
                        request.Message = String.Format("Filter {0} has been saved successfully", request.InstanceName);
                    }
                    break;
                case RepositoryRequestType.Update:
                    if (request.Filter != null)
                    {
                        DeleteObject(request.InstanceName, "TestCaseFilter");
                        SaveObject(request.Filter, request.InstanceName, "TestCaseFilter");
                        request.Message = String.Format("Filter {0} has been updated successfully", request.InstanceName);
                    }
                    break;
                case RepositoryRequestType.Get:
                    request.Filter = (FieldExpressionData)GetObject(typeof(FieldExpressionData), request.InstanceName, "TestCaseFilter");
                    break;
                case RepositoryRequestType.Delete:
                    DeleteObject(request.InstanceName, "TestCaseFilter");
                    request.Message = String.Format("Filter {0} has been deleted successfully", request.InstanceName);
                    break;
            }
        }

        public void ProcessRequest(FilterListRequest request)
        {
            switch (request.RequestType)
            {
                case RepositoryRequestType.Get:
                    request.Objects = ListFileNames("TestCaseFilter");
                    break;
            }
        }

        public void ProcessRequest(ConfigRequest request)
        {
            switch (request.RequestType)
            {
                case RepositoryRequestType.Update:
                    if (request.Expression != null && request.ConfigData != null)
                    {
                        DeleteObject(request.InstanceName, "Config.xml");
                        SaveObject(request.ConfigExpression, request.InstanceName, "Config.xml");
                        request.Message = String.Format("Config {0} has been updated successfully", request.InstanceName);
                    }
                    break;

                case RepositoryRequestType.Create:
                    if (request.Expression != null && request.ConfigData != null)
                    {
                        SaveObject(request.ConfigExpression, request.InstanceName, "Config.xml");
                        request.Message = String.Format("Config {0} has been saved successfully", request.InstanceName);
                    }
                    break;

                case RepositoryRequestType.Get:
                    request.ConfigExpression = (ConfigExpressionData)GetObject(typeof(ConfigExpressionData), request.InstanceName, "Config.xml");
                    break;

                case RepositoryRequestType.Delete:
                    DeleteObject(request.InstanceName, "Config.xml");
                    request.Message = String.Format("Config {0} has been deleted successfully", request.InstanceName);
                    break;
            }
        }

        public void ProcessRequest(ConfigListRequest request)
        {
            switch (request.RequestType)
            {
                case RepositoryRequestType.Get:
                    request.Objects = ListFileNames("Config.xml");
                    break;
            }
        }

        public void ProcessRequest(ImportExportTestRunRequest request)
        {
            ProcessRequest(request as LabRunRequest);
        }

        public void ProcessRequest(LabRunRequest request)
        {
            switch (request.RequestType)
            {
                case RepositoryRequestType.Create:
                    this.SaveLabRun(request.LabRun.Name, request.LabRun);
                    request.Message = String.Format("Test Run {0} has been saved successfully", request.LabRun.Name);
                    break;

                case RepositoryRequestType.Update:
                    this.UpdateLabRun(request.LabRunName, request.LabRun);
                    request.Message = String.Format("Test Run {0} has been updated successfully", request.LabRunName);
                    break;

                case RepositoryRequestType.Get:

                    string path = GetFilePath(request.LabRunName, "labrun.xml");

                    if (!File.Exists(path))
                    {
                        path = request.HintFilePath;
                    }

                    if (!File.Exists(path))
                    {
                        return;
                    }

                    request.LabRun = this.GetLabRun(path);
                    break;
            }
        }

        public void ProcessRequest(UserSettingRequest request)
        {
            string filename = request.Mode.ToString() + "_UserSettingData";

            UsersSetting settings = new TestStudioUsersSetting();

            switch (request.RequestType)
            {
                case RepositoryRequestType.Update:
                    if (request.Settings != null)
                    {
                        DeleteObject(filename, "UserSettings.xml");
                        SaveObject(request.Settings, filename, "UserSettings.xml");
                    }
                    break;

                case RepositoryRequestType.Get:
                    request.Settings = (UsersSetting)GetObject(settings.GetType(), filename, "UserSettings.xml");
                    if (request.Settings == null)
                    {
                        request.Settings = settings;
                    }
                    break;

                case RepositoryRequestType.Delete:
                    DeleteObject(filename, "UserSettings.xml");
                    break;
            }
        }

        public void ProcessRequest(ProfileRequest request)
        {
            switch (request.RequestType)
            {
                case RepositoryRequestType.Create:
                    if (request.Profile != null)
                    {
                        SaveObject(request.Profile, request.ProfileName, "Profile.XML");
                    }
                    break;

                case RepositoryRequestType.Update:
                    if (request.Profile != null)
                    {
                        SaveObject(request.Profile, request.ProfileName, "Profile.XML");
                    }
                    break;

                case RepositoryRequestType.Get:
                    request.Profile = (Profile)GetObject(typeof(Profile), request.ProfileName, "Profile.XML");
                    break;
            }
        }

        public object GetObject(Type type, string instanceName)
        {
            return GetObject(type, instanceName, type.GetType().Name);
        }

        public object GetObject(Type type, string instanceName, string extention)
        {

            string[] tokens = instanceName.Split('.');
            if (tokens.Length > 1)
            {
                instanceName = tokens[0];
            }

            string filePath = GetFilePath(instanceName, extention);
            if (File.Exists(filePath))
            {
                XmlTextReader reader = null;
                try
                {
                    XmlSerializer serializer = new XmlSerializer(type);
                    reader = new System.Xml.XmlTextReader(filePath);
                    return serializer.Deserialize(reader);
                }
                finally
                {
                    if (reader != null)
                    {
                        reader.Close();
                    }
                }
            }
            return null;
        }

        public void SaveObject(object obj, string instanceName)
        {
            SaveObject(obj, instanceName, obj.GetType().Name);
        }

        public void SaveObject(object obj, string instanceName, string extention)
        {
            string filePath = GetFilePath(instanceName, extention);
            using (StreamWriter sw = new StreamWriter(filePath))
            {
                XmlSerializer serializer = new XmlSerializer(obj.GetType());
                XmlTextWriter doc = new XmlTextWriter(sw);
                serializer.Serialize(doc, obj);
            }
            //remove previously modified config which shouldn't be saved in config.xml
            var text = System.IO.File.ReadAllText(filePath);
            var rx = new System.Text.RegularExpressions.Regex(@"<diffgr:before>.+?</diffgr:before>");
            var newtext = rx.Replace(text, string.Empty);
            System.IO.File.WriteAllText(filePath, newtext);
        }

        public void DeleteObject(string instanceName, Type type)
        {
            DeleteObject(instanceName, type.Name);
        }
        public void DeleteObject(string instanceName, string extention)
        {
            File.Delete(this.GetFilePath(instanceName, extention));
        }
        string GetFilePath(string fileName, string extention)
        {
            return string.Concat(this.RootFolder, @"\", fileName, ".", extention);
        }

        public void CheckRootFolder()
        {
            if (!Directory.Exists(this.RootFolder))
            {
                Directory.CreateDirectory(this.RootFolder);
            }
        }

        public string[] ListFileNames(string extention)
        {

            DirectoryInfo di = new DirectoryInfo(this.RootFolder);
            FileInfo[] files = di.GetFiles(string.Format("*.{0}", extention));
            string[] fileNames = new string[files.GetLength(0)];
            for (int i = 0; i < files.GetLength(0); i++)
            {
                string[] tokens = files[i].Name.Split('.');
                fileNames[i] = tokens[0];
            }
            return fileNames;
        }

        private void Serialize(XmlTextWriter writer, LabRun labRun)
        {
            if (writer == null || labRun == null)
            {
                return;
            }

            writer.WriteStartElement("TestRun");
            writer.WriteAttributeString("testrunname", labRun.Name);
            writer.WriteAttributeString("managername", labRun.Manager.Name);
            writer.WriteAttributeString("branchName", ((labRun.Build == null) || (String.IsNullOrEmpty(labRun.Build.Name))) ? "" : labRun.Build.Name);
            writer.WriteAttributeString("version", "2.0");
            
            SerializeTestBuild(writer, labRun.Build);
            SerializeAssignments(writer, labRun.Assignments);

            writer.WriteEndElement();

            writer.Flush();
            writer.Close();
        }

        public void SaveTestBuild(TestBuild build, string buildName)
        {
            if (build != null && buildName != null)
            {
                this.SaveObject(build, buildName, "build.xml");
            }
        }

        private void SerializeTestBuild(XmlTextWriter writer, TestBuild build)
        {
            if (writer == null || build == null)
            {
                return;
            }

            foreach (TestBuildModule module in build.Modules)
            {
                SerializeTestBuildModule(writer, module);
            }
        }

        public void SerializeTestBuildModule(XmlTextWriter writer, TestBuildModule module)
        {
            if (writer == null || module == null)
            {
                return;
            }
        }

        private void SerializeAssignments(XmlTextWriter writer, AssignmentCollection assignments)
        {
            if (writer == null || assignments == null)
            {
                return;
            }

            writer.WriteStartElement("Assignments");

            foreach (Assignment assign in assignments)
            {
                SerializeAssignment(writer, assign);
            }

            writer.WriteEndElement();
        }

        private void SerializeAssignment(XmlTextWriter writer, Assignment assignment)
        {
            if (writer == null || assignment == null)
            {
                return;
            }

            writer.WriteStartElement("Assignment");

            writer.WriteAttributeString("id", assignment.AssignmentId.ToString());
            writer.WriteAttributeString("Disabled", assignment.Disabled.ToString());

            writer.WriteStartElement("SoftTest");
            {
                //
                // If there is no SoftTestId or SoftTest name associated with the current test.
                // We will treat its method name as the SoftTest name, but still leave the SoftTestId
                // empty.
                //
                if ((assignment.TestCase.SoftTestId < 1) || (String.IsNullOrEmpty(assignment.TestCase.SoftTestName)))
                {
                    writer.WriteAttributeString("id", "");
                    writer.WriteAttributeString("name", assignment.TestCase.FullName);
                }
                else
                {
                    writer.WriteAttributeString("id", Convert.ToString(assignment.TestCase.SoftTestId));
                    writer.WriteAttributeString("name", assignment.TestCase.SoftTestName);
                }

                // serialize the test configs
                writer.WriteStartElement("TestConfigs");
                {
                    foreach (string key in assignment.TestCase.TestConfigs.Keys)
                    {
                        writer.WriteStartElement("TestConfig");
                        writer.WriteAttributeString("name", key);
                        writer.WriteAttributeString("value", assignment.TestCase.TestConfigs[key] == null? string.Empty : assignment.TestCase.TestConfigs[key].ToString());
                        writer.WriteEndElement();
                    } // foreach
                }
                writer.WriteEndElement();

                // serialize the method
                writer.WriteStartElement("Methods");
                {
                    writer.WriteStartElement("Method");
                    {
                        writer.WriteAttributeString("name", assignment.TestCase.FullName);
                        writer.WriteAttributeString("module", assignment.TestCase.Module.DllFullName);

                        writer.WriteStartElement("Parameters");
                        {
                            foreach (string key in assignment.TestCase.Parameters.Keys)
                            {
                                writer.WriteStartElement("Parameter");
                                writer.WriteAttributeString("name", key);
                                writer.WriteAttributeString("value", assignment.TestCase.Parameters[key]);
                                writer.WriteEndElement();
                            } // foreach
                        }
                        writer.WriteEndElement();
                    }
                    writer.WriteEndElement();
                }
                writer.WriteEndElement();
            }
            writer.WriteEndElement();

            SerializeAssignmentResult(writer, assignment.Result);

            SerializeConfigData(writer, assignment.ConfigData);

            writer.WriteEndElement();
        }

        private void SerializeAssignmentResult(XmlTextWriter writer, AssignmentResult result)
        {
            XmlSerializer resultSerizlizer = new XmlSerializer(typeof(AssignmentResult));
            resultSerizlizer.Serialize(writer, result);
        }

        private void DeSerializeAssignmentResult(XmlReader reader, Assignment assignment)
        {
            XmlSerializer resultSerizlizer = new XmlSerializer(typeof(AssignmentResult));
            object result = resultSerizlizer.Deserialize(reader);
            assignment.Result = result as AssignmentResult;
        }

        private void SerializeConfigData(XmlTextWriter writer, ConfigData configData)
        {
            if (writer == null || configData == null)
            {
                return;
            }

            writer.WriteStartElement("Configs");

            foreach (IConfig config in configData.GetAllConfigs())
            {
                SerializeIConfig(writer, config);
            }

            writer.WriteEndElement();
        }

        private void SerializeIConfig(XmlTextWriter writer, IConfig config)
        {
            StringConfig strConfig = (StringConfig)config;

            if (writer == null || config == null)
            {
                return;
            }

            foreach (object keys in strConfig.Config.Keys)
            {
                if (!TFxConst.IsSystemVar(keys.ToString()))
                {
                    SerializeVar(writer, keys.ToString(), strConfig.Config[keys].ToString());
                }
                else if (String.Equals(keys, "__releaseinfo"))
                {
                    SerializeVar(writer, keys.ToString(), strConfig.Config[keys].ToString());
                }
            }

        }

        private void SerializeVar(XmlTextWriter writer, string variableName, string variableValue)
        {
            if (writer == null)
            {
                return;
            }

            writer.WriteStartElement("Var");
            writer.WriteAttributeString("varName", variableName);
            writer.WriteAttributeString("varValue", variableValue);
            writer.WriteEndElement();
        }

        private LabRun DeSerialize(XmlTextReader reader)
        {
            Assignment assignment = null;
            ArrayList Configs = null;
            StringConfig strConfig = null;
            LabRun run = new LabRun();
            ArrayList modules = new ArrayList();
            TestBuild testBuild = new TestBuild();
            LabRun labRun = new LabRun();
            int softTestId = 0;
            string softTestName = null;
            Dictionary<string, string> testConfigs = new Dictionary<string, string>();
            bool skipRead = false;
            if (reader == null)
            {
                return null;
            }

            while (skipRead || reader.Read())
            {
                skipRead = false;
                if (reader.IsStartElement())
                {
                    switch (reader.Name)
                    {
                        case ("TestRun"):
                            labRun.Manager = new TFxUser();
                            labRun.Manager.Name = reader.GetAttribute("managername");
                            labRun.Assignments = new AssignmentCollection();
                            string version = reader.GetAttribute("version");
                            labRun.Version = new Version((String.IsNullOrEmpty(version)) ? "1.0" : version);

                            testBuild.Name = reader.GetAttribute("branchName");
                            labRun.Build = testBuild;
                            run.Build = labRun.Build;

                            break;

                        case ("TestBuild"):
                            DeSerializeTestBuild(reader, testBuild);
                            labRun.Build = testBuild;
                            run.Build = labRun.Build;
                            break;

                        case ("Assignments"):
                            assignment = new Assignment();
                            break;

                        case ("Assignment"):
                            DeSerializeAssignment(reader, assignment, labRun.Version);
                            break;

                        case ("SoftTest"):
                            // This element only exists in version 2 xml file
                            softTestId = String.IsNullOrEmpty(reader.GetAttribute("id")) ? -1 : Convert.ToInt32(reader.GetAttribute("id"));
                            softTestName = reader.GetAttribute("name");
                            break;

                        case ("Method"):
                            // This element only exists in version 2 xml file
                            DeSerializeMethod(reader, assignment, softTestId, softTestName);

                            foreach (KeyValuePair<string, string> item in testConfigs)
                            {
                                assignment.TestCase.TestConfigs.Add(item.Key, item.Value);
                            }

                            DeSerializeTestBuildModule(reader, modules);
                            break;

                        case ("Parameter"):
                            // This element only exists in version 2 xml file
                            DeSerializeParameter(reader, assignment);
                            break;

                        case ("TestConfig"):
                            // This element only exists in version 2 xml file
                            DeSerializeTestConfig(reader, testConfigs);
                            break;

                        case ("Configs"):
                            Configs = new ArrayList();
                            strConfig = new StringConfig();
                            break;

                        case ("Var"):
                            DeSerializeIConfig(reader, (IConfig)strConfig);
                            break;
                        case ("AssignmentResult"):
                            DeSerializeAssignmentResult(reader, assignment);
                            skipRead = true;//as deserializer would be at next element already
                            break;
                    }
                }
                else if (!reader.IsStartElement())
                {
                    switch (reader.Name)
                    {
                        case ("Assignment"):
                            assignment.LabRun = run;
                            labRun.Assignments.Add(assignment);
                            assignment = new Assignment();
                            testConfigs.Clear();
                            break;

                        case ("Configs"):
                            Configs.Add(strConfig);
                            
                            assignment.ConfigData.m_config = (IConfig[])Configs.ToArray(typeof(IConfig));
                            assignment.ConfigData.ConfigTable = BuildDataTable(assignment.ConfigData.m_config);
                            labRun.Build.Modules = (TestBuildModule[])modules.ToArray(typeof(TestBuildModule));
                            break;
                    }
                }
            }

            // Add the build name information
            if (labRun.Assignments != null && labRun.Assignments.Count > 0)
            {
                foreach (Assignment item in labRun.Assignments)
                {
                    if (item.TestCase != null)
                    {
                        // Add branch info
                        if (!item.TestCase.TestConfigs.ContainsKey("__releaseinfo"))
                        {
                            item.TestCase.TestConfigs.Add("__releaseinfo", 
                                string.Equals("default", labRun.Build.Name, StringComparison.CurrentCultureIgnoreCase)
                                    ? "main" :labRun.Build.Name);
                        }

                        //Add test namespace info
                        //Use SoftTestName as namespace to get softtest test data at the same time
                        if (!string.IsNullOrEmpty(item.TestCase.SoftTestName))
                        {
                            item.TestCase.TestConfigs["__testnamespace"] = item.TestCase.SoftTestName.Replace("Expedia.Automation.Test.", string.Empty);
                        }
                    }
                }
            }

            return labRun;
        }

        public TestBuild GetTestBuild(string buildName)
        {
            if (buildName != null)
            {
                object build = GetObject(typeof(TestBuild), buildName, "build.xml");
                return build as TestBuild;
            }

            return null;
        }

        private void DeSerializeTestBuild(XmlTextReader reader, TestBuild testBuild)
        {
            if (reader == null)
            {
                return;
            }

            testBuild.Name = reader.GetAttribute("name");
        }

        private void DeSerializeTestBuildModule(XmlTextReader reader, ArrayList moduleList)
        {
            if (reader == null || moduleList == null)
            {
                return;
            }

            ExecuteTestModule module = new ExecuteTestModule(reader.GetAttribute("module"));
            moduleList.Add(module);
        }

        private void DeSerializeMethod(XmlTextReader reader, Assignment assignment, int softTestId, string softTestName)
        {
            if (reader == null || assignment == null)
            {
                return;
            }
            assignment.TestCase = new TestCase(null, reader.GetAttribute("name"));
            assignment.TestCase.SoftTestId = softTestId;
            assignment.TestCase.SoftTestName = softTestName;

            // set the module
            ExecuteTestModule module = new ExecuteTestModule(reader.GetAttribute("module"));
            assignment.TestCase.Module = module;
        }

        private void DeSerializeTestConfig(XmlTextReader reader, Dictionary<string, string> testConfigs)
        {
            if (reader == null)
            {
                return;
            }

            testConfigs.Add(reader.GetAttribute("name"), reader.GetAttribute("value"));
        }

        private void DeSerializeParameter(XmlTextReader reader, Assignment assignment)
        {
            if (reader == null || assignment == null)
            {
                return;
            }

            assignment.TestCase.Parameters.Add(reader.GetAttribute("name"), reader.GetAttribute("value"));
        }

        private void DeSerializeAssignment(XmlTextReader reader, Assignment assignment, Version version)
        {
            if (reader == null || assignment == null)
            {
                return;
            }

            assignment.AssignmentId = Convert.ToInt32(reader.GetAttribute("id"));
            assignment.Disabled = Convert.ToBoolean(reader.GetAttribute("Disabled"));
            switch (version.Major)
            {
                case 2:
                    assignment.TestCase = new TestCase(null, reader.GetAttribute("methodName"));
                    assignment.TestCase.SoftTestId = Convert.ToInt32(reader.GetAttribute("softTestId"));
                    assignment.TestCase.SoftTestName = reader.GetAttribute("softTestName");
                    break;
                case 1:
                default:
                    assignment.TestCase = new TestCase(null, reader.GetAttribute("testName"));
                    ExecuteTestModule module = new ExecuteTestModule(reader.GetAttribute("module"));
                    assignment.TestCase.Module = module;
                    break;
            } // switch
            

            assignment.ConfigData = new ConfigData();

        }

        private void DeSerializeIConfig(XmlTextReader reader, IConfig config)
        {
            StringConfig strConfig = (StringConfig)config;

            if (reader == null || config == null)
            {
                return;
            }

            if (!strConfig.Config.Contains(reader.GetAttribute("varName")))
            {
                strConfig.Config.Add(reader.GetAttribute("varName"), reader.GetAttribute("varValue"));
            }
        }

        private DataTable BuildDataTable(IConfig[] configs)
        {
            if (configs == null || configs.Length == 0)
            {
                return null;
            }

            DataTable dt = new DataTable();
            StringConfig strConfig = (StringConfig)configs[0];
            DataRow dr = null;           

            //Create the columns
            foreach (object keys in strConfig.Config.Keys)
            {
                dt.Columns.Add(keys.ToString());
            }

            foreach (IConfig config in configs)
            {
                strConfig = (StringConfig)config;

                dr = dt.NewRow();

                foreach (object keys in strConfig.Config.Keys)
                {
                    dr[keys.ToString()] = strConfig.Config[keys];
                }

                dt.Rows.Add(dr);
            }

            dt.AcceptChanges();
            return dt;
        }

        private void SaveLabRun(string labRunName, LabRun labRun)
        {
            string fileName = "";

            if (labRun != null && labRunName != "")
            {
                fileName = GetFilePath(labRunName, "labrun.xml");
                StreamWriter stream = new StreamWriter(fileName);
                XmlTextWriter writer = new XmlTextWriter(stream);
                writer.WriteStartDocument(true);
                Serialize(writer, labRun);
            }
        }

        private void UpdateLabRun(string labRunName, LabRun labRun)
        {
            string fileName = "";

            if (labRun != null && !string.IsNullOrEmpty(labRunName))
            {
                fileName = GetFilePath(labRunName, "labrun.xml");
                StreamWriter stream = new StreamWriter(fileName);
                XmlTextWriter writer = new XmlTextWriter(stream);
                writer.WriteStartDocument(true);
                Serialize(writer, labRun);
            }
        }

        private LabRun GetLabRun(string labRunPath)
        {
            if (!File.Exists(labRunPath))
            {
                return null;
            }

            LabRun labRun = null;

            XmlTextReader reader = null;
            try
            {
                reader = new XmlTextReader(labRunPath);
                labRun = DeSerialize(reader);
                reader.Close();
            }
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                }
            }


            return labRun;
        }
    }
}
