//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: RepositoryDelegateUI.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//==========================================================================
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
	

	public delegate void NotificationRequestHandler(NotificationRequest request);
	public delegate void DataNotificationRequestHandler(NotificationRequest request, NotificationRequestHandler handler);

	/// <summary>
	/// Summary description for RepositoryDelegateUI.
	/// </summary>
	public class RepositoryDelegateUI : TFxUI
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;


		public RepositoryDelegateUI()
		{
			InitializeComponent();
		}

        public override NotificationListener AddNotificationHandler(Type type, NotificationType notifyType, NotificationRequestHandler handler)
        {
            TFxUI ui = this.GetTFxUIParent(this);
            if (ui != null)
            {
                return ui.AddNotificationHandler(type, notifyType, handler);
            }
            return null;
        }

        public override void RemoveNotificationHandler(Type type, NotificationRequestHandler handler)
        {
            TFxUI ui = this.GetTFxUIParent(this);
            if (ui != null)
            {
                ui.RemoveNotificationHandler(type, handler);
            }
        }

        public override void NotifyUI(NotificationRequest request)
        {
            TFxUI ui = this.GetTFxUIParent(this);
            if (ui != null)
            {
                ui.NotifyUI(request);
            }
        }

		public override void GetData(RepositoryRequest request)
		{
			TFxUI ui = this.GetTFxUIParent(this);
			if(ui != null)
			{
				ui.GetData(request);
			}
		}

		public TFxUI GetTFxUIParent(Control currentControl)
		{
			Control parent = currentControl.Parent;

			if(parent == null)
			{
				//throw new Exception("Could not find a TFxUI parent for this control!");
				return null;
			}
			else
			{
				if(parent is TFxUI)
				{
					return (TFxUI)parent;
				}
				else
				{
					return this.GetTFxUIParent(parent);
				}
			}
			
		}

		public virtual void PersistUIState()
		{

		}

		public virtual void PersistUIState(Profile profile)
		{
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}
		#endregion


    }
}
