using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TestRunEditorUI.
	/// </summary>
	/// 

	[Serializable]
	public class TestRunEditorUI : GenericEditorUI
	{
		public SplitterState splitterConfigPicker;
		public SplitterState splitterSelector;
		public SplitterState splitterAssignmentEditorBottom;
		public SplitterState splitterResultRight;

		public TestRunEditorUI()
		{
			
		}
	}
}
