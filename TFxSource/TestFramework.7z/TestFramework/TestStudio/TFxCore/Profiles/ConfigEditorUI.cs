using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ConfigEditorUI.
	/// </summary>
	/// 

	[Serializable]
	public class ConfigEditorUI : GenericEditorUI
	{
		public SplitterState configSplitter;
		public ConfigEditorUI()
		{
			
		}
	}
}
