using System;
using System.Data;
using System.Collections;
using System.ComponentModel;
using System.Drawing;

using System.Windows.Forms;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for SplitterState.
	/// </summary>
	/// 

	[Serializable]
	public class SplitterState
	{
		public Size ControlToHideSize;
		public bool isCollapsed;	
		public Point splitterLocation;


		public SplitterState()
		{
			
		}

		public SplitterState(System.Windows.Forms.Splitter splitter)
		{
			this.ControlToHideSize = splitter.Size;
			this.splitterLocation = splitter.Location;
			
		}

		public SplitterState(System.Windows.Forms.Control control)
		{
			this.ControlToHideSize = control.Size;
			this.splitterLocation = control.Location;
			
		}
		public SplitterState(Size ControltoHideSize, bool isCollapsed)
		{
			this.ControlToHideSize = ControltoHideSize;
			this.isCollapsed = isCollapsed;
			
		}
	}
}
