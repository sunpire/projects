using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for FilterEditorUI.
	/// </summary>
	/// 

	[Serializable]
	public class FilterEditorUI : GenericEditorUI
	{
		public FilterEditorUI() 
		{
			
		}
	}
}
