using System;
using System.Drawing;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TestStudioUI.
	/// </summary>
	/// 
	
	[Serializable]
	public class TestStudioUI
	{
		public System.Drawing.Rectangle WindowSize;
		public string SelectedTab;		 

		public TestStudioUI()
		{
			
		}
		public TestStudioUI(Rectangle WindowSize)
		{
			this.WindowSize = WindowSize;
		}
	}
}
