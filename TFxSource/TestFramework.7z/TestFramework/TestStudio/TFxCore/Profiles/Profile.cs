using System;
using System.Xml.Serialization;
using System.Collections;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for Profile.
	/// </summary>
	/// 
	public enum UIStateMode
	{
		Executing,
		Editing
	}

	[Serializable]
	public class Profile
	{
		public string Name;

		[System.Xml.Serialization.XmlArray("Editors")]
		[System.Xml.Serialization.XmlArrayItem("EditorType",typeof(string))]
		public ArrayList Controls;

		public UIStateMode TestRunEditorCurrentState;
		public TestStudioUI TestStudioSettings;
		public TestRunEditorUI TestRunEditingSettings;
		public TestRunEditorUI TestRunExecutingSettings;
		public ConfigEditorUI ConfigSettings;
		public FilterEditorUI FilterSettings;

		public Profile()
		{
			Controls = new ArrayList();
			TestStudioSettings = new TestStudioUI();
			TestRunEditingSettings = new TestRunEditorUI();
			TestRunExecutingSettings = new TestRunEditorUI();
			ConfigSettings = new ConfigEditorUI();
			FilterSettings = new FilterEditorUI();
			TestRunEditorCurrentState = new UIStateMode();
		}	
	}
}
