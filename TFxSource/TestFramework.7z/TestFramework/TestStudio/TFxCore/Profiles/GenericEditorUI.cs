using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for GenericEditorUI.
	/// </summary>
	/// 

	[Serializable]
	public class GenericEditorUI
	{
		public SplitterState splitterLeft;

		public GenericEditorUI()
		{
			
		}		
	}
}
