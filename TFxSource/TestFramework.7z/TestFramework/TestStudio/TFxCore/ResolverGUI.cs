//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: ResolverGUI.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using Expedia.Test.Framework;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for ResolverGUI.
    /// </summary>
    public class ResolverGUI : System.Windows.Forms.Form, IResolver
    {
        private enum AutoUpdateAction
        {
            Add,
            Delete,
            UpdateCategory
        }

        private ArrayList m_testCases1 = null;
        private ArrayList m_testCases2 = null;
        private ArrayList m_commonList = null;
        private ArrayList m_addList = null;
        private ArrayList m_deleteList = null;
        private ArrayList m_moveList = null;
        private ArrayList m_modifiedList = null;

        private ImageList images = null;
        private SelectableTreeView treeView1;
        private SelectableTreeView treeView2;
        private SelectableTreeView resolvedTreeView;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ToolBar toolBar;
        private System.Windows.Forms.ToolBarButton toolBarAddAllButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ToolBarButton toolBarDeleteAllButton;
        private System.Windows.Forms.ToolBarButton toolBarUpdateAllButton;
        private System.Windows.Forms.ToolBarButton toolBarAddButton;
        private System.Windows.Forms.ToolBarButton toolBarDeleteButton;
        private System.Windows.Forms.ToolBarButton toolBarMoveButton;
        private System.Windows.Forms.ToolBarButton toolBarUndoButton;
        private System.Windows.Forms.ToolBarButton toolBarSeparator;
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;

        public ResolverGUI()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            System.Resources.ResourceManager rm = new System.Resources.ResourceManager("Expedia.Test.Framework.ResolverGUI", this.GetType().Assembly);
            this.images = new ImageList();
            this.images.ColorDepth = ColorDepth.Depth8Bit;
            this.images.ImageSize = new Size(32, 32);
            this.images.Images.Add((Image)rm.GetObject("Add.gif"));
            this.images.Images.Add((Image)rm.GetObject("Delete.gif"));
            this.images.Images.Add((Image)rm.GetObject("Move.gif"));
            this.images.Images.Add((Image)rm.GetObject("Undo.gif"));
            this.images.Images.Add((Image)rm.GetObject("AddAll.gif"));
            this.images.Images.Add((Image)rm.GetObject("DeleteAll.gif"));
            this.images.Images.Add((Image)rm.GetObject("MoveAll.gif"));
            this.toolBar.ImageList = this.images;
            this.form_Resize(null, null);
        }

        /// <summary>
        /// Title of the tree on the left side.
        /// </summary>
        public string TreeLabel1
        {
            get
            {
                return this.groupBox1.Text;
            }
            set
            {
                this.groupBox1.Text = value;
            }
        }

        /// <summary>
        /// Title of the tree in the middle.
        /// </summary>
        public string TreeLabel2
        {
            get
            {
                return this.groupBox2.Text;
            }
            set
            {
                this.groupBox2.Text = value;
            }
        }

        private string appendCategoriesToName(string testName, long testCategories)
        {
            if (testCategories > 0)
            {
                string[] categories = getTestCategoryString(testCategories);

                if (categories.Length > 0)
                {
                    testName += " [";
                    foreach (string category in categories)
                    {
                        testName += category + ", ";
                    }
                    testName = testName.Substring(0, testName.Length - 2) + ']';
                }
            }

            return testName;
        }

        private TestCategoryType[] getTestCategoryEnums(long bitMask)
        {
            ArrayList a = new ArrayList();

            foreach (long category in Enum.GetValues(typeof(TestCategoryType)))
            {
                if ((category & bitMask) != 0)
                {
                    a.Add((TestCategoryType)category);
                }
            }

            return (TestCategoryType[])a.ToArray(typeof(TestCategoryType));
        }

        private string[] getTestCategoryString(long bitMask)
        {
            ArrayList a = new ArrayList();

            foreach (TestCategoryType category in getTestCategoryEnums(bitMask))
            {
                a.Add(category.ToString());
            }

            return (string[])a.ToArray(typeof(string));
        }

        /// <summary>
        /// This method is the main entry point into this resolver class.
        /// </summary>
        /// <param name="diffObject">Difference object to be resolved.</param>
        /// <returns>true if changes were applied to the diffObject, false if the user canceled.</returns>
        public bool Resolve(TestPublish diffObject)
        {
            ArrayList differences = diffObject.Differences.Differences;

            // Initialize lists of nodes
            this.m_addList = new ArrayList();
            this.m_deleteList = new ArrayList();
            this.m_moveList = new ArrayList();
            this.m_modifiedList = new ArrayList();

            // Set up the form
            this.InitializeTrees(differences);
            this.UpdateButtons();

            // Show the form
            if (this.ShowDialog() == DialogResult.OK)
            {
                // Apply changes
                this.ApplyTestChanges(diffObject);
                return true;
            }
            else
            {
                // No changes to be applied
                return false;
            }
        }

        private void InitializeTrees(ArrayList differences)
        {
            this.m_testCases1 = new ArrayList();
            this.m_testCases2 = new ArrayList();
            this.m_commonList = new ArrayList();

            foreach (TestCaseDifference diff in differences)
            {
                switch (diff.DifferenceType)
                {
                    case TestCaseDifferenceType.NoDifference:
                    case TestCaseDifferenceType.Rename:
                        this.m_commonList.Add(diff.TestCase1);
                        break;
                    case TestCaseDifferenceType.OwnerDifference:
                        this.m_testCases1.Add(diff.TestCase1);
                        this.m_testCases2.Add(diff.TestCase2);
                        break;
                    case TestCaseDifferenceType.CategoryDifference:
                        this.m_testCases1.Add(diff.TestCase1);
                        this.m_testCases2.Add(diff.TestCase2);
                        break;
                    case TestCaseDifferenceType.NoMatchFound:
                        if (diff.TestCase1 != null)
                        {
                            this.m_testCases1.Add(diff.TestCase1);
                        }
                        else if (diff.TestCase2 != null)
                        {
                            this.m_testCases2.Add(diff.TestCase2);
                        }
                        break;
                }
            }

            this.InitializeTree(this.m_testCases1, this.treeView1, Color.Red);
            this.InitializeTree(this.m_testCases2, this.treeView2, Color.Red);
            this.InitializeTree(this.m_commonList, this.resolvedTreeView, Color.Blue);
        }

        private void InitializeTree(ArrayList list, TreeView tree, Color color)
        {
            tree.KeyPress += new System.Windows.Forms.KeyPressEventHandler(form_KeyPress);

            foreach (TestCase testCase in list)
            {
                string[] tokens = this.appendCategoriesToName(testCase.FullName, testCase.TestCategory).Split('.');

                if (tree.Nodes.Count == 0)
                {
                    TreeNode newNode = new TreeNode(tokens[0]);
                    tree.Nodes.Add(newNode);
                }

                CreateNode(tree.Nodes[0], tokens, 1, color, testCase);
            }

            tree.ExpandAll();
        }

        private void CreateNode(TreeNode node, string[] tokens, int level, Color color, object tag)
        {
            TreeNode matchNode = null;
            if (level == tokens.Length)
            {
                node.ForeColor = color;
                node.Tag = tag;
                return;
            }

            foreach (TreeNode childNode in node.Nodes)
            {
                if (childNode.Text == tokens[level])
                {
                    matchNode = childNode;
                    break;
                }
            }

            if (matchNode == null)
            {
                TreeNode newNode = new TreeNode(tokens[level]);
                node.Nodes.Add(newNode);
                matchNode = newNode;
            }

            CreateNode(matchNode, tokens, level + 1, color, tag);
        }

        private void AddToResolvedTree(TreeNode node)
        {
            string[] tokens = node.FullPath.Split('\\');

            if (this.resolvedTreeView.Nodes.Count == 0)
            {
                TreeNode newNode = new TreeNode(tokens[0]);
                this.resolvedTreeView.Nodes.Add(newNode);
            }

            CreateNode(this.resolvedTreeView.Nodes[0], tokens, 1, node.ForeColor, node.Tag);
            this.resolvedTreeView.ExpandAll();
        }

        private void RemoveFromResolvedTree(TreeNode node)
        {
            string[] tokens = node.FullPath.Split('\\');
            TreeNode matchNode = this.resolvedTreeView.Nodes[0];
            int level = 1;

            // Find the matching node in common tree
            while (matchNode != null)
            {
                int index;
                TreeNode matchNode2 = null;
                for (index = 0; index < matchNode.Nodes.Count; index++)
                {
                    if (matchNode.Nodes[index].Text == tokens[level])
                    {
                        matchNode2 = matchNode.Nodes[index];
                        level++;
                        break;
                    }
                }

                // Can't find that node in  common tree view
                if (matchNode2 == null)
                {
                    return;
                }

                matchNode = matchNode2;
                if (level == tokens.Length)
                {
                    break;
                }
            }

            TreeNode parentNode = matchNode.Parent;
            matchNode.Remove();
            while (parentNode != null && parentNode.Nodes.Count == 0)
            {
                TreeNode temp = parentNode.Parent;
                parentNode.Remove();
                parentNode = temp;
            }
        }

        private void ApplyTestChanges(TestPublish diffObject)
        {
            ArrayList changes = new ArrayList();

            foreach (TreeNode node in this.m_addList)
            {
                TestCase testCase = node.Tag as TestCase;
                if (testCase != null)
                {
                    //changes.Add(new TestCaseChangeAdd(testCase, true, testCase.TestModule));
                    changes.Add(new TestCaseChange(RepositoryRequestType.Create, testCase));
                }
            }

            foreach (TreeNode node in this.m_deleteList)
            {
                TestCase testCase = node.Tag as TestCase;
                if (testCase != null)
                {
                    //changes.Add(new TestCaseChangeDelete(testCase));
                    changes.Add(new TestCaseChange(RepositoryRequestType.Delete, testCase));
                }
            }

            foreach (TreeNode[] list in this.m_moveList)
            {
                TestCase testCase1 = list[0].Tag as TestCase;
                TestCase testCase2 = list[1].Tag as TestCase;
                if (testCase1 != null && testCase2 != null)
                {
                    //changes.Add(new TestCaseChangeMove(testCase2, testCase1));
                    changes.Add(new TestCaseChange(testCase2, testCase1));
                }
            }

            foreach (TestCaseChange change in changes)
            {
                diffObject.AddChange(change);
            }
        }

        private void MarkAdd(TreeNode node)
        {
            if (!this.m_addList.Contains(node))
            {
                node.Text = "<ADD>" + node.Text;
                node.ForeColor = Color.Green;
                this.m_addList.Add(node);
                this.m_modifiedList.Add(node);
            }
        }

        private void MarkDelete(TreeNode node)
        {
            if (!this.m_deleteList.Contains(node))
            {
                node.Text = "<DELETE>" + node.Text;
                node.ForeColor = Color.Blue;
                this.m_deleteList.Add(node);
                this.m_modifiedList.Add(node);
            }
        }

        private void MarkMove(TreeNode node1, TreeNode node2)
        {
            TreeNode[] list = new TreeNode[2] { node1, node2 };
            if (!this.m_moveList.Contains(list))
            {
                string temp = node2.Text;
                node2.Text = "<MOVE FROM " + node1.Text + ">" + node2.Text;
                node1.Text = "<MOVE TO " + temp + ">" + node1.Text;
                node2.ForeColor = Color.Chocolate;
                node1.ForeColor = Color.Chocolate;
                this.m_moveList.Add(list);
                this.m_modifiedList.Add(node1);
                this.m_modifiedList.Add(node2);
            }
        }

        private void MarkUndo(TreeNode node1, TreeNode node2)
        {
            // Undo a MarkAdd
            if (node1 != null && node2 == null && this.m_addList.Contains(node1))
            {
                // Remove the node from respective trees and lists
                RemoveFromResolvedTree(node1);
                this.m_addList.Remove(node1);
                this.m_modifiedList.Remove(node1);

                // Change its appearance to unresolved
                node1.Text = RemoveTag(node1.Text);
                node1.ForeColor = Color.Red;
            }
            // Undo a MarkDelete
            else if (node1 == null && node2 != null && this.m_deleteList.Contains(node2))
            {
                // Remove the node from respective trees and lists
                this.m_deleteList.Remove(node2);
                this.m_modifiedList.Remove(node2);

                // Change its appearance to unresolved
                node2.Text = RemoveTag(node2.Text);
                node2.ForeColor = Color.Red;
            }
            // Undo a MarkMove
            else if (node1 != null && node2 != null)
            {
                foreach (TreeNode[] movePair in this.m_moveList)
                {
                    if (movePair[0] == node1 && movePair[1] == node2)
                    {
                        // Remove the node from respective trees and lists
                        RemoveFromResolvedTree(node1);
                        this.m_moveList.Remove(movePair);
                        this.m_modifiedList.Remove(node1);
                        this.m_modifiedList.Remove(node2);

                        // Change its appearance to unresolved
                        node1.Text = RemoveTag(node1.Text);
                        node1.ForeColor = Color.Red;
                        node2.Text = RemoveTag(node2.Text);
                        node2.ForeColor = Color.Red;

                        break;
                    }
                }
            }
        }

        private void toolbarUpdateAttributes()
        {
            this.treeView1.SetLastClickedNode(null);
            this.treeView2.SetLastClickedNode(null);
            this.UpdateButtons();

            int count = this.AutoUpdateTestCases(AutoUpdateAction.UpdateCategory);
            if (count >= 0)
            {
                MessageBox.Show(String.Format("Updated {0} test case(s).", count));
            }
        }

        private void toolbarAddAll()
        {
            this.treeView1.SetLastClickedNode(null);
            this.treeView2.SetLastClickedNode(null);
            this.UpdateButtons();

            int count = this.AutoUpdateTestCases(AutoUpdateAction.Add);
            if (count >= 0)
            {
                MessageBox.Show(String.Format("Added {0} test case(s).", count));
            }
        }

        private void toolbarDeleteAll()
        {
            this.treeView1.SetLastClickedNode(null);
            this.treeView2.SetLastClickedNode(null);
            this.UpdateButtons();

            int count = this.AutoUpdateTestCases(AutoUpdateAction.Delete);
            if (count >= 0)
            {
                MessageBox.Show(String.Format("Deleted {0} test case(s).", count));
            }
        }

        private int AutoUpdateTestCases(AutoUpdateAction updateAction)
        {
            int count = 0;
            ArrayList nodes1 = null;
            ArrayList nodes2 = null;

            if (updateAction == AutoUpdateAction.Add || updateAction == AutoUpdateAction.UpdateCategory)
            {
                if (this.treeView1.Nodes.Count > 0)
                {
                    nodes1 = this.GetAllChildNodes(this.treeView1.Nodes[0]);
                }
                else
                {
                    MessageBox.Show("No test cases in " + this.TreeLabel1);
                    return -1;
                }
            }

            if (updateAction == AutoUpdateAction.Delete || updateAction == AutoUpdateAction.UpdateCategory)
            {
                if (this.treeView2.Nodes.Count > 0)
                {
                    nodes2 = this.GetAllChildNodes(this.treeView2.Nodes[0]);
                }
                else
                {
                    MessageBox.Show("No test cases in " + this.TreeLabel2);
                    return -1;
                }
            }

            foreach (TreeNode node in (updateAction == AutoUpdateAction.Add || updateAction == AutoUpdateAction.UpdateCategory) ? nodes1 : nodes2)
            {
                if (node.ForeColor == Color.Red && node.Tag is TestCase)
                {
                    switch (updateAction)
                    {
                        case AutoUpdateAction.Add:
                            this.MarkAdd(node);
                            this.AddToResolvedTree(node);
                            count++;
                            break;
                        case AutoUpdateAction.Delete:
                            this.MarkDelete(node);
                            count++;
                            break;
                        case AutoUpdateAction.UpdateCategory:
                            TreeNode nodeMatch = this.FindTestCaseWithNonMatchingCateogry(nodes2, (TestCase)node.Tag);
                            if (nodeMatch != null)
                            {
                                this.MarkMove(node, nodeMatch);
                                this.AddToResolvedTree(node);
                                count++;
                            }
                            break;
                    }
                }
            }

            return count;
        }

        private TreeNode FindTestCaseWithNonMatchingCateogry(ArrayList nodes, TestCase tc1)
        {
            foreach (TreeNode node in nodes)
            {
                TestCase tc2 = node.Tag as TestCase;
                if (tc2 != null
                    && tc2.FullName == tc1.FullName
                    && tc2.TestCategory != tc1.TestCategory
                    && node.ForeColor == Color.Red)
                {
                    return node;
                }
            }
            return null;
        }

        private ArrayList GetAllChildNodes(TreeNode node)
        {
            ArrayList nodes = new ArrayList();
            foreach (TreeNode child in node.Nodes)
            {
                nodes.Add(child);
                nodes.AddRange(this.GetAllChildNodes(child));
            }
            return nodes;
        }

        private string RemoveTag(string str)
        {
            return str.Remove(str.IndexOf("<"), str.IndexOf(">") - str.IndexOf("<") + 1);
        }

        private void UpdateButtons()
        {
            this.toolBar.Buttons[0].Enabled = false;
            this.toolBar.Buttons[1].Enabled = false;
            this.toolBar.Buttons[2].Enabled = false;
            this.toolBar.Buttons[3].Enabled = false;

            if (this.m_modifiedList.Contains(this.treeView1.LastClickedNode) ||
                this.m_modifiedList.Contains(this.treeView2.LastClickedNode))
            {
                this.toolBar.Buttons[3].Enabled = true;
            }
            else if (this.treeView2.LastClickedNode != null && this.treeView2.LastClickedNode.LastNode == null
                && this.treeView1.LastClickedNode == null)
            {
                this.toolBar.Buttons[1].Enabled = true;
            }
            else if (this.treeView2.LastClickedNode != null && this.treeView2.LastClickedNode.LastNode == null
                && this.treeView1.LastClickedNode != null && this.treeView1.LastClickedNode.LastNode == null)
            {
                this.toolBar.Buttons[2].Enabled = true;
            }
            else if (this.treeView1.LastClickedNode != null && this.treeView1.LastClickedNode.LastNode == null
                && this.treeView2.LastClickedNode == null)
            {
                this.toolBar.Buttons[0].Enabled = true;
            }
        }

        #region Event Handlers

        public void form_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            switch (e.KeyChar)
            {
                case 'a':
                case 'A':
                case '1':
                    if (this.toolBar.Buttons[0].Enabled)
                        this.addButton_Click(sender, (System.EventArgs)e);
                    break;
                case 'd':
                case 'D':
                case '2':
                    if (this.toolBar.Buttons[1].Enabled)
                        this.deleteButton_Click(sender, (System.EventArgs)e);
                    break;
                case 'm':
                case 'M':
                case '3':
                    if (this.toolBar.Buttons[2].Enabled)
                        this.moveButton_Click(sender, (System.EventArgs)e);
                    break;
                case 'u':
                case 'U':
                case '4':
                    if (this.toolBar.Buttons[3].Enabled)
                        this.undoButton_Click(sender, (System.EventArgs)e);
                    break;
                case (char)1: // Ctrl + A
                    if (this.toolBar.Buttons[5].Enabled)
                        this.toolbarAddAll();
                    break;
                case (char)4: // Ctrl + D
                    if (this.toolBar.Buttons[6].Enabled)
                        this.toolbarDeleteAll();
                    break;
                case (char)21: // Ctrl + U
                    if (this.toolBar.Buttons[7].Enabled)
                        this.toolbarUpdateAttributes();
                    break;
            }
        }

        private void addButton_Click(object sender, System.EventArgs e)
        {
            this.MarkAdd(this.treeView1.LastClickedNode);
            this.AddToResolvedTree(this.treeView1.LastClickedNode);
            this.treeView1.SetLastClickedNode(null);
            this.treeView2.SetLastClickedNode(null);

            this.UpdateButtons();
        }

        private void deleteButton_Click(object sender, System.EventArgs e)
        {
            this.MarkDelete(this.treeView2.LastClickedNode);
            this.treeView1.SetLastClickedNode(null);
            this.treeView2.SetLastClickedNode(null);

            this.UpdateButtons();
        }

        private void moveButton_Click(object sender, System.EventArgs e)
        {
            this.MarkMove(this.treeView1.LastClickedNode, this.treeView2.LastClickedNode);
            this.AddToResolvedTree(this.treeView1.LastClickedNode);
            this.treeView1.SetLastClickedNode(null);
            this.treeView2.SetLastClickedNode(null);

            this.UpdateButtons();
        }

        private void undoButton_Click(object sender, System.EventArgs e)
        {
            this.MarkUndo(this.treeView1.LastClickedNode, this.treeView2.LastClickedNode);
            this.treeView1.SetLastClickedNode(null);
            this.treeView2.SetLastClickedNode(null);

            this.UpdateButtons();
        }

        private void submitButton_Click(object sender, System.EventArgs e)
        {
            if (this.treeView1.Nodes.Count > 0)
            {
                ArrayList nodes1 = this.GetAllChildNodes(this.treeView1.Nodes[0]);
                foreach (TreeNode node in nodes1)
                {
                    if (node.ForeColor == Color.Red)
                    {
                        MessageBox.Show("There are unresolved test cases in " + this.TreeLabel1);
                        return;
                    }
                }
            }

            if (this.treeView2.Nodes.Count > 0)
            {
                ArrayList nodes2 = this.GetAllChildNodes(this.treeView2.Nodes[0]);
                foreach (TreeNode node in nodes2)
                {
                    if (node.ForeColor == Color.Red)
                    {
                        MessageBox.Show("There are unresolved test cases in " + this.TreeLabel2);
                        return;
                    }
                }
            }

            this.DialogResult = DialogResult.OK;
        }

        private void cancelButton_Click(object sender, System.EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void treeView_Click(object sender, System.EventArgs e)
        {
            // Get the tree that fired the event
            SelectableTreeView tree1 = sender as SelectableTreeView;
            if (tree1 != null)
            {
                // Get the other tree
                SelectableTreeView tree2 = (tree1 == this.treeView1) ? this.treeView2 : this.treeView1;

                // Get the node that was clicked on
                TreeNode node = tree1.GetNodeAt(tree1.PointToClient(Control.MousePosition));

                // Highlight the corresponding node in the other tree, if one exists
                if (tree1.LastClickedNode != null)
                {
                    if (this.m_modifiedList.Contains(node))
                    {
                        tree2.SetLastClickedNode(null);
                        foreach (TreeNode[] list in this.m_moveList)
                        {
                            if ((tree1 == this.treeView1 && list[0] == node) || (tree1 == this.treeView2 && list[1] == node))
                            {
                                tree2.SetLastClickedNode(list[(tree1 == this.treeView1) ? 1 : 0]);
                                break;
                            }
                        }
                    }
                    else if (tree2.LastClickedNode != null && this.m_modifiedList.Contains(tree2.LastClickedNode))
                    {
                        tree2.SetLastClickedNode(null);
                    }
                }
                // Un-highlight the other node if we just unselected a pair of nodes
                else if (tree2.LastClickedNode != null && this.m_modifiedList.Contains(tree2.LastClickedNode))
                {
                    foreach (TreeNode[] list in this.m_moveList)
                    {
                        if ((tree1 == this.treeView1 && list[0] == node && list[1] == tree2.LastClickedNode) ||
                            (tree1 == this.treeView2 && list[1] == node && list[0] == tree2.LastClickedNode))
                        {
                            tree2.SetLastClickedNode(null);
                            break;
                        }
                    }
                }

                this.UpdateButtons();
            }
        }
        private void toolBar_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
        {
            switch (this.toolBar.Buttons.IndexOf(e.Button))
            {
                case 0:
                    this.addButton_Click(sender, e);
                    break;
                case 1:
                    this.deleteButton_Click(sender, e);
                    break;
                case 2:
                    this.moveButton_Click(sender, e);
                    break;
                case 3:
                    this.undoButton_Click(sender, e);
                    break;
                case 5:
                    this.toolbarAddAll();
                    break;
                case 6:
                    this.toolbarDeleteAll();
                    break;
                case 7:
                    this.toolbarUpdateAttributes();
                    break;
            }
        }

        private void form_Resize(object sender, System.EventArgs e)
        {
            const double sizePercent = 312.0 / 944.0;
            int width = (int)(((double)this.Width) * sizePercent);
            this.groupBox1.Width = width;
            this.groupBox1.Left = 0;

            this.groupBox3.Width = width;
            this.groupBox3.Left = this.Width - 7 - width;

            this.groupBox2.Width = this.groupBox3.Left - this.groupBox2.Left + 2;
            this.groupBox2.Left = this.groupBox1.Right - 2;
        }

        #endregion

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.treeView1 = new SelectableTreeView();
            this.treeView2 = new SelectableTreeView();
            this.resolvedTreeView = new SelectableTreeView();
            this.cancelButton = new System.Windows.Forms.Button();
            this.submitButton = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.toolBar = new System.Windows.Forms.ToolBar();
            this.toolBarAddButton = new System.Windows.Forms.ToolBarButton();
            this.toolBarDeleteButton = new System.Windows.Forms.ToolBarButton();
            this.toolBarMoveButton = new System.Windows.Forms.ToolBarButton();
            this.toolBarUndoButton = new System.Windows.Forms.ToolBarButton();
            this.toolBarSeparator = new System.Windows.Forms.ToolBarButton();
            this.toolBarAddAllButton = new System.Windows.Forms.ToolBarButton();
            this.toolBarDeleteAllButton = new System.Windows.Forms.ToolBarButton();
            this.toolBarUpdateAllButton = new System.Windows.Forms.ToolBarButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // treeView1
            // 
            this.treeView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView1.HideSelection = false;
            this.treeView1.ImageIndex = -1;
            this.treeView1.Location = new System.Drawing.Point(8, 2);
            this.treeView1.Name = "treeView1";
            this.treeView1.SelectedImageIndex = -1;
            this.treeView1.ShowPlusMinus = false;
            this.treeView1.Size = new System.Drawing.Size(290, 427);
            this.treeView1.Sorted = true;
            this.treeView1.TabIndex = 6;
            this.treeView1.Click += new System.EventHandler(this.treeView_Click);
            // 
            // treeView2
            // 
            this.treeView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView2.HideSelection = false;
            this.treeView2.ImageIndex = -1;
            this.treeView2.Location = new System.Drawing.Point(8, 2);
            this.treeView2.Name = "treeView2";
            this.treeView2.SelectedImageIndex = -1;
            this.treeView2.ShowPlusMinus = false;
            this.treeView2.Size = new System.Drawing.Size(290, 427);
            this.treeView2.Sorted = true;
            this.treeView2.TabIndex = 7;
            this.treeView2.Click += new System.EventHandler(this.treeView_Click);
            // 
            // resolvedTreeView
            // 
            this.resolvedTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resolvedTreeView.HideSelection = false;
            this.resolvedTreeView.ImageIndex = -1;
            this.resolvedTreeView.Location = new System.Drawing.Point(8, 2);
            this.resolvedTreeView.Name = "resolvedTreeView";
            this.resolvedTreeView.SelectedImageIndex = -1;
            this.resolvedTreeView.ShowPlusMinus = false;
            this.resolvedTreeView.Size = new System.Drawing.Size(290, 427);
            this.resolvedTreeView.Sorted = true;
            this.resolvedTreeView.TabIndex = 8;
            // 
            // cancelButton
            // 
            this.cancelButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
            this.cancelButton.Location = new System.Drawing.Point(848, 522);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.TabIndex = 13;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.form_KeyPress);
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // submitButton
            // 
            this.submitButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
            this.submitButton.Location = new System.Drawing.Point(760, 522);
            this.submitButton.Name = "submitButton";
            this.submitButton.TabIndex = 14;
            this.submitButton.Text = "Submit";
            this.submitButton.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.form_KeyPress);
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.treeView2});
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.DockPadding.Bottom = 8;
            this.panel2.DockPadding.Left = 8;
            this.panel2.DockPadding.Right = 8;
            this.panel2.DockPadding.Top = 2;
            this.panel2.Location = new System.Drawing.Point(3, 16);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(306, 437);
            this.panel2.TabIndex = 16;
            // 
            // panel3
            // 
            this.panel3.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.resolvedTreeView});
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.DockPadding.Bottom = 8;
            this.panel3.DockPadding.Left = 8;
            this.panel3.DockPadding.Right = 8;
            this.panel3.DockPadding.Top = 2;
            this.panel3.Location = new System.Drawing.Point(3, 16);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(306, 437);
            this.panel3.TabIndex = 17;
            // 
            // toolBar
            // 
            this.toolBar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
            this.toolBar.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																					   this.toolBarAddButton,
																					   this.toolBarDeleteButton,
																					   this.toolBarMoveButton,
																					   this.toolBarUndoButton,
																					   this.toolBarSeparator,
																					   this.toolBarAddAllButton,
																					   this.toolBarDeleteAllButton,
																					   this.toolBarUpdateAllButton});
            this.toolBar.DropDownArrows = true;
            this.toolBar.Name = "toolBar";
            this.toolBar.ShowToolTips = true;
            this.toolBar.Size = new System.Drawing.Size(936, 39);
            this.toolBar.TabIndex = 18;
            this.toolBar.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.toolBar_ButtonClick);
            this.toolBar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.form_KeyPress);
            // 
            // toolBarAddButton
            // 
            this.toolBarAddButton.ImageIndex = 0;
            this.toolBarAddButton.Text = "Add";
            this.toolBarAddButton.ToolTipText = "Add Test Case";
            // 
            // toolBarDeleteButton
            // 
            this.toolBarDeleteButton.ImageIndex = 1;
            this.toolBarDeleteButton.Text = "Delete";
            this.toolBarDeleteButton.ToolTipText = "Delete Test Case";
            // 
            // toolBarMoveButton
            // 
            this.toolBarMoveButton.ImageIndex = 2;
            this.toolBarMoveButton.Text = "Move";
            this.toolBarMoveButton.ToolTipText = "Move Test Case";
            // 
            // toolBarUndoButton
            // 
            this.toolBarUndoButton.ImageIndex = 3;
            this.toolBarUndoButton.Text = "Undo";
            this.toolBarUndoButton.ToolTipText = "Undo Action";
            // 
            // toolBarSeparator
            // 
            this.toolBarSeparator.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
            // 
            // toolBarAddAllButton
            // 
            this.toolBarAddAllButton.ImageIndex = 4;
            this.toolBarAddAllButton.Text = "Add All";
            this.toolBarAddAllButton.ToolTipText = "Add All Unresolved Test Cases";
            // 
            // toolBarDeleteAllButton
            // 
            this.toolBarDeleteAllButton.ImageIndex = 5;
            this.toolBarDeleteAllButton.Text = "Delete All";
            this.toolBarDeleteAllButton.ToolTipText = "Delete All Unresolved Test Cases";
            // 
            // toolBarUpdateAllButton
            // 
            this.toolBarUpdateAllButton.ImageIndex = 6;
            this.toolBarUpdateAllButton.Text = "Update All";
            this.toolBarUpdateAllButton.ToolTipText = "Update All Unresolved Test Case Categories";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                | System.Windows.Forms.AnchorStyles.Left);
            this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.panel1});
            this.groupBox1.Location = new System.Drawing.Point(0, 56);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(312, 456);
            this.groupBox1.TabIndex = 19;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Test Cases List 1";
            // 
            // panel1
            // 
            this.panel1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.treeView1});
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.DockPadding.Bottom = 8;
            this.panel1.DockPadding.Left = 8;
            this.panel1.DockPadding.Right = 8;
            this.panel1.DockPadding.Top = 2;
            this.panel1.Location = new System.Drawing.Point(3, 16);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(306, 437);
            this.panel1.TabIndex = 20;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom);
            this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.panel2});
            this.groupBox2.Location = new System.Drawing.Point(312, 56);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(312, 456);
            this.groupBox2.TabIndex = 20;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Test Cases List 2";
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                | System.Windows.Forms.AnchorStyles.Right);
            this.groupBox3.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.panel3});
            this.groupBox3.Location = new System.Drawing.Point(624, 56);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(312, 456);
            this.groupBox3.TabIndex = 21;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Resolved Test Cases List";
            // 
            // ResolverGUI
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(936, 560);
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.groupBox3,
																		  this.groupBox2,
																		  this.groupBox1,
																		  this.toolBar,
																		  this.submitButton,
																		  this.cancelButton});
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.MinimumSize = new System.Drawing.Size(600, 200);
            this.Name = "ResolverGUI";
            this.Text = "Resolver";
            this.Resize += new System.EventHandler(this.form_Resize);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.form_KeyPress);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }
        #endregion

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }
    }


    /*** Temporarily putting this class here until I get Sirisha's cool new TestAreaManager control ***/
    /// <summary>
    /// Summary description for SelectableTreeView.
    /// </summary>
    public class SelectableTreeView : System.Windows.Forms.TreeView
    {
        public TreeNode LastClickedNode = null;
        Color OldBackColor = Color.White;

        public SelectableTreeView()
        {
            //
            // TODO: Add constructor logic here
            //
            this.Click += new System.EventHandler(this.TreeView_Click);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.TreeView_MouseMove);
        }

        protected override void OnBeforeSelect(TreeViewCancelEventArgs e)
        {
            // Don't do anything
            e.Cancel = true;
            base.OnBeforeSelect(e);
        }

        private void TreeView_Click(object sender, System.EventArgs e)
        {
            TreeNode node = this.GetNodeAt(this.PointToClient(Control.MousePosition));
            if (node != null && node.Nodes.Count == 0)
                SetLastClickedNode(node);
        }

        private void TreeView_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            TreeNode node = this.GetNodeAt(e.X, e.Y);
            if (node != null && node.Nodes.Count == 0)
            {
                this.Cursor = Cursors.Hand;
            }
            else
            {
                this.Cursor = Cursors.Arrow;
            }
        }

        public void SetLastClickedNode(TreeNode node)
        {
            if (node == LastClickedNode && node != null)
            {
                if (LastClickedNode != null)
                {
                    LastClickedNode.BackColor = OldBackColor;
                    LastClickedNode = null;
                }
            }
            else if (node != null && LastClickedNode != null)
            {
                LastClickedNode.BackColor = OldBackColor;
                OldBackColor = node.BackColor;
                node.BackColor = Color.Silver;
                LastClickedNode = node;
            }
            else if (LastClickedNode != null && node == null)
            {
                LastClickedNode.BackColor = OldBackColor;
                LastClickedNode = null;
            }
            else if (LastClickedNode == null && node != null)
            {
                OldBackColor = node.BackColor;
                node.BackColor = Color.Silver;
                LastClickedNode = node;
            }
        }
    }
}
