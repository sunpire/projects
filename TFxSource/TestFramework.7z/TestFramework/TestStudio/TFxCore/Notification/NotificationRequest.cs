using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for NotificationRequest.
	/// </summary>
	public class NotificationRequest
	{
		public NotificationRequest()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
