using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for BuildNotification.
	/// </summary>
	public class StressProgressNotification: NotificationRequest
	{
        /// Comments: changed labrunid to GUID labrungid
		public StressProgressNotification(int assignmentID, Guid labrunGid, StressRecorder stressData)
		{
			this.data = stressData;
			this.assignmentID = assignmentID;
			this.labrunGid = labrunGid;
		}

		public StressRecorder data;
		public int assignmentID;
		public Guid labrunGid;

	}
}
