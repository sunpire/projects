using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for UIStateUpdateNotification.
	/// </summary>
	public class UIStateUpdateNotification : NotificationRequest
	{
		public Profile Profile;
		public UIStateMode UIState;

		public UIStateUpdateNotification()
		{
			
		}
	}
}
