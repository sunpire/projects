using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for UserChangeNotification.
	/// </summary>
	public class UserChangeNotification : NotificationRequest
	{
		public UserChangeNotification()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
