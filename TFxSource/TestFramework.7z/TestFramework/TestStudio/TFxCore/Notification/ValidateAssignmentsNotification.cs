using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ValidateAssignmentsNotification.
	/// </summary>
	public class ValidateAssignmentsNotification : NotificationRequest
	{
		public ValidateAssignmentsNotification()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
