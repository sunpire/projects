using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for BuildChangeNotification.
	/// </summary>
	public class BuildChangeNotification: NotificationRequest
	{
		public string BuildName;

		public BuildChangeNotification()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
