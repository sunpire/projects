using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for UpdateControlsNotification.
	/// </summary>
	public class FilterChangeNotification : NotificationRequest
	{
		public FilterChangeNotification()
		{
			
		}
	}
}
