using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for UIStateChangeNotification.
	/// </summary>
	public class UIStateChangeNotification : NotificationRequest
	{
		public Profile Profile;
		public UIStateMode UIState;

		public UIStateChangeNotification()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
