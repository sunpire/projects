using System;
using System.Collections;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TestTreeChangeNotification.
	/// </summary>
	public class TestTreeChangeNotification: NotificationRequest
	{
        public TestTreeChangeNotification() : base()
        {
            //
            // TODO: Add constructor logic here
            //
        }

		public TestTreeChangeNotification(ArrayList areas) : base()
		{
			//
			// TODO: Add constructor logic here
			//
            RootTestAreas = areas;
		}

		public ArrayList RootTestAreas;
        public TestInfo SelectedTestInfo;
	}
}
