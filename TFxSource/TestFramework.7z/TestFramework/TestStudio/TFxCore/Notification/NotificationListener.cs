using System;

namespace Expedia.Test.Framework
{
	public class NotificationListener
	{
		public Type type;
		public event NotificationRequestHandler handler;
			 

		public NotificationListener(Type t)
		{
			this.type = t;
		}

		public void AddListener(NotificationRequestHandler listener)
		{
			lock(this)
			{
				this.handler += listener;
			}
		}

		public void RemoveListener(NotificationRequestHandler listener)
		{
			lock(this)
			{
				this.handler -= listener;
			}
		}

		public void Invoke(NotificationRequest request)
		{
			if (this.handler !=null)
			{
				this.handler(request);
			}
		}

		public void RemoveListenerFor(object obj)
		{
			if (handler !=null)
			{
				Delegate[] array = handler.GetInvocationList();
					
				for (int i=0; i< array.GetLength(0); i++)
				{
					if (array[i].Target == obj)
					{
						handler -= (NotificationRequestHandler) array[i];
					}
				}
			}
		}

	}
}
