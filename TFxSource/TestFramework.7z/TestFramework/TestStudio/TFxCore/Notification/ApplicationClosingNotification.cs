using System;
using System.Drawing;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ApplicationClosingNotification.
	/// </summary>
	public class ApplicationClosingNotification : NotificationRequest
	{
		public System.Drawing.Rectangle WindowSize;
		public System.Windows.Forms.TabPage CloseTab;

		public ApplicationClosingNotification()
		{
			WindowSize = Rectangle.Empty;
		
		}

		public ApplicationClosingNotification(Rectangle WindowSize)
		{
			this.WindowSize = WindowSize;
		
		}
	}
}
