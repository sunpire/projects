using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for LoadTestRunNotification.
	/// </summary>
	public class LoadTestRunNotification : NotificationRequest
	{
		public string TestRunName;
		public Guid TestRunGid;
        public bool AutoPickBuild = false;
		

		public LoadTestRunNotification()
		{
			this.TestRunName = null;
			this.TestRunGid = Guid.Empty;

		}
		public LoadTestRunNotification(string TestRunName)
		{
			this.TestRunName = TestRunName;
			this.TestRunGid = Guid.Empty;

		}
		public LoadTestRunNotification(Guid TestRunGid)
		{
			this.TestRunGid= TestRunGid;
			this.TestRunName = null;

		}
	}
}
