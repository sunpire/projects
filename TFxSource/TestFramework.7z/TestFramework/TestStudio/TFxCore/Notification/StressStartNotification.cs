using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for BuildNotification.
	/// </summary>
	public class StressStartNotification: NotificationRequest
	{
        /// Comments: changed labrunid to GUID labrungid
		public StressStartNotification(int assignmentID, Guid labrunGid, TimeSpan durration, TimeSpan captureInterval, TimeSpan waitInterval, int threadCount, DateTime startTime, TimeSpan resolution )
		{
			this.assignmentID = assignmentID;
			this.labrunGid = labrunGid;
			this.durration = durration;
			this.captureInterval = captureInterval;
			this.waitInterval = waitInterval;
			this.threadCount = threadCount;
			this.startTime =startTime;
			this.resolution = resolution;
		}

		public int assignmentID;
		public Guid labrunGid;
		public TimeSpan durration;
		public TimeSpan captureInterval;
		public int	threadCount;
		public TimeSpan waitInterval;
		public DateTime startTime;
		public TimeSpan resolution;


	}
}
