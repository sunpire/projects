using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for FileAssignmentImport.
	/// </summary>
	public class FileAssignmentImportNotification : NotificationRequest
	{
		public FileAssignmentImportNotification()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
