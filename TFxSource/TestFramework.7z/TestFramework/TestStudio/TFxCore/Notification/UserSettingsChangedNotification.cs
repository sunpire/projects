using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for UserSettingsChangedNotification.
	/// </summary>
	public class UserSettingsChangedNotification : NotificationRequest
	{
		public UserSettingsChangedNotification()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
