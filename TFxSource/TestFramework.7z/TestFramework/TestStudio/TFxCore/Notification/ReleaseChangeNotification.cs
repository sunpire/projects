using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ReleaseChangeNotification.
	/// </summary>
	public class ReleaseChangeNotification: NotificationRequest
	{

		public String ReleaseName;

		public ReleaseChangeNotification()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
