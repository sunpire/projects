using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for DataNotification.
	/// </summary>
	public class DataNotification: NotificationRequest
	{

		public RepositoryRequest Request;

		public DataNotification()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
