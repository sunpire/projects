using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ValidateTestCasesNotification.
	/// </summary>
	public class ValidateTestCasesNotification : NotificationRequest
	{
		public ValidateTestCasesNotification()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
