using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for FileAssignmentExportNotification.
	/// </summary>
	public class FileAssignmentExportNotification : NotificationRequest
	{
		public FileAssignmentExportNotification()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
