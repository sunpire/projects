using System;
using System.Collections;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ImportTestRunNotification.
	/// </summary>
	public class ImportTestRunNotification : NotificationRequest
	{
		public string TestRunName;	
		public string BuildFolder;

		public ImportTestRunNotification()
		{
			this.TestRunName = null;
		}

		public ImportTestRunNotification(string TestRunName)
		{
			this.TestRunName = TestRunName;
		}

		public ImportTestRunNotification(string TestRunName, string buildFolder)
		{
			this.TestRunName = TestRunName;
			this.BuildFolder = buildFolder;
			
		}

		public ImportTestRunNotification(int TestRunId)
		{
			this.TestRunName = null;
		}
	}
}
