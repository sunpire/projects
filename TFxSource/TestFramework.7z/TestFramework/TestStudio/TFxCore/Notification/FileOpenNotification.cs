using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for BuildNotification.
	/// </summary>
	public class FileOpenNotification: NotificationRequest
	{
		public FileOpenNotification(TestBuildModule module): base()
		{
			//
			// TODO: Add constructor logic here
			//
			Module = module;
		}

		public TestBuildModule Module;
	}
}
