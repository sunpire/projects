using System;
using System.Collections.Generic;

namespace Expedia.Test.Framework
{
    public class TestTreeReloadNotification : NotificationRequest
    {
        public TestInfo ModifiedTestInfo;

        public TestTreeReloadNotification(TestInfo info)
        {
            ModifiedTestInfo = info;
        }

        public TestTreeReloadNotification()
        {
        }
    }
}
