using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for BuildNotification.
	/// </summary>
	public class AssignmentCompleteNotification: NotificationRequest
	{
		public AssignmentCompleteNotification(Client client, Assignment assignment, AssignmentResult result)
		{
			this.client = client;
			this.assignment = assignment;
			this.result = result;
		}

		public Client client; 
		public Assignment assignment; 
		public AssignmentResult result;
	}
}
