using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for InfoNotification.
	/// </summary>
	public class InfoNotification: NotificationRequest
	{
		public string Message;
		public SeverityType MessageType;

		public InfoNotification()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public static InfoNotification GetInfoNotification(SeverityType type, string errorMessage)
		{
			InfoNotification info = new InfoNotification();
			info.MessageType = type;
			info.Message = errorMessage;
			return info;
		}
	}


	/// <summary>
	/// Summary description for InfoNotification.
	/// </summary>
	public class InfoActionNotification: NotificationRequest
	{
		public string Message;
		public SeverityType MessageType;

		public InfoActionNotification()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
