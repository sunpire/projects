using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for LoadTemplateNotification.
	/// </summary>
	public class LoadTemplateNotification : NotificationRequest
	{
		public TestRun testRun;

		public LoadTemplateNotification(TestRunTemplate template)
		{
			testRun = template.CreateTestRun();
		}
	}
}
