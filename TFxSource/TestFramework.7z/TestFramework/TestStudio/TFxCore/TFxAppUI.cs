using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
    public enum NotificationType
    {
        Global,
        App
    }

    public partial class TFxAppUI : RepositoryDelegateUI
    {
        TFxUIListiners appListiners = new TFxUIListiners();

        public TFxAppUI()
        {
            InitializeComponent();
        }

        public override NotificationListener AddNotificationHandler(Type type, NotificationType notifyType, NotificationRequestHandler handler)
        {
            if (notifyType == NotificationType.App)
            {
                return appListiners.AddListener(type, handler);
            }
            else
            {
                return base.AddNotificationHandler(type,NotificationType.Global, handler);
            }

        }

        public override void RemoveNotificationHandler(Type type, NotificationRequestHandler handler)
        {
            appListiners.RemoveListener(type, handler);
            base.RemoveNotificationHandler(type, handler);
        }

        public override void NotifyUI(NotificationRequest request)
        {
            appListiners.Invoke(request);
            base.NotifyUI(request);

        }
    }
}
