//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: ITFxUI.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//==========================================================================
using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ITFxUI.
	/// </summary>
	public interface ITFxUI
	{
        NotificationListener AddNotificationHandler(Type type, NotificationType notifyType, NotificationRequestHandler handler);
        NotificationListener AddNotificationHandler(Type type, NotificationRequestHandler handler);
        void RemoveNotificationHandler(Type type, NotificationRequestHandler handler);

        void NotifyUI(NotificationRequest request);

		void GetData(RepositoryRequest request);
	}
}
