using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for LocalClient.
    /// </summary>
    public class LocalClient : Client
    {
        public LocalClient(int QSize, Repository repository)
            : base(QSize, repository)
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public override void RunAssignment(Assignment assignment)
        {
            LocalClientThread thread = new LocalClientThread(this, assignment);
            base.RunAssignment(assignment, thread);
        }
    }

    public class LocalClientThread : ClientThread
    {
        protected Timer timer;
        protected bool isTimeout;
        protected ManualResetEvent resetEvent = new ManualResetEvent(false);

        public LocalClientThread(Client client, Assignment assignment)
            : base(client, assignment)
        {
        }

        public override void Start()
        {
            if (thread != null)
            {
                thread.Start();

                if ((int)timeout.TotalMilliseconds > 0)
                {
                    timer = new Timer(new TimerCallback(CallBack), null, (int)timeout.TotalMilliseconds, -1);
                }
            }
        }

        public void CallBack(object obj)
        {
            isTimeout = true;
            resetEvent.Set();
            resetEvent = null;
        }

        private static Dictionary<string, string> GetAssignmentConfigs(Assignment assignment)
        {
            StringConfig strConfig;
            Dictionary<string, string> configDictionary;
            IConfig[] configs = assignment.ConfigData.GetAllConfigs();

            if (configs.Length > 0)
            {
                strConfig = configs[0] as StringConfig;
                configDictionary = new Dictionary<string, string>(StringComparer.CurrentCultureIgnoreCase);
                foreach (DictionaryEntry ent in strConfig.Config)
                {
                    if (!String.IsNullOrEmpty(ent.Value.ToString()))
                        configDictionary.Add(ent.Key.ToString(), ent.Value.ToString());
                }

                if (!configDictionary.ContainsKey("__AssignmentId"))
                {
                    configDictionary.Add("__AssignmentId", assignment.AssignmentId.ToString());
                }

                return configDictionary;
            }

            return null;
        }

        public override void ThreadWorker()
        {
            Dictionary<string, string> assignmentConfigs;
            string[,] scenariosList;
            string failureReason;
            string assignmentRunResult;

            DriverDomainSafe domainSafe = new DriverDomainSafe();

            assignmentConfigs = GetAssignmentConfigs(m_assignment);
            assignmentConfigs.Add("__labrunname", m_assignment.LabRun.Name);
            assignmentConfigs.Add("__createdby", Environment.UserName);

            // Add branch name and test namespace config to assignment configs.
            foreach (KeyValuePair<string, string> kvp in m_assignment.TestCase.TestConfigs)
            {
                //if (!(kvp.Key.Starts  With("__") || kvp.Key.Equals("__releaseinfo", StringComparison.CurrentCultureIgnoreCase) || kvp.Key.Equals("__testnamespace", StringComparison.CurrentCultureIgnoreCase))) continue;
                if (!kvp.Key.StartsWith("__")) continue;

                if (!assignmentConfigs.ContainsKey(kvp.Key))
                {
                    assignmentConfigs.Add(kvp.Key, kvp.Value);
                }
            }

            AssignmentResult result = new AssignmentResult();
            result.RunStatus = AssignmentStatusType.Completed;
            result.Status = AssignmentRunResultType.Pass;
 
            domainSafe.Execute(m_assignment.TestCase.FullName, m_assignment.TestCase.Module.DllFullName, assignmentConfigs, m_assignment.TestCase.Parameters, out scenariosList, out failureReason, out assignmentRunResult);


            if (!String.IsNullOrEmpty(failureReason))
            {
                result.FailureReason = failureReason;
            }

            if (!String.IsNullOrEmpty(assignmentRunResult))
            {
                result.Status = (AssignmentRunResultType)Enum.Parse(typeof(AssignmentRunResultType), assignmentRunResult);
            }

            int scenariosListLength = scenariosList.GetLength(0);

            if (scenariosListLength > 0)
            {
                for (int i = 0; i < scenariosListLength; i++)
                {
                    ScenarioResult scenarioResult = new ScenarioResult(scenariosList[i, 0]);

                    scenarioResult.Status = scenariosList[i, 1];
                    scenarioResult.FailureReason = scenariosList[i, 2];
                    scenarioResult.FailureDetail = scenariosList[i, 3];

                    result.Scenarios.Add(scenarioResult);
                }
            }

            m_assignment.Result = result;

            if (isTimeout)
            {
                m_assignment.Result = new AssignmentResult();
                m_assignment.Result.Status = AssignmentRunResultType.Timeout;
            }

            if (timer != null)
            {
                timer.Dispose();
            }
            base.ThreadWorker();
        }
    }
}
