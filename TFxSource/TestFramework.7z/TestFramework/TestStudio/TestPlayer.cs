//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: TestPlayer.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using Expedia.Test.Framework;

namespace TestStudio
{
	/// <summary>
	/// Summary description for TestPlayer.
	/// </summary>
	public class TestPlayer : System.Windows.Forms.UserControl
	{
		private Expedia.Test.Framework.TestAreaControl testAreaControl;
		private System.Windows.Forms.Splitter Splitter;
		private Expedia.Test.Framework.TestInfoDisplayControl testInfoDisplayControl;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public TestPlayer()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitForm call

		}

		#region Methods
		public void LoadTree()
		{			
			TestArea RootTestArea = null;

			using(TFx tfx = new TFx(DBUserType.ReadOnly))
			{
				//Get all the testareas and the testcases for the RootTestArea
				RootTestArea = tfx.LoadAllTests();				
			}

			this.testAreaControl.RootTestArea = RootTestArea;
		}
		#endregion


		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(TestPlayer));
			this.testAreaControl = new Expedia.Test.Framework.TestAreaControl();
			this.testInfoDisplayControl = new Expedia.Test.Framework.TestInfoDisplayControl();
			this.Splitter = new System.Windows.Forms.Splitter();
			this.SuspendLayout();
			// 
			// testAreaControl
			// 
			this.testAreaControl.AutomatedTestCaseIcon = ((System.Drawing.Bitmap)(resources.GetObject("testAreaControl.AutomatedTestCaseIcon")));
			this.testAreaControl.Dock = System.Windows.Forms.DockStyle.Left;
			this.testAreaControl.EnableTestCases = false;
			this.testAreaControl.MultipleSelect = false;
			this.testAreaControl.Name = "testAreaControl";
			this.testAreaControl.RootTestArea = null;
			this.testAreaControl.SelectedNode = null;
			this.testAreaControl.Size = new System.Drawing.Size(184, 440);
			this.testAreaControl.TabIndex = 0;
			this.testAreaControl.TestAreaIcon = ((System.Drawing.Bitmap)(resources.GetObject("testAreaControl.TestAreaIcon")));
			this.testAreaControl.TestAreaSelectedIcon = ((System.Drawing.Bitmap)(resources.GetObject("testAreaControl.TestAreaSelectedIcon")));
			this.testAreaControl.Load += new System.EventHandler(this.testAreaControl_Load);
			this.testAreaControl.AfterSelect += new Expedia.Test.Framework.TestAreaControl.TestAreaEventHandler(this.testAreaControl_AfterSelect);
			// 
			// testInfoDisplayControl
			// 
			this.testInfoDisplayControl.Dock = System.Windows.Forms.DockStyle.Fill;
			this.testInfoDisplayControl.Location = new System.Drawing.Point(184, 0);
			this.testInfoDisplayControl.Name = "testInfoDisplayControl";
			this.testInfoDisplayControl.Size = new System.Drawing.Size(480, 440);
			this.testInfoDisplayControl.TabIndex = 2;
			this.testInfoDisplayControl.TestInformation = null;
			// 
			// Splitter
			// 
			this.Splitter.Location = new System.Drawing.Point(184, 0);
			this.Splitter.Name = "Splitter";
			this.Splitter.Size = new System.Drawing.Size(3, 440);
			this.Splitter.TabIndex = 3;
			this.Splitter.TabStop = false;
			// 
			// TestPlayer
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.Splitter,
																		  this.testInfoDisplayControl,
																		  this.testAreaControl});
			this.Name = "TestPlayer";
			this.Size = new System.Drawing.Size(664, 440);
			this.Resize += new System.EventHandler(this.TestPlayer_Resize);
			this.ResumeLayout(false);

		}
		#endregion

		private void testAreaControl_Load(object sender, System.EventArgs e)
		{
			this.testAreaControl.EnableTestCases = true;
			LoadTree();
			
		}

		private void testAreaControl_AfterSelect(object sender, Expedia.Test.Framework.TestAreaEventArgs e)
		{
			//Fire the Event
			this.testInfoDisplayControl.TestInformation = e.Test;
		}

		private void TestPlayer_Resize(object sender, System.EventArgs e)
		{
					
			Control control = (Control)sender;
			Control testArea = (Control)this.testAreaControl;
			Control testDisplay = (Control)this.testInfoDisplayControl;

			const double sizePercent = 30.0/100.0;
			int width = (int)(((double)this.Width)*sizePercent);

			testArea.Size = new Size(width,control.Size.Height);

			int testDisplaySize = control.Size.Width - width;
			testDisplay.Size = new Size(testDisplaySize, control.Size.Height);			
		
		}

		
	}
}
