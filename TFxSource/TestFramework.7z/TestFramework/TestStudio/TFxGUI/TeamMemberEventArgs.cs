//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: TeamEventArgs.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 

using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TeamMemberEventArgs.
	/// </summary>
	public class TeamMemberEventArgs : EventArgs
	{

		#region Properties

		private TFxUser m_member;

		public TFxUser Member
		{
			get
			{
				return m_member;
			}
			set
			{
				m_member = value;
			}
		}

		#endregion
		public TeamMemberEventArgs()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
