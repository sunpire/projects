//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: BaseSelectionEditorControl.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{


	/// <summary>
	/// Summary description for BaseSelectionEditorControl.
	/// </summary>
	public class EditableFilterControl : RepositoryDelegateUI
	{
		public delegate void SelectionEditorModeChangeEventHandler(object sender, SelectionEditorEventArgs e);
		
		[Category("Behavior"),
		 Description("Raised when the SelectionEditorMode changes")]
	//	public event SelectionEditorModeChangeEventHandler SelectionEditorModeChanged;
	//	public virtual event EventHandler EditorDone;
	//	public virtual event EventHandler EditorCancel;

		public event EventHandler SelectionChanged;
		
		public event EventHandler SaveButtonClick
		{
			add
			{
				this.saveButton.Click += value;
			}
			remove
			{
				this.saveButton.Click -= value;
			}
		}

		public event EventHandler CancelButtonClick
		{
			add
			{
				this.cancelButton.Click += value;
			}
			remove
			{
				this.cancelButton.Click -= value;
			}
		}

		private SelectionEditorMode m_currentMode = SelectionEditorMode.Simple;
		private int m_savedSelectedIndex = -1;
		protected UserControl simpleEditorControl;
		protected UserControl advancedEditorControl;
		private System.Windows.Forms.Panel panelHeader;
		private System.Windows.Forms.ComboBox selectorComboBox;
		private System.Windows.Forms.Label editorNameLabel;
		private System.Windows.Forms.Button saveButton;
		private System.Windows.Forms.Button cancelButton;
		//private Expedia.Test.Framework.AdvancedFilterBodyControl advancedFilterBodyControl1;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel2;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private bool m_editable = false;
		private EditObject m_editObject = new EditObject();

		private class EditObject
		{
			public string Name
			{
				get
				{
					return "<< New >>";
				}
			}
		}

		public EditableFilterControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			FilterListRequest listRequest = new FilterListRequest();
			listRequest.FilterType = typeof(FilterExpression);			
			this.GetData(listRequest);
		}


		public bool Editable
		{
			get
			{
				return this.m_editable;
			}
			set
			{
				if(this.m_editable != value)
				{
					if(value)
					{
						this.selectorComboBox.Items.Add(this.m_editObject);
					}
					else
					{
						this.selectorComboBox.Items.Remove(this.m_editObject);
					}
					this.m_editable = value;
				}
			}
		}

		public string EditorName
		{
			get
			{
				return this.editorNameLabel.Text;
			}
			set
			{
				this.editorNameLabel.Text = value;
			}
		}

		public ComboBox SelectorComboBox
		{
			get
			{
				return this.selectorComboBox;
			}
		}

		public bool ModeSelectionEnabled
		{
			get
			{
				return false;
				//return this.modeButton.Visible;
			}
			set
			{

				//this.modeButton.Visible = value;
			}
		}

		public SaveSelectionMode CurrentSaveMode
		{
			get
			{
				if(this.saveButton.Text == "Create")
				{
					return SaveSelectionMode.CreateNew;
				}
				else
				{
					return SaveSelectionMode.Overwrite;
				}
			}
			set
			{
				switch(value)
				{
					case SaveSelectionMode.CreateNew:
						this.saveButton.Text = "Create";
						this.saveButton.Enabled = true;
						break;
					case SaveSelectionMode.Overwrite:
						this.saveButton.Text = "Overwrite";
						this.saveButton.Enabled = true;
						break;
					case SaveSelectionMode.Disabled:
						this.saveButton.Text = "Invalid Name";
						this.saveButton.Enabled = false;
						break;
				}
			}
		}

		public SelectionEditorMode CurrentMode
		{
			get
			{
				return this.m_currentMode;
			}
			set
			{
//				if(this.m_currentMode != value && this.ModeSelectionEnabled)
//				{
//					switch(value)
//					{
//						case SelectionEditorMode.Simple:
//							this.modeButton.Text = "Advanced";
//							break;
//						case SelectionEditorMode.Advanced:
//							this.modeButton.Text = "Simple";
//							break;
//					}
//					this.m_currentMode = value;
//					SelectionEditorModeChanged(this, new SelectionEditorEventArgs(this.CurrentMode));
//				}
			}
		}

		public UserControl CurrentEditorControl
		{
			get
			{
				switch(this.CurrentMode)
				{
					case SelectionEditorMode.Simple:
						return this.simpleEditorControl;
					case SelectionEditorMode.Advanced:
						return this.advancedEditorControl;
					default:
						return null;
				}
			}
		}

		public virtual object CurrentSelectedObject
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panelHeader = new System.Windows.Forms.Panel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.selectorComboBox = new System.Windows.Forms.ComboBox();
			this.editorNameLabel = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.saveButton = new System.Windows.Forms.Button();
			this.cancelButton = new System.Windows.Forms.Button();
			this.panelHeader.SuspendLayout();
			this.panel2.SuspendLayout();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// panelHeader
			// 
			this.panelHeader.Controls.AddRange(new System.Windows.Forms.Control[] {
																					  this.panel2,
																					  this.panel1});
			this.panelHeader.Dock = System.Windows.Forms.DockStyle.Top;
			this.panelHeader.Name = "panelHeader";
			this.panelHeader.Size = new System.Drawing.Size(648, 40);
			this.panelHeader.TabIndex = 0;
			// 
			// panel2
			// 
			this.panel2.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.selectorComboBox,
																				 this.editorNameLabel});
			this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(448, 40);
			this.panel2.TabIndex = 5;
			// 
			// selectorComboBox
			// 
			this.selectorComboBox.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.selectorComboBox.Location = new System.Drawing.Point(88, 8);
			this.selectorComboBox.Name = "selectorComboBox";
			this.selectorComboBox.Size = new System.Drawing.Size(360, 21);
			this.selectorComboBox.TabIndex = 3;
			this.selectorComboBox.SelectedValueChanged += new System.EventHandler(this.selectorComboBox_SelectedValueChanged);
			// 
			// editorNameLabel
			// 
			this.editorNameLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.editorNameLabel.Location = new System.Drawing.Point(8, 8);
			this.editorNameLabel.Name = "editorNameLabel";
			this.editorNameLabel.Size = new System.Drawing.Size(80, 21);
			this.editorNameLabel.TabIndex = 2;
			this.editorNameLabel.Text = "Selected Filter";
			this.editorNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panel1
			// 
			this.panel1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.saveButton,
																				 this.cancelButton});
			this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel1.Location = new System.Drawing.Point(448, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(200, 40);
			this.panel1.TabIndex = 4;
			this.panel1.Visible = false;
			// 
			// saveButton
			// 
			this.saveButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.saveButton.Location = new System.Drawing.Point(8, 8);
			this.saveButton.Name = "saveButton";
			this.saveButton.Size = new System.Drawing.Size(80, 23);
			this.saveButton.TabIndex = 4;
			this.saveButton.Text = "Create";
			// 
			// cancelButton
			// 
			this.cancelButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.cancelButton.Location = new System.Drawing.Point(112, 8);
			this.cancelButton.Name = "cancelButton";
			this.cancelButton.Size = new System.Drawing.Size(80, 23);
			this.cancelButton.TabIndex = 3;
			this.cancelButton.Text = "Cancel";
			// 
			// EditableFilterControl
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.panelHeader});
			this.Name = "EditableFilterControl";
			this.Size = new System.Drawing.Size(648, 40);
			this.panelHeader.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.panel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void modeButton_Click(object sender, System.EventArgs e)
		{
			if(this.ModeSelectionEnabled)
			{
				if(this.CurrentMode == SelectionEditorMode.Simple)
				{
					this.CurrentMode = SelectionEditorMode.Advanced;
				}
				else
				{
					this.CurrentMode = SelectionEditorMode.Simple;
				}
			}
		}

		/// <summary>
		/// This function saves the SelectedIndex when the ComboBox is Hidden,
		/// and restores the SelectedIndex when the ComboBox is made Visible again.
		/// The reason for this is if the SelectedIndex is set to -1 and the ComboBox.Visible
		/// property is set to true, the SelectedIndex is reset to 0, which is undesirable.
		/// </summary>
		private void ComboBoxVisibileChange(object sender, EventArgs e)
		{
			if(this.selectorComboBox.Visible)
			{
				this.selectorComboBox.SelectedIndex = this.m_savedSelectedIndex;
			}
			else
			{
				this.m_savedSelectedIndex = this.selectorComboBox.SelectedIndex;
			}
		}

		private void advancedFilterBodyControl1_Load(object sender, System.EventArgs e)
		{
		
		}

		private void selectorComboBox_SelectedValueChanged(object sender, System.EventArgs e)
		{
			
			if(SelectionChanged != null)
			{
				SelectionChanged(sender,e);
			}
		}

	}
}
