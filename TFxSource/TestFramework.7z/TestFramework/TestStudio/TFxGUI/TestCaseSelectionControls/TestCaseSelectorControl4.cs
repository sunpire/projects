using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TestCaseSelectorControl.
	/// </summary>
	public class TestCaseSelectorControl : System.Windows.Forms.UserControl
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		/// 
		private TestInfoCollection m_testcaseslist;
        private System.Windows.Forms.Splitter collapsibleSplitter1;
        private System.Windows.Forms.Panel panelSelectedTestsBottom;
		private Expedia.Test.Framework.TestCasePickerControl pickerSelected;
		private System.Windows.Forms.Panel panelButtons;	
		private System.ComponentModel.Container components = null;

		
		
		public TestInfoCollection TestCasesList
		{
			get
			{
				return m_testcaseslist;

			}
			set
			{
				m_testcaseslist = value;				
			}

		}		


		public TestInfoCollection SeletedTestCases
		{
			get
			{
				return this.pickerSelected.TestCases;
			}
		}

		public TestCaseSelectorControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitForm call
			m_testcaseslist = new TestInfoCollection();	
			this.pickerSelected.AllowDropGrid = true;
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.collapsibleSplitter1 = new System.Windows.Forms.Splitter();
            this.panelSelectedTestsBottom = new System.Windows.Forms.Panel();
            this.pickerSelected = new Expedia.Test.Framework.TestCasePickerControl();
            this.panelButtons = new System.Windows.Forms.Panel();
            this.panelSelectedTestsBottom.SuspendLayout();
            this.SuspendLayout();
            // 
            // collapsibleSplitter1
            // 
            this.collapsibleSplitter1.Dock = System.Windows.Forms.DockStyle.Top;
            this.collapsibleSplitter1.Location = new System.Drawing.Point(0, 0);
            this.collapsibleSplitter1.Name = "collapsibleSplitter1";
            this.collapsibleSplitter1.Size = new System.Drawing.Size(552, 3);
            this.collapsibleSplitter1.TabIndex = 1;
            this.collapsibleSplitter1.TabStop = false;
            // 
            // panelSelectedTestsBottom
            // 
            this.panelSelectedTestsBottom.Controls.Add(this.pickerSelected);
            this.panelSelectedTestsBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelSelectedTestsBottom.Location = new System.Drawing.Point(0, 3);
            this.panelSelectedTestsBottom.Name = "panelSelectedTestsBottom";
            this.panelSelectedTestsBottom.Size = new System.Drawing.Size(552, 437);
            this.panelSelectedTestsBottom.TabIndex = 2;
            // 
            // pickerSelected
            // 
            this.pickerSelected.AllowDropGrid = true;
            this.pickerSelected.Caption = "Selected Tests";
            this.pickerSelected.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pickerSelected.Location = new System.Drawing.Point(0, 0);
            this.pickerSelected.Name = "pickerSelected";
            this.pickerSelected.Size = new System.Drawing.Size(552, 437);
            this.pickerSelected.TabIndex = 12;
            // 
            // panelButtons
            // 
            this.panelButtons.Location = new System.Drawing.Point(184, 48);
            this.panelButtons.Name = "panelButtons";
            this.panelButtons.Size = new System.Drawing.Size(168, 24);
            this.panelButtons.TabIndex = 13;
            // 
            // TestCaseSelectorControl
            // 
            this.Controls.Add(this.panelSelectedTestsBottom);
            this.Controls.Add(this.collapsibleSplitter1);
            this.Name = "TestCaseSelectorControl";
            this.Size = new System.Drawing.Size(552, 440);
            this.panelSelectedTestsBottom.ResumeLayout(false);
            this.ResumeLayout(false);

		}
		#endregion		

        public void Clear()
        {
            TestInfoCollection newlist = new TestInfoCollection();
            this.pickerSelected.ClearSource(true);
            this.pickerSelected.TestCases = newlist;
        }

        public void EditSelectedTestCasesParameter()
        {
            TestInfoCollection selectedTests = this.pickerSelected.SelectedRows;
            TestInfoCollection sourceControl = this.pickerSelected.TestCases;

            if (selectedTests == null)
                return;

            // make sure only one test is selected
            if (selectedTests.Count != 1)
            {
                return;
            }

            TestCase test = selectedTests[0] as TestCase;

            if (test == null)
                return;

            SoftTestEditForm editForm = new SoftTestEditForm(test);
            editForm.ShowDialog();

            // Update the DataGrid on the form to show the latest changes
            this.pickerSelected.TestCases = this.pickerSelected.TestCases;           
        }

        public void DeleteSelectedTestCases()
        {
            TestInfoCollection selectedTests = this.pickerSelected.SelectedRows;
            TestInfoCollection sourceControl = this.pickerSelected.TestCases;
 
            if (selectedTests != null)
            {
                //Remove the selected test cases from the first grid control
                foreach (TestInfo ti in selectedTests)
                {
                    if (sourceControl.Contains(ti))
                    {
                        sourceControl.Remove(ti);
                    }
                }

                this.pickerSelected.ClearSource(true);
                this.pickerSelected.TestCases = sourceControl;

            }         
        }

		public void AppendSelectedTestCases(TestInfoCollection newTestCases)
		{
			if(newTestCases == null)
			{
				return;
			}

			TestInfoCollection selectedTestCases = this.pickerSelected.TestCases;
			//bool pickerTestCasesExists = true;

			if(selectedTestCases == null)
			{
				selectedTestCases = new TestInfoCollection();
			}

			foreach(TestInfo testInfo in newTestCases)
			{
				if(!selectedTestCases.Contains(testInfo))
				{
					selectedTestCases.Add(testInfo);
				}

			}

			this.pickerSelected.ClearSource(true);
			this.pickerSelected.TestCases = selectedTestCases;

		}

		/// <summary>
		/// This function will clear the selected test cases and will append with '
		/// the new list of test cases
		/// </summary>
		/// <param name="newTestCases"></param>

		public void UpdateSelectedTestCases(TestInfoCollection newTestCases)
		{
			TestInfoCollection selectedTestCases = this.pickerSelected.TestCases;

			if(newTestCases == null)
			{
				return;
			}

			if(selectedTestCases == null)
			{
				selectedTestCases = new TestInfoCollection();
			}

			this.pickerSelected.ClearSource(true);
			this.pickerSelected.TestCases = newTestCases;		

		}
	}
}
