using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ConfigSelectionControl.
	/// </summary>
	public class ConfigSelectionControl : RepositoryDelegateUI
	{
		public Expedia.Test.Framework.ConfigPickerControl configPickerControl1;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;


		public ConfigData[] SelectedConfigData
		{
			get
			{
				return this.configPickerControl1.SelectedConfigs;
			}
		}
		public ConfigSelectionControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitForm call

		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			//System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ConfigSelectionControl));
			this.configPickerControl1 = new Expedia.Test.Framework.ConfigPickerControl();
			this.SuspendLayout();
			// 
			// configPickerControl1
			// 
			this.configPickerControl1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.configPickerControl1.Name = "configPickerControl1";
			this.configPickerControl1.Size = new System.Drawing.Size(304, 144);
			this.configPickerControl1.TabIndex = 6;
			// 
			// ConfigSelectionControl
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.configPickerControl1});
			this.Name = "ConfigSelectionControl";
			this.Size = new System.Drawing.Size(304, 144);
			this.ResumeLayout(false);

		}
		#endregion

	}
}
