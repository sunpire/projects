using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TestCaseSelectionControl.
	/// </summary>
	public class TestCaseSelectionControl4 : System.Windows.Forms.UserControl
	{
		private TestInfoCollection m_testcaseslist;
		
//		private UIComponents.XPPanel TestCasePanel;
//		private UIComponents.XPPanel TestCasePickerPanel;
		private System.Windows.Forms.Panel panel1;
		private NJFLib.Controls.CollapsibleSplitter collapsibleSplitter1;
		private System.Windows.Forms.Panel panel2;
		private NJFLib.Controls.CollapsibleSplitter collapsibleSplitter3;
		private Expedia.Test.Framework.TestAreaAndFilterControl testAreaAndFilterControl1;
		private Expedia.Test.Framework.ConfigPickerControl configPickerControl1;
		private Expedia.Test.Framework.TestCaseSelectorControl testCaseSelectorControl1;
		

		/// <summary> 
		/// Required designer variable.
		/// </summary>
		/// 

		public TestInfoCollection TestCasesList
		{
			get
			{
				return m_testcaseslist;
			}
			set
			{
				m_testcaseslist = value;
			}

				
		}
		private System.ComponentModel.Container components = null;

		public TestCaseSelectionControl4()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitForm call
			m_testcaseslist = new TestInfoCollection();

			this.testAreaAndFilterControl1.TestAreaControl.AfterSelect += new Expedia.Test.Framework.TestAreaControl.TestAreaEventHandler(this.testAreaControl_AfterSelect);
//			this.testAreaAndFilterControl1.TestAreaControl.MouseDown += new Expedia.Test.Framework.TestAreaControl.TestAreaEventHandler(this.testAreaControl_MouseDown);


		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
//			this.TestCasePanel = new UIComponents.XPPanel(100);
//			this.TestCasePickerPanel = new UIComponents.XPPanel(100);
			this.panel1 = new System.Windows.Forms.Panel();
			this.testAreaAndFilterControl1 = new Expedia.Test.Framework.TestAreaAndFilterControl();
			this.collapsibleSplitter3 = new NJFLib.Controls.CollapsibleSplitter();
			this.panel2 = new System.Windows.Forms.Panel();
			this.configPickerControl1 = new Expedia.Test.Framework.ConfigPickerControl();
			this.collapsibleSplitter1 = new NJFLib.Controls.CollapsibleSplitter();
			this.testCaseSelectorControl1 = new Expedia.Test.Framework.TestCaseSelectorControl();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.SuspendLayout();
			// 
			// TestCasePanel
			// 
//			this.TestCasePanel.BackColor = System.Drawing.Color.Transparent;
//			this.TestCasePanel.CaptionCornerType = UIComponents.CornerType.Top;
//			this.TestCasePanel.CaptionGradient.End = System.Drawing.Color.Blue;
//			this.TestCasePanel.CaptionGradient.Start = System.Drawing.Color.FromArgb(((System.Byte)(192)), ((System.Byte)(192)), ((System.Byte)(255)));
//			this.TestCasePanel.CaptionGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
//			this.TestCasePanel.CaptionUnderline = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(255)));
//			this.TestCasePanel.Dock = System.Windows.Forms.DockStyle.Top;
//			this.TestCasePanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold);
//			this.TestCasePanel.ForeColor = System.Drawing.SystemColors.WindowText;
//			this.TestCasePanel.HorzAlignment = System.Drawing.StringAlignment.Near;
//			this.TestCasePanel.ImageItems.ImageSet = null;
//			this.TestCasePanel.Name = "TestCasePanel";
//			this.TestCasePanel.PanelGradient.End = System.Drawing.Color.FromArgb(((System.Byte)(214)), ((System.Byte)(223)), ((System.Byte)(247)));
//			this.TestCasePanel.PanelGradient.Start = System.Drawing.Color.FromArgb(((System.Byte)(214)), ((System.Byte)(223)), ((System.Byte)(247)));
//			this.TestCasePanel.PanelGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
//			this.TestCasePanel.TabIndex = 0;
//			this.TestCasePanel.TextColors.Foreground = System.Drawing.Color.FromArgb(((System.Byte)(33)), ((System.Byte)(93)), ((System.Byte)(198)));
//			this.TestCasePanel.TextHighlightColors.Foreground = System.Drawing.Color.FromArgb(((System.Byte)(66)), ((System.Byte)(142)), ((System.Byte)(255)));
//			this.TestCasePanel.VertAlignment = System.Drawing.StringAlignment.Center;
//			// 
//			// TestCasePickerPanel
//			// 
//			this.TestCasePickerPanel.BackColor = System.Drawing.Color.Transparent;
//			this.TestCasePickerPanel.CaptionCornerType = UIComponents.CornerType.Top;
//			this.TestCasePickerPanel.CaptionGradient.End = System.Drawing.Color.FromArgb(((System.Byte)(200)), ((System.Byte)(213)), ((System.Byte)(247)));
//			this.TestCasePickerPanel.CaptionGradient.Start = System.Drawing.Color.White;
//			this.TestCasePickerPanel.CaptionGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
//			this.TestCasePickerPanel.CaptionUnderline = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(255)));
//			this.TestCasePickerPanel.Dock = System.Windows.Forms.DockStyle.Top;
//			this.TestCasePickerPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold);
//			this.TestCasePickerPanel.ForeColor = System.Drawing.SystemColors.WindowText;
//			this.TestCasePickerPanel.HorzAlignment = System.Drawing.StringAlignment.Near;
//			this.TestCasePickerPanel.ImageItems.ImageSet = null;
//			this.TestCasePickerPanel.Location = new System.Drawing.Point(0, 155);
//			this.TestCasePickerPanel.Name = "TestCasePickerPanel";
//			this.TestCasePickerPanel.PanelGradient.End = System.Drawing.Color.FromArgb(((System.Byte)(214)), ((System.Byte)(223)), ((System.Byte)(247)));
//			this.TestCasePickerPanel.PanelGradient.Start = System.Drawing.Color.FromArgb(((System.Byte)(214)), ((System.Byte)(223)), ((System.Byte)(247)));
//			this.TestCasePickerPanel.PanelGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
//			this.TestCasePickerPanel.TabIndex = 0;
//			this.TestCasePickerPanel.TextColors.Foreground = System.Drawing.Color.FromArgb(((System.Byte)(33)), ((System.Byte)(93)), ((System.Byte)(198)));
//			this.TestCasePickerPanel.TextHighlightColors.Foreground = System.Drawing.Color.FromArgb(((System.Byte)(66)), ((System.Byte)(142)), ((System.Byte)(255)));
//			this.TestCasePickerPanel.VertAlignment = System.Drawing.StringAlignment.Center;
			// 
			// panel1
			// 
			this.panel1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.testAreaAndFilterControl1,
																				 this.collapsibleSplitter3,
																				 this.panel2});
			this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(200, 600);
			this.panel1.TabIndex = 8;
			// 
			// testAreaAndFilterControl1
			// 
			this.testAreaAndFilterControl1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.testAreaAndFilterControl1.Name = "testAreaAndFilterControl1";
			this.testAreaAndFilterControl1.Size = new System.Drawing.Size(200, 492);
			this.testAreaAndFilterControl1.TabIndex = 3;
			// 
			// collapsibleSplitter3
			// 
			this.collapsibleSplitter3.AnimationDelay = 20;
			this.collapsibleSplitter3.AnimationStep = 20;
			this.collapsibleSplitter3.BorderStyle3D = System.Windows.Forms.Border3DStyle.Flat;
			this.collapsibleSplitter3.ControlToHide = this.panel2;
			this.collapsibleSplitter3.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.collapsibleSplitter3.ExpandParentForm = false;
			this.collapsibleSplitter3.Location = new System.Drawing.Point(0, 492);
			this.collapsibleSplitter3.Name = "collapsibleSplitter3";
			this.collapsibleSplitter3.TabIndex = 1;
			this.collapsibleSplitter3.TabStop = false;
			this.collapsibleSplitter3.UseAnimations = false;
			this.collapsibleSplitter3.VisualStyle = NJFLib.Controls.VisualStyles.Mozilla;
			// 
			// panel2
			// 
			this.panel2.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.configPickerControl1});
			this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel2.Location = new System.Drawing.Point(0, 500);
			this.panel2.Name = "panel2";
			this.panel2.TabIndex = 0;
			// 
			// configPickerControl1
			// 
			this.configPickerControl1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.configPickerControl1.Name = "configPickerControl1";
			this.configPickerControl1.Size = new System.Drawing.Size(200, 100);
			this.configPickerControl1.TabIndex = 10;
			// 
			// collapsibleSplitter1
			// 
			this.collapsibleSplitter1.AnimationDelay = 20;
			this.collapsibleSplitter1.AnimationStep = 20;
			this.collapsibleSplitter1.BorderStyle3D = System.Windows.Forms.Border3DStyle.Flat;
			this.collapsibleSplitter1.ControlToHide = this.panel1;
			this.collapsibleSplitter1.ExpandParentForm = false;
			this.collapsibleSplitter1.Location = new System.Drawing.Point(200, 0);
			this.collapsibleSplitter1.Name = "collapsibleSplitter1";
			this.collapsibleSplitter1.TabIndex = 9;
			this.collapsibleSplitter1.TabStop = false;
			this.collapsibleSplitter1.UseAnimations = false;
			this.collapsibleSplitter1.VisualStyle = NJFLib.Controls.VisualStyles.Mozilla;
			// 
			// testCaseSelectorControl1
			// 
			this.testCaseSelectorControl1.AllowDrop = true;
			this.testCaseSelectorControl1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.testCaseSelectorControl1.Location = new System.Drawing.Point(208, 0);
			this.testCaseSelectorControl1.Name = "testCaseSelectorControl1";
			this.testCaseSelectorControl1.Size = new System.Drawing.Size(472, 600);
			this.testCaseSelectorControl1.TabIndex = 10;
			this.testCaseSelectorControl1.TestCasesList = null;
			// 
			// TestCaseSelectionControl4
			// 
			this.AllowDrop = true;
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.testCaseSelectorControl1,
																		  this.collapsibleSplitter1,
																		  this.panel1});
			this.Name = "TestCaseSelectionControl4";
			this.Size = new System.Drawing.Size(680, 600);
			this.panel1.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void testAreaControl_AfterSelect(object sender, Expedia.Test.Framework.TestAreaEventArgs e)
		{
			//Get all the test cases and assign it to the TestCasePanel Grid Control
		
			TestArea ta;
			ArrayList TestCases = new ArrayList();
			TestInfoCollection TestCasesCollection = new TestInfoCollection();
			

			if((e.Test != null) && (e.Test.GetType() == typeof(TFxTestArea)))
			{
				ta = e.Test as TestArea;
				TestCases = ta.GetAllTestCases();

				if(TestCases != null)
				{
					foreach(TestInfo ti in TestCases)
					{
						TestCasesCollection.Add(ti);
					}
				}

				TestCasesList = TestCasesCollection;

				//Send it to the TestSelectorControl

				this.testCaseSelectorControl1.TestCasesList = TestCasesList;

			}	 
		}

		
	}
}
