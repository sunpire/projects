using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for TestCasePickerControl.
    /// </summary>
    /// 

    public delegate void TestCaseSelectionChangeHandler(TestInfoCollection testCases);
    public delegate void TestCaseDeleteHandler(TestInfo testInfo);
    public delegate void TestCaseDoubleClickHandler(TestInfo testInfo);

    public class TestCasePickerControl : System.Windows.Forms.UserControl
    {
        private TestInfoCollection m_testcases;
        private string m_trimText = "";
        private bool m_firstClick = true;
        private bool m_doubleClick = false;
        private int clickedRow = -1;
        private DateTime clickedTime = DateTime.Now;

        private System.Windows.Forms.DataGrid dataGrid1;
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;
        public event TestCaseSelectionChangeHandler onTestCaseSelectionChange;
        public event TestCaseDeleteHandler onTestCaseDelete;
        public event TestCaseDoubleClickHandler onTestCaseDoubleClick;

        public TestCasePickerControl()
        {
            // This call is required by the Windows.Forms Form Designer.
            InitializeComponent();

            // TODO: Add any initialization after the InitForm call
            m_testcases = new TestInfoCollection();

        }

        public string Caption
        {
            get
            {
                return dataGrid1.CaptionText;
            }
            set
            {
                dataGrid1.CaptionText = value;
            }
        }

        public TestInfoCollection SelectedRows
        {
            get
            {
                return GetSelectedRows();
            }
        }

        public bool AllowDropGrid
        {
            set
            {
                this.dataGrid1.AllowDrop = value;
            }
            get
            {
                return this.dataGrid1.AllowDrop;
            }
        }

        public TestInfoCollection TestCases
        {
            set
            {
                m_testcases = value;
                BindDataGrid(value);
                SetCaption();
            }
            get
            {
                return m_testcases;
                //return GetTestInfoCollection(this.dataGrid1.DataSource as DataTable);
            }
        }

        public void ClearSource(bool value)
        {
            if (value)
            {
                this.dataGrid1.DataSource = null;
            }
        }

        private void BindDataGrid(object TestCasesList)
        {
            DataTable dt;
            int columnWidth = 0;
            int c_randomWidth = 30;

            TestInfoCollection currentTests = this.TestCases;

            if (currentTests != null)
            {
                currentTests.Sort();
                dt = new DataTable("TestCases");

                dt.RowDeleting += new DataRowChangeEventHandler(this.RowsDeletingEvent);

                DataColumn col1 = dt.Columns.Add("SoftTest Name");
                dt.Columns.Add("Method Name");
                dt.Columns.Add("Disabled");
                dt.Columns.Add("SoftTestGuid");

                col1.ReadOnly = true;

                foreach (TestInfo ti in currentTests)
                {
                    DataRow row = dt.NewRow();

                    TestCase test = ti as TestCase;
                    if (test == null)
                        continue;

                    if (String.IsNullOrEmpty(test.SoftTestName))
                        row["SoftTest Name"] = ti.FullName;
                    else
                        row["SoftTest Name"] = test.SoftTestName + ((test.SoftTestId > 0) ? " (" + Convert.ToString(test.SoftTestId) + ")" : "");

                    row["Method Name"] = ti.FullName;
                    row["Disabled"] = ti.Disabled;
                    row["SoftTestGuid"] = test.SoftTestGuid;

                    //Get the columnWidth
                    if (ti.FullName.Length > columnWidth)
                    {
                        columnWidth = ti.FullName.Length;
                    }
                    dt.Rows.Add(row);
                }

                dt.DefaultView.AllowEdit = false;
                dt.DefaultView.AllowNew = false;
                dt.DefaultView.AllowDelete = true;

                this.dataGrid1.DataSource = dt;

                this.dataGrid1.Font = new System.Drawing.Font("Verdana", 8, System.Drawing.FontStyle.Regular);

                this.dataGrid1.TableStyles.Clear();

                DataGridTableStyle dgts = new DataGridTableStyle();
                dgts.MappingName = "TestCases";

                DataGridColoredTextBoxColumn nameColumn = new DataGridColoredTextBoxColumn();
                nameColumn.MappingName = "SoftTest Name";
                nameColumn.HeaderText = "SoftTest Name";
                nameColumn.Width = (this.dataGrid1.Width * (columnWidth + c_randomWidth)) / 100;
                dgts.GridColumnStyles.Add(nameColumn);

                DataGridColoredTextBoxColumn methodNameColumn = new DataGridColoredTextBoxColumn();
                methodNameColumn.MappingName = "Method Name";
                methodNameColumn.HeaderText = "Method Name";
                methodNameColumn.Width = (this.dataGrid1.Width * (columnWidth + c_randomWidth)) / 100;
                dgts.GridColumnStyles.Add(methodNameColumn);

                DataGridColoredTextBoxColumn SoftTestGuidColumn = new DataGridColoredTextBoxColumn();
                SoftTestGuidColumn.MappingName = "SoftTestGuid";
                SoftTestGuidColumn.HeaderText = "Method NameSoftTestGuid";
                SoftTestGuidColumn.Width = 1;
                dgts.GridColumnStyles.Add(SoftTestGuidColumn);

                this.dataGrid1.TableStyles.Add(dgts);
            }
        }

        int m_SelectedTestCaseCount;

        public int SelectedTestCaseCount
        {
            set
            {
                m_SelectedTestCaseCount = value;

                Control c = this.Parent;

                while (c != null && c.GetType() != typeof(GroupBox))
                {
                    c = c.Parent;
                }

                if (c != null)
                {
                    c.Text = "Selected Test Case (" + m_SelectedTestCaseCount + ")";
                }
            }
        }

        //Get the list of rows that are selected 
        private TestInfoCollection GetSelectedRows()
        {
            int index = 0;
            DataTable dataTable = null;

            dataTable = this.dataGrid1.DataSource as DataTable;
            if (dataTable != null)
            {
                index = dataTable.Rows.Count;
            }

            TestInfoCollection Tests = new TestInfoCollection();
            TestInfo ti;

            for (int i = 0; i < index; i++)
            {
                if (this.dataGrid1.IsSelected(i))
                {
                    ti = this.FindTestName(new Guid(this.dataGrid1[i, 2].ToString()), this.dataGrid1[i, 1].ToString(), this.TestCases);

                    if (ti != null)
                    {
                        Tests.Add(ti);
                    }
                }
            }

            return Tests;
        }

        /// <summary>
        /// Finds all the TestInfo Objects that have the given TestFullName
        /// </summary>
        /// <param name="softTestName"></param>
        /// <param name="methodName"></param>
        /// <param name="testCases"></param>
        /// <returns></returns>
        public TestInfo FindTestName(Guid softTestGuid, string methodName, TestInfoCollection testCases)
        {

            foreach (TestInfo ti in testCases)
            {
                TestCase test = ti as TestCase;

                if ((test != null) && (test.SoftTestGuid == softTestGuid))
                {
                    return test;
                }
            }

            return null;
        }

        /// <summary>
        /// This function will get the list of Test Cases from the DataTable
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private TestInfoCollection GetTestInfoCollection(DataTable data)
        {
            TestInfoCollection tests = new TestInfoCollection();

            if (data != null)
            {
                foreach (DataRow row in data.Rows)
                {
                    tests.Add(new TestCase(null, row["TestName"].ToString()));
                }

                return tests;
            }
            return null;
        }

        public void SetCaption()
        {
            if (this.TestCases != null)
            {
                if (this.m_trimText != "")
                {
                    this.Caption = this.Caption.TrimEnd(m_trimText.ToCharArray());
                }

                m_trimText = "(" + this.TestCases.Count + ")";
                this.Caption = this.Caption + m_trimText;
            }
        }

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code
        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGrid1 = new System.Windows.Forms.DataGrid();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGrid1
            // 
            this.dataGrid1.AllowDrop = true;
            this.dataGrid1.DataMember = "";
            this.dataGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dataGrid1.Location = new System.Drawing.Point(0, 0);
            this.dataGrid1.Name = "dataGrid1";
            this.dataGrid1.Size = new System.Drawing.Size(200, 216);
            this.dataGrid1.TabIndex = 1;
            this.dataGrid1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.dataGrid1_MouseUp);
            this.dataGrid1.DragDrop += new System.Windows.Forms.DragEventHandler(this.dataGrid1_DragDrop);
            this.dataGrid1.DragEnter += new System.Windows.Forms.DragEventHandler(this.dataGrid1_DragEnter);
            // 
            // TestCasePickerControl
            // 
            this.Controls.Add(this.dataGrid1);
            this.Name = "TestCasePickerControl";
            this.Size = new System.Drawing.Size(200, 216);
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
            this.ResumeLayout(false);

        }
        #endregion

        private void dataGrid1_DragEnter(object sender, System.Windows.Forms.DragEventArgs e)
        {
            TestInfoCollection testCasesList = null;

            testCasesList = e.Data.GetData(typeof(TestInfoCollection)) as TestInfoCollection;
            if (testCasesList != null)
            {
                e.Effect = DragDropEffects.Copy;
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }
        }

        private void dataGrid1_DragDrop(object sender, System.Windows.Forms.DragEventArgs e)
        {
            TestInfoCollection testCasesList = null;

            string[] data = e.Data.GetFormats();

            if ((data == null) && (data.Length == 0))
            {
                return;
            }

            testCasesList = e.Data.GetData(typeof(TestInfoCollection)) as TestInfoCollection;

            if (testCasesList != null)
            {
                GetTestCasesList(testCasesList);
                this.TestCases = TestCases;
            }

            if (onTestCaseSelectionChange != null)
            {
                onTestCaseSelectionChange(this.TestCases);
            }
        }

        private void RowsDeletingEvent(object sender, DataRowChangeEventArgs e)
        {
            string methodName = null;
            string softTestGuid = null;
            TestInfo testInfo = null;

            if (e.Action == DataRowAction.Delete)
            {
                methodName = e.Row["Method Name"].ToString();
                softTestGuid = e.Row["SoftTestGuid"].ToString();
                testInfo = FindTestName(new Guid(softTestGuid), methodName, this.TestCases);

                if (testInfo != null)
                {
                    this.TestCases.Remove(testInfo);
                    if (onTestCaseDelete != null)
                    {
                        onTestCaseDelete(testInfo);
                    }
                }

                SetCaption();
            }
        }

        public void GetTestCasesList(TestInfoCollection newTestCases)
        {
            if (newTestCases == null)
            {
                return;
            }

            foreach (TestInfo ti in newTestCases)
            {
                // Always clone the test when drag and drop into the selected test grid
                TestCase test = (ti as TestCase).Clone() as TestCase;
                this.TestCases.Add(test);
            }
        }

        public void dataGrid1_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            DataGrid.HitTestInfo hitTest;
            DateTime currentTime;
            DataTable dt;
            DataRow row;
            string methodName;
            string softTestGuid;
            TestInfo testInfo;
            TimeSpan elapsedTime;
            int doubleClickTime = 200;

            hitTest = this.dataGrid1.HitTest(e.X, e.Y);

            //select the row when user clicks on a cell in that row
            if (hitTest != null && hitTest.Type == DataGrid.HitTestType.Cell)
            {
                dataGrid1.CurrentCell = new DataGridCell(hitTest.Row, hitTest.Column);
                dataGrid1.Select(hitTest.Row);
            }

            if (hitTest != null && hitTest.Row >= 0)
            {
                if (m_firstClick)
                {
                    clickedRow = hitTest.Row;
                    m_firstClick = false;
                    m_doubleClick = false;
                    clickedTime = DateTime.Now;
                }
                else
                {
                    //Second Click
                    if (clickedRow == hitTest.Row)
                    {
                        //DoubleClick
                        currentTime = DateTime.Now;
                        elapsedTime = currentTime - clickedTime;

                        if (elapsedTime.Milliseconds < doubleClickTime)
                        {
                            m_doubleClick = true;
                        }
                        else
                        {
                            m_firstClick = true;
                        }
                    }
                    else
                    {
                        //Then clicked on a new row
                        m_firstClick = false;
                        clickedRow = hitTest.Row;
                    }
                }
            }
            else
            {
                m_firstClick = true;
            }

            if (m_doubleClick)
            {
                m_firstClick = true;
                m_doubleClick = true;
                //Raise the event to add the test case to the Test Case Selected List
                dt = this.dataGrid1.DataSource as DataTable;
                if (dt.Rows.Count > clickedRow)
                {
                    row = dt.Rows[clickedRow];
                    methodName = row["Method Name"].ToString();
                    softTestGuid = row["SoftTestGuid"].ToString();
                    testInfo = FindTestName(new Guid(softTestGuid), methodName, this.TestCases);

                    if (testInfo != null)
                    {
                        if (onTestCaseDoubleClick != null)
                        {
                            onTestCaseDoubleClick(testInfo);
                        }
                    }
                }
            }
        }
    }
}
