using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using Expedia.Test.Framework;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for TestAreaAndFilterControl.
    /// </summary>
    public class TestAreaAndFilterControl : RepositoryDelegateUI
    {
        //private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panelTestAreaandFilter;
        private System.Windows.Forms.Panel panelFilter;
        private NJFLib.Controls.CollapsibleSplitter collapsibleSplitter1;
        private Expedia.Test.Framework.TestAreaControl testAreaControl;

        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;
        private Expedia.Test.Framework.EditableFilterControl editableFilterControl1;

        public TestAreaControl TestAreaControl
        {
            get
            {
                return this.testAreaControl;
            }
        }

        private ArrayList m_rootTestAreas = new ArrayList();

        public ArrayList RootTestAreas
        {
            get { return m_rootTestAreas; }
        }

        public void AddRootTestArea(TestArea area)
        {
            m_rootTestAreas.Add(area);
        }

        public void ClearRootTestAreas()
        {
            m_rootTestAreas.Clear();
        }

        public TestInfo FindTest(string testFullPath)
        {
            foreach (TestArea area in m_rootTestAreas)
            {
                TestInfo info = area.FindTest(testFullPath);
                if (info != null)
                    return info;
            }
            return null;
        }

        public TestAreaAndFilterControl()
        {
            // This call is required by the Windows.Forms Form Designer.
            InitializeComponent();
        }

        public void TreeListCompleted(NotificationRequest request)
        {

            DataNotification dataRequest = request as DataNotification;

            if (dataRequest != null)
            {

                TestCaseListRequest testList = dataRequest.Request as TestCaseListRequest;

                this.testAreaControl.ClearRootTestAreas();
                this.ClearRootTestAreas();

                if (testList != null && testList.TestAreaRoots != null && testList.TestAreaRoots.Length != 0)
                {
                    foreach (TestArea area in testList.TestAreaRoots)
                    {
                        this.testAreaControl.AddRootTestArea(area);
                        this.AddRootTestArea(area);
                    }
                }

                TestTreeChangeNotification change = new TestTreeChangeNotification(this.testAreaControl.RootTestAreas);
                NotifyUI(change);

                ValidateAssignmentsNotification validate = new ValidateAssignmentsNotification();
                NotifyUIAsync(validate);

                ValidateTestCasesNotification testCasesValidate = new ValidateTestCasesNotification();
                NotifyUIAsync(testCasesValidate);

            }

            this.Cursor = Cursors.Default;

        }


        public void LoadTree()
        {
            TestCaseListRequest testList = new TestCaseListRequest(RepositoryRequestType.Get);
            testList.BuildName = GetBuildName();
            NotificationRequestHandler handler = new NotificationRequestHandler(this.TreeListCompleted);
            GetDataAsync(testList, handler);
            this.Cursor = Cursors.WaitCursor;
        }

        //public void LoadTree(string buildname)
        //{
        //    TestCaseListRequest testList = new TestCaseListRequest(RepositoryRequestType.Get);
        //    testList.BuildName = buildname;
        //    NotificationRequestHandler handler = new NotificationRequestHandler(this.TreeListCompleted);
        //    GetDataAsync(testList, handler);
        //    this.Cursor = Cursors.WaitCursor;
        //}

        public void LoadTree(string requestType, string name)
        {
            TestCaseListRequest testList = new TestCaseListRequest(RepositoryRequestType.Get);
            switch (requestType)
            {
                case "Release": testList.ReleaseName = name;
                    break;
                case "Build": testList.BuildName = name;
                    break;                   
            }

            NotificationRequestHandler handler = new NotificationRequestHandler(this.TreeListCompleted);
            GetDataAsync(testList, handler);
            this.Cursor = Cursors.WaitCursor;

        }

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code
        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelTestAreaandFilter = new System.Windows.Forms.Panel();
            this.testAreaControl = new Expedia.Test.Framework.TestAreaControl();
            this.collapsibleSplitter1 = new NJFLib.Controls.CollapsibleSplitter();
            this.panelFilter = new System.Windows.Forms.Panel();
            this.editableFilterControl1 = new Expedia.Test.Framework.EditableFilterControl();
            this.panelTestAreaandFilter.SuspendLayout();
            this.panelFilter.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelTestAreaandFilter
            // 
            this.panelTestAreaandFilter.Controls.AddRange(new System.Windows.Forms.Control[] {
																								 this.testAreaControl,
																								 this.collapsibleSplitter1,
																								 this.panelFilter});
            this.panelTestAreaandFilter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTestAreaandFilter.Name = "panelTestAreaandFilter";
            this.panelTestAreaandFilter.Size = new System.Drawing.Size(424, 520);
            this.panelTestAreaandFilter.TabIndex = 1;
            // 
            // testAreaControl
            // 
            this.testAreaControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.testAreaControl.EnableEmptyTestArea = false;
            this.testAreaControl.EnableTestCases = false;
            this.testAreaControl.Filter = null;
            this.testAreaControl.Location = new System.Drawing.Point(0, 32);
            this.testAreaControl.Name = "testAreaControl";
            this.testAreaControl.Size = new System.Drawing.Size(424, 488);
            this.testAreaControl.TabIndex = 3;
            this.testAreaControl.Load += new System.EventHandler(this.testAreaControl_Load);
            // 
            // collapsibleSplitter1
            // 
            this.collapsibleSplitter1.AnimationDelay = 20;
            this.collapsibleSplitter1.AnimationStep = 20;
            this.collapsibleSplitter1.BorderStyle3D = System.Windows.Forms.Border3DStyle.Flat;
            this.collapsibleSplitter1.ControlToHide = this.panelFilter;
            this.collapsibleSplitter1.Dock = System.Windows.Forms.DockStyle.Top;
            this.collapsibleSplitter1.ExpandParentForm = false;
            this.collapsibleSplitter1.Location = new System.Drawing.Point(0, 32);
            this.collapsibleSplitter1.Name = "collapsibleSplitter1";
            this.collapsibleSplitter1.TabIndex = 1;
            this.collapsibleSplitter1.TabStop = false;
            this.collapsibleSplitter1.UseAnimations = false;
            this.collapsibleSplitter1.Visible = false;
            this.collapsibleSplitter1.VisualStyle = NJFLib.Controls.VisualStyles.Mozilla;
            // 
            // panelFilter
            // 
            this.panelFilter.Controls.AddRange(new System.Windows.Forms.Control[] {
																					  this.editableFilterControl1});
            this.panelFilter.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelFilter.Name = "panelFilter";
            this.panelFilter.Size = new System.Drawing.Size(424, 32);
            this.panelFilter.TabIndex = 0;
            // 
            // editableFilterControl1
            // 
            this.editableFilterControl1.CurrentMode = Expedia.Test.Framework.SelectionEditorMode.Simple;
            this.editableFilterControl1.CurrentSaveMode = Expedia.Test.Framework.SaveSelectionMode.CreateNew;
            this.editableFilterControl1.CurrentSelectedObject = null;
            this.editableFilterControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.editableFilterControl1.Editable = false;
            this.editableFilterControl1.EditorName = "Selected Filter";
            this.editableFilterControl1.ModeSelectionEnabled = false;
            this.editableFilterControl1.Name = "editableFilterControl1";
            this.editableFilterControl1.Size = new System.Drawing.Size(424, 32);
            this.editableFilterControl1.TabIndex = 0;
            // 
            // TestAreaAndFilterControl
            // 
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.panelTestAreaandFilter});
            this.Name = "TestAreaAndFilterControl";
            this.Size = new System.Drawing.Size(424, 520);
            this.panelTestAreaandFilter.ResumeLayout(false);
            this.panelFilter.ResumeLayout(false);
            this.ResumeLayout(false);

        }
        #endregion


        private void HandleFileOpenNotication(NotificationRequest request)
        {
            LoadTree();
        }




        private void testAreaControl_Load(object sender, System.EventArgs e)
        {

            AddNotificationHandler(typeof(FileOpenNotification), new NotificationRequestHandler(this.HandleFileOpenNotication));
            AddNotificationHandler(typeof(FilterChangeNotification), new NotificationRequestHandler(this.HandleFilterChangeNotification));


            this.testAreaControl.EnableTestCases = true;
            this.testAreaControl.EnableEmptyTestArea = false;

            LoadTree();
            LoadFilters();

        }

        private void selectionControl1_SelectionChangeCommitted(object sender, System.EventArgs e)
        {
            //Display the panel control
            if (!this.panelFilter.Visible)
            {
                this.panelFilter.Visible = true;
            }
        }

        private void editableFilterControl1_SelectionChanged(object sender, System.EventArgs e)
        {
            string c_filterName = "No Filter";
            FieldExpression fieldExpression = new FieldExpression();
            FilterExpression filterExpression = new FilterExpression(typeof(TestCase));

            if (this.editableFilterControl1.SelectorComboBox.SelectedValue.ToString().CompareTo(c_filterName) != 0)
            {
                FilterRequest filterRequest = new FilterRequest(RepositoryRequestType.Get);
                filterRequest.FilterType = typeof(TestCase);
                filterRequest.InstanceName = this.editableFilterControl1.SelectorComboBox.SelectedValue.ToString();
                this.GetData(filterRequest);

                //Generated the FieldExpressionData
                if (filterRequest.Filter != null)
                {
                    DataSet ds = filterRequest.Filter.GetDataSet(filterRequest.Filter.dataset);
                    fieldExpression.ExpressionDataTable = ds.Tables[0];
                    this.testAreaControl.Filter = filterExpression.GenerateFilterExpression(fieldExpression);
                }
            }
            else
            {
                //Load the Tree with no filter selected
                this.testAreaControl.Filter = null;
            }

            //Send the notification to the test run editor to update itself
            TestTreeChangeNotification change = new TestTreeChangeNotification(this.testAreaControl.RootTestAreas);
            NotifyUI(change);

        }

        private void LoadFilters()
        {
            //Load Filters
            FilterListRequest request = new FilterListRequest();
            request.FilterType = typeof(TestCase);
            this.GetData(request);

            if (request.Objects.Length > 0)
            {
                this.editableFilterControl1.SelectionChanged -= new System.EventHandler(this.editableFilterControl1_SelectionChanged);

                //To add the No Filter option to the drop down
                ArrayList tests = new ArrayList();
                tests.Add("No Filter");
                tests.AddRange(request.Objects);

                this.editableFilterControl1.SelectorComboBox.DataSource = tests;
                this.editableFilterControl1.SelectionChanged += new System.EventHandler(this.editableFilterControl1_SelectionChanged);
            }

        }

        private void HandleFilterChangeNotification(NotificationRequest request)
        {
            LoadFilters();
        }

        private string GetBuildName()
        {
            UserSettingRequest userSettings = new UserSettingRequest(RepositoryRequestType.Get);
            this.GetData(userSettings);

            TestStudioUsersSetting setting = userSettings.Settings as TestStudioUsersSetting;

            if (setting != null && setting.DefaultBuildName != null)
            {
                return setting.DefaultBuildName;
            }
            return null;
        }
    }
}
