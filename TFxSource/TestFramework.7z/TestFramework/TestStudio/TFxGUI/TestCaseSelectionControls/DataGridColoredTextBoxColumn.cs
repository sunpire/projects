using System.Windows.Forms;
using System;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace Expedia.Test.Framework
{
	public class DataGridColoredTextBoxColumn : DataGridTextBoxColumn 
 
	{ 
 
		protected override void Paint(System.Drawing.Graphics g, 
 
			System.Drawing.Rectangle bounds, System.Windows.Forms.CurrencyManager 
 
			source, int rowNum, System.Drawing.Brush backBrush, System.Drawing.Brush 
 
			foreBrush, bool alignToRight) 
 
		{ 
 
			try
			{ 

				DataRowView view = source.Current as DataRowView ;
				DataTable dt = view.Row.Table;

				DataRow row = dt.Rows[rowNum];

 
				if( row != null) 
				{ 
					if (row["Disabled"].ToString().ToLower() == "true")
					{
						backBrush = new SolidBrush(Color.Gray); 
					}
				}
 
 
			} 
 
			catch(Exception ){ /* empty catch */ } 
 
			finally
			{ 
 
				// make sure the base class gets called to do the drawing with 
 
				// the possibly changed brushes 
 
				base.Paint(g, bounds, source, rowNum, backBrush, foreBrush, alignToRight); 
 
			} 
 
		} 
 
	} 
}
 

