//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: BaseSelectionEditorControl.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
	public enum SelectionEditorMode
	{
		Simple,
		Advanced
	}

	public enum SaveSelectionMode
	{
		Disabled,
		CreateNew,
		Overwrite
	}

	public class SelectionEditorEventArgs : EventArgs
	{
		public SelectionEditorEventArgs(SelectionEditorMode currentMode)
		{
			this.CurrentMode = currentMode;
		}

		public readonly SelectionEditorMode CurrentMode;
	}

	/// <summary>
	/// Summary description for BaseSelectionEditorControl.
	/// </summary>
	public class BaseSelectionEditorControl : System.Windows.Forms.UserControl
	{
		public delegate void SelectionEditorModeChangeEventHandler(object sender, SelectionEditorEventArgs e);

		[Category("Behavior"),
		 Description("Raised when the SelectionEditorMode changes")]
		public event SelectionEditorModeChangeEventHandler SelectionEditorModeChanged;
//		public virtual event EventHandler EditorDone;
//		public virtual event EventHandler EditorCancel;
		
		public event EventHandler SaveButtonClick
		{
			add
			{
				this.saveButton.Click += value;
			}
			remove
			{
				this.saveButton.Click -= value;
			}
		}

		public event EventHandler CancelButtonClick
		{
			add
			{
				this.cancelButton.Click += value;
			}
			remove
			{
				this.cancelButton.Click -= value;
			}
		}

		private SelectionEditorMode m_currentMode = SelectionEditorMode.Simple;
		private int m_savedSelectedIndex = -1;
		protected UserControl simpleEditorControl;
		protected UserControl advancedEditorControl;

		private System.Windows.Forms.Panel headerPanel;
		protected System.Windows.Forms.Panel bodyPanel;
		private System.Windows.Forms.Button cancelButton;
		private System.Windows.Forms.Button saveButton;
		private System.Windows.Forms.Button modeButton;
		private System.Windows.Forms.Label editorNameLabel;
		private System.Windows.Forms.ComboBox selectorComboBox;
		private System.Windows.Forms.Panel panel1;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public BaseSelectionEditorControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
		}

		public string EditorName
		{
			get
			{
				return this.editorNameLabel.Text;
			}
			set
			{
				this.editorNameLabel.Text = value;
			}
		}

		public ComboBox SelectorComboBox
		{
			get
			{
				return this.selectorComboBox;
			}
		}

		public bool ModeSelectionEnabled
		{
			get
			{
				return this.modeButton.Visible;
			}
			set
			{
				this.modeButton.Visible = value;
			}
		}

		public SaveSelectionMode CurrentSaveMode
		{
			get
			{
				if(this.saveButton.Text == "Create")
				{
					return SaveSelectionMode.CreateNew;
				}
				else
				{
					return SaveSelectionMode.Overwrite;
				}
			}
			set
			{
				switch(value)
				{
					case SaveSelectionMode.CreateNew:
						this.saveButton.Text = "Create";
						this.saveButton.Enabled = true;
						break;
					case SaveSelectionMode.Overwrite:
						this.saveButton.Text = "Overwrite";
						this.saveButton.Enabled = true;
						break;
					case SaveSelectionMode.Disabled:
						this.saveButton.Text = "Invalid Name";
						this.saveButton.Enabled = false;
						break;
				}
			}
		}

		public SelectionEditorMode CurrentMode
		{
			get
			{
				return this.m_currentMode;
			}
			set
			{
				if(this.m_currentMode != value && this.ModeSelectionEnabled)
				{
					switch(value)
					{
						case SelectionEditorMode.Simple:
							this.modeButton.Text = "Advanced";
							break;
						case SelectionEditorMode.Advanced:
							this.modeButton.Text = "Simple";
							break;
					}
					this.m_currentMode = value;
					SelectionEditorModeChanged(this, new SelectionEditorEventArgs(this.CurrentMode));
				}
			}
		}

		public UserControl CurrentEditorControl
		{
			get
			{
				switch(this.CurrentMode)
				{
					case SelectionEditorMode.Simple:
						return this.simpleEditorControl;
					case SelectionEditorMode.Advanced:
						return this.advancedEditorControl;
					default:
						return null;
				}
			}
		}

		public virtual object CurrentSelectedObject
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.headerPanel = new System.Windows.Forms.Panel();
			this.selectorComboBox = new System.Windows.Forms.ComboBox();
			this.editorNameLabel = new System.Windows.Forms.Label();
			this.bodyPanel = new System.Windows.Forms.Panel();
			this.modeButton = new System.Windows.Forms.Button();
			this.saveButton = new System.Windows.Forms.Button();
			this.cancelButton = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.headerPanel.SuspendLayout();
			this.bodyPanel.SuspendLayout();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// headerPanel
			// 
			this.headerPanel.Controls.AddRange(new System.Windows.Forms.Control[] {
																					  this.selectorComboBox,
																					  this.editorNameLabel});
			this.headerPanel.Dock = System.Windows.Forms.DockStyle.Top;
			this.headerPanel.Name = "headerPanel";
			this.headerPanel.Size = new System.Drawing.Size(488, 40);
			this.headerPanel.TabIndex = 0;
			// 
			// selectorComboBox
			// 
			this.selectorComboBox.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.selectorComboBox.Location = new System.Drawing.Point(88, 8);
			this.selectorComboBox.Name = "selectorComboBox";
			this.selectorComboBox.Size = new System.Drawing.Size(384, 21);
			this.selectorComboBox.TabIndex = 1;
			this.selectorComboBox.VisibleChanged += new System.EventHandler(this.ComboBoxVisibileChange);
			// 
			// editorNameLabel
			// 
			this.editorNameLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.editorNameLabel.Location = new System.Drawing.Point(8, 8);
			this.editorNameLabel.Name = "editorNameLabel";
			this.editorNameLabel.Size = new System.Drawing.Size(80, 21);
			this.editorNameLabel.TabIndex = 0;
			this.editorNameLabel.Text = "EditorName";
			this.editorNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// bodyPanel
			// 
			this.bodyPanel.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.panel1});
			this.bodyPanel.Dock = System.Windows.Forms.DockStyle.Fill;
			this.bodyPanel.DockPadding.All = 8;
			this.bodyPanel.Location = new System.Drawing.Point(0, 40);
			this.bodyPanel.Name = "bodyPanel";
			this.bodyPanel.Size = new System.Drawing.Size(488, 312);
			this.bodyPanel.TabIndex = 1;
			// 
			// modeButton
			// 
			this.modeButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.modeButton.Location = new System.Drawing.Point(184, 0);
			this.modeButton.Name = "modeButton";
			this.modeButton.Size = new System.Drawing.Size(80, 23);
			this.modeButton.TabIndex = 2;
			this.modeButton.Text = "Advanced";
			this.modeButton.Visible = false;
			this.modeButton.Click += new System.EventHandler(this.modeButton_Click);
			// 
			// saveButton
			// 
			this.saveButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.saveButton.Location = new System.Drawing.Point(280, 0);
			this.saveButton.Name = "saveButton";
			this.saveButton.Size = new System.Drawing.Size(80, 23);
			this.saveButton.TabIndex = 1;
			this.saveButton.Text = "Create";
			// 
			// cancelButton
			// 
			this.cancelButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.cancelButton.Location = new System.Drawing.Point(376, 0);
			this.cancelButton.Name = "cancelButton";
			this.cancelButton.Size = new System.Drawing.Size(80, 23);
			this.cancelButton.TabIndex = 0;
			this.cancelButton.Text = "Cancel";
			// 
			// panel1
			// 
			this.panel1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.modeButton,
																				 this.saveButton,
																				 this.cancelButton});
			this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel1.Location = new System.Drawing.Point(8, 280);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(472, 24);
			this.panel1.TabIndex = 3;
			// 
			// BaseSelectionEditorControl
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {this.headerPanel,
																		  this.bodyPanel
																						});
			this.Name = "BaseSelectionEditorControl";
			this.Size = new System.Drawing.Size(488, 352);
			this.headerPanel.ResumeLayout(false);
			this.bodyPanel.ResumeLayout(false);
			this.panel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void modeButton_Click(object sender, System.EventArgs e)
		{
			if(this.ModeSelectionEnabled)
			{
				if(this.CurrentMode == SelectionEditorMode.Simple)
				{
					this.CurrentMode = SelectionEditorMode.Advanced;
				}
				else
				{
					this.CurrentMode = SelectionEditorMode.Simple;
				}
			}
		}

		/// <summary>
		/// This function saves the SelectedIndex when the ComboBox is Hidden,
		/// and restores the SelectedIndex when the ComboBox is made Visible again.
		/// The reason for this is if the SelectedIndex is set to -1 and the ComboBox.Visible
		/// property is set to true, the SelectedIndex is reset to 0, which is undesirable.
		/// </summary>
		private void ComboBoxVisibileChange(object sender, EventArgs e)
		{
			if(this.selectorComboBox.Visible)
			{
				this.selectorComboBox.SelectedIndex = this.m_savedSelectedIndex;
			}
			else
			{
				this.m_savedSelectedIndex = this.selectorComboBox.SelectedIndex;
			}
		}

	}
}
