//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: LabelEventArgs.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for LabelEventArgs.
	/// </summary>
	public class LabelEventArgs
	{
		string m_label;

		public string Label
		{
			get
			{
				return m_label;
			}
			set
			{
				m_label = value;
			}
		}
		public LabelEventArgs()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
