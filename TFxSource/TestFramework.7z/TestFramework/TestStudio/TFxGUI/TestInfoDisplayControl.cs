//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: TestInfoDialogControl.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;


namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TestInfoDisplayControl.
	/// </summary>
	public class TestInfoDisplayControl : System.Windows.Forms.UserControl
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		
		private Expedia.Test.Framework.TestAreaInfoControl testAreaInfoControl;
		private Expedia.Test.Framework.TestCaseInfoControl testCaseInfoControl;


		#region Properties
		//Properties

		private TestInfo m_testInformation;

		public TestInfo TestInformation
		{
			get
			{
				return m_testInformation;
			}
			set
			{
				m_testInformation = value;
				//Expedia.Test.Player.TestInfoControl.Test
				DisplayTestInformation();
			}
		}
		#endregion

		public TestInfoDisplayControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitForm call
			this.testAreaInfoControl.Visible = true;
			this.testCaseInfoControl.Visible = false;

		}

		#region InternalMethods

		private void DisplayTestInformation()
		{
			if(TestInformation != null)
			{
				this.testAreaInfoControl.Visible = false;
				this.testCaseInfoControl.Visible = false;
			
				if(TestInformation.GetType()==typeof(TestArea)||TestInformation.GetType().IsSubclassOf(typeof(TestArea)))
				{
					this.testAreaInfoControl.Visible = true;
					this.testAreaInfoControl.TestDetails = TestInformation;						
				}

				if(TestInformation.GetType()==typeof(TestCase)||TestInformation.GetType().IsSubclassOf(typeof(TestCase)))
				{
					this.testCaseInfoControl.Visible = true;	
					this.testCaseInfoControl.TestDetails = TestInformation;
				}
			}
			else
			{

			}

		}

		#endregion

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.testAreaInfoControl = new Expedia.Test.Framework.TestAreaInfoControl();
			this.testCaseInfoControl = new Expedia.Test.Framework.TestCaseInfoControl();
			this.SuspendLayout();
			// 
			// testAreaInfoControl
			// 
			this.testAreaInfoControl.AccessibleDescription = "";
			this.testAreaInfoControl.Name = "testAreaInfoControl";
			this.testAreaInfoControl.Size = new System.Drawing.Size(384, 336);
			this.testAreaInfoControl.TabIndex = 0;
			this.testAreaInfoControl.TestDetails = null;
			// 
			// testCaseInfoControl
			// 
			this.testCaseInfoControl.AccessibleDescription = "";
			this.testCaseInfoControl.Name = "testCaseInfoControl";
			this.testCaseInfoControl.Size = new System.Drawing.Size(400, 352);
			this.testCaseInfoControl.TabIndex = 1;
			this.testCaseInfoControl.TestDetails = null;
			// 
			// TestInfoDisplayControl
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.testAreaInfoControl,
																		  this.testCaseInfoControl});
			this.Name = "TestInfoDisplayControl";
			this.Size = new System.Drawing.Size(384, 336);
			this.Resize += new System.EventHandler(this.TestInfoDisplayControl_Resize);
			this.ResumeLayout(false);

		}
		#endregion

		private void TestInfoDisplayControl_Resize(object sender, System.EventArgs e)
		{
			Control control = (Control)sender;
			Control testArea = (Control)this.testAreaInfoControl;
			Control testCase = (Control)this.testCaseInfoControl;

			testArea.Size = new Size(this.Width, this.Height);
			testCase.Size = new Size(this.Width, this.Height);
		}
	}
}
