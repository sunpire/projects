using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.IO;
using System.Xml;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
    
	public partial class BuildUpgradeTool: RepositoryConnectedUI
	{
       
        bool m_CreateProjectReferenceFile = false;

        string getCurrentDir = "";
        string itemName = "";

        Hashtable uniqueFileNames = new Hashtable();

		public BuildUpgradeTool()
		{
			InitializeComponent();
		}


        private string ReadProjectFile(string fileName)
        {
            StreamReader reader = new StreamReader(fileName);
            string data = reader.ReadToEnd();
            reader.Close();

            return data;

        }

        private bool ValidateFileName(string fileName)
        {
            FileInfo fileInfo = new FileInfo(fileName);

            if (fileInfo.Extension != ".csproj")
            {
                MessageBox.Show("Selected File should be a csproj file");
                return false;
            }

            return true;
        }

        private void WriteElement(XmlWriter writer, XmlReader reader)
        {
            writer.WriteStartElement(reader.Name,reader.NamespaceURI);            
            writer.WriteAttributes(reader,false);           

        }     

       
        private void WriteElement(XmlWriter writer, XmlElement element)
        {
            if (element == null || writer == null)
            {
                return;
            }
            writer.WriteStartElement(element.Name);
            
            foreach(XmlAttribute attribs in element.Attributes)
            {
                writer.WriteAttributeString(attribs.Name,attribs.Value);
            }

            if (element.InnerText != null)
            {
                writer.WriteString(element.InnerText);
            }
           

            writer.WriteEndElement();

        }

        private void WriteDocumentElement(XmlWriter writer, XmlElement element)
        {
            writer.WriteStartElement(element.Name, element.NamespaceURI);

            foreach (XmlAttribute attribs in element.Attributes)
            {
                writer.WriteAttributeString(attribs.Name, attribs.Value);
            }         

        }

        private void WritePropertyGroupElement(XmlWriter writer, XmlElement propertyElement)
        {
            string fileName = this.textBoxFileName.Text;
            FileInfo fileInfo = new FileInfo(fileName);

            writer.WriteStartElement(propertyElement.Name);

            writer.WriteStartElement("ObjFolder");
            writer.WriteString(fileInfo.Name.Trim(fileInfo.Extension.ToCharArray()));
            writer.WriteEndElement();

            foreach (XmlNode xmlNode in propertyElement.ChildNodes)
            {
                XmlElement childElement = xmlNode as XmlElement;
                if (childElement.Name == "ProjectGuid" || childElement.Name == "AssemblyOriginatorKeyFile" ||
                    childElement.Name == "RootNamespace")
                {
                    this.WriteElement(writer, childElement);
                }
                
            }

            writer.WriteStartElement("Dependencies");
            writer.WriteEndElement();

            writer.WriteEndElement();
        }

        private void WriteItemGroupElement(XmlWriter writer, XmlElement itemElement)
        {
            if (itemElement == null)
            {
                return;
            }
            writer.WriteStartElement(itemElement.Name);

            foreach (XmlNode xmlNode in itemElement.ChildNodes)
            {
                XmlElement childElement = xmlNode as XmlElement;

                writer.WriteStartElement(childElement.Name);

                foreach (XmlAttribute attribs in childElement.Attributes)
                {
                    if (attribs.Name != "HintPath")
                    {
                        writer.WriteAttributeString(attribs.Name, attribs.Value);
                    }
                    
                }

               
                foreach (XmlNode child in childElement.ChildNodes)
                {
                    if (child.Name != "HintPath")
                    {
                        this.WriteElement(writer, child as XmlElement);

                    }
                    
                }

                writer.WriteEndElement();

            }
            
            writer.WriteEndElement();
        }

        private void ProjectReference_CreateTargetElement(XmlWriter writer)
        {
            string[] tokens = this.folderBrowserDialog.SelectedPath.Split('\\');
            if (tokens != null && tokens.Length > 0)
            {
                getCurrentDir = "Get" + tokens[tokens.Length - 1].ToString() + "Dir";
                itemName = tokens[tokens.Length - 1].ToString() + "Dir";

            }

            writer.WriteStartElement("Target");
            writer.WriteAttributeString("Name", getCurrentDir);

            writer.WriteStartElement("CurrentDir");

            writer.WriteStartElement("Output");
            writer.WriteAttributeString("ItemName", itemName);
            writer.WriteAttributeString("TaskParameter", "CurrentDirectory");

            writer.WriteEndElement();

            //End Element for Current Die=r
            writer.WriteEndElement();

            writer.WriteStartElement("CreateProperty");
            writer.WriteAttributeString("Value", "@(" + itemName + ")");
            
            writer.WriteStartElement("Output");
            writer.WriteAttributeString("TaskParameter", "Value");
            writer.WriteAttributeString("PropertyName", itemName);


            //End Element for Create Property
            writer.WriteEndElement();

            //End Element for Target
            writer.WriteEndElement();

            writer.WriteEndElement();

        }

        private void ProjectReference_CreateItemGroup(XmlWriter writer)
        {
            string fileNameWithNoDots = "";
            string fileName="";
            bool firstTime = true;
            DirectoryInfo dirInfo = new DirectoryInfo(this.folderBrowserDialog.SelectedPath);
            FileInfo[] fileNames = dirInfo.GetFiles("*.csproj", SearchOption.AllDirectories);

            writer.WriteStartElement("ItemGroup");

            foreach (FileInfo file in fileNames)
            {
                fileName = "";
                firstTime = true;
                string[] tokens = file.Name.Split('.');

                for (int i = 0; i < tokens.Length - 1; i++)
                {
                    if (!firstTime)
                    {
                        fileName = fileName + "." + tokens[i];
                    }
                    else
                    {
                        fileName = fileName + tokens[i];
                        firstTime = false;
                    }
                    
                }
                 

                if (!uniqueFileNames.ContainsKey(fileName))
                {

                    writer.WriteStartElement("AutoBuildRefs");
                    writer.WriteAttributeString("Include", fileName);
                    writer.WriteStartElement("TargetName");

                    fileNameWithNoDots = fileName.Replace('.','_');
                    writer.WriteString(fileNameWithNoDots);

                    writer.WriteEndElement();
                    uniqueFileNames.Add(fileNameWithNoDots, file.FullName);
                    writer.WriteEndElement();
                }               
            }

           // writer.WriteEndElement();
            
            writer.WriteEndElement();
        }

        private void ProjectReference_CreateTargetDetail(XmlWriter writer)
        {
            string projectGuid = "";
            string relativePath = "";

            foreach (string key in uniqueFileNames.Keys)
            {
                projectGuid = "Project=" + this.getProjectGuid(uniqueFileNames[key].ToString());
                relativePath = this.getRelativePath(this.folderBrowserDialog.SelectedPath, uniqueFileNames[key].ToString());
                writer.WriteStartElement("Target");
                writer.WriteAttributeString("Name", key);
                writer.WriteAttributeString("DependsOnTargets", getCurrentDir);

                writer.WriteStartElement("CreateItem");
                writer.WriteAttributeString("Include", relativePath);
                writer.WriteAttributeString("AdditionalMetadata", projectGuid);

                writer.WriteStartElement("Output");
                writer.WriteAttributeString("ItemName", "RefrenceToBuild");
                writer.WriteAttributeString("TaskParameter", "Include");
                writer.WriteEndElement();

                //Create End Element 
                writer.WriteEndElement();

                
                //Target Element
                writer.WriteEndElement();

            }
            
            //Find the ProjectGUID

        }

        private string getProjectGuid(string fileName)
        {
            XmlDocument sourceXml = new XmlDocument();
            sourceXml.Load(fileName);

            XmlNode xmlNode = sourceXml.GetElementsByTagName("ProjectGuid")[0];

            if (xmlNode != null)
            {
                return xmlNode.InnerText;
            }
            return null;
        }

        private string getRelativePath(string currentFolder, string fileFullPath)
        {
            string tempFileName = fileFullPath.Remove(0, currentFolder.Length);

            return "$(" + itemName + ")" + tempFileName;

        }

        


        private void buttonNewVersion_Click(object sender, EventArgs e)
        {
            this.richTextBoxLatest.Text = "";

            if (m_CreateProjectReferenceFile)
            {
                this.CreateProjectReferenceFile();
            }
            else
            {
                this.UpdateProjectFile();
            }       

        }

        private void CreateProjectReferenceFile()
        {
                   
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.OmitXmlDeclaration = true;
            settings.ConformanceLevel = ConformanceLevel.Fragment;
            settings.CloseOutput = false;
            settings.Indent = true;
            //settings.NewLineChars = "\r\n";

            MemoryStream strm = new MemoryStream();
            XmlWriter writer = XmlWriter.Create(strm, settings);

            //Write the Dcument Element
            writer.WriteStartElement("Project", "http://schemas.microsoft.com/developer/msbuild/2003");

            //Write the Target Element 
            this.ProjectReference_CreateTargetElement(writer);

            //Write the Item Group
            this.ProjectReference_CreateItemGroup(writer);

            //Write the Target Detail Stuff
            ProjectReference_CreateTargetDetail(writer);      

            
		
            //End for the Document Element
            writer.WriteEndElement();

            writer.Flush();
            writer.Close();

            StreamReader sr = new StreamReader(strm);
            strm.Position = 0;
            this.richTextBoxLatest.Text = sr.ReadToEnd();
            strm.Close();
        }

        private void UpdateProjectFile()
        {
            string fileName = this.textBoxFileName.Text;
            FileInfo fileInfo = new FileInfo(fileName);

            //Read the source document
            XmlDocument sourceXml = new XmlDocument();
            sourceXml.Load(fileName);

            XmlWriterSettings settings = new XmlWriterSettings();
            settings.OmitXmlDeclaration = true;
            settings.ConformanceLevel = ConformanceLevel.Fragment;
            settings.CloseOutput = false;
            settings.Indent = true;
            settings.NewLineChars = "\r\n";

            MemoryStream strm = new MemoryStream();
            XmlWriter writer = XmlWriter.Create(strm, settings);

            //Write the Document Element
            XmlElement oNode = sourceXml.DocumentElement;
            this.WriteDocumentElement(writer, oNode);

            //Write the new Import Element
            writer.WriteStartElement("Import");
            writer.WriteAttributeString("Project", "..\\build.env");
            writer.WriteEndElement();

            //Write the PropertyGroupElement
            XmlElement propertyGroup = sourceXml.GetElementsByTagName("PropertyGroup")[0] as XmlElement;
            this.WritePropertyGroupElement(writer, propertyGroup);

            //Add another Import Element
            string attribValue = "..\\$(ScriptDir)\\" + this.comboBoxBuildType.SelectedItem.ToString();
            writer.WriteStartElement("Import");
            writer.WriteAttributeString("Project", attribValue);
            writer.WriteEndElement();


            //Add the ItemGroup Information
            XmlNodeList itemGroupList = sourceXml.GetElementsByTagName("ItemGroup");
            foreach (XmlNode node in itemGroupList)
            {
                XmlElement itemElement = node as XmlElement;
                this.WriteItemGroupElement(writer, itemElement);
            }

            //End for the Document Element
            writer.WriteEndElement();

            writer.Flush();
            writer.Close();

            StreamReader sr = new StreamReader(strm);
            strm.Position = 0;
            this.richTextBoxLatest.Text = sr.ReadToEnd();
            strm.Close();

        }

        private void BuildUpgradeTool_Load(object sender, EventArgs e)
        {

            this.comboBoxBuildType.SelectedIndex = 0;
           
        }


        private void openFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                if (this.openFileDialog.FileName != "")
                {
                    this.textBoxFileName.Text = this.openFileDialog.FileName;

                    if (!ValidateFileName(this.openFileDialog.FileName))
                    {
                        return;
                    }

                    this.richTextBoxSource.Text = this.ReadProjectFile(this.openFileDialog.FileName);
                    this.m_CreateProjectReferenceFile = false;
                }

            }

        }

        private void createProjectReferenceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            if (this.folderBrowserDialog.ShowDialog(this) == DialogResult.OK)
            {
                //Open the current reference.csproj file
                if (this.folderBrowserDialog.SelectedPath != "")
                {
                    this.m_CreateProjectReferenceFile = true;
                    this.CreateProjectReferenceFile();
                }     

                
            }

        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            string fileName = "";

            try
            {
                if (this.m_CreateProjectReferenceFile)
                {
                    fileName = this.folderBrowserDialog.SelectedPath + "\\refrence.projs";
                }
                else
                {
                    fileName = this.textBoxFileName.Text;
                }


                FileStream file = new FileStream(fileName, FileMode.Create);

                StreamWriter sw = new StreamWriter(file);
                sw.Write(this.richTextBoxLatest.Text);
                sw.Close();
                this.NotifyUI(InfoNotification.GetInfoNotification(SeverityType.Info, "The file is updated successfully"));

            }
            catch (Exception exp)
            {
                this.NotifyUI(InfoNotification.GetInfoNotification(SeverityType.Error, exp.Message));

            }
           

            


        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            this.richTextBoxLatest.Text = "";
        }


        

        
	}
}
