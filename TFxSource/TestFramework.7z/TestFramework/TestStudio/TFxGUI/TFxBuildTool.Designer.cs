namespace Expedia.Test.Framework
{
	partial class TFxBuildTool
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            this.menuStripFolder = new System.Windows.Forms.MenuStrip();
            this.pleaseSelectFolderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listBoxAllFiles = new System.Windows.Forms.ListBox();
            this.listBoxSelectedFiles = new System.Windows.Forms.ListBox();
            this.label = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonDestinationFolder = new System.Windows.Forms.Button();
            this.textBoxDestinationFolder = new System.Windows.Forms.TextBox();
            this.labelDestinationFolder = new System.Windows.Forms.Label();
            this.labelFileName = new System.Windows.Forms.Label();
            this.textBoxFileName = new System.Windows.Forms.TextBox();
            this.buttonSave = new System.Windows.Forms.Button();
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.buttonDelete = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.buttonAddAll = new System.Windows.Forms.Button();
            this.errorDisplayControl1 = new Expedia.Test.Framework.ErrorDisplayControl();
            this.menuStripFolder.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStripFolder
            // 
            this.menuStripFolder.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pleaseSelectFolderToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStripFolder.Location = new System.Drawing.Point(0, 0);
            this.menuStripFolder.Name = "menuStripFolder";
            this.menuStripFolder.Size = new System.Drawing.Size(863, 24);
            this.menuStripFolder.TabIndex = 0;
            this.menuStripFolder.Text = "Please Select Folder";
            // 
            // pleaseSelectFolderToolStripMenuItem
            // 
            this.pleaseSelectFolderToolStripMenuItem.Name = "pleaseSelectFolderToolStripMenuItem";
            this.pleaseSelectFolderToolStripMenuItem.Size = new System.Drawing.Size(115, 20);
            this.pleaseSelectFolderToolStripMenuItem.Text = "Please Select Folder";
            this.pleaseSelectFolderToolStripMenuItem.Click += new System.EventHandler(this.pleaseSelectFolderToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.helpToolStripMenuItem.Text = "Help";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            // 
            // listBoxAllFiles
            // 
            this.listBoxAllFiles.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.listBoxAllFiles.DisplayMember = "Name";
            this.listBoxAllFiles.FormattingEnabled = true;
            this.listBoxAllFiles.Location = new System.Drawing.Point(47, 277);
            this.listBoxAllFiles.Name = "listBoxAllFiles";
            this.listBoxAllFiles.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.listBoxAllFiles.Size = new System.Drawing.Size(272, 160);
            this.listBoxAllFiles.TabIndex = 2;
            // 
            // listBoxSelectedFiles
            // 
            this.listBoxSelectedFiles.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.listBoxSelectedFiles.FormattingEnabled = true;
            this.listBoxSelectedFiles.Location = new System.Drawing.Point(474, 277);
            this.listBoxSelectedFiles.Name = "listBoxSelectedFiles";
            this.listBoxSelectedFiles.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.listBoxSelectedFiles.Size = new System.Drawing.Size(263, 160);
            this.listBoxSelectedFiles.TabIndex = 3;
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Location = new System.Drawing.Point(15, 252);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(135, 13);
            this.label.TabIndex = 4;
            this.label.Text = "Files in the Selected Folder";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(471, 252);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Selected Files";
            // 
            // buttonDestinationFolder
            // 
            this.buttonDestinationFolder.AutoSize = true;
            this.buttonDestinationFolder.Location = new System.Drawing.Point(484, 133);
            this.buttonDestinationFolder.Margin = new System.Windows.Forms.Padding(0);
            this.buttonDestinationFolder.Name = "buttonDestinationFolder";
            this.buttonDestinationFolder.Size = new System.Drawing.Size(29, 23);
            this.buttonDestinationFolder.TabIndex = 11;
            this.buttonDestinationFolder.Text = "...";
            this.buttonDestinationFolder.UseVisualStyleBackColor = true;
            this.buttonDestinationFolder.Click += new System.EventHandler(this.buttonDestinationFolder_Click);
            // 
            // textBoxDestinationFolder
            // 
            this.textBoxDestinationFolder.Enabled = false;
            this.textBoxDestinationFolder.Location = new System.Drawing.Point(56, 135);
            this.textBoxDestinationFolder.Name = "textBoxDestinationFolder";
            this.textBoxDestinationFolder.Size = new System.Drawing.Size(425, 21);
            this.textBoxDestinationFolder.TabIndex = 10;
            // 
            // labelDestinationFolder
            // 
            this.labelDestinationFolder.AutoSize = true;
            this.labelDestinationFolder.Location = new System.Drawing.Point(15, 107);
            this.labelDestinationFolder.Name = "labelDestinationFolder";
            this.labelDestinationFolder.Size = new System.Drawing.Size(94, 13);
            this.labelDestinationFolder.TabIndex = 9;
            this.labelDestinationFolder.Text = "Destination Folder";
            // 
            // labelFileName
            // 
            this.labelFileName.AutoSize = true;
            this.labelFileName.Location = new System.Drawing.Point(18, 168);
            this.labelFileName.Name = "labelFileName";
            this.labelFileName.Size = new System.Drawing.Size(53, 13);
            this.labelFileName.TabIndex = 12;
            this.labelFileName.Text = "File Name";
            // 
            // textBoxFileName
            // 
            this.textBoxFileName.Location = new System.Drawing.Point(56, 195);
            this.textBoxFileName.Name = "textBoxFileName";
            this.textBoxFileName.Size = new System.Drawing.Size(223, 21);
            this.textBoxFileName.TabIndex = 13;
            // 
            // buttonSave
            // 
            this.buttonSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonSave.Location = new System.Drawing.Point(47, 443);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(103, 23);
            this.buttonSave.TabIndex = 16;
            this.buttonSave.Text = "Create Solution";
            this.toolTip1.SetToolTip(this.buttonSave, "Use the currently selected project\r\nfiles to create a solution file");
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // buttonDelete
            // 
            this.buttonDelete.Location = new System.Drawing.Point(374, 364);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new System.Drawing.Size(54, 23);
            this.buttonDelete.TabIndex = 17;
            this.buttonDelete.Text = "<<";
            this.buttonDelete.UseVisualStyleBackColor = true;
            this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(374, 393);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(54, 23);
            this.buttonClear.TabIndex = 18;
            this.buttonClear.Text = "<< All";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonAdd
            // 
            this.buttonAdd.Location = new System.Drawing.Point(374, 335);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(54, 23);
            this.buttonAdd.TabIndex = 16;
            this.buttonAdd.Text = ">>";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // buttonAddAll
            // 
            this.buttonAddAll.Location = new System.Drawing.Point(374, 306);
            this.buttonAddAll.Name = "buttonAddAll";
            this.buttonAddAll.Size = new System.Drawing.Size(54, 23);
            this.buttonAddAll.TabIndex = 19;
            this.buttonAddAll.Text = ">> All";
            this.buttonAddAll.UseVisualStyleBackColor = true;
            this.buttonAddAll.Click += new System.EventHandler(this.buttonAddAll_Click);
            // 
            // errorDisplayControl1
            // 
            this.errorDisplayControl1.BackColor = System.Drawing.SystemColors.Info;
            this.errorDisplayControl1.Location = new System.Drawing.Point(3, 27);
            this.errorDisplayControl1.Name = "errorDisplayControl1";
            this.errorDisplayControl1.Size = new System.Drawing.Size(655, 28);
            this.errorDisplayControl1.TabIndex = 1;
            // 
            // TFxBuildTool
            // 
            this.Controls.Add(this.buttonAddAll);
            this.Controls.Add(this.buttonAdd);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttonSave);
            this.Controls.Add(this.buttonDelete);
            this.Controls.Add(this.textBoxFileName);
            this.Controls.Add(this.labelFileName);
            this.Controls.Add(this.buttonDestinationFolder);
            this.Controls.Add(this.textBoxDestinationFolder);
            this.Controls.Add(this.labelDestinationFolder);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label);
            this.Controls.Add(this.listBoxSelectedFiles);
            this.Controls.Add(this.listBoxAllFiles);
            this.Controls.Add(this.errorDisplayControl1);
            this.Controls.Add(this.menuStripFolder);
            this.Name = "TFxBuildTool";
            this.Size = new System.Drawing.Size(863, 506);
            this.Click += new System.EventHandler(this.TFxBuildTool_Click);
            this.menuStripFolder.ResumeLayout(false);
            this.menuStripFolder.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

        private System.Windows.Forms.MenuStrip menuStripFolder;
        private ErrorDisplayControl errorDisplayControl1;
        private System.Windows.Forms.ListBox listBoxAllFiles;
        private System.Windows.Forms.ListBox listBoxSelectedFiles;
        private System.Windows.Forms.ToolStripMenuItem pleaseSelectFolderToolStripMenuItem;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonDestinationFolder;
        private System.Windows.Forms.TextBox textBoxDestinationFolder;
        private System.Windows.Forms.Label labelDestinationFolder;
        private System.Windows.Forms.Label labelFileName;
        private System.Windows.Forms.TextBox textBoxFileName;
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button buttonDelete;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Button buttonAddAll;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
	}
}
