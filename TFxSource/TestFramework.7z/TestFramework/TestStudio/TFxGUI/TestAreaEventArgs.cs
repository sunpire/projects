//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: TestAreEventArgs.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 

using System;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TestAreaEventArgs.
	/// </summary>
	public class TestAreaEventArgs : EventArgs
	{
		private TestInfo m_test;

		public TestInfo Test
		{
			get
			{
				return m_test;
			}
			set
			{
				m_test = value;
			}
		}

		private TreeNode m_selected;

		public TreeNode Selected
		{
			get
			{
				return m_selected;
			}
			set
			{
				m_selected = value;

			}

		}

		private TreeViewAction  m_action;

		public TreeViewAction Action
		{
			get
			{
				return m_action;
			}
			set
			{
				m_action = value;
			}

		}


		public TestAreaEventArgs()
		{
			//
			// TODO: Add constructor logic here
			//

		}
		
	}
}
