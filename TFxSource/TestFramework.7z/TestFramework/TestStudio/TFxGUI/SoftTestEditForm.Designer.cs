﻿namespace Expedia.Test.Framework
{
    partial class SoftTestEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancelButton = new System.Windows.Forms.LinkLabel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtBranchName = new System.Windows.Forms.TextBox();
            this.lbSoftTestName = new System.Windows.Forms.TextBox();
            this.lbSoftTestId = new System.Windows.Forms.TextBox();
            this.lbMethod = new System.Windows.Forms.Label();
            this.lbModule = new System.Windows.Forms.Label();
            this.SaveButton = new System.Windows.Forms.LinkLabel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dgParameters = new System.Windows.Forms.DataGridView();
            this.NameColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ValueColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dgTestConfigs = new System.Windows.Forms.DataGridView();
            this.ConfigNameColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ConfigValueColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgParameters)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgTestConfigs)).BeginInit();
            this.SuspendLayout();
            // 
            // btnCancelButton
            // 
            this.btnCancelButton.AutoSize = true;
            this.btnCancelButton.Location = new System.Drawing.Point(60, 147);
            this.btnCancelButton.Name = "btnCancelButton";
            this.btnCancelButton.Size = new System.Drawing.Size(33, 13);
            this.btnCancelButton.TabIndex = 0;
            this.btnCancelButton.TabStop = true;
            this.btnCancelButton.Text = "Close";
            this.btnCancelButton.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.CancelButton_LinkClicked);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtBranchName);
            this.groupBox1.Controls.Add(this.lbSoftTestName);
            this.groupBox1.Controls.Add(this.lbSoftTestId);
            this.groupBox1.Controls.Add(this.lbMethod);
            this.groupBox1.Controls.Add(this.lbModule);
            this.groupBox1.Controls.Add(this.SaveButton);
            this.groupBox1.Controls.Add(this.btnCancelButton);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(382, 171);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "SoftTest";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(60, 84);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(258, 13);
            this.label8.TabIndex = 12;
            this.label8.Text = "( Full Name && Branch are used for locating TestData )";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 64);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 13);
            this.label7.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(60, 37);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(233, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "( Full Name should include namespace + name )";
            // 
            // txtBranchName
            // 
            this.txtBranchName.Location = new System.Drawing.Point(270, 60);
            this.txtBranchName.Name = "txtBranchName";
            this.txtBranchName.Size = new System.Drawing.Size(100, 20);
            this.txtBranchName.TabIndex = 9;
            // 
            // lbSoftTestName
            // 
            this.lbSoftTestName.Location = new System.Drawing.Point(63, 14);
            this.lbSoftTestName.Name = "lbSoftTestName";
            this.lbSoftTestName.Size = new System.Drawing.Size(307, 20);
            this.lbSoftTestName.TabIndex = 9;
            // 
            // lbSoftTestId
            // 
            this.lbSoftTestId.Location = new System.Drawing.Point(63, 61);
            this.lbSoftTestId.Name = "lbSoftTestId";
            this.lbSoftTestId.Size = new System.Drawing.Size(100, 20);
            this.lbSoftTestId.TabIndex = 8;
            // 
            // lbMethod
            // 
            this.lbMethod.AutoSize = true;
            this.lbMethod.Location = new System.Drawing.Point(62, 126);
            this.lbMethod.Name = "lbMethod";
            this.lbMethod.Size = new System.Drawing.Size(35, 13);
            this.lbMethod.TabIndex = 7;
            this.lbMethod.Text = "label5";
            // 
            // lbModule
            // 
            this.lbModule.AutoSize = true;
            this.lbModule.Location = new System.Drawing.Point(62, 105);
            this.lbModule.Name = "lbModule";
            this.lbModule.Size = new System.Drawing.Size(35, 13);
            this.lbModule.TabIndex = 6;
            this.lbModule.Text = "label5";
            // 
            // SaveButton
            // 
            this.SaveButton.AutoSize = true;
            this.SaveButton.Location = new System.Drawing.Point(6, 147);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(32, 13);
            this.SaveButton.TabIndex = 1;
            this.SaveButton.TabStop = true;
            this.SaveButton.Text = "Save";
            this.SaveButton.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.SaveButton_LinkClicked);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 126);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Method";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Module";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(183, 64);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Branch Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Id";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Full Name";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dgParameters);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox2.Location = new System.Drawing.Point(0, 171);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(382, 202);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Parameters";
            // 
            // dgParameters
            // 
            this.dgParameters.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgParameters.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.NameColumn,
            this.ValueColumn,
            this.Column2});
            this.dgParameters.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgParameters.Location = new System.Drawing.Point(3, 16);
            this.dgParameters.Name = "dgParameters";
            this.dgParameters.Size = new System.Drawing.Size(376, 111);
            this.dgParameters.TabIndex = 2;
            this.dgParameters.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgParameters_CellContentClick);
            // 
            // NameColumn
            // 
            this.NameColumn.HeaderText = "Name";
            this.NameColumn.Name = "NameColumn";
            // 
            // ValueColumn
            // 
            this.ValueColumn.HeaderText = "Value";
            this.ValueColumn.Name = "ValueColumn";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "";
            this.Column2.Name = "Column2";
            this.Column2.Text = "Edit Value";
            this.Column2.UseColumnTextForLinkValue = true;
            this.Column2.Width = 65;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dgTestConfigs);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox3.Location = new System.Drawing.Point(0, 270);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(382, 103);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Configurations";
            // 
            // dgTestConfigs
            // 
            this.dgTestConfigs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgTestConfigs.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ConfigNameColumn,
            this.ConfigValueColumn,
            this.Column1});
            this.dgTestConfigs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgTestConfigs.Location = new System.Drawing.Point(3, 16);
            this.dgTestConfigs.Name = "dgTestConfigs";
            this.dgTestConfigs.Size = new System.Drawing.Size(376, 84);
            this.dgTestConfigs.TabIndex = 0;
            this.dgTestConfigs.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgTestConfigs_CellContentClick);
            // 
            // ConfigNameColumn
            // 
            this.ConfigNameColumn.HeaderText = "Name";
            this.ConfigNameColumn.Name = "ConfigNameColumn";
            // 
            // ConfigValueColumn
            // 
            this.ConfigValueColumn.HeaderText = "Value";
            this.ConfigValueColumn.Name = "ConfigValueColumn";
            // 
            // Column1
            // 
            this.Column1.HeaderText = "";
            this.Column1.Name = "Column1";
            this.Column1.Text = "Edit Value";
            this.Column1.UseColumnTextForLinkValue = true;
            this.Column1.Width = 65;
            // 
            // SoftTestEditForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(382, 373);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "SoftTestEditForm";
            this.Text = "SoftTest Editor";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgParameters)).EndInit();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgTestConfigs)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.LinkLabel btnCancelButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbMethod;
        private System.Windows.Forms.Label lbModule;
        private System.Windows.Forms.LinkLabel SaveButton;
        private System.Windows.Forms.DataGridView dgParameters;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dgTestConfigs;
        private System.Windows.Forms.TextBox lbSoftTestName;
        private System.Windows.Forms.TextBox lbSoftTestId;
        private System.Windows.Forms.DataGridViewTextBoxColumn ConfigNameColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ConfigValueColumn;
        private System.Windows.Forms.DataGridViewLinkColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn NameColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ValueColumn;
        private System.Windows.Forms.DataGridViewLinkColumn Column2;
        private System.Windows.Forms.TextBox txtBranchName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
    }
}
