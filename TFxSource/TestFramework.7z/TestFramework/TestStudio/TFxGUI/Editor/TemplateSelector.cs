using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Expedia.Test.Framework.Editor
{
	/// <summary>
	/// Summary description for TemplateSelector.
	/// </summary>
	public class TemplateSelector : RepositoryDelegateUI
	{
		private System.Windows.Forms.Button buttonLoadFrom;
		private System.Windows.Forms.ComboBox comboBoxTemplate;
		private System.Windows.Forms.Panel panelButton;
		private System.Windows.Forms.Panel panelTemplate;
		
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public TemplateSelector()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
			this.buttonSize = new Size(this.panelButton.Size.Width, this.panelButton.Size.Height);
			this.templateSize = new Size(this.panelTemplate.Size.Width, this.panelTemplate.Size.Height);
 		}

		public bool ButtonView
		{
			get
			{
				return this.panelButton.Visible;
			}
			set
			{
				this.panelButton.Visible = value;
				this.panelTemplate.Visible = !value;

				if(value)
				{
					this.Size = new Size(buttonSize.Width, buttonSize.Height);
				}
				else
				{
					this.Size = new Size(templateSize.Width, templateSize.Height);
				}
			}
		}


		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panelButton = new System.Windows.Forms.Panel();
			this.buttonLoadFrom = new System.Windows.Forms.Button();
			this.panelTemplate = new System.Windows.Forms.Panel();
			this.comboBoxTemplate = new System.Windows.Forms.ComboBox();
			this.panelButton.SuspendLayout();
			this.panelTemplate.SuspendLayout();
			this.SuspendLayout();
			// 
			// panelButton
			// 
			this.panelButton.Controls.Add(this.buttonLoadFrom);
			this.panelButton.Dock = System.Windows.Forms.DockStyle.Left;
			this.panelButton.Location = new System.Drawing.Point(0, 0);
			this.panelButton.Name = "panelButton";
			this.panelButton.Size = new System.Drawing.Size(80, 40);
			this.panelButton.TabIndex = 0;
			// 
			// buttonLoadFrom
			// 
			this.buttonLoadFrom.Location = new System.Drawing.Point(0, 8);
			this.buttonLoadFrom.Name = "buttonLoadFrom";
			this.buttonLoadFrom.Size = new System.Drawing.Size(75, 20);
			this.buttonLoadFrom.TabIndex = 0;
			this.buttonLoadFrom.Text = "Load From";
			this.buttonLoadFrom.Click += new System.EventHandler(this.buttonLoadFrom_Click);
			// 
			// panelTemplate
			// 
			this.panelTemplate.Controls.Add(this.comboBoxTemplate);
			this.panelTemplate.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panelTemplate.Location = new System.Drawing.Point(80, 0);
			this.panelTemplate.Name = "panelTemplate";
			this.panelTemplate.Size = new System.Drawing.Size(128, 40);
			this.panelTemplate.TabIndex = 1;
			// 
			// comboBoxTemplate
			// 
			this.comboBoxTemplate.Location = new System.Drawing.Point(0, 8);
			this.comboBoxTemplate.Name = "comboBoxTemplate";
			this.comboBoxTemplate.Size = new System.Drawing.Size(121, 21);
			this.comboBoxTemplate.TabIndex = 0;
			this.comboBoxTemplate.SelectedIndexChanged += new System.EventHandler(this.comboBoxTemplate_SelectedIndexChanged);

			// 
			// TemplateSelector
			// 
			this.Controls.Add(this.panelTemplate);
			this.Controls.Add(this.panelButton);
			this.Name = "TemplateSelector";
			this.Size = new System.Drawing.Size(208, 40);
			this.Load += new System.EventHandler(this.TemplateSelector_Load);
			this.panelButton.ResumeLayout(false);
			this.panelTemplate.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		Size buttonSize;
		Size templateSize;

		private void buttonLoadFrom_Click(object sender, System.EventArgs e)
		{
			this.GetDataAsync(new TestRunTemplateListRequest(), new NotificationRequestHandler(TemplateListLoaded));
			this.ButtonView = false;
		}

		private void comboBoxTemplate_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			this.ButtonView = true;
			this.NotifyUIAsync(new LoadTemplateNotification(comboBoxTemplate.Items[comboBoxTemplate.SelectedIndex] as TestRunTemplate));
		}

		private void TemplateSelector_Load(object sender, System.EventArgs e)
		{
			this.ButtonView = true;
		}

		public void TemplateListLoaded(NotificationRequest request)
		{
			//turning off index changed handler while loading data since data binding
			//fires off index changed events. 
			this.comboBoxTemplate.SelectedIndexChanged -= new System.EventHandler(this.comboBoxTemplate_SelectedIndexChanged);
			DataNotification dataRequest = request as DataNotification;
			if (dataRequest != null)
			{
				TestRunTemplateListRequest t = dataRequest.Request as TestRunTemplateListRequest;
				if(t != null && t.list != null)
				{
					this.comboBoxTemplate.DataSource = t.list;
					this.comboBoxTemplate.DisplayMember = "TemplateName";
				}
			}
			this.comboBoxTemplate.SelectedIndexChanged += new System.EventHandler(this.comboBoxTemplate_SelectedIndexChanged);

		}

	}
}
