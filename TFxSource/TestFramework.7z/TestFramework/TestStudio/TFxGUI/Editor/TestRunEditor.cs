using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Security.Principal;
using System.Text;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
    public class TestRunEditor : GenericEditor
    {
        protected System.Windows.Forms.Panel panelConfigPicker;
        protected NJFLib.Controls.CollapsibleSplitter splitterConfigPicker;
        protected System.Windows.Forms.Panel panelSelector;
        protected System.Windows.Forms.Panel panelTestRunAssignmentInfo;
        protected System.Windows.Forms.Panel panelTestRunInfo;
        protected System.Windows.Forms.Panel panelAssignmentEditor;
        protected Expedia.Test.Framework.ConfigPickerControl1 config;
        protected Expedia.Test.Framework.TestAreaAndFilterControl testArea;
        protected Expedia.Test.Framework.TestCaseSelectorControl testSelector;
        protected Expedia.Test.Framework.AssignmentCollectionEditor assignments;
        private IContainer components;
        protected System.Windows.Forms.Button buttonGenerate;

        protected System.Windows.Forms.Panel panelShowLabRun;
        protected System.Windows.Forms.Button buttonShowLabRun;
        protected Expedia.Test.Framework.Editor.LabRunInfoControl labRunInfo;
        protected System.Windows.Forms.Button buttonSave;
        protected System.Windows.Forms.Button buttonExecute;
        protected System.Windows.Forms.Panel panelExecute;
        protected System.Windows.Forms.Panel panelSave;
        protected System.Windows.Forms.Button buttonToggle;
        protected System.Windows.Forms.Panel panelToggleButton;
        protected NJFLib.Controls.CollapsibleSplitter splitterSelector;


        private bool AutoRun = false;
        private string AutoRunFileName = "";


        //Used to get the TestCases List for the Test Area Control

        private TestInfoCollection m_testcaseslist;
        private int m_maxAssignmentIndex = -1;
        protected System.Windows.Forms.Panel panelTemplate;
        protected System.Windows.Forms.Panel panelGnerate;
        //private Expedia.Test.Framework.Editor.TemplateSelector templateSelector;
        private ExecutionManager manager = null;

        private string m_executedAssignmentsList = "TSExecutedAssignmentList";

        public TestInfoCollection TestCasesList
        {
            get
            {
                return m_testcaseslist;
            }
            set
            {
                m_testcaseslist = value;
            }
        }

        public int MaxAssignmentIndex
        {
            set
            {
                m_maxAssignmentIndex = value;
            }
            get
            {
                return m_maxAssignmentIndex;
            }
        }

        public Guid m_labRunGid;
        protected System.Windows.Forms.Panel panelPublish;
        protected System.Windows.Forms.Button buttonPublish;
        private System.Windows.Forms.ComboBox comboBoxRelease;
        private System.Windows.Forms.ContextMenu contextMenu;
        private System.Windows.Forms.MenuItem menuItemExport;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.MenuItem menuItemImport;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;

        public Guid LabRunGid
        {
            set
            {
                m_labRunGid = value;
            }
            get
            {
                return m_labRunGid;
            }
        }

        private System.Windows.Forms.MenuItem menuItemBulkEdit;


        bool m_labrunMode = false;
        private ContextMenuStrip contextMenu2;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private ToolStripMenuItem clearListToolStripMenuItem;
        private ToolStripMenuItem editParamToolStripMenuItem;
        private Button buttonOpenlog;

        /// <summary>
        /// Menu item on right click menu for assignment grids which popup a dialog
        /// to show all relevant information about the assignment such as branch used
        /// </summary>
        private System.Windows.Forms.MenuItem menuItemDisplayAssignmentInfo;

        public bool LabRunMode
        {
            get
            {
                return m_labrunMode;
            }
            set
            {
                m_labrunMode = value;
            }
        }

        string m_logonUser = "";
        public string LogonUser
        {
            get
            {
                return m_logonUser;
            }
            set
            {
                m_logonUser = value;
            }
        }

        bool m_debugMode = false;
        public bool DebugMode
        {
            get
            {
                return m_debugMode;
            }
            set
            {
                m_debugMode = value;
            }
        }

        public TestRunEditor()
        {
            // This call is required by the Windows Form Designer.
            InitializeComponent();

            // TODO: Add any initialization after the InitializeComponent call
            m_testcaseslist = new TestInfoCollection();

            this.myTestRunner = new RunMyTest(this.Runner);
            this.releaseHandler = new NotificationRequestHandler(this.HandleReleaseChangeNotification);
        }

        public TestRunEditor(string autoRunFile, bool debugMode)
        {
            this.AutoRun = true;
            this.AutoRunFileName = autoRunFile;

            this.DebugMode = debugMode;

            // This call is required by the Windows Form Designer.
            InitializeComponent();

            // TODO: Add any initialization after the InitializeComponent call
            m_testcaseslist = new TestInfoCollection();

            this.myTestRunner = new RunMyTest(this.Runner);
            this.releaseHandler = new NotificationRequestHandler(this.HandleReleaseChangeNotification);

            // Register a notification for the completed form load.
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panelConfigPicker = new System.Windows.Forms.Panel();
            this.config = new Expedia.Test.Framework.ConfigPickerControl1();
            this.splitterConfigPicker = new NJFLib.Controls.CollapsibleSplitter();
            this.testArea = new Expedia.Test.Framework.TestAreaAndFilterControl();
            this.panelSelector = new System.Windows.Forms.Panel();
            this.testSelector = new Expedia.Test.Framework.TestCaseSelectorControl();
            this.contextMenu2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editParamToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.splitterSelector = new NJFLib.Controls.CollapsibleSplitter();
            this.panelTestRunAssignmentInfo = new System.Windows.Forms.Panel();
            this.panelAssignmentEditor = new System.Windows.Forms.Panel();
            this.assignments = new Expedia.Test.Framework.AssignmentCollectionEditor();
            this.panelTestRunInfo = new System.Windows.Forms.Panel();
            this.labRunInfo = new Expedia.Test.Framework.Editor.LabRunInfoControl();
            this.panelExecute = new System.Windows.Forms.Panel();
            this.buttonExecute = new System.Windows.Forms.Button();
            this.panelSave = new System.Windows.Forms.Panel();
            this.buttonSave = new System.Windows.Forms.Button();
            this.panelGnerate = new System.Windows.Forms.Panel();
            this.buttonGenerate = new System.Windows.Forms.Button();
            this.panelShowLabRun = new System.Windows.Forms.Panel();
            this.buttonShowLabRun = new System.Windows.Forms.Button();
            this.panelToggleButton = new System.Windows.Forms.Panel();
            this.buttonToggle = new System.Windows.Forms.Button();
            this.panelTemplate = new System.Windows.Forms.Panel();
            this.panelPublish = new System.Windows.Forms.Panel();
            this.comboBoxRelease = new System.Windows.Forms.ComboBox();
            this.buttonPublish = new System.Windows.Forms.Button();
            this.contextMenu = new System.Windows.Forms.ContextMenu();
            this.menuItemExport = new System.Windows.Forms.MenuItem();
            this.menuItemImport = new System.Windows.Forms.MenuItem();
            this.menuItemBulkEdit = new System.Windows.Forms.MenuItem();
            this.menuItemDisplayAssignmentInfo = new System.Windows.Forms.MenuItem();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.buttonOpenlog = new System.Windows.Forms.Button();
            this.panelTop1.SuspendLayout();
            this.panelBottom1.SuspendLayout();
            this.panelCenter.SuspendLayout();
            this.panelLeft.SuspendLayout();
            this.panelRight.SuspendLayout();
            this.panelMiddle.SuspendLayout();
            this.panelConfigPicker.SuspendLayout();
            this.panelSelector.SuspendLayout();
            this.contextMenu2.SuspendLayout();
            this.panelTestRunAssignmentInfo.SuspendLayout();
            this.panelAssignmentEditor.SuspendLayout();
            this.panelTestRunInfo.SuspendLayout();
            this.panelExecute.SuspendLayout();
            this.panelSave.SuspendLayout();
            this.panelGnerate.SuspendLayout();
            this.panelShowLabRun.SuspendLayout();
            this.panelToggleButton.SuspendLayout();
            this.panelPublish.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelTop1
            // 
            this.panelTop1.Size = new System.Drawing.Size(776, 24);
            this.panelTop1.Visible = false;
            // 
            // panelBottom1
            // 
            this.panelBottom1.Controls.Add(this.buttonOpenlog);
            this.panelBottom1.Controls.Add(this.panelPublish);
            this.panelBottom1.Controls.Add(this.panelToggleButton);
            this.panelBottom1.Controls.Add(this.panelShowLabRun);
            this.panelBottom1.Controls.Add(this.panelExecute);
            this.panelBottom1.Controls.Add(this.panelSave);
            this.panelBottom1.Controls.Add(this.panelGnerate);
            this.panelBottom1.Controls.Add(this.panelTemplate);
            this.panelBottom1.Location = new System.Drawing.Point(0, 576);
            this.panelBottom1.Size = new System.Drawing.Size(776, 32);
            // 
            // panelCenter
            // 
            this.panelCenter.Location = new System.Drawing.Point(0, 0);
            this.panelCenter.Size = new System.Drawing.Size(776, 576);
            // 
            // panelLeft
            // 
            this.panelLeft.Controls.Add(this.testArea);
            this.panelLeft.Controls.Add(this.splitterConfigPicker);
            this.panelLeft.Controls.Add(this.panelConfigPicker);
            this.panelLeft.Size = new System.Drawing.Size(176, 576);
            // 
            // panelRight
            // 
            this.panelRight.Location = new System.Drawing.Point(184, 0);
            this.panelRight.Size = new System.Drawing.Size(592, 576);
            // 
            // panelUpper
            // 
            this.panelUpper.Size = new System.Drawing.Size(592, 40);
            this.panelUpper.Visible = false;
            // 
            // panelLower
            // 
            this.panelLower.Location = new System.Drawing.Point(0, 536);
            this.panelLower.Size = new System.Drawing.Size(592, 40);
            this.panelLower.Visible = false;
            // 
            // panelMiddle
            // 
            this.panelMiddle.Controls.Add(this.panelTestRunAssignmentInfo);
            this.panelMiddle.Controls.Add(this.splitterSelector);
            this.panelMiddle.Controls.Add(this.panelSelector);
            this.panelMiddle.Size = new System.Drawing.Size(592, 496);
            // 
            // splitterLeft
            // 
            this.splitterLeft.Location = new System.Drawing.Point(176, 0);
            // 
            // errorDisplayControl
            // 
            this.errorDisplayControl.Size = new System.Drawing.Size(776, 24);
            // 
            // panelConfigPicker
            // 
            this.panelConfigPicker.Controls.Add(this.config);
            this.panelConfigPicker.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelConfigPicker.Location = new System.Drawing.Point(0, 480);
            this.panelConfigPicker.Name = "panelConfigPicker";
            this.panelConfigPicker.Size = new System.Drawing.Size(176, 96);
            this.panelConfigPicker.TabIndex = 0;
            // 
            // config
            // 
            this.config.Dock = System.Windows.Forms.DockStyle.Fill;
            this.config.Location = new System.Drawing.Point(0, 0);
            this.config.Name = "config";
            this.config.ShowDetailedPicker = false;
            this.config.Size = new System.Drawing.Size(176, 96);
            this.config.TabIndex = 1;
            // 
            // splitterConfigPicker
            // 
            this.splitterConfigPicker.AnimationDelay = 20;
            this.splitterConfigPicker.AnimationStep = 20;
            this.splitterConfigPicker.BorderStyle3D = System.Windows.Forms.Border3DStyle.Flat;
            this.splitterConfigPicker.ControlToHide = this.panelConfigPicker;
            this.splitterConfigPicker.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitterConfigPicker.ExpandParentForm = false;
            this.splitterConfigPicker.Location = new System.Drawing.Point(0, 477);
            this.splitterConfigPicker.Name = "splitterConfigPicker";
            this.splitterConfigPicker.TabIndex = 1;
            this.splitterConfigPicker.TabStop = false;
            this.splitterConfigPicker.UseAnimations = false;
            this.splitterConfigPicker.VisualStyle = NJFLib.Controls.VisualStyles.Mozilla;
            // 
            // testArea
            // 
            this.testArea.Cursor = System.Windows.Forms.Cursors.Default;
            this.testArea.Dock = System.Windows.Forms.DockStyle.Fill;
            this.testArea.Location = new System.Drawing.Point(0, 0);
            this.testArea.Name = "testArea";
            this.testArea.Size = new System.Drawing.Size(176, 477);
            this.testArea.TabIndex = 3;
            // 
            // panelSelector
            // 
            this.panelSelector.Controls.Add(this.testSelector);
            this.panelSelector.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSelector.Location = new System.Drawing.Point(0, 0);
            this.panelSelector.Name = "panelSelector";
            this.panelSelector.Size = new System.Drawing.Size(592, 360);
            this.panelSelector.TabIndex = 0;
            // 
            // testSelector
            // 
            this.testSelector.ContextMenuStrip = this.contextMenu2;
            this.testSelector.Dock = System.Windows.Forms.DockStyle.Fill;
            this.testSelector.Location = new System.Drawing.Point(0, 0);
            this.testSelector.Name = "testSelector";
            this.testSelector.Size = new System.Drawing.Size(592, 360);
            this.testSelector.TabIndex = 1;
            // 
            // contextMenu2
            // 
            this.contextMenu2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteToolStripMenuItem,
            this.clearListToolStripMenuItem,
            this.editParamToolStripMenuItem});
            this.contextMenu2.Name = "contextMenu2";
            this.contextMenu2.Size = new System.Drawing.Size(196, 70);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.deleteToolStripMenuItem.Text = "Remove";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // clearListToolStripMenuItem
            // 
            this.clearListToolStripMenuItem.Name = "clearListToolStripMenuItem";
            this.clearListToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.clearListToolStripMenuItem.Text = "Clear List";
            this.clearListToolStripMenuItem.Click += new System.EventHandler(this.clearListToolStripMenuItem_Click);
            // 
            // editParamToolStripMenuItem
            // 
            this.editParamToolStripMenuItem.Name = "editParamToolStripMenuItem";
            this.editParamToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.editParamToolStripMenuItem.Text = "Edit SoftTest Information";
            this.editParamToolStripMenuItem.Click += new System.EventHandler(this.editParametersToolStripMenuItem_Click);
            // 
            // splitterSelector
            // 
            this.splitterSelector.AnimationDelay = 20;
            this.splitterSelector.AnimationStep = 20;
            this.splitterSelector.BorderStyle3D = System.Windows.Forms.Border3DStyle.Flat;
            this.splitterSelector.ControlToHide = this.panelSelector;
            this.splitterSelector.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitterSelector.ExpandParentForm = false;
            this.splitterSelector.Location = new System.Drawing.Point(0, 360);
            this.splitterSelector.Name = "splitterSelector";
            this.splitterSelector.TabIndex = 1;
            this.splitterSelector.TabStop = false;
            this.splitterSelector.UseAnimations = false;
            this.splitterSelector.VisualStyle = NJFLib.Controls.VisualStyles.Mozilla;
            // 
            // panelTestRunAssignmentInfo
            // 
            this.panelTestRunAssignmentInfo.Controls.Add(this.panelAssignmentEditor);
            this.panelTestRunAssignmentInfo.Controls.Add(this.panelTestRunInfo);
            this.panelTestRunAssignmentInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTestRunAssignmentInfo.Location = new System.Drawing.Point(0, 363);
            this.panelTestRunAssignmentInfo.Name = "panelTestRunAssignmentInfo";
            this.panelTestRunAssignmentInfo.Size = new System.Drawing.Size(592, 133);
            this.panelTestRunAssignmentInfo.TabIndex = 2;
            // 
            // panelAssignmentEditor
            // 
            this.panelAssignmentEditor.Controls.Add(this.assignments);
            this.panelAssignmentEditor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelAssignmentEditor.Location = new System.Drawing.Point(0, 104);
            this.panelAssignmentEditor.Name = "panelAssignmentEditor";
            this.panelAssignmentEditor.Size = new System.Drawing.Size(592, 29);
            this.panelAssignmentEditor.TabIndex = 1;
            // 
            // assignments
            // 
            this.assignments.Assignments = null;
            this.assignments.ContextMenuStrip = this.contextMenu2;
            this.assignments.Dock = System.Windows.Forms.DockStyle.Fill;
            this.assignments.Location = new System.Drawing.Point(0, 0);
            this.assignments.Name = "assignments";
            this.assignments.ShortResultBottomVisible = false;
            this.assignments.ShortResultRightVisible = false;
            this.assignments.ShowFilterEditor = false;
            this.assignments.Size = new System.Drawing.Size(592, 29);
            this.assignments.TabIndex = 1;
            // 
            // panelTestRunInfo
            // 
            this.panelTestRunInfo.Controls.Add(this.labRunInfo);
            this.panelTestRunInfo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTestRunInfo.Location = new System.Drawing.Point(0, 0);
            this.panelTestRunInfo.Name = "panelTestRunInfo";
            this.panelTestRunInfo.Size = new System.Drawing.Size(592, 104);
            this.panelTestRunInfo.TabIndex = 0;
            // 
            // labRunInfo
            // 
            this.labRunInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labRunInfo.Email = "";
            this.labRunInfo.EnabledEmail = true;
            this.labRunInfo.LabRunText = "";
            this.labRunInfo.Location = new System.Drawing.Point(0, 0);
            this.labRunInfo.LogLevelUpdated = false;
            this.labRunInfo.Manager = null;
            this.labRunInfo.Name = "labRunInfo";
            this.labRunInfo.Release = null;
            this.labRunInfo.ReleaseUpdated = false;
            this.labRunInfo.Size = new System.Drawing.Size(592, 104);
            this.labRunInfo.Status = "Created";
            this.labRunInfo.TabIndex = 1;
            this.labRunInfo.TestBuildName = null;
            this.labRunInfo.TestReleaseName = null;
            // 
            // panelExecute
            // 
            this.panelExecute.Controls.Add(this.buttonExecute);
            this.panelExecute.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelExecute.Location = new System.Drawing.Point(642, 0);
            this.panelExecute.Name = "panelExecute";
            this.panelExecute.Size = new System.Drawing.Size(70, 32);
            this.panelExecute.TabIndex = 13;
            // 
            // buttonExecute
            // 
            this.buttonExecute.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonExecute.Location = new System.Drawing.Point(2, 8);
            this.buttonExecute.Name = "buttonExecute";
            this.buttonExecute.Size = new System.Drawing.Size(61, 20);
            this.buttonExecute.TabIndex = 0;
            this.buttonExecute.Text = "&Execute";
            this.buttonExecute.Click += new System.EventHandler(this.buttonExecute_Click);
            // 
            // panelSave
            // 
            this.panelSave.Controls.Add(this.buttonSave);
            this.panelSave.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelSave.Location = new System.Drawing.Point(712, 0);
            this.panelSave.Name = "panelSave";
            this.panelSave.Size = new System.Drawing.Size(64, 32);
            this.panelSave.TabIndex = 12;
            // 
            // buttonSave
            // 
            this.buttonSave.Location = new System.Drawing.Point(0, 8);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(61, 20);
            this.buttonSave.TabIndex = 0;
            this.buttonSave.Text = "&Save";
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // panelGnerate
            // 
            this.panelGnerate.Controls.Add(this.buttonGenerate);
            this.panelGnerate.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelGnerate.Location = new System.Drawing.Point(120, 0);
            this.panelGnerate.Name = "panelGnerate";
            this.panelGnerate.Size = new System.Drawing.Size(64, 32);
            this.panelGnerate.TabIndex = 15;
            // 
            // buttonGenerate
            // 
            this.buttonGenerate.Location = new System.Drawing.Point(0, 8);
            this.buttonGenerate.Name = "buttonGenerate";
            this.buttonGenerate.Size = new System.Drawing.Size(61, 20);
            this.buttonGenerate.TabIndex = 0;
            this.buttonGenerate.Text = "&Generate";
            this.buttonGenerate.Click += new System.EventHandler(this.buttonGenerate_Click);
            // 
            // panelShowLabRun
            // 
            this.panelShowLabRun.Controls.Add(this.buttonShowLabRun);
            this.panelShowLabRun.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelShowLabRun.Location = new System.Drawing.Point(546, 0);
            this.panelShowLabRun.Name = "panelShowLabRun";
            this.panelShowLabRun.Size = new System.Drawing.Size(96, 32);
            this.panelShowLabRun.TabIndex = 16;
            // 
            // buttonShowLabRun
            // 
            this.buttonShowLabRun.Location = new System.Drawing.Point(0, 8);
            this.buttonShowLabRun.Name = "buttonShowLabRun";
            this.buttonShowLabRun.Size = new System.Drawing.Size(88, 20);
            this.buttonShowLabRun.TabIndex = 0;
            this.buttonShowLabRun.Text = "&Show Lab Run";
            this.buttonShowLabRun.Click += new System.EventHandler(this.buttonShowLabRun_Click);
            // 
            // panelToggleButton
            // 
            this.panelToggleButton.Controls.Add(this.buttonToggle);
            this.panelToggleButton.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelToggleButton.Location = new System.Drawing.Point(426, 0);
            this.panelToggleButton.Name = "panelToggleButton";
            this.panelToggleButton.Size = new System.Drawing.Size(120, 32);
            this.panelToggleButton.TabIndex = 17;
            // 
            // buttonToggle
            // 
            this.buttonToggle.Location = new System.Drawing.Point(0, 8);
            this.buttonToggle.Name = "buttonToggle";
            this.buttonToggle.Size = new System.Drawing.Size(104, 20);
            this.buttonToggle.TabIndex = 0;
            this.buttonToggle.Text = "&Switch to Execute";
            this.buttonToggle.Click += new System.EventHandler(this.buttonToggle_Click);
            // 
            // panelTemplate
            // 
            this.panelTemplate.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelTemplate.Location = new System.Drawing.Point(0, 0);
            this.panelTemplate.Name = "panelTemplate";
            this.panelTemplate.Size = new System.Drawing.Size(120, 32);
            this.panelTemplate.TabIndex = 19;
            // 
            // panelPublish
            // 
            this.panelPublish.Controls.Add(this.comboBoxRelease);
            this.panelPublish.Controls.Add(this.buttonPublish);
            this.panelPublish.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelPublish.Location = new System.Drawing.Point(258, 0);
            this.panelPublish.Name = "panelPublish";
            this.panelPublish.Size = new System.Drawing.Size(168, 32);
            this.panelPublish.TabIndex = 20;
            this.panelPublish.Visible = false;
            // 
            // comboBoxRelease
            // 
            this.comboBoxRelease.Location = new System.Drawing.Point(72, 8);
            this.comboBoxRelease.Name = "comboBoxRelease";
            this.comboBoxRelease.Size = new System.Drawing.Size(88, 21);
            this.comboBoxRelease.TabIndex = 20;
            // 
            // buttonPublish
            // 
            this.buttonPublish.Location = new System.Drawing.Point(8, 6);
            this.buttonPublish.Name = "buttonPublish";
            this.buttonPublish.Size = new System.Drawing.Size(56, 20);
            this.buttonPublish.TabIndex = 19;
            this.buttonPublish.Text = "&Publish";
            this.buttonPublish.Click += new System.EventHandler(this.buttonPublish_Click);
            // 
            // contextMenu
            // 
            this.contextMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItemExport,
            this.menuItemImport,
            this.menuItemBulkEdit,
            this.menuItemDisplayAssignmentInfo});
            this.contextMenu.Popup += new System.EventHandler(this.contextMenu_Popup);
            // 
            // menuItemExport
            // 
            this.menuItemExport.Index = 0;
            this.menuItemExport.Text = "Export...";
            this.menuItemExport.Click += new System.EventHandler(this.menuItemExport_Click);
            // 
            // menuItemImport
            // 
            this.menuItemImport.Index = 1;
            this.menuItemImport.Text = "Import...";
            this.menuItemImport.Click += new System.EventHandler(this.menuItemImport_Click);
            // 
            // menuItemBulkEdit
            // 
            this.menuItemBulkEdit.Index = 2;
            this.menuItemBulkEdit.Text = "Bulk Edit...";
            this.menuItemBulkEdit.Click += new System.EventHandler(this.menuItemBulkEdit_Click);
            // 
            // menuItemDisplayAssignmentInfo
            // 
            this.menuItemDisplayAssignmentInfo.Index = 3;
            this.menuItemDisplayAssignmentInfo.Text = "Display Execution Info";
            this.menuItemDisplayAssignmentInfo.Click += new System.EventHandler(this.menuItemDisplayAssignmentInfo_Click);
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.InitialDirectory = "C:\\\\teststudio";
            this.saveFileDialog.RestoreDirectory = true;
            // 
            // openFileDialog
            // 
            this.openFileDialog.InitialDirectory = "C:\\\\teststudio";
            this.openFileDialog.RestoreDirectory = true;
            // 
            // buttonOpenlog
            // 
            this.buttonOpenlog.Location = new System.Drawing.Point(190, 8);
            this.buttonOpenlog.Name = "buttonOpenlog";
            this.buttonOpenlog.Size = new System.Drawing.Size(108, 21);
            this.buttonOpenlog.TabIndex = 21;
            this.buttonOpenlog.Text = "Html/Pic/Xml Log";
            this.buttonOpenlog.UseVisualStyleBackColor = true;
            this.buttonOpenlog.Click += new System.EventHandler(this.buttonOpenlog_Click);
            // 
            // TestRunEditor
            // 
            this.Name = "TestRunEditor";
            this.Size = new System.Drawing.Size(776, 608);
            this.Load += new System.EventHandler(this.TestRunEditor_Load);
            this.Controls.SetChildIndex(this.panelTop1, 0);
            this.Controls.SetChildIndex(this.panelBottom1, 0);
            this.Controls.SetChildIndex(this.panelCenter, 0);
            this.panelTop1.ResumeLayout(false);
            this.panelBottom1.ResumeLayout(false);
            this.panelCenter.ResumeLayout(false);
            this.panelLeft.ResumeLayout(false);
            this.panelRight.ResumeLayout(false);
            this.panelMiddle.ResumeLayout(false);
            this.panelConfigPicker.ResumeLayout(false);
            this.panelSelector.ResumeLayout(false);
            this.contextMenu2.ResumeLayout(false);
            this.panelTestRunAssignmentInfo.ResumeLayout(false);
            this.panelAssignmentEditor.ResumeLayout(false);
            this.panelTestRunInfo.ResumeLayout(false);
            this.panelExecute.ResumeLayout(false);
            this.panelSave.ResumeLayout(false);
            this.panelGnerate.ResumeLayout(false);
            this.panelShowLabRun.ResumeLayout(false);
            this.panelToggleButton.ResumeLayout(false);
            this.panelPublish.ResumeLayout(false);
            this.ResumeLayout(false);

        }
        #endregion

        private void HandleApplicationClosingNotification(NotificationRequest request)
        {
            ApplicationClosingNotification notify = request as ApplicationClosingNotification;

            if (notify != null)
            {
                this.assignments.ApplyConfigChange();

                if (this.assignments.dirtyBit)
                {
                    DialogResult dlgRes;
                    dlgRes = MessageBox.Show(
                        "Do you want to save changes?",
                        "Confirm Document Close",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question);

                    if (dlgRes == DialogResult.Yes)
                    {
                        SaveTestRun();
                    }
                }
            }
        }

        private void HandleReleaseChangeNotification(NotificationRequest request)
        {
            ReleaseChangeNotification change = request as ReleaseChangeNotification;

            if (change != null)
            {
                BuildListRequest buildRequest = new BuildListRequest();
                buildRequest.Release = new TestRelease();
                buildRequest.Release.ReleaseName = change.ReleaseName;
                this.GetDataAsync(buildRequest, new NotificationRequestHandler(this.BuildListLoaded));
            }
        }

        public void HandleBuildChangeNotification(NotificationRequest request)
        {
            string requestType = "Build";
            BuildChangeNotification notify = request as BuildChangeNotification;

            if (notify != null)
            {
                this.testArea.LoadTree(requestType, notify.BuildName);
            }
        }

        private void HandleUserChangeNotification(NotificationRequest request)
        {
            this.GetDataAsync(new ManagerRequest(RepositoryRequestType.Get), new NotificationRequestHandler(this.ManagerListLoaded));
        }

        private void HandleValidateAssignmentsNotification(NotificationRequest request)
        {
            AssignmentCollection validateAssignments = new AssignmentCollection();

            //Validate the assignments after the build change

            if (this.assignments != null && this.assignments.Assignments != null)
            {
                validateAssignments = this.assignments.Assignments;
                this.ValidateAssignments(validateAssignments, false);
                this.assignments.Assignments = validateAssignments;
            }
        }

        private void HandleValidateTestCasesNotification(NotificationRequest request)
        {
            this.testSelector.UpdateSelectedTestCases(this.ValidateTestCases());
        }

        private void HandleTestAreaChangeNotification(NotificationRequest request)
        {
            //Get all the test cases and assign it to the TestCasePanel Grid Control

            FilterExpression expression;
            ArrayList TestCases = new ArrayList();
            TestInfoCollection TestCasesCollection = new TestInfoCollection();

            TestTreeChangeNotification change = request as TestTreeChangeNotification;

            if (change != null && change.RootTestAreas != null)
            {
                foreach (TestArea ta in change.RootTestAreas)
                {
                    // enabled email if System Task test cases in build
                    this.labRunInfo.EnabledEmail = (ta.FindTest(c_EmailNotification) != null);

                    TestCases = ta.GetAllTestCases();

                    if (TestCases != null)
                    {
                        foreach (TestInfo ti in TestCases)
                        {
                            TestCase testCase = ti as TestCase;
                            expression = this.testArea.TestAreaControl.Filter;

                            if ((expression != null) && (testCase != null))
                            {
                                if (!expression.Filter(testCase))
                                {
                                    continue;
                                }
                            }

                            TestCasesCollection.Add(ti);
                        }
                    }
                }

                TestCasesList = TestCasesCollection;

                //Send it to the TestSelectorControl

                this.testSelector.TestCasesList = TestCasesList;
            }
            else
            {
                //               this.testSelector.ClearPickerTestCases();
            }
        }

        NotificationRequestHandler releaseHandler = null;

        void LoadBuildRelease(string release, string buildname)
        {
            this.RemoveNotificationHandler(typeof(ReleaseChangeNotification), releaseHandler);

            ReleaseListRequest releaseList = new ReleaseListRequest();
            this.GetData(releaseList);
            this.labRunInfo.Release = releaseList.Objects;

            if (release == null && this.labRunInfo.Release != null && this.labRunInfo.Release.Length > 0)
            {
                release = this.labRunInfo.Release[0];
            }

            BuildListRequest buildList = new BuildListRequest();
            buildList.Release = new TestRelease();
            buildList.Release.ReleaseName = release;
            this.GetData(buildList);
            labRunInfo.Builds = buildList.Objects;

            if (release != null)
            {
                this.labRunInfo.TestReleaseName = release;
            }

            if (buildname != null)
            {
                this.labRunInfo.TestBuildName = buildname;
            }

            AddNotificationHandler(typeof(ReleaseChangeNotification), releaseHandler);
        }

        private void TestRunEditor_Load(object sender, System.EventArgs e)
        {

            try
            {
                // Check to see if there is any Execution Driver available
                AddNotificationHandler(typeof(TestTreeChangeNotification), NotificationType.App, new NotificationRequestHandler(this.HandleTestAreaChangeNotification));
                AddNotificationHandler(typeof(LoadTestRunNotification), new NotificationRequestHandler(this.HandleLoadTestRunNotification));
                AddNotificationHandler(typeof(ImportTestRunNotification), new NotificationRequestHandler(this.HandleImportTestRunNotification));
                AddNotificationHandler(typeof(ApplicationClosingNotification), new NotificationRequestHandler(this.HandleApplicationClosingNotification));
                //AddNotificationHandler(typeof(LoadTemplateNotification), new NotificationRequestHandler(this.HandleLoadTemplateNotification));
                AddNotificationHandler(typeof(BuildChangeNotification), new NotificationRequestHandler(this.HandleBuildChangeNotification));
                AddNotificationHandler(typeof(ValidateAssignmentsNotification), new NotificationRequestHandler(this.HandleValidateAssignmentsNotification));
                AddNotificationHandler(typeof(ValidateTestCasesNotification), new NotificationRequestHandler(this.HandleValidateTestCasesNotification));
                AddNotificationHandler(typeof(UserChangeNotification), new NotificationRequestHandler(this.HandleUserChangeNotification));
                AddNotificationHandler(typeof(FileAssignmentImportNotification), new NotificationRequestHandler(this.HandleFileAssignmentImportNotification));
                AddNotificationHandler(typeof(FileAssignmentExportNotification), new NotificationRequestHandler(this.HandleFileAssignmentExportNotification));
                AddNotificationHandler(typeof(UserSettingsChangedNotification), new NotificationRequestHandler(this.HandleUserSettingsChangedNotification));

                //App Config to show the appropriate controls
                this.GetDataAsync(new AppConfigRequest(RepositoryRequestType.Get), new NotificationRequestHandler(AppConfigLoaded));
                this.GetDataAsync(new ManagerRequest(RepositoryRequestType.Get), new NotificationRequestHandler(this.ManagerListLoaded));

                ArrayList logLevel = new ArrayList();
                logLevel.Add(LogLevelType.Default);

                //LabRun Status Combo
                this.labRunInfo.LabRunStatus = Enum.GetNames(typeof(LabRunStatusType));
                this.labRunInfo.LogLevel = Enum.GetNames(typeof(LogLevelType));

                this.labRunInfo.UpdateSelectedLogLevels(logLevel);
            }
            catch (Exception)
            {
            }
        }

        public void AppConfigLoaded(NotificationRequest aRequest)
        {
            DataNotification dataRequest = aRequest as DataNotification;

            if (dataRequest != null)
            {
                AppConfigRequest appRequest = dataRequest.Request as AppConfigRequest;
                if (appRequest != null)
                {

                    LoadPersistedUIState(appRequest.AppConfig.Mode);

                    this.labRunInfo.LabRunText = this.GetDefualtLabRunName();

                    //Exporting Assignments
                    this.assignments.OnExportAssignments += new EventHandler(assignments_OnExportAssignments);

                    //Get the Logged on User
                    this.LogonUser = WindowsIdentity.GetCurrent().Name;

                    switch (appRequest.AppConfig.Mode)
                    {
                        case ApplicationMode.LabRun:
                            this.LabRunMode = true;
                            this.panelTestRunInfo.Visible = true;
                            this.panelShowLabRun.Visible = true;
                            this.panelExecute.Visible = false;
                            this.panelToggleButton.Visible = false;
                            this.buttonShowLabRun.Text = "&Hide LabRun";
                            this.panelPublish.Visible = false;
                            //this.templateSelector.Visible = true;
                            this.buttonOpenlog.Visible = false;

                            LoadBuildRelease(null, null);

                            break;

                        case ApplicationMode.TestPlayer:
                            this.panelExecute.Visible = true;
                            this.panelToggleButton.Visible = true;
                            this.panelTestRunInfo.Visible = false;
                            this.panelShowLabRun.Visible = false;
                            this.panelTemplate.Visible = false;
                            this.buttonOpenlog.Visible = true;

                            this.NotifyUIAsync(new LoadTestRunNotification(this.GetDefualtLabRunName()));

                            //object[] obj = NetPlugin.PluginManager.FindPluginByInterface(typeof(ITFxEngineDriver));

                            //if (obj == null || obj.Length == 0)
                            //{
                            //    InfoNotification error = new InfoNotification();
                            //    error.MessageType = SeverityType.Error;
                            //    error.Message = "There is no Execution Driver availabe. Please check application config";
                            //    NotifyUI(error);
                            //}

                            AppConfigRequest request = new AppConfigRequest(RepositoryRequestType.Get);
                            this.GetData(request);

                            this.panelPublish.Visible = request.AppConfig.DevMode;
                            if (request.AppConfig.DevMode)
                            {
                                // TODO: Delete all DB-connected-mode code from Test Studio
                                //LabRunManagerRepository rep = new LabRunManagerRepository();
                                //ReleaseListRequest req = new ReleaseListRequest();
                                //rep.ExecuteRequest(req);

                                //this.comboBoxRelease.DataSource = req.Objects;
                                //this.comboBoxRelease.DisplayMember = "Name";
                            }

                            break;
                    }

                    LoadUIState();
                }
            }

        }

        public void ManagerListLoaded(NotificationRequest request)
        {
            DataNotification dataRequest = request as DataNotification;

            if (dataRequest != null)
            {
                ManagerRequest managerRequest = dataRequest.Request as ManagerRequest;
                if (managerRequest != null && managerRequest.ManagersList != null)
                {
                    this.labRunInfo.LabRunManagers = managerRequest.ManagersList;
                }
            }
        }

        public void BuildListLoaded(NotificationRequest request)
        {
            DataNotification dataRequest = request as DataNotification;

            if (dataRequest != null)
            {
                BuildListRequest buildRequest = dataRequest.Request as BuildListRequest;
                if (buildRequest != null && buildRequest.Objects != null)
                {
                    this.labRunInfo.Builds = buildRequest.Objects;
                }
            }
        }

        protected int GetMaxAssignment(AssignmentCollection col)
        {
            int max = 0;

            if (col != null)
            {
                foreach (Assignment assignment in col)
                {
                    if (max < assignment.AssignmentId)
                    {
                        max = assignment.AssignmentId;
                    }
                }
            }

            return max;
        }

        protected virtual void GetConfigInfo(ConfigData data, AppConfigRequest appRequest, UserSettingRequest userSettings)
        {
            ConfigData logdd = new ConfigData();
            TFxConst env = new TFxConst();

            if (appRequest.AppConfig.Mode == ApplicationMode.TestPlayer)
            {
                TestStudioUsersSetting settings = userSettings.Settings as TestStudioUsersSetting;

                env.LogType = TFxConst.c_FileLog;
                env.LogInfo = Application.StartupPath;
                env.LogLevel = this.ConvertToLogLevelType(settings.LogLevel);
                env.SeverityType = settings.SeverityLevel;
            }
            // TODO: Delete all DB-connected-mode code from Test Studio
            //else
            //{
            //    env.LogType = TFxConst.c_DBLog;

            //    TFxDBRepository.DBInfoRequest db = new TFxDBRepository.DBInfoRequest(RepositoryRequestType.Get);
            //    GetData(db);

            //    env.LogInfo = string.Format("Data Source={0};Initial Catalog={1};Integrated Security=SSPI", db.LogServerName, db.LogDBName);

            //    logLevel = this.labRunInfo.GetSelectedLogLevels();
            //    env.LogLevel = this.ConvertToLogLevelType(logLevel);
            //    // we have assignments in the labrun already we need to add thows rows as well
            //}

            env.AssignmentTimeout = userSettings.Settings.AssignmentTimeOut;

            logdd.Append(env.Config);
            if (data.ConfigTable != null && data.ConfigTable.Rows.Count > 0)
            {
                data.Merge(logdd, false);
            }
            else
            {
                //Hack: Merge is not working when the config data rows count is 0
                data.Append(logdd);
            }
        }

        protected virtual void ApplyExistingConfigData(ConfigData dd)
        {
            if (assignments.Assignments == null)
                return;
            foreach (Assignment assignment in assignments.Assignments)
            {
                if (assignment != null && assignment.ConfigData != null)
                {
                    for (int i = 0; i < assignment.ConfigData.ConfigTable.Columns.Count; i++)
                    {
                        if (!dd.ConfigTable.Columns.Contains(assignment.ConfigData.ConfigTable.Columns[i].ToString()))
                        {
                            dd.ConfigTable.Columns.Add(assignment.ConfigData.ConfigTable.Columns[i].ToString());
                        }
                    }
                }
            }
        }

        // Changed labrunid guid to labrungid
        protected virtual void buttonGenerate_Click(object sender, System.EventArgs e)
        {
            int currentMaxAssignmentIndex = 0;
            int count = 0;
            TestInfoCollection validTestCases = new TestInfoCollection();

            //Used to get the assignments list that is needed to update the AssignmentCollectionEditor
            AssignmentCollection assignList = new AssignmentCollection();

            //Get the Config Data selected in the Config Picker Control(via the Config Selection Control)
            if (this.config != null)
            {
                IConfig[] Data = this.config.GetSelectedConfigs();

                // need to get build into the assignment to run the test
                TestBuildRequest request = new TestBuildRequest(RepositoryRequestType.Get);
                request.BuildName = this.labRunInfo.TestBuildName;
                request.BuildType = BuildType.Specific;

                GetData(request);

                if (Data != null && Data.Length > 0)
                {

                    if (this.assignments.Assignments != null)
                    {
                        this.assignments.ApplyConfigChange();
                        assignList.AddRange(this.assignments.Assignments);
                    }

                    //Find out the index from where to start the assignment index
                    if (assignList.Count > 0)
                    {
                        currentMaxAssignmentIndex = GetMaxAssignment(assignList);
                    }
                    else
                    {
                        count = currentMaxAssignmentIndex;
                    }

                    if (currentMaxAssignmentIndex <= MaxAssignmentIndex)
                    {
                        count = MaxAssignmentIndex + 1;
                    }
                    else
                    {
                        count = currentMaxAssignmentIndex + 1;
                    }

                    //App Config to show the appropriate controls
                    AppConfigRequest appRequest = new AppConfigRequest(RepositoryRequestType.Get);
                    this.GetData(appRequest);

                    UserSettingRequest userSettings = new UserSettingRequest(RepositoryRequestType.Get);
                    userSettings.Mode = appRequest.AppConfig.Mode;
                    GetData(userSettings);

                    //Loop througth the entire selected config data
                    for (int index = 0; index < Data.Length; index++)
                    {
                        validTestCases = this.testSelector.SeletedTestCases.ValidTestCases();

                        //Loop through the entire selected test cases
                        if (validTestCases != null && validTestCases.Count > 0)
                        {
                            this.assignments.dirtyBit = true;

                            foreach (TestCase testCase in validTestCases)
                            {
                                Assignment assignment = new Assignment();
                                assignment.TestCase = testCase as TestCase;

                                //
                                // Update the test case of the assignment with 
                                // namespace and branch information if none
                                // are defined
                                //
                                if (assignment.TestCase.TestConfigs.ContainsKey("__releaseinfo") == false)
                                {
                                    assignment.TestCase.TestConfigs.Add("__releaseinfo", "main");
                                }
                                if (assignment.TestCase.TestConfigs.ContainsKey("__testnamespace") == false)
                                {
                                    assignment.TestCase.TestConfigs.Add("__testnamespace", assignment.TestCase.FullName);
                                }


                                ConfigData dd = new ConfigData();
                                dd.Append(Data[index]);

                                assignment.AssignmentId = count;
                                assignList.Add(assignment);
                                assignment.LabRun = new LabRun();
                                assignment.LabRun.Name = this.labRunInfo.LabRunText;
                                assignment.LabRun.LabRunGid = Guid.Empty/*1*/; //Not sure what this means
                                assignment.LabRun.Build = request.Build;

                                GetConfigInfo(dd, appRequest, userSettings);
                                ApplyExistingConfigData(dd);
                                assignment.ConfigData = dd;

                                string timeout = assignment.ConfigData.GetValue(TFxConst.c_AssignmentTimeout);

                                if (timeout != null)
                                {
                                    try
                                    {
                                        assignment.AssignmentTimeout = TimeSpan.Parse(timeout);
                                    }
                                    catch
                                    {
                                        // this is not a value timeout
                                        assignment.AssignmentTimeout = TimeSpan.Zero;
                                    }
                                }
                                count++;
                            }
                        }
                    }

                    this.assignments.Assignments = assignList;
                }
            }
        }

        /// <summary>
        /// This function is used to show the Lab Run Info whenever required
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonShowLabRun_Click(object sender, System.EventArgs e)
        {
            if (this.panelTestRunInfo.Visible == false)
            {
                this.panelTestRunInfo.Visible = true;
                this.buttonShowLabRun.Text = "&Hide LabRun";
            }
            else
            {
                if (this.panelTestRunInfo.Visible == true)
                {
                    this.panelTestRunInfo.Visible = false;
                    this.buttonShowLabRun.Text = "&Show LabRun";
                }
            }
        }

        public const string c_EmailNotification = "Expedia.System.Task.EmailNotification";

        /// Comments: changed testrunid to GUID testrungid
        public void SaveTestRun()
        {
            LabRunRequest labRequest = null;
            string invalidTestCasesNames = null;
            bool invalidAssignmentExists = false;

            //Build the Test Run object
            LabRun testRun = new LabRun();
            this.assignments.ApplyConfigChange();
            testRun.Assignments = this.assignments.Assignments;

            this.Cursor = Cursors.WaitCursor;

            //Make sure that the user has actually generated the assignments
            if ((testRun != null) && (testRun.Assignments != null)/*&&(testRun.Assignments.Count >0)*/)
            {
                invalidTestCasesNames = this.InvalidTestCasesNames(testRun.Assignments);

                if (LabRunMode)
                {
                    if (invalidTestCasesNames != null)
                    {
                        invalidAssignmentExists = true;
                    }

                    if (invalidAssignmentExists)
                    {
                        testRun.Assignments = this.GetValidAssignments(testRun.Assignments);
                    }
                }

                testRun.Name = this.labRunInfo.LabRunText;

                TestBuildRequest request = new TestBuildRequest(RepositoryRequestType.Get);
                request.BuildName = this.labRunInfo.TestBuildName;
                request.BuildType = BuildType.Specific;
                GetData(request);

                testRun.Build = request.Build;

                testRun.Manager = this.labRunInfo.Manager;

                testRun.Status = (LabRunStatusType)Enum.Parse(typeof(LabRunStatusType), this.labRunInfo.Status);

                if (this.labRunInfo.Email != null && this.labRunInfo.Email != "")
                {
                    TestInfo info = this.testArea.FindTest(c_EmailNotification);
                    testRun.SystemTasks.Clear();

                    Assignment systemTask = new Assignment();
                    systemTask.AssignmentId = int.MaxValue;
                    systemTask.TestCase = info as TestCase;

                    ConfigData dd = new ConfigData();
                    StringConfig config = new StringConfig();
                    config.Add(TFxConst.c_Email, this.labRunInfo.Email);
                    dd.Append(config);

                    systemTask.ConfigData = dd;
                    systemTask.LabRun = new LabRun();
                    systemTask.LabRun.Name = this.labRunInfo.LabRunText;
                    systemTask.LabRun.LabRunGid = LabRunGid;
                    systemTask.LabRun.Build = request.Build;

                    if (systemTask.TestCase != null)
                    {
                        testRun.SystemTasks.Add(systemTask);
                    }
                }
                if (LabRunGid != Guid.Empty)
                {
                    //Update the assignments logs
                    UpdateAssignmentsLog(testRun.Assignments);

                    labRequest = new LabRunRequest(RepositoryRequestType.Update);
                    labRequest.UserName = this.LogonUser;

                    if (this.labRunInfo.LogLevelUpdated)
                    {
                        testRun.Assignments.UpdateAssignments(true);
                    }
                    labRequest.isAssignmentCollectionChanged = this.assignments.dirtyBit || this.labRunInfo.LogLevelUpdated || this.labRunInfo.ReleaseUpdated || testRun.SystemTasks.Count > 0;
                    testRun.LabRunGid = LabRunGid;

                    //If Labrun status is reset to Created, reset assignment status to Assign and assign to the labrun manager
                    if (testRun.Status == LabRunStatusType.Created && labRunInfo.OriginalStatus != null &&
                        !labRunInfo.OriginalStatus.Equals(LabRunStatusType.Created))
                    {
                        foreach (Assignment assign in testRun.Assignments)
                        {
                            assign.RunStatus = AssignmentStatusType.Assigned;
                            assign.AssignedTo = testRun.Manager;
                        }

                        labRequest.isAssignmentCollectionChanged = true;
                        testRun.Assignments.UpdateAssignments(true);
                    }
                }
                else
                {
                    labRequest = new LabRunRequest(RepositoryRequestType.Create);
                    labRequest.UserName = this.LogonUser;
                    testRun.LabRunGid = this.LabRunGid;
                }

                labRequest.LabRun = testRun;
                GetData(labRequest);

                if (labRequest.Message != null)
                {
                    this.assignments.dirtyBit = false;
                }

                LabRunGid = labRequest.LabRun.LabRunGid;
            }

            this.Cursor = Cursors.Default;
        }

        public void ExportTestRun(AssignmentCollection importAssignments, string fileName)
        {
            ImportExportTestRunRequest exportRequest = null;

            //Build the Test Run object
            LabRun testRun = new LabRun();
            this.assignments.ApplyConfigChange();

            if (importAssignments == null || fileName == "")
            {
                return;
            }

            testRun.Assignments = importAssignments;

            //Make sure that the user has actually generated the assignments
            if ((testRun != null) && (testRun.Assignments != null)/*&&(testRun.Assignments.Count >0)*/)
            {
                testRun.Name = fileName;

                TestBuildRequest request = new TestBuildRequest(RepositoryRequestType.Get);
                request.BuildName = this.labRunInfo.TestBuildName;
                request.BuildType = BuildType.Specific;
                GetData(request);

                testRun.Build = request.Build;

                testRun.Manager = this.labRunInfo.Manager;

                testRun.Status = (LabRunStatusType)Enum.Parse(typeof(LabRunStatusType), this.labRunInfo.Status);

                exportRequest = new ImportExportTestRunRequest(RepositoryRequestType.Create);
                testRun.LabRunGid = LabRunGid;

                exportRequest.LabRun = testRun;
                GetData(exportRequest);

                if (exportRequest.Message != null)
                {
                    this.assignments.dirtyBit = false;
                }
            }
        }

        /// <summary>
        /// Save the labrun
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected virtual void buttonSave_Click(object sender, System.EventArgs e)
        {
            SaveTestRun();
        }

        private void buttonPublish_Click(object sender, System.EventArgs e)
        {
            // TODO: Remove all DB-connected code from TestStudio
            // This code commented out during SoftTest since labrungid is no longer supported

            //TestBuildRequest request = new TestBuildRequest(RepositoryRequestType.Get);
            //request.BuildName = "Latest";
            //GetData(request);

            //if (request.Build.Modules.Length == 1)
            //{
            //    RepositorySyncTestArea syncRequest = new RepositorySyncTestArea(RepositoryRequestType.Sync_Echo);
            //    Repository publishingRepository = new LabRunManagerRepository();
            //    syncRequest.TestAreaToSync = this.testArea.TestAreaControl.RootTestAreas[0] as TestArea;
            //    syncRequest.Release = this.comboBoxRelease.SelectedItem.ToString();
            //    syncRequest.RightRepository = publishingRepository;

            //    GetData(syncRequest);
            //}
            //else
            //{
            //    // there is more than one module loaded
            //    MessageBox.Show("Cannot support more than one module");
            //}
        }

        public delegate void RunMyTest(Assignment assignment, AssignmentResult result);

        RunMyTest myTestRunner;

        protected virtual void AssignmentCompleted(Client client, Assignment assignment, AssignmentResult result)
        {
            System.IAsyncResult async = this.BeginInvoke(this.myTestRunner, new object[2] { assignment, result });
        }

        protected void AssignmentRunning(Client client, Assignment assignment, AssignmentResult result)
        {
            System.IAsyncResult async = this.BeginInvoke(this.myTestRunner, new object[2] { assignment, result });
        }

        protected void TestRunCompleted(LabRun run)
        {
            buttonExecute.Text = "&Execute";
            buttonExecute.Enabled = true;
        }

        public void Runner(Assignment assignment, AssignmentResult result)
        {
            bool shouldBind = false;
            if (this.assignments.Assignments.Contains(assignment))
            {
                assignment.Result = result;
                shouldBind = true;
            }
            if (shouldBind)
            {
                // TODO: STOP rebinding the data grid every time an assignment completes!
                this.assignments.BindDataGrid();
                this.SaveTestRun();
            }
        }

        protected virtual TFxTeam GetTeam()
        {
            TFxTeam team1 = new TFxTeam();
            team1.Manager = new TFxUser();
            team1.Manager.IsManager = true;
            team1.Manager.Name = "TP_Manager";

            UserSettingRequest request = new UserSettingRequest(RepositoryRequestType.Get);
            GetData(request);

            TestStudioUsersSetting setting = request.Settings as TestStudioUsersSetting;

            team1.Clients = new ClientCollection();
            LocalClient client = new LocalClient(setting.ClientCount, null);

            client.Tester = new TFxUser();
            client.Tester.IsManager = false;
            client.Tester.Name = "TP_Client";

            client.Name = "TP_Client";
            client.ClientAssignmentCompleted += new ClientAssignmentEventHandler(this.AssignmentCompleted);
            client.ClientAssignmentRunning += new ClientAssignmentEventHandler(this.AssignmentRunning);
            team1.Clients.Add(client);

            return team1;
        }

        protected LabRun CreateTestRun(TFxTeam team, AssignmentCollection col)
        {
            LabRun run = new LabRun();
            run.Assignments = col;
            run.Name = this.labRunInfo.LabRunText;

            TestBuildRequest request = new TestBuildRequest(RepositoryRequestType.Get);
            GetData(request);
            run.Build = request.Build;

            run.Manager = this.labRunInfo.Manager;

            for (int i = 0; i < run.Assignments.Count; i++)
            {
                run.Assignments[i].AssignedTo = run.Manager;
                run.Assignments[i].LabRun.Name = run.Name;
                run.Assignments[i].LabRun.AssignedTo = run.Manager;
                run.Assignments[i].Result = null;
                run.Assignments[i].RunStatus = AssignmentStatusType.None;
            }

            return run;
        }

        protected virtual void buttonExecute_Click(object sender, System.EventArgs e)
        {
            if (this.buttonExecute.Text == "&Execute")
            {
                //Save UI Settings if Editing State
                if (GetUIMode() == UIStateMode.Editing)
                {
                    PersistUIState();
                    this.buttonToggle.Text = "&Switch to Edit";
                    LoadUIState();
                }

                // If there are no selected assignments, run all assignments instead
                AssignmentCollection col = new AssignmentCollection();
                AssignmentCollection localCol = null;
                if (assignments.SelectedAssignments.Count > 0)
                {
                    localCol = assignments.SelectedAssignments;
                }
                else
                {
                    localCol = assignments.Assignments;
                }

                foreach (Assignment assign in localCol)
                {
                    if (!assign.Disabled)
                    {
                        col.Add(assign);
                    }
                }

                if (col != null && col.Count > 0)
                {
                    //Track the assignments that the user has last executed so that we can run this when debug is selected
                    ExportTestRun(col, m_executedAssignmentsList);

                    UpdateAssignmentsLog(col);

                    TFxTeam team = GetTeam();
                    this.assignments.ApplyConfigChange();
                    this.assignments.ClearResult();

                    LabRun run = CreateTestRun(team, col);

                    manager = new ExecutionManager();
                    manager.TestRunComplete += new ExecutionManagerLabRunHandler(this.TestRunCompleted);
                    manager.Execute(team, run);
                    this.assignments.reloadResults = true;

                    //buttonExecute.Enabled = false;
                    this.buttonExecute.Text = "&Stop";
                    this.assignments.ShortResultBottomVisible = true;
                    this.assignments.ShortResultRightVisible = false;
                }
            }
            else if (buttonExecute.Text == "&Stop")
            {
                if (manager != null)
                {
                    manager.PauseLabRun();
                    manager = null;
                }

                this.buttonExecute.Text = "&Execute";
            }
        }

        private void buttonToggle_Click(object sender, System.EventArgs e)
        {
            //this.templateSelector.ButtonView = !this.templateSelector.ButtonView;
            if (this.buttonToggle.Text.EndsWith("Execute"))
            {
                //Save the Editing State
                this.PersistUIState();
                this.assignments.ShortResultBottomVisible = true;
                this.assignments.ShortResultRightVisible = false;
                this.buttonToggle.Text = "&Switch to Edit";
                this.PersistCurrentState();
            }
            else
            {
                //Save Executing State
                PersistUIState();
                this.assignments.ShortResultBottomVisible = false;
                this.assignments.ShortResultRightVisible = false;
                this.buttonToggle.Text = "&Switch to Execute";
                this.PersistCurrentState();
            }

            LoadUIState();
        }

        /// <summary>
        /// This event is called when the Application is closing
        /// The control needs to update the value in the file repository
        ///  
        /// </summary>
        /// <param name="request"></param>
        /// 

        //Copy to the File
        public override void PersistUIState()
        {
            UIStateMode persistMode = this.GetUIMode();
            Profile profile = base.GetProfile();

            if (profile == null)
            {
                profile = new Profile();
            }

            switch (persistMode)
            {
                case (UIStateMode.Editing):
                    PersistEditingMode(profile);
                    break;

                case (UIStateMode.Executing):
                    PersistExecutingMode(profile);
                    break;
            }

            //Save it to the file
            base.UpdateProfile(profile);
        }

        private void PersistCurrentState()
        {
            UIStateMode persistMode = this.GetUIMode();

            Profile profile = base.GetProfile();

            if (profile == null)
            {
                profile = new Profile();
            }

            profile.TestRunEditorCurrentState = persistMode;

            //Save it to the file
            base.UpdateProfile(profile);
        }

        /// <summary>
        /// This event is called during the load
        /// Get all the current settings from the file repository
        /// </summary>
        /// <param name="request"></param>

        //Get from the File
        protected void LoadUIState()
        {
            Profile profile = null;
            UIStateMode currentMode;

            profile = base.GetProfile();
            currentMode = this.GetUIMode();

            if (profile != null)
            {
                switch (currentMode)
                {
                    case (UIStateMode.Editing):
                        LoadEditingModeInformation(profile);
                        break;

                    case (UIStateMode.Executing):
                        LoadExecutingModeInformation(profile);
                        break;
                }
            }
        }


        public void LoadPersistedUIState(ApplicationMode mode)
        {
            Profile profile = null;
            UIStateMode currentMode;

            profile = base.GetProfile();

            if (profile != null)
            {
                if (mode == ApplicationMode.LabRun)
                {
                    currentMode = UIStateMode.Editing;
                }
                else
                {
                    currentMode = profile.TestRunEditorCurrentState;
                }

                switch (currentMode)
                {
                    case (UIStateMode.Editing):
                        LoadEditingModeInformation(profile);
                        this.buttonToggle.Text = "&Switch to Execute";

                        break;

                    case (UIStateMode.Executing):
                        LoadExecutingModeInformation(profile);
                        this.buttonToggle.Text = "&Switch to Edit";
                        break;
                }
            }
        }

        protected UIStateMode GetUIMode()
        {
            if ((this.panelExecute.Visible == false) || (this.buttonToggle.Text.EndsWith("Execute")))
            {
                return UIStateMode.Editing;
            }
            else
            {
                return UIStateMode.Executing;
            }
        }

        private void PersistEditingMode(Profile profile)
        {
            if (profile != null && profile.TestRunEditingSettings != null)
            {
                profile.TestRunEditingSettings.splitterLeft = new SplitterState(this.splitterLeft.ControlToHide.Size, this.splitterLeft.IsCollapsed);
                profile.TestRunEditingSettings.splitterConfigPicker = new SplitterState(this.splitterConfigPicker.ControlToHide.Size, this.splitterConfigPicker.IsCollapsed);
                profile.TestRunEditingSettings.splitterSelector = new SplitterState(this.splitterSelector.ControlToHide.Size, this.splitterSelector.IsCollapsed);
            }
        }

        private void PersistExecutingMode(Profile profile)
        {
            if (profile != null && profile.TestRunExecutingSettings != null)
            {
                profile.TestRunExecutingSettings.splitterLeft = new SplitterState(this.splitterLeft.ControlToHide.Size, this.splitterLeft.IsCollapsed);
                profile.TestRunExecutingSettings.splitterConfigPicker = new SplitterState(this.splitterConfigPicker.ControlToHide.Size, this.splitterConfigPicker.IsCollapsed);
                profile.TestRunExecutingSettings.splitterSelector = new SplitterState(this.splitterSelector.ControlToHide.Size, this.splitterSelector.IsCollapsed);
                this.assignments.PersistUIState(profile);
            }
        }

        private void LoadExecutingModeInformation(Profile profile)
        {
            if (profile != null && profile.TestRunExecutingSettings != null)
            {
                LoadSplitterLeft(profile.TestRunExecutingSettings.splitterLeft);
                LoadSplitterConfigPicker(profile.TestRunExecutingSettings.splitterConfigPicker);
                LoadSplitterSplitterSelector(profile.TestRunExecutingSettings.splitterSelector);
                this.assignments.LoadUIState(profile);
            }
        }

        private void LoadEditingModeInformation(Profile profile)
        {
            if (profile != null && profile.TestRunEditingSettings != null)
            {
                LoadSplitterLeft(profile.TestRunEditingSettings.splitterLeft);
                LoadSplitterConfigPicker(profile.TestRunEditingSettings.splitterConfigPicker);
                LoadSplitterSplitterSelector(profile.TestRunEditingSettings.splitterSelector);
            }
        }

        private void LoadSplitterLeft(SplitterState splitterLeft)
        {
            if (splitterLeft != null)
            {
                base.LoadUIState(splitterLeft);
            }
        }

        private void LoadSplitterConfigPicker(SplitterState splitterConfig)
        {
            if (splitterConfig != null)
            {
                this.splitterConfigPicker.ControlToHide.Size = new Size(splitterConfig.ControlToHideSize.Width, splitterConfig.ControlToHideSize.Height);

                if (splitterConfig.isCollapsed)
                {
                    this.splitterConfigPicker.ControlToHide.Visible = false;
                }
                else
                {
                    this.splitterConfigPicker.ControlToHide.Visible = true;
                }
            }
        }

        private void LoadSplitterSplitterSelector(SplitterState splitterSelector)
        {
            if (splitterSelector != null)
            {
                this.splitterSelector.ControlToHide.Size = new Size(splitterSelector.ControlToHideSize.Width, splitterSelector.ControlToHideSize.Height);

                if (splitterSelector.isCollapsed)
                {
                    this.splitterSelector.ControlToHide.Visible = false;
                }
                else
                {
                    this.splitterSelector.ControlToHide.Visible = true;
                }
            }
        }

        /// <summary>
        /// Load a Labrun from a Template 
        /// Comments: changed testrunid to GUID testrungid
        /// </summary>
        /// <param name="request"></param>
        //private void HandleLoadTemplateNotification(NotificationRequest request)
        //{
        //    ArrayList logLevels = new ArrayList();
        //    //LoadTemplateNotification notification = request as LoadTemplateNotification;
        //    LogLevelType logLevel = LogLevelType.None;
        //    TestInfoCollection selectedTestCases = new TestInfoCollection();

        //    //App Config to show the appropriate controls
        //    AppConfigRequest appRequest = new AppConfigRequest(RepositoryRequestType.Get);
        //    this.GetData(appRequest);

        //    UserSettingRequest userSettings = new UserSettingRequest(RepositoryRequestType.Get);
        //    userSettings.Mode = appRequest.AppConfig.Mode;
        //    GetData(userSettings);

        //    if (notification != null)
        //    {
        //        if (notification.testRun.Assignments != null)
        //        {
        //            this.assignments.Assignments = notification.testRun.Assignments;
        //            this.TestRunGid = notification.testRun.TestRunGid;
        //        }

        //        foreach (Assignment assignment in this.assignments.Assignments)
        //        {
        //            ConfigData dd = new ConfigData();
        //            dd.Append(assignment.ConfigData.GetIConfig(0));
        //            GetConfigInfo(dd, appRequest, userSettings);
        //            assignment.ConfigData = dd;

        //            if (assignment.ConfigData.ConfigTable.Columns.Contains("__LogLevel"))
        //            {
        //                DataRow row = assignment.ConfigData.ConfigTable.Rows[0];
        //                logLevel = this.ConvertToLogLevelType(row["__LogLevel"].ToString());
        //            }
        //            logLevels = this.GetAllLogLevels((long)logLevel);

        //            this.labRunInfo.UpdateSelectedLogLevels(logLevels);

        //            //Update the selected test cases control
        //            if (assignment.TestCase != null)
        //            {
        //                if ((!selectedTestCases.Contains(assignment.TestCase)) && (!assignment.Disabled))
        //                {
        //                    selectedTestCases.Add(assignment.TestCase);
        //                }
        //            }
        //        }
        //
        //        if (notification.testRun.Manager != null)
        //        {
        //            this.labRunInfo.Manager = notification.testRun.Manager;
        //        }
        //
        //        if (notification.testRun.TestBuild != null)
        //        {
        //            this.labRunInfo.TestBuildName = notification.testRun.TestBuild.Name;
        //            if (notification.testRun.TestBuild.TestRelease != null)
        //            {
        //                this.labRunInfo.TestReleaseName = notification.testRun.TestBuild.TestRelease.ReleaseName;
        //            }
        //        }
        //
        //        //Update the selected test cases control
        //        this.testSelector.AppendSelectedTestCases(selectedTestCases);
        //    }
        //}

        /// Comments: changed labrun to GUID labrungid
        /// Comments: changed testrunid to GUID testrungid
        public virtual void HandleLoadTestRunNotification(NotificationRequest request)
        {
            LabRunRequest labRequest = new LabRunRequest(RepositoryRequestType.Get);
            LoadTestRunNotification notification = request as LoadTestRunNotification;
            ArrayList logLevels = new ArrayList();
            LogLevelType logLevel = LogLevelType.None;
            TestInfoCollection selectedTestCases = new TestInfoCollection();

            this.labRunInfo.ClearLogLevel();

            if (notification != null)
            {
                if (notification.TestRunName != null)
                {
                    labRequest.LabRunName = notification.TestRunName;
                }
                else if (notification.TestRunGid != Guid.Empty)
                {
                    labRequest.LabRunGid = notification.TestRunGid;
                }

                this.GetData(labRequest);

                if (labRequest.LabRun != null && labRequest.LabRun.Assignments != null)
                {
                    //if teh notification has autobuildpick we need to update the TestBuid
                    if (notification.AutoPickBuild)
                    {
                        TestBuildRequest buildRequest = new TestBuildRequest(RepositoryRequestType.Get);
                        buildRequest.BitAvailable = 1;
                        buildRequest.BuildType = BuildType.Latest;
                        buildRequest.Release = labRequest.LabRun.Build.TestRelease.ReleaseName;
                        this.GetData(buildRequest);

                        if (buildRequest.Build != null)
                        {
                            labRequest.LabRun.Build = buildRequest.Build;
                            labRequest.LabRun.Build.TestRelease = new TestRelease();
                            labRequest.LabRun.Build.TestRelease.ReleaseName = buildRequest.Release;
                        }
                    }

                    LabRunGid = labRequest.LabRun.LabRunGid;

                    this.assignments.Assignments = labRequest.LabRun.Assignments;

                    //App Config to show the appropriate controls
                    AppConfigRequest appRequest = new AppConfigRequest(RepositoryRequestType.Get);
                    this.GetData(appRequest);

                    UserSettingRequest userSettings = new UserSettingRequest(RepositoryRequestType.Get);
                    userSettings.Mode = appRequest.AppConfig.Mode;
                    GetData(userSettings);

                    // Update System Variables
                    foreach (Assignment assignment in this.assignments.Assignments)
                    {
                        ConfigData dd = new ConfigData();
                        dd.Append(assignment.ConfigData.GetIConfig(0));
                        GetConfigInfo(dd, appRequest, userSettings);
                        assignment.ConfigData = dd;

                        string timeout = assignment.ConfigData.GetValue(TFxConst.c_AssignmentTimeout);

                        if (timeout != null)
                        {
                            try
                            {
                                assignment.AssignmentTimeout = TimeSpan.Parse(timeout);
                            }
                            catch
                            {
                                // this is not a value timeout
                                assignment.AssignmentTimeout = TimeSpan.Zero;
                            }
                        }

                        if (assignment.ConfigData.ConfigTable.Columns.Contains(TFxConst.c_LogLevel))
                        {
                            DataRow row = assignment.ConfigData.ConfigTable.Rows[0];
                            logLevel = this.ConvertToLogLevelType(row[TFxConst.c_LogLevel].ToString());
                        }
                        logLevels = this.GetAllLogLevels((long)logLevel);

                        this.labRunInfo.UpdateSelectedLogLevels(logLevels);

                        //Update the selected test cases control
                        if (assignment.TestCase != null)
                        {
                            if (!selectedTestCases.Contains(assignment.TestCase))
                            {
                                selectedTestCases.Add(assignment.TestCase);
                            }
                        }
                    }

                    if (labRequest.LabRun.SystemTasks != null && labRequest.LabRun.SystemTasks.Count > 0)
                    {
                        foreach (Assignment assignment in labRequest.LabRun.SystemTasks)
                        {
                            if (assignment.TestCase != null && assignment.TestCase.FullName == c_EmailNotification)
                            {
                                this.labRunInfo.Email = assignment.ConfigData.GetValue(TFxConst.c_Email);
                                break;
                            }
                        }
                    }

                    //Update the lab run info control
                    if (labRequest.LabRun.Name != null)
                    {
                        labRunInfo.LabRunText = labRequest.LabRun.Name;
                    }

                    if (labRequest.LabRun.Manager != null)
                    {
                        labRunInfo.Manager = labRequest.LabRun.Manager;
                    }

                    if (labRequest.LabRun.Build != null && labRequest.LabRun.Build.TestRelease != null)
                    {
                        this.LoadBuildRelease(labRequest.LabRun.Build.TestRelease.ReleaseName, labRequest.LabRun.Build.Name);
                    }

                    labRunInfo.Status = Enum.GetName(typeof(LabRunStatusType), labRequest.LabRun.Status);

                    //Do not allow updates if labrun status is Running
                    if (labRequest.LabRun.Status == LabRunStatusType.Running
                        || labRequest.LabRun.Status == LabRunStatusType.ToBePaused
                        || labRequest.LabRun.Status == LabRunStatusType.Queued)
                    {
                        InfoNotification warning = new InfoNotification();
                        warning.MessageType = SeverityType.Warning;
                        warning.Message = "Update is not allowed when LabRun is Running";
                        this.NotifyUI(warning);
                        this.buttonSave.Visible = false;
                    }

                    //Get the DB Assignment Index
                    MaxAssignmentIndex = GetMaxAssignment(labRequest.LabRun.Assignments);

                    //Update the selected testcases control
                    this.testSelector.AppendSelectedTestCases(selectedTestCases);
                }
                else
                {
                    LabRunGid = Guid.Empty;
                }
            }

            if (this.AutoRun)
            {
                ImportTestRunNotification importRequest = new ImportTestRunNotification(AutoRunFileName);
                HandleImportTestRunNotification(importRequest);
                buttonExecute.PerformClick();
            }
        }

        private void HandleImportTestRunNotification(NotificationRequest request)
        {
            //int tempMaxIndex;
            //ArrayList buildFolders			= null;
            //string moduleFullPath			= "";
            //bool moduleExists				= false;
            //ArrayList testCasesList			= null;
            //TestArea[] roots;

            ImportExportTestRunRequest importRequest = new ImportExportTestRunRequest(RepositoryRequestType.Get);
            ImportTestRunNotification notification = request as ImportTestRunNotification;

            if (notification != null)
            {
                if (notification.TestRunName != null)
                {
                    importRequest.LabRunName = notification.TestRunName;
                }

                this.GetData(importRequest);

                if (importRequest.LabRun != null && importRequest.LabRun.Assignments != null)
                {
                    if (DebugMode)
                    {
                        //There is no need to validate the assignemnts,  select the assingmnet using Id
                        this.assignments.SelectAssignments(importRequest.LabRun.Assignments);
                        return;
                    }

                    //Validate later to get the correct assignment id's
                    if (!this.ValidateAssignments(importRequest.LabRun.Assignments, true) && !AutoRun)
                    {
                        return;
                    }

                    if (this.assignments.Assignments == null || this.assignments.Assignments.Count == 0)
                    {
                        this.assignments.Assignments = importRequest.LabRun.Assignments;
                    }
                    else
                    {
                        this.assignments.AppendAssignments(importRequest.LabRun.Assignments);
                    }

                    this.assignments.dirtyBit = true;
                }
                else
                {
                    LabRunGid = Guid.Empty;
                }
            }
        }

        private void buttonDeleteAssignment_Click(object sender, System.EventArgs e)
        {
            assignments.DeleteSelected();
        }

        private string GetDefualtLabRunName()
        {
            UserSettingRequest userSettings = new UserSettingRequest(RepositoryRequestType.Get);
            this.GetData(userSettings);

            TestStudioUsersSetting setting = userSettings.Settings as TestStudioUsersSetting;

            if (setting != null && setting.DefaultLabRunName != null)
            {
                return setting.DefaultLabRunName;
            }
            return null;
        }

        //private void splitterSelector_SplitterMoved(object sender, System.Windows.Forms.SplitterEventArgs e)
        //{
        //    testSelector.SetButtonAddLocation();
        //    testSelector.SetButtonDeleteLocation();

        //}

        protected void UpdateAssignmentsLog(AssignmentCollection assignments)
        {
            if (assignments != null)
            {
                //App Config to show the appropriate controls
                AppConfigRequest appRequest = new AppConfigRequest(RepositoryRequestType.Get);
                this.GetData(appRequest);

                UserSettingRequest userSettings = new UserSettingRequest(RepositoryRequestType.Get);
                userSettings.Mode = appRequest.AppConfig.Mode;
                GetData(userSettings);

                //Update the assignments logs
                foreach (Assignment assignment in assignments)
                {
                    ConfigData dd = new ConfigData();
                    GetConfigInfo(dd, appRequest, userSettings);
                    if (dd != null && dd.ConfigTable.Rows.Count > 0)
                    {
                        assignment.ConfigData.UpdateData(dd.ConfigTable.Rows[0]);
                    }
                }
            }
        }

        private LogLevelType ConvertToLogLevelType(string str)
        {
            string val = str.Replace(" ", "");
            string[] types = val.Split('|');
            LogLevelType logLevel = LogLevelType.None;
            if (types.GetLength(0) != 0 && types[0].Length != 0)
            {
                foreach (string type in types)
                {
                    logLevel |= (LogLevelType)Enum.Parse(typeof(LogLevelType), type, true);
                }
            }
            return logLevel;
        }

        private ArrayList GetAllLogLevels(long logValue)
        {
            ArrayList logLevels = new ArrayList();

            System.Array logs = Enum.GetValues(typeof(LogLevelType)) as System.Array;
            foreach (long num in logs)
            {
                if ((num != 0) && (num & logValue) == num)
                {
                    logLevels.Add((LogLevelType)num);
                }
            }

            return logLevels;
        }

        //private void templateSelector_Resize(object sender, System.EventArgs e)
        //{
        //    this.panelTemplate.Size = new Size(this.templateSelector.Size.Width, this.templateSelector.Size.Height);
        //}

        private void assignments_OnExportAssignments(object sender, EventArgs e)
        {
            this.assignments.ContextMenu = this.contextMenu;
        }

        private void HandleFileAssignmentExportNotification(NotificationRequest notification)
        {
            this.ExportAssignments();
        }

        private void menuItemExport_Click(object sender, System.EventArgs e)
        {
            this.ExportAssignments();
        }

        private void ExportAssignments()
        {
            AssignmentCollection exportAssignments = null;
            string fileName = "";
            FileInfo fileInfo;

            this.saveFileDialog = new SaveFileDialog();
            this.saveFileDialog.InitialDirectory = "C:\\teststudio";
            string extension = ".labrun.xml";


            if (this.saveFileDialog.ShowDialog() != DialogResult.Cancel)
            {
                if (this.saveFileDialog.FileName != "")
                {

                    fileName = this.GetFileName(this.saveFileDialog.FileName, extension);
                    fileInfo = new FileInfo(fileName);

                    exportAssignments = this.assignments.SelectedAssignments;
                    if (exportAssignments != null && exportAssignments.Count > 0)
                    {
                        this.ExportTestRun(exportAssignments, fileInfo.Name);
                    }
                    else
                    {
                        this.NotifyUI(InfoNotification.GetInfoNotification(SeverityType.Error, "Please select the assignments that have to be exported"));
                    }
                }
            }
        }

        private void HandleFileAssignmentImportNotification(NotificationRequest notification)
        {
            this.ImportAssignment();
        }

        private void menuItemImport_Click(object sender, System.EventArgs e)
        {
            this.ImportAssignment();
        }

        private void ImportAssignment()
        {
            string fileName = "";
            string destFileName = "";

            FileInfo fileInfo;

            //To set the default to c:\teststudio
            this.openFileDialog = new OpenFileDialog();
            this.openFileDialog.InitialDirectory = "C:\\teststudio";
            this.openFileDialog.Filter = "LabRun files (*.labrun.xml)|*.labrun.xml";
            string extension = ".labrun.xml";

            if (this.openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                if (this.openFileDialog.FileName != "")
                {
                    fileName = this.GetFileName(this.openFileDialog.FileName, extension);

                    fileInfo = new FileInfo(fileName);

                    //Copy the selected file from the directory to intial directory, if the selected file is not in the intial dirrectory
                    if (fileInfo.DirectoryName.CompareTo(this.openFileDialog.InitialDirectory) != 0)
                    {
                        destFileName = this.openFileDialog.InitialDirectory + "\\" + fileInfo.Name + extension;
                        File.Copy(this.openFileDialog.FileName, destFileName, true);
                    }

                    this.NotifyUIAsync(new ImportTestRunNotification(fileInfo.Name));
                }
            }
        }

        private bool ValidateAssignments(AssignmentCollection importAssignments, bool isImport)
        {
            //StringBuilder missingModuleNames = null;
            TestBuild localBuild;
            TestBuildModule testBuildModule;
            TestCase testCase = null;
            TestInfoCollection selectedTestCases = new TestInfoCollection();
            TestCase rootTestCase = null;

            int assignmentIndex;

            if (assignments == null)
            {
                return false;
            }

            assignmentIndex = this.GetAssignmentCurrentIndex(importAssignments);

            TestBuildRequest buildRequest = new TestBuildRequest(RepositoryRequestType.Get);
            this.GetData(buildRequest);

            localBuild = buildRequest.Build;
            //App Config to show the appropriate controls
            AppConfigRequest appRequest = new AppConfigRequest(RepositoryRequestType.Get);
            this.GetData(appRequest);

            UserSettingRequest userSettings = new UserSettingRequest(RepositoryRequestType.Get);
            userSettings.Mode = appRequest.AppConfig.Mode;
            GetData(userSettings);

            foreach (Assignment assignment in importAssignments)
            {
                rootTestCase = this.testArea.FindTest(assignment.TestCase.FullName) as TestCase;

                if (rootTestCase == null)
                {
                    //InValid Assignment
                    assignment.Disabled = true;
                }
                else
                {
                    //Valid assignment
                    assignment.Disabled = false;

                    //Update the assignments full path information

                    if (!LabRunMode)
                    {
                        //Update the assignment build information
                        if (localBuild != null)
                        {
                            testBuildModule = localBuild.GetModule(assignment.TestCase.Module.Name);
                            assignment.TestCase.Module = testBuildModule;
                            //assignment.TestCase.Module.DllFullName = testBuildModule.DllFullName;
                        }
                        else
                        {
                            assignment.Disabled = true;
                        }
                    }
                    else
                    {
                        //LabRunMode, update the test case information
                        testCase = this.testArea.FindTest(assignment.TestCase.FullName) as TestCase;
                        assignment.TestCase = testCase;
                    }

                    //Update the System variables
                    ConfigData dd = new ConfigData();
                    dd.Append(assignment.ConfigData.GetIConfig(0));
                    GetConfigInfo(dd, appRequest, userSettings);
                    assignment.ConfigData = dd;

                    if (assignment.ConfigData.ConfigTable.Columns.Contains("__LogLevel"))
                    {
                        DataRow row = assignment.ConfigData.ConfigTable.Rows[0];
                    }
                }

                //Update the assignment id anyway
                if (isImport)
                {
                    assignment.AssignmentId = assignmentIndex;
                    assignmentIndex++;

                    //Add the testcasename to the selectedtestcase list to append 
                    //the selected test cases control
                    if (!selectedTestCases.Contains(assignment.TestCase))
                    {
                        selectedTestCases.Add(assignment.TestCase);
                    }
                }
            }

            if (isImport)
            {
                this.testSelector.AppendSelectedTestCases(this.ValidateTestCases(selectedTestCases));
            }

            if (this.testArea.RootTestAreas.Count == 0)
            {
                return false;
            }

            return true;
        }

        private int GetAssignmentCurrentIndex(AssignmentCollection assignments)
        {
            int currentMaxAssignmentIndex = 0;
            int count = 0;

            if (this.assignments.Assignments != null && this.assignments.Assignments.Count > 0)
            {
                currentMaxAssignmentIndex = GetMaxAssignment(this.assignments.Assignments);
            }
            else
            {
                count = currentMaxAssignmentIndex;
            }

            if (currentMaxAssignmentIndex <= MaxAssignmentIndex)
            {
                count = MaxAssignmentIndex + 1;
            }
            else
            {
                count = currentMaxAssignmentIndex + 1;
            }

            return count;
        }


        public AssignmentCollection GetValidAssignments(AssignmentCollection assignments)
        {
            AssignmentCollection validAssignments = new AssignmentCollection();

            foreach (Assignment assign in assignments)
            {
                if (!assign.Disabled)
                {
                    validAssignments.Add(assign);
                }
            }

            return validAssignments;
        }

        public string InvalidTestCasesNames(AssignmentCollection assignments)
        {
            StringBuilder invalidTestCases = null;

            foreach (Assignment assign in assignments)
            {
                if (assign.Disabled)
                {
                    if (invalidTestCases == null)
                    {
                        invalidTestCases = new StringBuilder();
                    }
                    invalidTestCases.Append(assign.TestCase.Name + '\n');
                }
            }

            if (invalidTestCases != null)
            {
                return invalidTestCases.ToString();
            }
            else
            {
                return null;
            }


        }

        /// <summary>
        /// This function will validate the test cases of the selected test
        /// cases against the test area control
        /// 
        /// During import only validate the imported assignments(test cases belong to 
        /// imported assignments)
        /// </summary>
        private TestInfoCollection ValidateTestCases(TestInfoCollection testCases)
        {
            TestInfoCollection selectedTestCases;
            TestInfoCollection newTestCases = new TestInfoCollection();
            TestInfo test;
            TestCase testCase = null;

            if (testCases == null)
            {
                selectedTestCases = this.testSelector.SeletedTestCases;
            }
            else
            {
                selectedTestCases = testCases;
            }


            if (selectedTestCases == null || selectedTestCases.Count == 0)
            {
                return null;
            }

            foreach (TestInfo testInfo in selectedTestCases)
            {
                testCase = this.testArea.FindTest(testInfo.FullName) as TestCase;

                if (testCase != null)
                {
                    //Valid test case
                    testCase.Disabled = false;

                    // If the current test do have a SoftTestId, it means it is 
                    // a softtest exported from a LR, keep all the SoftTest information
                    TestCase softTest = testInfo as TestCase;
                    if ((softTest != null) && (softTest.SoftTestId > 0))
                    {
                        testCase.SoftTestId = softTest.SoftTestId;
                        testCase.SoftTestName = softTest.SoftTestName;

                        testCase.Parameters.Clear();
                        foreach (KeyValuePair<string, string> entry in softTest.Parameters)
                        {
                            testCase.Parameters.Add(entry.Key, entry.Value);
                        } // foreach

                        testCase.TestConfigs.Clear();
                        foreach (KeyValuePair<string, string> entry in softTest.TestConfigs)
                        {
                            testCase.TestConfigs.Add(entry.Key, entry.Value);
                        } // foreach
                    }

                    test = testCase;
                }
                else
                {
                    testInfo.Disabled = true;
                    test = testInfo;
                }

                //
                // We now always add tests to the "Selected Test" grid
                // even there are duplicate names
                //
                TestCase newTest = test.Clone() as TestCase;
                newTestCases.Add(newTest);
            }

            return newTestCases;


        }

        /// <summary>
        /// Display the Execution Information Dialog for an assignment
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void menuItemDisplayAssignmentInfo_Click(object sender, System.EventArgs e)
        {
            AssignmentCollection selectedAssignments = this.assignments.SelectedAssignments;

            //
            // Only display the dialog when there is only one assignment selected
            //
            if (selectedAssignments.Count > 1)
                return;

            //
            // Display nothing if none is selected
            //
            if (selectedAssignments.Count <= 0)
                return;

            AssignmentExecutionInformation info = new AssignmentExecutionInformation(selectedAssignments[0]);
            info.ShowDialog();
        }

        private void menuItemBulkEdit_Click(object sender, System.EventArgs e)
        {
            AssignmentCollection selectedAssignments = this.assignments.SelectedAssignments;
            AssignmentBulkEditForm editForm = new AssignmentBulkEditForm();
            string confirmation;
            DialogResult result;

            if (selectedAssignments != null && selectedAssignments.Count > 0)
            {
                editForm.ConfigNames = this.assignments.GetUniqueColumnNames();
                editForm.ShowDialog();

                if (editForm.UpdatedConfigValues != null && editForm.UpdatedConfigValues.Count > 0)
                {
                    confirmation = String.Format("Do u want to bulk edit the {0} assignments", selectedAssignments.Count);

                    result = MessageBox.Show(confirmation, "Confirmation", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        selectedAssignments.UpdateAssignments(true);
                        this.assignments.dirtyBit = true;

                        this.assignments.UpdateAssignmentConfig(editForm.UpdatedConfigValues);
                    }
                }
            }
        }

        private TestInfoCollection ValidateTestCases()
        {
            return this.ValidateTestCases(null);
        }

        private string GetFileName(string fileFullPath, string extension)
        {
            ArrayList extensionList = new ArrayList(extension.Split('.'));
            string actualFileName = "";
            string dotExtension = ".";

            string[] tokens = fileFullPath.Split('.');
            foreach (string token in tokens)
            {
                if (!extensionList.Contains(token))
                {
                    actualFileName = actualFileName + token;
                }

                actualFileName = actualFileName + dotExtension;
            }
            actualFileName = actualFileName.TrimEnd(dotExtension.ToCharArray());
            return actualFileName;
        }

        private void HandleUserSettingsChangedNotification(NotificationRequest notification)
        {
            this.assignments.Assignments.UpdateAssignments(true);
            //this.assignments.dirtyBit = true;
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.testSelector.DeleteSelectedTestCases();
        }

        private void clearListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.testSelector.Clear();
        }

        private void editParametersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.testSelector.EditSelectedTestCasesParameter();
        }

        private void buttonOpenlog_Click(object sender, EventArgs e)
        {
            string dir = System.IO.Directory.GetCurrentDirectory() + "\\Log";
            if (System.IO.Directory.Exists(dir))
            {
                System.Diagnostics.Process process = new System.Diagnostics.Process();
                process.StartInfo.FileName = "explorer.exe";
                process.StartInfo.Arguments = dir;
                process.Start();
            }
        }

        /// <summary>
        /// Only display relevant menu item for the right click assignment menu
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void contextMenu_Popup(object sender, EventArgs e)
        {
            //
            // Make sure it is a context menu
            //
            if (!(sender is ContextMenu))
                return;

            ContextMenu menu = (ContextMenu)sender;

            AssignmentCollection selectedAssignments = this.assignments.SelectedAssignments;

            if ((selectedAssignments.Count > 1) ||
                (selectedAssignments.Count <= 0))
            {
                menu.MenuItems[3].Enabled = false;
                return;
            } 

            menu.MenuItems[3].Enabled = true;
        }
    }
}
