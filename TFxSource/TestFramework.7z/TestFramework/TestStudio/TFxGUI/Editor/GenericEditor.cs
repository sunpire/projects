using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for GenericEditor.
	/// </summary>
	public class GenericEditor : Expedia.Test.Framework.RepositoryDelegateUI
	{
		protected System.Windows.Forms.Panel panelTop1;
		protected System.Windows.Forms.Panel panelBottom1;
		protected System.Windows.Forms.Panel panelCenter;
		protected System.Windows.Forms.Panel panelLeft;
		protected System.Windows.Forms.Panel panelRight;
		protected System.Windows.Forms.Panel panelUpper;
		protected System.Windows.Forms.Panel panelLower;
		protected System.Windows.Forms.Panel panelMiddle;
		protected NJFLib.Controls.CollapsibleSplitter splitterLeft;
		protected Expedia.Test.Framework.ErrorDisplayControl errorDisplayControl;

		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public GenericEditor()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitForm call

		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panelTop1 = new System.Windows.Forms.Panel();
			this.errorDisplayControl = new Expedia.Test.Framework.ErrorDisplayControl();
			this.panelBottom1 = new System.Windows.Forms.Panel();
			this.panelCenter = new System.Windows.Forms.Panel();
			this.panelRight = new System.Windows.Forms.Panel();
			this.panelMiddle = new System.Windows.Forms.Panel();
			this.panelLower = new System.Windows.Forms.Panel();
			this.panelUpper = new System.Windows.Forms.Panel();
			this.splitterLeft = new NJFLib.Controls.CollapsibleSplitter();
			this.panelLeft = new System.Windows.Forms.Panel();
			this.panelTop1.SuspendLayout();
			this.panelCenter.SuspendLayout();
			this.panelRight.SuspendLayout();
			this.SuspendLayout();
			// 
			// panelTop1
			// 
			this.panelTop1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.errorDisplayControl});
			this.panelTop1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panelTop1.Name = "panelTop1";
			this.panelTop1.Size = new System.Drawing.Size(552, 24);
			this.panelTop1.TabIndex = 0;
			// 
			// errorDisplayControl
			// 
			this.errorDisplayControl.BackColor = System.Drawing.SystemColors.Info;
			this.errorDisplayControl.Dock = System.Windows.Forms.DockStyle.Fill;
			this.errorDisplayControl.Name = "errorDisplayControl";
			this.errorDisplayControl.Size = new System.Drawing.Size(552, 24);
			this.errorDisplayControl.TabIndex = 0;
			// 
			// panelBottom1
			// 
			this.panelBottom1.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panelBottom1.Location = new System.Drawing.Point(0, 328);
			this.panelBottom1.Name = "panelBottom1";
			this.panelBottom1.Size = new System.Drawing.Size(552, 40);
			this.panelBottom1.TabIndex = 1;
			// 
			// panelCenter
			// 
			this.panelCenter.Controls.AddRange(new System.Windows.Forms.Control[] {
																					  this.panelRight,
																					  this.splitterLeft,
																					  this.panelLeft});
			this.panelCenter.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panelCenter.Location = new System.Drawing.Point(0, 24);
			this.panelCenter.Name = "panelCenter";
			this.panelCenter.Size = new System.Drawing.Size(552, 304);
			this.panelCenter.TabIndex = 2;
			// 
			// panelRight
			// 
			this.panelRight.Controls.AddRange(new System.Windows.Forms.Control[] {
																					 this.panelMiddle,
																					 this.panelLower,
																					 this.panelUpper});
			this.panelRight.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panelRight.Location = new System.Drawing.Point(152, 0);
			this.panelRight.Name = "panelRight";
			this.panelRight.Size = new System.Drawing.Size(400, 304);
			this.panelRight.TabIndex = 2;
			// 
			// panelMiddle
			// 
			this.panelMiddle.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panelMiddle.Location = new System.Drawing.Point(0, 40);
			this.panelMiddle.Name = "panelMiddle";
			this.panelMiddle.Size = new System.Drawing.Size(400, 224);
			this.panelMiddle.TabIndex = 2;
			// 
			// panelLower
			// 
			this.panelLower.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panelLower.Location = new System.Drawing.Point(0, 264);
			this.panelLower.Name = "panelLower";
			this.panelLower.Size = new System.Drawing.Size(400, 40);
			this.panelLower.TabIndex = 1;
			// 
			// panelUpper
			// 
			this.panelUpper.Dock = System.Windows.Forms.DockStyle.Top;
			this.panelUpper.Name = "panelUpper";
			this.panelUpper.Size = new System.Drawing.Size(400, 40);
			this.panelUpper.TabIndex = 0;
			// 
			// splitterLeft
			// 
			this.splitterLeft.AnimationDelay = 20;
			this.splitterLeft.AnimationStep = 20;
			this.splitterLeft.BorderStyle3D = System.Windows.Forms.Border3DStyle.Flat;
			this.splitterLeft.ControlToHide = this.panelLeft;
			this.splitterLeft.ExpandParentForm = false;
			this.splitterLeft.Location = new System.Drawing.Point(144, 0);
			this.splitterLeft.Name = "splitterLeft";
			this.splitterLeft.TabIndex = 1;
			this.splitterLeft.TabStop = false;
			this.splitterLeft.UseAnimations = false;
			this.splitterLeft.VisualStyle = NJFLib.Controls.VisualStyles.Mozilla;
			// 
			// panelLeft
			// 
			this.panelLeft.Dock = System.Windows.Forms.DockStyle.Left;
			this.panelLeft.Name = "panelLeft";
			this.panelLeft.Size = new System.Drawing.Size(144, 304);
			this.panelLeft.TabIndex = 0;
			// 
			// GenericEditor
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.panelCenter,
																		  this.panelBottom1,
																		  this.panelTop1});
			this.Name = "GenericEditor";
			this.Size = new System.Drawing.Size(552, 368);
			this.Load += new System.EventHandler(this.GenericEditor_Load);
			this.panelTop1.ResumeLayout(false);
			this.panelCenter.ResumeLayout(false);
			this.panelRight.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion


		
		private void GenericEditor_Load(object sender, System.EventArgs e)
		{
			this.AddNotificationHandler(typeof(InfoActionNotification), new NotificationRequestHandler(this.HandleInfoActionNotification));	
			this.AddNotificationHandler(typeof(InfoNotification), new NotificationRequestHandler(this.HandleInfoNotification));	

			this.panelTop1.Visible = true;
			this.panelTop1.Visible = false;
		}

		private void HandleInfoNotification(NotificationRequest request)

		{
			InfoNotification info = request as InfoNotification;

			if (info !=null)
			{
				this.panelTop1.Visible = true;
			}
		}

		public Profile GetProfile()
		{
			ProfileRequest profileRequest = new ProfileRequest(RepositoryRequestType.Get);
			profileRequest.ProfileName = Enum.GetName(typeof(ProfileName), ProfileName.DefaultProfile);
			this.GetData(profileRequest);
			return profileRequest.Profile;
		}
		
		public void UpdateProfile(Profile profile)
		{
			if(profile != null)
			{
				ProfileRequest profileRequest = new ProfileRequest(RepositoryRequestType.Update);
				profileRequest.Profile =profile;
				profileRequest.ProfileName = Enum.GetName(typeof(ProfileName), ProfileName.DefaultProfile);
				GetData(profileRequest);
			}
		}


		private void HandleInfoActionNotification(NotificationRequest request)
		{
			InfoActionNotification info = request as InfoActionNotification;

			if (info !=null)
			{
				this.panelTop1.Visible = false;
			}
		}



		public void LoadUIState(SplitterState currentSplitter)
		{
			if(currentSplitter != null)
			{
				this.splitterLeft.ControlToHide.Size = new Size(currentSplitter.ControlToHideSize.Width, currentSplitter.ControlToHideSize.Height); 
				if(currentSplitter.isCollapsed)
				{
					this.splitterLeft.ControlToHide.Visible = false;
					
				}
				else
				{
					this.splitterLeft.ControlToHide.Visible = true;
				}

			}			
		}

		



		
	}
}
