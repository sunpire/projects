using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;

using System.Windows.Forms;


namespace Expedia.Test.Framework
{
	public class UserSettingsEditor : Expedia.Test.Framework.GenericEditor
	{
		private System.Windows.Forms.PropertyGrid propertyGrid;
		private System.Windows.Forms.Panel panelSave;
		private System.Windows.Forms.Panel panelCancel;
		private System.Windows.Forms.Button buttonSave;
		private System.Windows.Forms.Button buttonCancel;
        private Button buttonClear;
		private System.ComponentModel.IContainer components = null;

		public UserSettingsEditor()
		{
			// This call is required by the Windows Form Designer.
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.propertyGrid = new System.Windows.Forms.PropertyGrid();
            this.panelSave = new System.Windows.Forms.Panel();
            this.buttonSave = new System.Windows.Forms.Button();
            this.panelCancel = new System.Windows.Forms.Panel();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.panelTop1.SuspendLayout();
            this.panelBottom1.SuspendLayout();
            this.panelCenter.SuspendLayout();
            this.panelRight.SuspendLayout();
            this.panelMiddle.SuspendLayout();
            this.panelSave.SuspendLayout();
            this.panelCancel.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelTop1
            // 
            this.panelTop1.Visible = false;
            // 
            // panelBottom1
            // 
            this.panelBottom1.Controls.Add(this.buttonClear);
            this.panelBottom1.Controls.Add(this.panelSave);
            this.panelBottom1.Controls.Add(this.panelCancel);
            // 
            // panelCenter
            // 
            this.panelCenter.Location = new System.Drawing.Point(0, 0);
            this.panelCenter.Size = new System.Drawing.Size(552, 328);
            // 
            // panelLeft
            // 
            this.panelLeft.Size = new System.Drawing.Size(144, 328);
            this.panelLeft.Visible = false;
            // 
            // panelRight
            // 
            this.panelRight.Location = new System.Drawing.Point(144, 0);
            this.panelRight.Size = new System.Drawing.Size(408, 328);
            // 
            // panelUpper
            // 
            this.panelUpper.Size = new System.Drawing.Size(408, 40);
            this.panelUpper.Visible = false;
            // 
            // panelLower
            // 
            this.panelLower.Location = new System.Drawing.Point(0, 288);
            this.panelLower.Size = new System.Drawing.Size(408, 40);
            // 
            // panelMiddle
            // 
            this.panelMiddle.Controls.Add(this.propertyGrid);
            this.panelMiddle.Size = new System.Drawing.Size(408, 248);
            // 
            // splitterLeft
            // 
            this.splitterLeft.Visible = false;
            // 
            // propertyGrid
            // 
            this.propertyGrid.BackColor = System.Drawing.SystemColors.Control;
            this.propertyGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.propertyGrid.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.propertyGrid.Location = new System.Drawing.Point(0, 0);
            this.propertyGrid.Name = "propertyGrid";
            this.propertyGrid.Size = new System.Drawing.Size(408, 248);
            this.propertyGrid.TabIndex = 0;
            // 
            // panelSave
            // 
            this.panelSave.Controls.Add(this.buttonSave);
            this.panelSave.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelSave.Location = new System.Drawing.Point(424, 0);
            this.panelSave.Name = "panelSave";
            this.panelSave.Size = new System.Drawing.Size(64, 40);
            this.panelSave.TabIndex = 1;
            // 
            // buttonSave
            // 
            this.buttonSave.Location = new System.Drawing.Point(6, 8);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(56, 23);
            this.buttonSave.TabIndex = 0;
            this.buttonSave.Text = "Save";
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // panelCancel
            // 
            this.panelCancel.Controls.Add(this.buttonCancel);
            this.panelCancel.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelCancel.Location = new System.Drawing.Point(488, 0);
            this.panelCancel.Name = "panelCancel";
            this.panelCancel.Size = new System.Drawing.Size(64, 40);
            this.panelCancel.TabIndex = 2;
            // 
            // buttonCancel
            // 
            this.buttonCancel.Location = new System.Drawing.Point(0, 8);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(64, 23);
            this.buttonCancel.TabIndex = 2;
            this.buttonCancel.Text = "Cancel";
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(278, 8);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(140, 26);
            this.buttonClear.TabIndex = 3;
            this.buttonClear.Text = "Clear HTML/Pic Log";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // UserSettingsEditor
            // 
            this.Name = "UserSettingsEditor";
            this.Load += new System.EventHandler(this.UserSettingsEditor_Load);
            this.panelTop1.ResumeLayout(false);
            this.panelBottom1.ResumeLayout(false);
            this.panelCenter.ResumeLayout(false);
            this.panelRight.ResumeLayout(false);
            this.panelMiddle.ResumeLayout(false);
            this.panelSave.ResumeLayout(false);
            this.panelCancel.ResumeLayout(false);
            this.ResumeLayout(false);

		}
		#endregion

		private void buttonSave_Click(object sender, System.EventArgs e)
		{				
			UsersSetting setting = new UsersSetting();
			setting = this.propertyGrid.SelectedObject as UsersSetting;

			AppConfigRequest request = new AppConfigRequest(RepositoryRequestType.Get);
			this.GetData(request);

			if(setting != null)
			{
				UserSettingRequest settingRequest = new UserSettingRequest(setting, RepositoryRequestType.Update);
				settingRequest.Mode = request.AppConfig.Mode;
				this.GetData(settingRequest);
			}
		
			this.NotifyUIAsync(new UserSettingsChangedNotification());
			this.NotifyUI(InfoNotification.GetInfoNotification(SeverityType.Info, "User Setting is saved"));
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			
		}

		private void UserSettingsEditor_Load(object sender, System.EventArgs e)
		{

			AppConfigRequest appRequest = new AppConfigRequest(RepositoryRequestType.Get);
			this.GetData(appRequest);


			UserSettingRequest settingRequest = new UserSettingRequest(RepositoryRequestType.Get);
			settingRequest.Mode = appRequest.AppConfig.Mode;
			this.GetData(settingRequest);
			
			UsersSetting settings = null;

			if (appRequest.AppConfig.Mode == ApplicationMode.TestPlayer)
			{
				settings = settingRequest.Settings as TestStudioUsersSetting;
                buttonClear.Visible = true;
			}
            


			if (settings !=null)
			{
				this.propertyGrid.SelectedObject = settings;
			}
		}

		private void buttonDelete_Click(object sender, System.EventArgs e)
		{
		
		}

        private void buttonClear_Click(object sender, EventArgs e)
        {
            string logdir = System.IO.Directory.GetCurrentDirectory() + "//Log";
            if (System.IO.Directory.Exists(logdir))
            {
                System.IO.DirectoryInfo dir = new System.IO.DirectoryInfo(logdir);
                System.IO.FileInfo[] files = dir.GetFiles();
                foreach (System.IO.FileInfo file in files)
                {
                    file.Delete();
                }
            }
        }
		

	}
}

