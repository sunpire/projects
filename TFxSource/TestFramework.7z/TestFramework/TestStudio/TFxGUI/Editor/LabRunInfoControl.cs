using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Expedia.Test.Framework.Editor
{
	/// <summary>
	/// Summary description for LabRunInfoControl.
	/// </summary>
	public class LabRunInfoControl : Expedia.Test.Framework.RepositoryDelegateUI
	{
		private System.Windows.Forms.TextBox LabRunName;
		private System.Windows.Forms.ComboBox LabRunManagerCombo;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ComboBox LabRunStatusCombo;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.ComboBox TFxBuildCombo;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.CheckedListBox checkedListBoxLogLevel;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.ComboBox TFxReleaseComboBox;
		private System.Windows.Forms.TextBox email;
		bool m_logLevelUpdated;
        bool m_releaseUpdated;

		public bool EnabledEmail
		{
			get
			{
				return this.email.Visible;
			}
			set
			{
				this.email.Visible = value;
				this.label6.Visible = value;
			}
		}

		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public LabRunInfoControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitForm call
			this.TFxReleaseComboBox.SelectedIndexChanged +=new EventHandler(TFxReleaseComboBox_SelectedIndexChanged);
			this.TFxBuildCombo.SelectedIndexChanged += new EventHandler(TFxBuildCombo_SelectedIndexChanged);
		}

        /// <summary>
        /// Comments:	Changed UserId to UserGid
        /// </summary>
		public TFxUser[] LabRunManagers
		{
			set
			{
				if(value != null)
				{
					this.LabRunManagerCombo.DataSource = value;
					this.LabRunManagerCombo.DisplayMember = "Name";
					this.LabRunManagerCombo.ValueMember = "UserGid";
				}				
			}
		}


		public string Email
		{
			get
			{
				if (this.email.Visible)
				{
					return this.email.Text;
				}

				return null;
			}
			set
			{
				this.email.Text = value;
			}
		}

		public string LabRunText
		{
			get
			{
				return this.LabRunName.Text.ToString();
			}
			set
			{
				this.LabRunName.Text = value;
			}
		}

		public string TestBuildName
		{
			get
			{
				if(this.TFxBuildCombo.SelectedItem == null)
				{
					return null;
				}

				return this.TFxBuildCombo.SelectedItem.ToString();
			}
			set
			{
				this.TFxBuildCombo.SelectedItem = value;
			}
		}

        public string TestReleaseName
		{
			get
			{
				if(this.TFxReleaseComboBox.SelectedItem == null)
				{
					return null;
				}

				return this.TFxReleaseComboBox.SelectedItem.ToString();
			}
			set
			{
				this.TFxReleaseComboBox.SelectedItem = value;
			}
		}

		public String[]  Builds
		{
			set
			{
				if(value != null)
				{
					this.TFxBuildCombo.DataSource = value;
					this.TFxBuildCombo.DisplayMember = "Name";					
				}
			}
		}

		public String[] Release
		{
			get
			{
				return this.TFxReleaseComboBox.DataSource as String[];
			}
	
			set
			{
				if(value != null)
				{
					this.TFxReleaseComboBox.DataSource = value;
					this.TFxReleaseComboBox.DisplayMember = "Name";					
				}
			}

		}

        /// <summary>
        /// Comments:	Changed UserId from Int to GUID
        /// </summary>
		public TFxUser Manager
		{
			get
			{
				return (TFxUser)this.LabRunManagerCombo.SelectedItem;
			}
			set
			{
				TFxUser user = value as TFxUser;
				if(user != null)
				{
                    this.LabRunManagerCombo.SelectedValue = user.usergid;
				}
				
			}
		}

		public String[] LabRunStatus
		{
			set
			{
				this.LabRunStatusCombo.DataSource = value;
			}
		}

		public string Status
		{
			get
			{
				if (this.LabRunStatusCombo.SelectedItem !=null)
				{
					return this.LabRunStatusCombo.SelectedItem.ToString();
				}
                return LabRunStatusType.Created.ToString();
			}

			set
			{
				this.LabRunStatusCombo.SelectedItem = value;					
				this.OriginalStatus = value;
			}
		}

		public string OriginalStatus;

		public string[] LogLevel
		{
			set
			{
				this.checkedListBoxLogLevel.Items.AddRange(value);
			}
		}

		public bool LogLevelUpdated
		{
			set
			{
				m_logLevelUpdated = value;
			}
			get
			{
				return m_logLevelUpdated;
			}
		}

        public bool ReleaseUpdated
        {
            set
            {
                m_releaseUpdated = value;
            }
            get
            {
                return m_releaseUpdated;
            }
        }

		public void TFxReleaseComboBox_SelectedIndexChanged(object sender, System.EventArgs args)
		{
            ReleaseUpdated = true;

			ReleaseChangeNotification notify = new ReleaseChangeNotification();
			notify.ReleaseName = TFxReleaseComboBox.SelectedItem.ToString();
			this.NotifyUI(notify);
		}

		public void TFxBuildCombo_SelectedIndexChanged(object sender, System.EventArgs args)
		{
			BuildChangeNotification notify = new BuildChangeNotification();
			notify.BuildName = TFxBuildCombo.SelectedItem.ToString();
			this.NotifyUI(notify);
		}

		public string GetSelectedLogLevels()
		{
			string logLevel = "";
 
			foreach(object itemChecked in this.checkedListBoxLogLevel.CheckedItems)
			{
				logLevel = logLevel + itemChecked.ToString()+ "|";				
			}
			
			logLevel = logLevel.TrimEnd('|');

			if(logLevel == "")
			{
				logLevel = LogLevelType.None.ToString();
			}

			return logLevel;
		}

		public void UpdateSelectedLogLevels(ArrayList logValues)
		{
			int itemIndex = 0;
			int noneItemIndex = 0;

			foreach(LogLevelType type in logValues)
			{
				itemIndex = this.checkedListBoxLogLevel.Items.IndexOf(type.ToString());
				if(itemIndex != -1)
				{
					this.checkedListBoxLogLevel.SetItemChecked(itemIndex,true);
				}				
			}

			noneItemIndex = this.checkedListBoxLogLevel.Items.IndexOf(LogLevelType.None.ToString());

			if(logValues.Count == 0)
			{
				if(this.checkedListBoxLogLevel.CheckedItems.Count <=0)
				{
					if(noneItemIndex != -1)
					{
						this.checkedListBoxLogLevel.SetItemChecked(noneItemIndex,true);
					}
				}
			}
			

		}

		public void ClearLogLevel()
		{
			int i =0;

			this.checkedListBoxLogLevel.SelectedIndexChanged -= new System.EventHandler(this.checkedListBoxLogLevel_SelectedIndexChanged);
					
					
			while(checkedListBoxLogLevel.CheckedIndices.Count >0)																							   
			{
				this.checkedListBoxLogLevel.SetItemChecked(checkedListBoxLogLevel.CheckedIndices[i],false);
			}

			this.checkedListBoxLogLevel.SelectedIndexChanged += new System.EventHandler(this.checkedListBoxLogLevel_SelectedIndexChanged);
		}

		public void TemplateConfig()
		{
			this.LabRunStatusCombo.Visible = false;
			this.label5.Visible = false;
			this.label1.Text = "Template Name:";
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.LabRunName = new System.Windows.Forms.TextBox();
			this.LabRunManagerCombo = new System.Windows.Forms.ComboBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.LabRunStatusCombo = new System.Windows.Forms.ComboBox();
			this.label6 = new System.Windows.Forms.Label();
			this.TFxBuildCombo = new System.Windows.Forms.ComboBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.email = new System.Windows.Forms.TextBox();
			this.checkedListBoxLogLevel = new System.Windows.Forms.CheckedListBox();
			this.panel2 = new System.Windows.Forms.Panel();
			this.label7 = new System.Windows.Forms.Label();
			this.TFxReleaseComboBox = new System.Windows.Forms.ComboBox();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.SuspendLayout();
			// 
			// LabRunName
			// 
			this.LabRunName.Location = new System.Drawing.Point(112, 8);
			this.LabRunName.Name = "LabRunName";
			this.LabRunName.Size = new System.Drawing.Size(136, 20);
			this.LabRunName.TabIndex = 26;
			this.LabRunName.Text = "";
			// 
			// LabRunManagerCombo
			// 
			this.LabRunManagerCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.LabRunManagerCombo.Location = new System.Drawing.Point(112, 8);
			this.LabRunManagerCombo.Name = "LabRunManagerCombo";
			this.LabRunManagerCombo.Size = new System.Drawing.Size(136, 21);
			this.LabRunManagerCombo.TabIndex = 17;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(96, 23);
			this.label1.TabIndex = 15;
			this.label1.Text = "LabRun Name:";
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(16, 40);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(88, 23);
			this.label5.TabIndex = 22;
			this.label5.Text = "LabRun Status:";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(16, 8);
			this.label2.Name = "label2";
			this.label2.TabIndex = 16;
			this.label2.Text = "LabRun Manager:";
			// 
			// LabRunStatusCombo
			// 
			this.LabRunStatusCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.LabRunStatusCombo.Location = new System.Drawing.Point(112, 40);
			this.LabRunStatusCombo.Name = "LabRunStatusCombo";
			this.LabRunStatusCombo.Size = new System.Drawing.Size(136, 21);
			this.LabRunStatusCombo.TabIndex = 23;
			// 
			// label6
			// 
			this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.label6.Location = new System.Drawing.Point(472, 8);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(40, 16);
			this.label6.TabIndex = 24;
			this.label6.Text = "Email:";
			// 
			// TFxBuildCombo
			// 
			this.TFxBuildCombo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.TFxBuildCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.TFxBuildCombo.Location = new System.Drawing.Point(328, 8);
			this.TFxBuildCombo.Name = "TFxBuildCombo";
			this.TFxBuildCombo.Size = new System.Drawing.Size(128, 21);
			this.TFxBuildCombo.TabIndex = 19;
			// 
			// label3
			// 
			this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.label3.Location = new System.Drawing.Point(256, 8);
			this.label3.Name = "label3";
			this.label3.TabIndex = 18;
			this.label3.Text = "TFxBuild:";
			// 
			// label4
			// 
			this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.label4.Location = new System.Drawing.Point(256, 8);
			this.label4.Name = "label4";
			this.label4.TabIndex = 20;
			this.label4.Text = "LogLevel:";
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.email);
			this.panel1.Controls.Add(this.checkedListBoxLogLevel);
			this.panel1.Controls.Add(this.LabRunManagerCombo);
			this.panel1.Controls.Add(this.label5);
			this.panel1.Controls.Add(this.label4);
			this.panel1.Controls.Add(this.label2);
			this.panel1.Controls.Add(this.LabRunStatusCombo);
			this.panel1.Controls.Add(this.label6);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel1.Location = new System.Drawing.Point(0, 32);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(680, 72);
			this.panel1.TabIndex = 31;
			// 
			// email
			// 
			this.email.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.email.Location = new System.Drawing.Point(536, 8);
			this.email.Name = "email";
			this.email.Size = new System.Drawing.Size(136, 20);
			this.email.TabIndex = 27;
			this.email.Text = "";
			// 
			// checkedListBoxLogLevel
			// 
			this.checkedListBoxLogLevel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.checkedListBoxLogLevel.CheckOnClick = true;
			this.checkedListBoxLogLevel.Location = new System.Drawing.Point(328, 8);
			this.checkedListBoxLogLevel.Name = "checkedListBoxLogLevel";
			this.checkedListBoxLogLevel.Size = new System.Drawing.Size(128, 49);
			this.checkedListBoxLogLevel.TabIndex = 26;
			this.checkedListBoxLogLevel.SelectedIndexChanged += new System.EventHandler(this.checkedListBoxLogLevel_SelectedIndexChanged);
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.LabRunName);
			this.panel2.Controls.Add(this.label1);
			this.panel2.Controls.Add(this.TFxBuildCombo);
			this.panel2.Controls.Add(this.label3);
			this.panel2.Controls.Add(this.label7);
			this.panel2.Controls.Add(this.TFxReleaseComboBox);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel2.Location = new System.Drawing.Point(0, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(680, 104);
			this.panel2.TabIndex = 32;
			// 
			// label7
			// 
			this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.label7.Location = new System.Drawing.Point(472, 8);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(56, 23);
			this.label7.TabIndex = 27;
			this.label7.Text = "Release:";
			// 
			// TFxReleaseComboBox
			// 
			this.TFxReleaseComboBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.TFxReleaseComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.TFxReleaseComboBox.Location = new System.Drawing.Point(536, 8);
			this.TFxReleaseComboBox.Name = "TFxReleaseComboBox";
			this.TFxReleaseComboBox.Size = new System.Drawing.Size(136, 21);
			this.TFxReleaseComboBox.TabIndex = 27;
			// 
			// LabRunInfoControl
			// 
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.panel2);
			this.Name = "LabRunInfoControl";
			this.Size = new System.Drawing.Size(680, 104);
			this.panel1.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void checkedListBoxLogLevel_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			this.LogLevelUpdated = true;
			int noneItemIndex = 0;
			int i =0;

			noneItemIndex = this.checkedListBoxLogLevel.Items.IndexOf(LogLevelType.None.ToString());

			if(this.checkedListBoxLogLevel.SelectedIndex == noneItemIndex)
			{
				if(this.checkedListBoxLogLevel.GetSelected(noneItemIndex))
				{
					//Clear all the others except None
					
					this.checkedListBoxLogLevel.SelectedIndexChanged -= new System.EventHandler(this.checkedListBoxLogLevel_SelectedIndexChanged);
					
					
					while(checkedListBoxLogLevel.CheckedIndices.Count >0)																							   
					{
						this.checkedListBoxLogLevel.SetItemChecked(checkedListBoxLogLevel.CheckedIndices[i],false);
					}

					this.checkedListBoxLogLevel.SelectedIndexChanged += new System.EventHandler(this.checkedListBoxLogLevel_SelectedIndexChanged);
					this.checkedListBoxLogLevel.SetItemChecked(noneItemIndex, true);

				}
			}
			else
			{
				if(this.checkedListBoxLogLevel.CheckedItems.Count > 1)
				{
					if(noneItemIndex != -1)
					{
						if(this.checkedListBoxLogLevel.CheckedItems.Contains(LogLevelType.None.ToString()))
						{
							this.checkedListBoxLogLevel.SetItemChecked(noneItemIndex,false);
						}
					}
				}
			}

			
		
		}

	}
}
