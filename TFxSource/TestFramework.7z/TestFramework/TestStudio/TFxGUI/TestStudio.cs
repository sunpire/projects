using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.IO;
using Expedia.Test.Framework;

namespace TestStudioApp
{
	/// <summary>
	/// Summary description for AppStudio.
	/// </summary>
    public class TestStudio : RepositoryConnectedUI
    {
        public System.Windows.Forms.TabControl appTab;
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;

        const string c_BaseFolderForLabRunFileRepository = @"c:\teststudio";
        const string c_BaseFolderForTestPlayerFileRepository = @"c:\teststudio";
        public TestStudio()
        {
            // This call is required by the Windows.Forms Form Designer.
            InitializeComponent();
        }

        private bool m_labRunMode;

        public bool LabRunMode
        {
            get
            {
                return m_labRunMode;
            }
            set
            {
                m_labRunMode = value;
            }
        }

        public void InitRepository(bool labRunMode)
        {
            if (labRunMode)
            {
                //this.LabRunMode = labRunMode;
                //this.Repository = new LabRunManagerRepository();
            }
            else
            {
                this.Repository = new TestPlayerRepository();
            }
        }

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        public void OpenTab(UserControl control)
        {
            AppStudio.OpenTab(appTab, control);
        }

        public TabPage ContainsTab(string controlName)
        {
            return AppStudio.ContainsTab(appTab, controlName);
        }

        #region Component Designer generated code
        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.appTab = new System.Windows.Forms.TabControl();
            this.SuspendLayout();
            // 
            // appTab
            // 
            this.appTab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.appTab.Name = "appTab";
            this.appTab.SelectedIndex = 0;
            this.appTab.Size = new System.Drawing.Size(280, 248);
            this.appTab.TabIndex = 1;
            // 
            // TestStudio
            // 
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.appTab});
            this.Name = "TestStudio";
            this.Size = new System.Drawing.Size(280, 248);
            this.Load += new System.EventHandler(this.TestStudio_Load);
            this.ResumeLayout(false);

        }
        #endregion


        private UserControl CreateUserControl(string controlType)
        {
            System.Type type = Type.GetType(controlType);

            if (type != null)
            {
                return Activator.CreateInstance(type) as UserControl;
            }

            return null;
        }

        private void TestStudio_Load(object sender, System.EventArgs e)
        {
            //create default config values for the first time
            DirectoryInfo di = new DirectoryInfo(c_BaseFolderForTestPlayerFileRepository);
            if(di.GetFiles("*.Config.xml").Length==0 && File.Exists(@"default.Config.xml"))
            {
                File.Copy(@"default.Config.xml", c_BaseFolderForTestPlayerFileRepository + @"\default.Config.xml");
            }
            //Wire up the event AppClosingNotification
            AddNotificationHandler(typeof(ApplicationClosingNotification), new NotificationRequestHandler(this.HandleApplicationClosingNotification));
            ProfileRequest profileRequest = new ProfileRequest(RepositoryRequestType.Get);
            profileRequest.ProfileName = Enum.GetName(typeof(ProfileName), ProfileName.DefaultProfile);
            this.GetData(profileRequest);

            if (profileRequest.Profile == null || profileRequest.Profile.Controls == null)
            {
                return;
            }

            this.OpenTab(new TestRunEditor());

            if (profileRequest.Profile.TestStudioSettings != null)
            {
                Rectangle WindowSize = profileRequest.Profile.TestStudioSettings.WindowSize;
                Control parentControl = this.Parent;

                if (parentControl != null)
                {
                    parentControl.Location = new Point(WindowSize.Location.X, WindowSize.Location.Y);
                    parentControl.Size = new Size(WindowSize.Width, WindowSize.Height);
                }
            }
        }

        private void HandleApplicationClosingNotification(NotificationRequest request)
        {
            ApplicationClosingNotification notification = request as ApplicationClosingNotification;
            Profile profile = null;
            ArrayList controls = new ArrayList();
            string selectedTabPage = null;

            if (!LabRunMode)
            {

                if (notification != null && notification.WindowSize != Rectangle.Empty)
                {

                    if (this.appTab.SelectedTab != null && this.appTab.SelectedTab.Controls != null && this.appTab.SelectedTab.Controls.Count > 0)
                    {
                        //selectedTabPage = this.appTab.SelectedTab.Controls[0].Text.ToString();
                        selectedTabPage = this.appTab.SelectedTab.Text.ToString();
                    }



                    foreach (TabPage page in appTab.TabPages)
                    {
                        if (notification.CloseTab == null || notification.CloseTab == page)
                        {
                            if (page.Controls.Count == 1)
                            {
                                appTab.SelectedTab = page;
                                foreach (Control control in page.Controls)
                                {
                                    RepositoryDelegateUI delegateUI = control as RepositoryDelegateUI;
                                    if (delegateUI != null)
                                    {
                                        delegateUI.PersistUIState();
                                    }
                                }
                                controls.Add(page.Controls[0].GetType().ToString());
                            }

                        }

                    }

                    profile = this.GetProfile();

                    if (profile == null)
                    {
                        profile = new Profile();
                    }

                    profile.TestStudioSettings.WindowSize = notification.WindowSize;
                    profile.TestStudioSettings.SelectedTab = selectedTabPage;


                    profile.Controls = new ArrayList(controls);

                    this.UpdateProfile(profile);
                }


            }
        }

        private Profile GetProfile()
        {
            ProfileRequest profileRequest = new ProfileRequest(RepositoryRequestType.Get);
            profileRequest.ProfileName = Enum.GetName(typeof(ProfileName), ProfileName.DefaultProfile);
            this.GetData(profileRequest);
            return profileRequest.Profile;
        }

        private void UpdateProfile(Profile profile)
        {
            if (profile != null)
            {
                ProfileRequest profileRequest = new ProfileRequest(RepositoryRequestType.Update);
                profileRequest.Profile = profile;
                profileRequest.ProfileName = Enum.GetName(typeof(ProfileName), ProfileName.DefaultProfile);
                GetData(profileRequest);
            }
        }
    }
}
