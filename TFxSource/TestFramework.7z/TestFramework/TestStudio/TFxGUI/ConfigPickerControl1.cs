using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ConfigPickerControl1.
	/// </summary>
	public class ConfigPickerControl1 : RepositoryDelegateUI
	{
		private System.Windows.Forms.Panel panelConfigsetPicker;
		private NJFLib.Controls.CollapsibleSplitter splitterConfigsetPicker;
		private System.Windows.Forms.Panel panelDetailPicker;
		private System.Windows.Forms.Panel panelSecondryPicker;
		private System.Windows.Forms.Panel panelPrimaryPicker;
		private System.Windows.Forms.Panel panelPrimaryList;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ListBox listBoxPrimaryConfig;
		private System.Windows.Forms.LinkLabel linkLabelShowPicker;
		private System.Windows.Forms.LinkLabel linkLabelShowDetail;
		private System.Windows.Forms.Panel panelSelectConfig;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.LinkLabel linkLabel1;
		private System.Windows.Forms.Panel panelConfigs;
		private System.Windows.Forms.DataGrid dataGridConfig;
		private System.Windows.Forms.ComboBox comboBoxSecondary;
		private System.Windows.Forms.LinkLabel linkLabelMerge;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ConfigPickerControl1()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			XMergeMode = false;
			ShowDetailedPicker = false;
		}

		public bool ShowDetailedPicker
		{
			get
			{
				return this.panelDetailPicker.Visible;
			}
			set
			{
				if(value)
				{
					this.panelConfigsetPicker.Visible = false;
					this.panelDetailPicker.Visible = true;
					this.panelDetailPicker.Dock = DockStyle.Fill;
				}
				else
				{
					this.panelConfigsetPicker.Visible = true;
					this.panelConfigsetPicker.Dock = DockStyle.Fill;;
					this.panelDetailPicker.Visible = false;
				}
			}
		}
		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panelConfigsetPicker = new System.Windows.Forms.Panel();
			this.panelPrimaryPicker = new System.Windows.Forms.Panel();
			this.panelPrimaryList = new System.Windows.Forms.Panel();
			this.listBoxPrimaryConfig = new System.Windows.Forms.ListBox();
			this.label1 = new System.Windows.Forms.Label();
			this.panelSecondryPicker = new System.Windows.Forms.Panel();
			this.comboBoxSecondary = new System.Windows.Forms.ComboBox();
			this.linkLabelMerge = new System.Windows.Forms.LinkLabel();
			this.linkLabelShowDetail = new System.Windows.Forms.LinkLabel();
			this.splitterConfigsetPicker = new NJFLib.Controls.CollapsibleSplitter();
			this.panelDetailPicker = new System.Windows.Forms.Panel();
			this.panelConfigs = new System.Windows.Forms.Panel();
			this.dataGridConfig = new System.Windows.Forms.DataGrid();
			this.panel1 = new System.Windows.Forms.Panel();
			this.linkLabel1 = new System.Windows.Forms.LinkLabel();
			this.panelSelectConfig = new System.Windows.Forms.Panel();
			this.linkLabelShowPicker = new System.Windows.Forms.LinkLabel();
			this.panelConfigsetPicker.SuspendLayout();
			this.panelPrimaryPicker.SuspendLayout();
			this.panelPrimaryList.SuspendLayout();
			this.panelSecondryPicker.SuspendLayout();
			this.panelDetailPicker.SuspendLayout();
			this.panelConfigs.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridConfig)).BeginInit();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// panelConfigsetPicker
			// 
			this.panelConfigsetPicker.Controls.AddRange(new System.Windows.Forms.Control[] {
																							   this.panelPrimaryPicker,
																							   this.panelSecondryPicker});
			this.panelConfigsetPicker.Dock = System.Windows.Forms.DockStyle.Top;
			this.panelConfigsetPicker.Name = "panelConfigsetPicker";
			this.panelConfigsetPicker.Size = new System.Drawing.Size(256, 120);
			this.panelConfigsetPicker.TabIndex = 0;
			// 
			// panelPrimaryPicker
			// 
			this.panelPrimaryPicker.Controls.AddRange(new System.Windows.Forms.Control[] {
																							 this.panelPrimaryList,
																							 this.label1});
			this.panelPrimaryPicker.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panelPrimaryPicker.Name = "panelPrimaryPicker";
			this.panelPrimaryPicker.Size = new System.Drawing.Size(256, 96);
			this.panelPrimaryPicker.TabIndex = 1;
			// 
			// panelPrimaryList
			// 
			this.panelPrimaryList.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.panelPrimaryList.Controls.AddRange(new System.Windows.Forms.Control[] {
																						   this.listBoxPrimaryConfig});
			this.panelPrimaryList.Location = new System.Drawing.Point(0, 24);
			this.panelPrimaryList.Name = "panelPrimaryList";
			this.panelPrimaryList.Size = new System.Drawing.Size(256, 72);
			this.panelPrimaryList.TabIndex = 0;
			// 
			// listBoxPrimaryConfig
			// 
			this.listBoxPrimaryConfig.Dock = System.Windows.Forms.DockStyle.Fill;
			this.listBoxPrimaryConfig.Name = "listBoxPrimaryConfig";
			this.listBoxPrimaryConfig.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
			this.listBoxPrimaryConfig.Size = new System.Drawing.Size(256, 69);
			this.listBoxPrimaryConfig.TabIndex = 10;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(0, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(100, 16);
			this.label1.TabIndex = 1;
			this.label1.Text = "Config:";
			// 
			// panelSecondryPicker
			// 
			this.panelSecondryPicker.Controls.AddRange(new System.Windows.Forms.Control[] {
																							  this.comboBoxSecondary,
																							  this.linkLabelMerge,
																							  this.linkLabelShowDetail});
			this.panelSecondryPicker.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panelSecondryPicker.Location = new System.Drawing.Point(0, 96);
			this.panelSecondryPicker.Name = "panelSecondryPicker";
			this.panelSecondryPicker.Size = new System.Drawing.Size(256, 24);
			this.panelSecondryPicker.TabIndex = 0;
			// 
			// comboBoxSecondary
			// 
			this.comboBoxSecondary.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.comboBoxSecondary.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxSecondary.Location = new System.Drawing.Point(48, 2);
			this.comboBoxSecondary.Name = "comboBoxSecondary";
			this.comboBoxSecondary.Size = new System.Drawing.Size(144, 21);
			this.comboBoxSecondary.TabIndex = 13;
			// 
			// linkLabelMerge
			// 
			this.linkLabelMerge.Dock = System.Windows.Forms.DockStyle.Left;
			this.linkLabelMerge.Name = "linkLabelMerge";
			this.linkLabelMerge.Size = new System.Drawing.Size(56, 24);
			this.linkLabelMerge.TabIndex = 12;
			this.linkLabelMerge.TabStop = true;
			this.linkLabelMerge.Text = "XMerege";
			this.linkLabelMerge.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.linkLabelMerge.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelMerge_LinkClicked);
			// 
			// linkLabelShowDetail
			// 
			this.linkLabelShowDetail.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
			this.linkLabelShowDetail.Location = new System.Drawing.Point(192, 8);
			this.linkLabelShowDetail.Name = "linkLabelShowDetail";
			this.linkLabelShowDetail.Size = new System.Drawing.Size(104, 16);
			this.linkLabelShowDetail.TabIndex = 8;
			this.linkLabelShowDetail.TabStop = true;
			this.linkLabelShowDetail.Text = "Show Detail";
			this.linkLabelShowDetail.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelShowDetail_LinkClicked);
			// 
			// splitterConfigsetPicker
			// 
			this.splitterConfigsetPicker.AnimationDelay = 20;
			this.splitterConfigsetPicker.AnimationStep = 20;
			this.splitterConfigsetPicker.BorderStyle3D = System.Windows.Forms.Border3DStyle.Flat;
			this.splitterConfigsetPicker.ControlToHide = this.panelConfigsetPicker;
			this.splitterConfigsetPicker.Dock = System.Windows.Forms.DockStyle.Top;
			this.splitterConfigsetPicker.ExpandParentForm = false;
			this.splitterConfigsetPicker.Location = new System.Drawing.Point(0, 120);
			this.splitterConfigsetPicker.Name = "splitterConfigsetPicker";
			this.splitterConfigsetPicker.TabIndex = 5;
			this.splitterConfigsetPicker.TabStop = false;
			this.splitterConfigsetPicker.UseAnimations = false;
			this.splitterConfigsetPicker.Visible = false;
			this.splitterConfigsetPicker.VisualStyle = NJFLib.Controls.VisualStyles.Mozilla;
			// 
			// panelDetailPicker
			// 
			this.panelDetailPicker.Controls.AddRange(new System.Windows.Forms.Control[] {
																							this.panelConfigs,
																							this.panel1});
			this.panelDetailPicker.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panelDetailPicker.Location = new System.Drawing.Point(0, 120);
			this.panelDetailPicker.Name = "panelDetailPicker";
			this.panelDetailPicker.Size = new System.Drawing.Size(256, 160);
			this.panelDetailPicker.TabIndex = 6;
			this.panelDetailPicker.Visible = false;
			// 
			// panelConfigs
			// 
			this.panelConfigs.Controls.AddRange(new System.Windows.Forms.Control[] {
																					   this.dataGridConfig});
			this.panelConfigs.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panelConfigs.Name = "panelConfigs";
			this.panelConfigs.Size = new System.Drawing.Size(256, 144);
			this.panelConfigs.TabIndex = 1;
			// 
			// dataGridConfig
			// 
			this.dataGridConfig.DataMember = "";
			this.dataGridConfig.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGridConfig.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGridConfig.Name = "dataGridConfig";
			this.dataGridConfig.Size = new System.Drawing.Size(256, 144);
			this.dataGridConfig.TabIndex = 9;
			// 
			// panel1
			// 
			this.panel1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.linkLabel1});
			this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel1.Location = new System.Drawing.Point(0, 144);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(256, 16);
			this.panel1.TabIndex = 0;
			// 
			// linkLabel1
			// 
			this.linkLabel1.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.linkLabel1.Location = new System.Drawing.Point(184, 0);
			this.linkLabel1.Name = "linkLabel1";
			this.linkLabel1.Size = new System.Drawing.Size(72, 23);
			this.linkLabel1.TabIndex = 0;
			this.linkLabel1.TabStop = true;
			this.linkLabel1.Text = "Select Config";
			this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
			// 
			// panelSelectConfig
			// 
			this.panelSelectConfig.Name = "panelSelectConfig";
			this.panelSelectConfig.TabIndex = 0;
			// 
			// linkLabelShowPicker
			// 
			this.linkLabelShowPicker.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
			this.linkLabelShowPicker.Location = new System.Drawing.Point(184, 0);
			this.linkLabelShowPicker.Name = "linkLabelShowPicker";
			this.linkLabelShowPicker.Size = new System.Drawing.Size(80, 16);
			this.linkLabelShowPicker.TabIndex = 8;
			this.linkLabelShowPicker.TabStop = true;
			this.linkLabelShowPicker.Text = "Select Config";
			this.linkLabelShowPicker.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
			// 
			// ConfigPickerControl1
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.panelDetailPicker,
																		  this.splitterConfigsetPicker,
																		  this.panelConfigsetPicker});
			this.Name = "ConfigPickerControl1";
			this.Size = new System.Drawing.Size(256, 280);
			this.Load += new System.EventHandler(this.ConfigPickerControl1_Load);
			this.panelConfigsetPicker.ResumeLayout(false);
			this.panelPrimaryPicker.ResumeLayout(false);
			this.panelPrimaryList.ResumeLayout(false);
			this.panelSecondryPicker.ResumeLayout(false);
			this.panelDetailPicker.ResumeLayout(false);
			this.panelConfigs.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dataGridConfig)).EndInit();
			this.panel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		public ConfigData[] SelectedConfigs
		{
			get
			{
				return null;
			}
		}

		ConfigData GetConfig(string name)
		{
			ConfigRequest configRequest = new ConfigRequest(RepositoryRequestType.Get);
			configRequest.InstanceName = name;
			this.GetData(configRequest);
			return configRequest.Data();
		}

		ConfigData GetPrimaryConfig()
		{
			ConfigData primary = new ConfigData();
			foreach(object selected in this.listBoxPrimaryConfig.SelectedItems)
			{
				ConfigData more = GetConfig( selected.ToString());
				primary.Append(more);
			}
			return primary;
		}

		ConfigData GetConfig()
		{
			ConfigData primary = GetPrimaryConfig(); //GetConfig(comboBoxPrimary.Text);
			if(comboBoxSecondary.Text != c_NoneItem)
			{
				ConfigData secondary = GetConfig(comboBoxSecondary.Text);
				if(primary != null)
				{
					if(secondary != null)
					{
						primary.Merge(secondary, XMergeMode);				
					}
				}
			}
			return primary;
		}
		public IConfig[] GetSelectedConfigs()
		{
			if(!ShowDetailedPicker)
			{
				ConfigData primary = GetConfig();
				return primary.GetAllConfigs();
			}

			return GetDetailedSelectedConfigs();
		}

		IConfig FindConfigFromDataGrid(int dataGridRow, IConfig[] configs)
		{
			return configs[ dataGridRow ];
		}

		IConfig[] GetDetailedSelectedConfigs()
		{
			ConfigData primary = new ConfigData();
			DataTable dataTable = null;
			int rowCount = 0;
				
			primary.ConfigTable = dataGridConfig.DataSource as DataTable;
			IConfig[] configs = primary.GetAllConfigs();
			ArrayList list = new ArrayList();

			dataTable = this.dataGridConfig.DataSource as DataTable;
			if(dataTable != null)
			{
				rowCount = dataTable.Rows.Count;
			}

			for(int i = 0; i < rowCount; i++)
			{
				if(this.dataGridConfig.IsSelected(i))
				{										
					StringConfig selectedConfig = new StringConfig();
					
					for (int j=0; j < dataTable.Columns.Count; j++)
					{
						selectedConfig.Add(dataTable.Columns[j].ColumnName, dataGridConfig[i,j].ToString());
					}

					list.Add(selectedConfig);
				}
			}
			return (IConfig[]) list.ToArray(typeof(IConfig));
		}

		private void HandleUpdateControlsNotification(NotificationRequest request)
		{
			LoadConfigs();
		}

		const string c_NoneItem = "None";
		private void LoadConfigs()
		{
			ConfigListRequest configListRequest = new ConfigListRequest();
			this.GetData(configListRequest);

			if((configListRequest.Objects != null)&&(configListRequest.Objects.Length > 0))
			{
				this.listBoxPrimaryConfig.DataSource = configListRequest.Objects;
				ArrayList list = new ArrayList();
				list.Add(c_NoneItem);
				list.AddRange(configListRequest.Objects);
				this.comboBoxSecondary.DataSource = list;

				this.comboBoxSecondary.SelectedText= c_NoneItem;
			}
		}

		private void ConfigPickerControl1_Load(object sender, System.EventArgs e)
		{
			AddNotificationHandler(typeof(ConfigChangeNotification), new NotificationRequestHandler(this.HandleUpdateControlsNotification) );
			LoadConfigs();		
		}

		private void linkLabelShowDetail_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			ConfigData primary = GetConfig();
			if(primary != null)
			{
				this.dataGridConfig.DataSource = primary.ConfigTable;
				this.ShowDetailedPicker = true;
			}
		}

		private void linkLabel1_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			this.ShowDetailedPicker = false;
		}

		bool m_XMergeMode=false;
		bool XMergeMode
		{
			get
			{
				return m_XMergeMode;
			}
			set
			{
				m_XMergeMode = value;
				if(value)
				{
					this.linkLabelMerge.Text = "XMerge";
				}
				else
				{
					this.linkLabelMerge.Text = "Merge";
				}
			}
		}
		private void linkLabelMerge_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			XMergeMode = !XMergeMode;
		}
	}
}
