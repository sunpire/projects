namespace Expedia.Test.Framework
{
	partial class BuildUpgradeTool
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.openFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.createProjectReferenceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.labelSource = new System.Windows.Forms.Label();
            this.richTextBoxSource = new System.Windows.Forms.RichTextBox();
            this.labelDestination = new System.Windows.Forms.Label();
            this.richTextBoxLatest = new System.Windows.Forms.RichTextBox();
            this.buttonNewVersion = new System.Windows.Forms.Button();
            this.buttonSave = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.labelFileName = new System.Windows.Forms.Label();
            this.textBoxFileName = new System.Windows.Forms.TextBox();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.labelBuildType = new System.Windows.Forms.Label();
            this.comboBoxBuildType = new System.Windows.Forms.ComboBox();
            this.buttonClear = new System.Windows.Forms.Button();
            this.errorDisplayControl = new Expedia.Test.Framework.ErrorDisplayControl();
            this.menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openFileToolStripMenuItem,
            this.createProjectReferenceToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(814, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "menuStrip1";
            // 
            // openFileToolStripMenuItem
            // 
            this.openFileToolStripMenuItem.Name = "openFileToolStripMenuItem";
            this.openFileToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.openFileToolStripMenuItem.Text = "Open File";
            this.openFileToolStripMenuItem.Click += new System.EventHandler(this.openFileToolStripMenuItem_Click);
            // 
            // createProjectReferenceToolStripMenuItem
            // 
            this.createProjectReferenceToolStripMenuItem.Name = "createProjectReferenceToolStripMenuItem";
            this.createProjectReferenceToolStripMenuItem.Size = new System.Drawing.Size(142, 20);
            this.createProjectReferenceToolStripMenuItem.Text = "Create Project Reference";
            this.createProjectReferenceToolStripMenuItem.Click += new System.EventHandler(this.createProjectReferenceToolStripMenuItem_Click);
            // 
            // labelSource
            // 
            this.labelSource.AutoSize = true;
            this.labelSource.Location = new System.Drawing.Point(21, 115);
            this.labelSource.Name = "labelSource";
            this.labelSource.Size = new System.Drawing.Size(105, 13);
            this.labelSource.TabIndex = 2;
            this.labelSource.Text = "Source File Contents";
            // 
            // richTextBoxSource
            // 
            this.richTextBoxSource.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.richTextBoxSource.Location = new System.Drawing.Point(24, 134);
            this.richTextBoxSource.Name = "richTextBoxSource";
            this.richTextBoxSource.Size = new System.Drawing.Size(391, 375);
            this.richTextBoxSource.TabIndex = 3;
            this.richTextBoxSource.Text = "";
            // 
            // labelDestination
            // 
            this.labelDestination.AutoSize = true;
            this.labelDestination.Location = new System.Drawing.Point(435, 117);
            this.labelDestination.Name = "labelDestination";
            this.labelDestination.Size = new System.Drawing.Size(112, 13);
            this.labelDestination.TabIndex = 4;
            this.labelDestination.Text = "Updated File Contents";
            // 
            // richTextBoxLatest
            // 
            this.richTextBoxLatest.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBoxLatest.Location = new System.Drawing.Point(432, 134);
            this.richTextBoxLatest.Name = "richTextBoxLatest";
            this.richTextBoxLatest.Size = new System.Drawing.Size(365, 375);
            this.richTextBoxLatest.TabIndex = 5;
            this.richTextBoxLatest.Text = "";
            // 
            // buttonNewVersion
            // 
            this.buttonNewVersion.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.buttonNewVersion.Location = new System.Drawing.Point(203, 516);
            this.buttonNewVersion.Name = "buttonNewVersion";
            this.buttonNewVersion.Size = new System.Drawing.Size(108, 23);
            this.buttonNewVersion.TabIndex = 6;
            this.buttonNewVersion.Text = "Get New Version";
            this.buttonNewVersion.UseVisualStyleBackColor = true;
            this.buttonNewVersion.Click += new System.EventHandler(this.buttonNewVersion_Click);
            // 
            // buttonSave
            // 
            this.buttonSave.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.buttonSave.Location = new System.Drawing.Point(349, 515);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(75, 23);
            this.buttonSave.TabIndex = 7;
            this.buttonSave.Text = "Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.buttonCancel.Location = new System.Drawing.Point(577, 515);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(75, 23);
            this.buttonCancel.TabIndex = 8;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonCancel.UseVisualStyleBackColor = true;
            // 
            // labelFileName
            // 
            this.labelFileName.AutoSize = true;
            this.labelFileName.Location = new System.Drawing.Point(21, 65);
            this.labelFileName.Name = "labelFileName";
            this.labelFileName.Size = new System.Drawing.Size(57, 13);
            this.labelFileName.TabIndex = 9;
            this.labelFileName.Text = "File Name:";
            // 
            // textBoxFileName
            // 
            this.textBoxFileName.Location = new System.Drawing.Point(83, 60);
            this.textBoxFileName.Name = "textBoxFileName";
            this.textBoxFileName.Size = new System.Drawing.Size(375, 20);
            this.textBoxFileName.TabIndex = 10;
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog1";
            // 
            // labelBuildType
            // 
            this.labelBuildType.AutoSize = true;
            this.labelBuildType.Location = new System.Drawing.Point(21, 93);
            this.labelBuildType.Name = "labelBuildType";
            this.labelBuildType.Size = new System.Drawing.Size(60, 13);
            this.labelBuildType.TabIndex = 11;
            this.labelBuildType.Text = "Build Type:";
            // 
            // comboBoxBuildType
            // 
            this.comboBoxBuildType.FormattingEnabled = true;
            this.comboBoxBuildType.Items.AddRange(new object[] {
            "webservicetest.build",
            "expwebtest.build",
            "tfxtest.build",
            "common.builddll",
            "common.buildexe",
            "common.buildwindll",
            "common.buildwinexe",
            "common.properties",
            "common.references",
            "common.strongdll",
            "common.targets",
            "tfxtest.references"});
            this.comboBoxBuildType.Location = new System.Drawing.Point(83, 84);
            this.comboBoxBuildType.Name = "comboBoxBuildType";
            this.comboBoxBuildType.Size = new System.Drawing.Size(228, 21);
            this.comboBoxBuildType.TabIndex = 12;
            // 
            // buttonClear
            // 
            this.buttonClear.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.buttonClear.Location = new System.Drawing.Point(464, 515);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(75, 23);
            this.buttonClear.TabIndex = 13;
            this.buttonClear.Text = "Clear ";
            this.buttonClear.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonClear.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // errorDisplayControl
            // 
            this.errorDisplayControl.BackColor = System.Drawing.SystemColors.Info;
            this.errorDisplayControl.Location = new System.Drawing.Point(3, 27);
            this.errorDisplayControl.Name = "errorDisplayControl";
            this.errorDisplayControl.Size = new System.Drawing.Size(560, 27);
            this.errorDisplayControl.TabIndex = 14;
            // 
            // BuildUpgradeTool
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Controls.Add(this.errorDisplayControl);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.comboBoxBuildType);
            this.Controls.Add(this.labelBuildType);
            this.Controls.Add(this.textBoxFileName);
            this.Controls.Add(this.labelFileName);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonSave);
            this.Controls.Add(this.buttonNewVersion);
            this.Controls.Add(this.richTextBoxLatest);
            this.Controls.Add(this.labelDestination);
            this.Controls.Add(this.richTextBoxSource);
            this.Controls.Add(this.labelSource);
            this.Controls.Add(this.menuStrip);
            this.Name = "BuildUpgradeTool";
            this.Size = new System.Drawing.Size(814, 542);
            this.Load += new System.EventHandler(this.BuildUpgradeTool_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem openFileToolStripMenuItem;
        private System.Windows.Forms.Label labelSource;
        private System.Windows.Forms.RichTextBox richTextBoxSource;
        private System.Windows.Forms.Label labelDestination;
        private System.Windows.Forms.RichTextBox richTextBoxLatest;
        private System.Windows.Forms.Button buttonNewVersion;
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Label labelFileName;
        private System.Windows.Forms.TextBox textBoxFileName;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.Label labelBuildType;
        private System.Windows.Forms.ComboBox comboBoxBuildType;
        private System.Windows.Forms.ToolStripMenuItem createProjectReferenceToolStripMenuItem;
        private System.Windows.Forms.Button buttonClear;
        private ErrorDisplayControl errorDisplayControl;
	}
}
