﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Expedia.Test.Framework;

namespace Expedia.Test.Framework
{
    public partial class SoftTestEditForm : Form
    {
        const string c_runtime_testnamespace = "__testnamespace";
        const string c_runtime_releaseinfo = "__releaseinfo";

        TestCase m_test;

        /// <summary>
        /// Load the test information into the form
        /// </summary>
        /// <param name="test"></param>
        public SoftTestEditForm(TestCase test)
        {
            InitializeComponent();

            m_test = test;

            // initialize the SoftTest values
            lbSoftTestName.Text = test.SoftTestName;
            lbSoftTestId.Text = Convert.ToString(test.SoftTestId);
            lbModule.Text = test.Module.Name;
            lbMethod.Text = test.FullName;

            // initialize the SoftTest parameters
            foreach (KeyValuePair<string, string> item in test.Parameters)
            {
                dgParameters.Rows.Add(item.Key, item.Value);
            } // for

            // initialize the SoftTest test configs
            foreach (KeyValuePair<string, string> item in test.TestConfigs)
            {
                //
                // initialize branch name
                //
                if (c_runtime_releaseinfo.Equals(item.Key, StringComparison.CurrentCultureIgnoreCase))
                {
                    txtBranchName.Text = item.Value == null ? string.Empty : item.Value.ToString();
                    continue;
                }

                dgTestConfigs.Rows.Add(item.Key, item.Value);
            } // for

            // set the SoftTest Name to be the same as method name if non specified
            if (String.IsNullOrEmpty(this.lbSoftTestName.Text))
            {
                Int32 index = lbMethod.Text.IndexOf("Expedia.Automation.Test.");
                if (index == 0)
                {
                    lbSoftTestName.Text = lbMethod.Text.Replace("Expedia.Automation.Test.", String.Empty);
                }
                else
                {
                    lbSoftTestName.Text = lbMethod.Text;
                }
            }

            // set default branch name as "main"
            if (string.IsNullOrEmpty(txtBranchName.Text))
            {
                txtBranchName.Text = "main";
            }
        }

        /// <summary>
        /// Hide the current form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CancelButton_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
        }

        /// <summary>
        /// Save the changes in Parameters to the current test
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SaveButton_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Save the updated softtest id and softtest name
            Int32 softTestId = 0;
            if (Int32.TryParse(this.lbSoftTestId.Text, out softTestId) == true)
            {
                if (softTestId > 0)
                    this.m_test.SoftTestId = softTestId;
            }

            if (String.IsNullOrEmpty(this.lbSoftTestName.Text) == false)
            {
                this.m_test.SoftTestName = this.lbSoftTestName.Text;
            }

            // Clear all existing parameters pair
            this.m_test.Parameters.Clear();

            // Reconstructure the parameter list in the test
            for (int i = 0; i < this.dgParameters.Rows.Count; i++)
            {
                string key = Convert.ToString(this.dgParameters.Rows[i].Cells[0].Value);
                string value = Convert.ToString(this.dgParameters.Rows[i].Cells[1].Value);

                if (!String.IsNullOrEmpty(key))
                    this.m_test.Parameters.Add(key, value);
            } // for

            // Clear all existing test config pair
            this.m_test.TestConfigs.Clear();

            // Reconstructure the test configs list in the test
            for (int i = 0; i < this.dgTestConfigs.Rows.Count; i++)
            {
                string key = Convert.ToString(this.dgTestConfigs.Rows[i].Cells[0].Value);
                string value = Convert.ToString(this.dgTestConfigs.Rows[i].Cells[1].Value);

                if (!String.IsNullOrEmpty(key))
                    this.m_test.TestConfigs.Add(key, value);
            } // for

            // Add test namespace and branch name into test configs
            // Use SoftTestName as namespace to get softtest test data at the same time
            this.m_test.TestConfigs[c_runtime_testnamespace] = this.lbSoftTestName.Text.Replace("Expedia.Automation.Test.", string.Empty);
            this.m_test.TestConfigs[c_runtime_releaseinfo] = this.txtBranchName.Text;

            this.Hide();

            
        }

        /// <summary>
        /// Handle the clicking of the cell content (Link Column)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgParameters_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > dgParameters.Rows.Count)
                return;

            //
            // Click on the link column
            //
            if (e.ColumnIndex == 2) 
            {
                SoftTestTextEditor editor = new SoftTestTextEditor(Convert.ToString(this.dgParameters[1, e.RowIndex].Value));
                editor.ShowDialog();
                this.dgParameters[1, e.RowIndex].Value = editor.Value;
            }
        }

        private void dgTestConfigs_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > dgTestConfigs.Rows.Count)
                return;

            //
            // Click on the link column
            //
            if (e.ColumnIndex == 2)
            {
                SoftTestTextEditor editor = new SoftTestTextEditor(Convert.ToString(this.dgTestConfigs[1, e.RowIndex].Value));
                editor.ShowDialog();
                this.dgTestConfigs[1, e.RowIndex].Value = editor.Value;
            }
        }
    }
}
