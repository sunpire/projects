﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Expedia.Test.Framework;

namespace Expedia.Test.Framework
{
    public partial class SoftTestTextEditor : Form
    {
        public String Value
        {
            get;
            set;
        }

        public SoftTestTextEditor(string text)
        {
            InitializeComponent();
            this.Value = text;
            this.txtLargeText.Text = this.Value;
        }

        private void lnkCancel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.txtLargeText.Text = String.Empty;
            this.Close();
        }

        private void lnkSave_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Value = this.txtLargeText.Text;
            this.Close();
        }


    }
}
