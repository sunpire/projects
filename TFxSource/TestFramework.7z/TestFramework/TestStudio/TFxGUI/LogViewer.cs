using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for LogViewer.
	/// </summary>
    public class LogViewer : System.Windows.Forms.UserControl
    {
        private System.Windows.Forms.Panel panelTop;
        internal System.Windows.Forms.DataGrid dataGridLogs;
        private IPersistableLog m_log;
        private System.Windows.Forms.Panel panelFilter;
        private System.Windows.Forms.Label labelFilter;
        private System.Windows.Forms.Panel panelViewColumns;
        private System.Windows.Forms.Label labelViewColumns;
        private System.Windows.Forms.CheckedListBox checkedListBoxView;

        private FilterExpression exp;
        private System.Windows.Forms.Panel panelFilterGroup;

        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;

        public LogViewer()
        {
            // This call is required by the Windows.Forms Form Designer.
            InitializeComponent();

            // Init Filters
            exp = new FilterExpression(typeof(LogEntry));

        }

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        public int SelectedEntryId
        {
            get
            {
                int currentRow = this.dataGridLogs.CurrentRowIndex;
                DataTable dt = this.dataGridLogs.DataSource as DataTable;

                if (currentRow >= 0 && dt != null)
                {
                    int id = Convert.ToInt32(dt.Rows[currentRow]["EntryId"]);

                    return id;
                }

                return -1;
            }
            set
            {
                DataTable dt = this.dataGridLogs.DataSource as DataTable;

                if (value > 0 && dt != null)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        int id = Convert.ToInt32(dt.Rows[i]["EntryId"]);

                        if (value == id)
                        {
                            this.dataGridLogs.Select(i);
                            break;
                        }
                    }
                }
            }
        }

        private void BindData()
        {
            DataTable dt = CreateDataTable();
            List<LogEntry> filterEntries = ApplyFilter(m_log.LogEntries);

            foreach (LogEntry entry in filterEntries)
            {
                DataRow row = CreateLogEntryRow(entry, dt);
                if (row != null) dt.Rows.Add(row);
            }

            //if (dt !=null)
            //{
                BindData(dt);
            //}
        }

        private void BindData(DataTable dt)
        {
            this.dataGridLogs.TableStyles.Clear();
            this.dataGridLogs.TableStyles.Add(CreateDataGridTableStyle(dt));
            this.dataGridLogs.AllowSorting = true;
            this.dataGridLogs.DataSource = dt;
        }

        public void BindData(IPersistableLog log)
        {
            if (log != null)
            {
                m_log = log;
                DataTable dt = CreateDataTable();

                //ArrayList filterEntries = ApplyFilter(log.LogEntries);

                foreach (LogEntry entry in log.LogEntries)
                {
                    DataRow row = CreateLogEntryRow(entry, dt);
                    if (row != null) dt.Rows.Add(row);
                }

                BuildFilters(dt);
                BindData(dt);
            }
            else
            {
                this.dataGridLogs.DataSource = null;
                BuildFilters(null);
            }
        }

        private List<LogEntry> ApplyFilter(List<LogEntry> logEntries)
        {
            List<LogEntry> filterEntries = new List<LogEntry>();

            FieldExpression fieldExp = CreateFieldExpression();
            FilterExpression exp = new FilterExpression(typeof(LogEntry));
            exp = exp.GenerateFilterExpression(fieldExp);

            if (fieldExp.ExpressionDataTable.Rows.Count > 0)
            {
                // Filtered objects into filterEntries
                foreach (LogEntry entry in logEntries)
                {
                    if (exp == null || exp.Filter(entry))
                    {
                        filterEntries.Add(entry);
                    }
                }

                return filterEntries;
            }
            else
            {
                return logEntries;
            }
        }

        private bool IsChecked(string name)
        {
            foreach (string checkname in this.checkedListBoxView.CheckedItems)
            {
                if (checkname == name) return true;
            }
            return false;
        }

        private FieldExpression CreateFieldExpression()
        {
            // Build Filter Expression
            FieldExpression fieldExp = new FieldExpression();

            // Foreach filter
            int i = 0;

            foreach (Control c in this.panelFilterGroup.Controls)
            {
                ComboBox filterControl = c as ComboBox;

                if (filterControl != null && filterControl.SelectedIndex != 0)
                {
                    fieldExp.SetField(i, filterControl.Name);
                    fieldExp.SetOperator(i, FilterOperator.Equals.ToString());
                    fieldExp.SetValue(i, filterControl.Text);
                    fieldExp.SetOperator(i, "And");
                    i++;
                }
            }

            return fieldExp;
        }

        private DataGridTableStyle CreateDataGridTableStyle(DataTable dt)
        {
            DataGridTableStyle style = new DataGridTableStyle();

            if (dt != null)
            {
                foreach (DataColumn col in dt.Columns)
                {
                    DataGridTextBoxColumn styleColumn = new DataGridTextBoxColumn();
                    styleColumn.MappingName = col.ColumnName;
                    styleColumn.HeaderText = col.ColumnName;
                    styleColumn.Width = CalculateRowWidth(col);
                    if (IsChecked(col.ColumnName)) style.GridColumnStyles.Add(styleColumn);
                }
            }
            return style;
        }

        private void UpdataDataGridTableStyle()
        {
            DataTable dt = this.dataGridLogs.DataSource as DataTable;

            if (dt != null && this.dataGridLogs.TableStyles.Count > 0)
            {
                DataGridTableStyle style = this.dataGridLogs.TableStyles[0];

                foreach (DataColumn col in dt.Columns)
                {
                    if (IsChecked(col.ColumnName) && !style.GridColumnStyles.Contains(col.ColumnName))
                    {
                        DataGridTextBoxColumn styleColumn = new DataGridTextBoxColumn();
                        styleColumn.MappingName = col.ColumnName;
                        styleColumn.HeaderText = col.ColumnName;
                        styleColumn.Width = CalculateRowWidth(col) + 20;
                        style.GridColumnStyles.Add(styleColumn);
                    }
                    else if (!IsChecked(col.ColumnName) && style.GridColumnStyles.Contains(col.ColumnName))
                    {
                        style.GridColumnStyles.Remove(style.GridColumnStyles[col.ColumnName]);
                    }
                }
            }
        }

        private int CalculateRowWidth(DataColumn dataColumn)
        {
            int iWidth = 0;
            DataTable dataTable = dataColumn.Table;

            using (Graphics g = CreateGraphics())
            {
                iWidth = (int)(g.MeasureString(dataColumn.ColumnName,
                    this.dataGridLogs.Font).Width);

                DataRow dataRow;
                for (int iRow = 0; iRow < dataTable.Rows.Count; iRow++)
                {
                    dataRow = dataTable.Rows[iRow];

                    if (null != dataRow[dataColumn.ColumnName])
                    {
                        int iColWidth = (int)(TextRenderer.MeasureText(
							dataRow[dataColumn].ToString(),
                            this.dataGridLogs.Font).Width);
                        iWidth = (int)System.Math.Max(iWidth, iColWidth);
                    }
                }
            }

            return iWidth;
        }

        private DataTable CreateDataTable()
        {
            DataTable dt = new DataTable();

            PropertyInfo[] pis = typeof(LogEntry).GetProperties();

            foreach (PropertyInfo info in pis)
            {
                DataColumn myColumn = new DataColumn(info.Name);
                //myColumn.DataType = info.PropertyType;
                myColumn.ReadOnly = true;
                dt.Columns.Add(myColumn);
            }

            return dt;
        }

        private DataRow CreateLogEntryRow(LogEntry entry, DataTable dt)
        {
            if (entry != null && dt != null)
            {
                DataRow row = dt.NewRow();

                foreach (DataColumn col in dt.Columns)
                {
                    PropertyInfo info = typeof(LogEntry).GetProperty(col.ColumnName);

                    if (info != null && dt.Columns.Contains(col.ColumnName))
                    {
                        object obj = info.GetValue(entry, null);
                        if (obj != null) row[col.ColumnName] = obj;
                    }
                }

                return row;
            }

            return null;
        }

        private void BuildCheckBox()
        {
            // Build CheckBox

            PropertyInfo[] pis = typeof(LogEntry).GetProperties();

            foreach (PropertyInfo pi in pis)
            {
                this.checkedListBoxView.Items.Add(pi.Name, true);
            }
        }

        private ArrayList GetUniqueValues(string columnName, DataTable dt)
        {
            ArrayList array = new ArrayList();

            if (dt != null && dt.Columns.Contains(columnName))
            {
                Hashtable table = new Hashtable();

                foreach (DataRow row in dt.Rows)
                {
                    if (!table.Contains(row[columnName])) table.Add(row[columnName], 1);
                }

                array.AddRange(table.Keys);
            }

            return array;
        }

        private void FilterChanged(object sender, EventArgs arg)
        {
            BindData();
        }

        private void BuildFilters(DataTable dt)
        {
            IFilter[] filters = exp.Fields;

            Control control = null;

            if (filters != null)
            {
                this.panelFilterGroup.Controls.Clear();

                foreach (IFilter filter in filters)
                {
                    ComboBox filterControl = new ComboBox();

                    filterControl.Name = filter.Name;
                    filterControl.DropDownStyle = ComboBoxStyle.DropDownList;

                    ArrayList list = new ArrayList();
                    list.Add("[" + filter.Name + "]");

                    string longest = "[" + filter.Name + "]";

                    if (dt != null)
                    {
                        ArrayList uniqueList = GetUniqueValues(filterControl.Name, dt);

                        foreach (object obj in uniqueList)
                        {
                            list.Add(obj);
                            if (longest.Length < obj.ToString().Length)
                            {
                                longest = obj.ToString();
                            }
                        }
                    }

                    using (Graphics g = CreateGraphics())
                    {
                        SizeF size = g.MeasureString(longest, filterControl.Font, 10000, StringFormat.GenericDefault);
                        filterControl.Width = (int)size.Width + 20;
                    }

                    filterControl.DataSource = list;

                    Point loc = CalculateNextFilterLocation(control);
                    filterControl.Location = loc;

                    this.panelFilterGroup.Controls.Add(filterControl);
                    filterControl.SelectedIndexChanged += new EventHandler(this.FilterChanged);
                    control = filterControl;
                }
            }
        }

        private Point CalculateNextFilterLocation(Control control)
        {
            Point p = new Point();

            if (control != null)
            {
                p.X = control.Location.X + control.Size.Width;
                p.Y = control.Location.Y;

            }

            return p;
        }

        #region Component Designer generated code
        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelTop = new System.Windows.Forms.Panel();
            this.panelViewColumns = new System.Windows.Forms.Panel();
            this.checkedListBoxView = new System.Windows.Forms.CheckedListBox();
            this.labelViewColumns = new System.Windows.Forms.Label();
            this.panelFilter = new System.Windows.Forms.Panel();
            this.panelFilterGroup = new System.Windows.Forms.Panel();
            this.labelFilter = new System.Windows.Forms.Label();
            this.dataGridLogs = new System.Windows.Forms.DataGrid();
            this.panelTop.SuspendLayout();
            this.panelViewColumns.SuspendLayout();
            this.panelFilter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridLogs)).BeginInit();
            this.SuspendLayout();
            // 
            // panelTop
            // 
            this.panelTop.Controls.AddRange(new System.Windows.Forms.Control[] {
																				   this.panelViewColumns,
																				   this.panelFilter});
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(672, 72);
            this.panelTop.TabIndex = 0;
            // 
            // panelViewColumns
            // 
            this.panelViewColumns.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panelViewColumns.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelViewColumns.Controls.AddRange(new System.Windows.Forms.Control[] {
																						   this.checkedListBoxView,
																						   this.labelViewColumns});
            this.panelViewColumns.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelViewColumns.Location = new System.Drawing.Point(0, 21);
            this.panelViewColumns.Name = "panelViewColumns";
            this.panelViewColumns.Size = new System.Drawing.Size(672, 51);
            this.panelViewColumns.TabIndex = 4;
            // 
            // checkedListBoxView
            // 
            this.checkedListBoxView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.checkedListBoxView.CheckOnClick = true;
            this.checkedListBoxView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkedListBoxView.Location = new System.Drawing.Point(96, 0);
            this.checkedListBoxView.MultiColumn = true;
            this.checkedListBoxView.Name = "checkedListBoxView";
            this.checkedListBoxView.Size = new System.Drawing.Size(574, 45);
            this.checkedListBoxView.TabIndex = 1;
            this.checkedListBoxView.SelectedIndexChanged += new System.EventHandler(this.checkedListBoxView_SelectedValueChanged);
            // 
            // labelViewColumns
            // 
            this.labelViewColumns.BackColor = System.Drawing.SystemColors.Desktop;
            this.labelViewColumns.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelViewColumns.Dock = System.Windows.Forms.DockStyle.Left;
            this.labelViewColumns.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
            this.labelViewColumns.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labelViewColumns.Name = "labelViewColumns";
            this.labelViewColumns.Size = new System.Drawing.Size(96, 49);
            this.labelViewColumns.TabIndex = 0;
            this.labelViewColumns.Text = "View:";
            // 
            // panelFilter
            // 
            this.panelFilter.BackColor = System.Drawing.SystemColors.HighlightText;
            this.panelFilter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelFilter.Controls.AddRange(new System.Windows.Forms.Control[] {
																					  this.panelFilterGroup,
																					  this.labelFilter});
            this.panelFilter.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelFilter.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panelFilter.Name = "panelFilter";
            this.panelFilter.Size = new System.Drawing.Size(672, 21);
            this.panelFilter.TabIndex = 3;
            // 
            // panelFilterGroup
            // 
            this.panelFilterGroup.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelFilterGroup.Location = new System.Drawing.Point(96, 0);
            this.panelFilterGroup.Name = "panelFilterGroup";
            this.panelFilterGroup.Size = new System.Drawing.Size(574, 19);
            this.panelFilterGroup.TabIndex = 1;
            // 
            // labelFilter
            // 
            this.labelFilter.BackColor = System.Drawing.SystemColors.Desktop;
            this.labelFilter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelFilter.Dock = System.Windows.Forms.DockStyle.Left;
            this.labelFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
            this.labelFilter.Name = "labelFilter";
            this.labelFilter.Size = new System.Drawing.Size(96, 19);
            this.labelFilter.TabIndex = 0;
            this.labelFilter.Text = "Filter:";
            // 
            // dataGridLogs
            // 
            this.dataGridLogs.CaptionVisible = false;
            this.dataGridLogs.DataMember = "";
            this.dataGridLogs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridLogs.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dataGridLogs.Location = new System.Drawing.Point(0, 72);
            this.dataGridLogs.Name = "dataGridLogs";
            this.dataGridLogs.Size = new System.Drawing.Size(672, 416);
            this.dataGridLogs.TabIndex = 1;
            // 
            // LogViewer
            // 
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.dataGridLogs,
																		  this.panelTop});
            this.Name = "LogViewer";
            this.Size = new System.Drawing.Size(672, 488);
            this.Load += new System.EventHandler(this.LogViewer_Load);
            this.panelTop.ResumeLayout(false);
            this.panelViewColumns.ResumeLayout(false);
            this.panelFilter.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridLogs)).EndInit();
            this.ResumeLayout(false);

        }
        #endregion

        private void LogViewer_Load(object sender, System.EventArgs e)
        {
            BuildCheckBox();
        }

        private void checkedListBoxView_SelectedValueChanged(object sender, System.EventArgs e)
        {
            UpdataDataGridTableStyle();
        }
    }
}
