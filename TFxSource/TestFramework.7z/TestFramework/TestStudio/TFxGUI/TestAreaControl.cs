﻿//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: TestAreaControl.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 

using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Lifetime;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Data;
using System.Windows.Forms;
using System.Resources;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TestAreaControl.
	/// </summary>
	public class TestAreaControl : RepositoryDelegateUI
	{
		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.TreeView TestAreaControlTree;
        private System.Windows.Forms.ImageList IconImageList;		
				
		public delegate string LabelEventHandler(TestInfo testInfo, LabelEventArgs e); 
		public delegate void TestAreaEventHandler(object sender, TestAreaEventArgs e);
		
		public event LabelEventHandler OnLabelEdit;
		public event TestAreaEventHandler AfterSelect;
	
		private bool m_enabletestcases;
		public bool EnableTestCases
		{
			get
			{
				return m_enabletestcases;
			}
			set
			{
				m_enabletestcases = value;
			}
		}

		private bool m_enableEmptyTestAreas;
		public bool EnableEmptyTestArea
		{
			get
			{
				return m_enableEmptyTestAreas;
			}
			set
			{
				m_enableEmptyTestAreas = value;
			}
		}

        private bool m_selectOnRightClick = true;
        public bool SelectOnRightClick
        {
            get { return m_selectOnRightClick; }
            set { m_selectOnRightClick = value; }
        }
	
		private const int m_testAreaIconIndex = 0;
		private const int m_automatedTestCaseIconIndex = 1;

        private ArrayList m_rootTestAreas = new ArrayList();

        public ArrayList RootTestAreas
        {
            get { return m_rootTestAreas; }
        }

        public void AddRootTestArea(TestArea area)
        {
            m_rootTestAreas.Add(area);
            LoadTree();
        }

        public void ClearRootTestAreas()
        {
            m_rootTestAreas.Clear();
            LoadTree();
        }

		private FilterExpression m_filter;
        private ContextMenuStrip m_contextMenu;
    
		public FilterExpression Filter
		{
			get
			{
				return m_filter;
			}
			set
			{
				m_filter = value;
				LoadTree();				
			}
		}

		public TestAreaControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
		}	
	

		private void TestAreaControlTree_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			TestAreaEventArgs ta = new TestAreaEventArgs();
			ta.Action = e.Action;
			ta.Selected = e.Node;
			ta.Test = (TestInfo)e.Node.Tag;

			if (AfterSelect != null)
			{
				AfterSelect(sender, ta);
			}

            TestTreeChangeNotification change = new TestTreeChangeNotification(new ArrayList());

			if (ta.Test as TestArea != null)
			{
				this.TestAreaControlTree.SelectedImageIndex = 0;
                change.RootTestAreas.Add(ta.Test as TestArea);
                change.SelectedTestInfo = ta.Test as TestArea;
			}
			
			if (ta.Test as TestCase !=null)
			{
				this.TestAreaControlTree.SelectedImageIndex = 1;
                change.SelectedTestInfo = ta.Test as TestCase;
			}

            NotifyUI(change);					
		}

		private void TestAreaControlTree_ItemDrag(object sender, System.Windows.Forms.ItemDragEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				TreeNode node = e.Item as TreeNode;
				TestInfoCollection testCaseList = GetTestCasesList(node);
				if(node != null)
				{
					DoDragDrop(testCaseList, DragDropEffects.Copy);
				}			
			}
		}

		string GetLabel(TestInfo test)
		{
			if(OnLabelEdit != null)
			{
				LabelEventArgs le = new LabelEventArgs();
				le.Label = test.Name;
				OnLabelEdit(test,le);
				return le.Label;
				
			}
			return test.Name;
		}

		private void LoadTree()
		{
			//Clear the Existing nodes in the tree
			this.TestAreaControlTree.Nodes.Clear();

            foreach (TestArea area in m_rootTestAreas)
            {
                TreeNode node = this.CreateNode(area);
                if (node != null)
                {
                    this.TestAreaControlTree.Nodes.Add(node);
                }
            }
		}
		
		TreeNode CreateNode(TestInfo test)
		{
			TestCase testCase = test as TestCase;
			if (testCase != null)
			{
				return CreateNode( testCase);
			}

            TestArea testArea = test as TestArea;
			if (testArea != null)
			{
				return  CreateNode( testArea);
			}
			
			return null;
		}

		TreeNode CreateNode(TestArea testArea)
		{	
			
			TreeNode node = new TreeNode( testArea.Name );
			node.Tag = testArea;
			node.ImageIndex = m_testAreaIconIndex;

            int testsCount = 0;
            int testAreasCount = 0;
            ArrayList TestNames = new ArrayList(testArea.Tests.Keys);
			TestNames.Sort();

			foreach(string testName in TestNames)
			{
				TestInfo test = testArea.Tests[ testName ] as TestInfo;
                if (test is TestCase)
                {
                    ++testsCount;
                }
                else if (test is TestArea)
                {
                    ++testAreasCount;
                }              
				
				TreeNode childNode = CreateNode(test);
				if(childNode != null)
				{
					node.Nodes.Add ( CreateNode( test ));
				}								
			}

            System.Text.StringBuilder toolTipBuilder = new System.Text.StringBuilder();
            toolTipBuilder.Append(testArea.Name);
            if ((testAreasCount + testsCount) > 0)
            {
                if (testsCount == 0)
                {
                    toolTipBuilder.AppendFormat(" (test areas: {0})", testAreasCount);
                }
                else if (testAreasCount == 0)
                {
                    toolTipBuilder.AppendFormat(" (tests: {0})", testsCount);
                }
                else
                {
                    toolTipBuilder.AppendFormat(" (tests: {0}, test areas: {1})", testsCount, testAreasCount);
                }
            }
            node.ToolTipText = toolTipBuilder.ToString();

			if ((node.Nodes.Count > 0) || m_enableEmptyTestAreas)
			{
				node.ImageIndex = m_testAreaIconIndex;
				return node;
			}
			else
			{
				return null;
			}			
		}

		TreeNode CreateNode(TestCase testCase)
		{
			if(this.Filter != null)
			{
				if(!this.Filter.Filter(testCase))
				{
					return null;
				}
			}

            TreeNode node = new TreeNode(testCase.Name);
            node.ImageIndex = m_automatedTestCaseIconIndex;
            node.SelectedImageIndex = node.ImageIndex;
            node.Tag = testCase;
            node.ToolTipText = String.Format("{0} (Module: {1}, Test Category: {2}, Test Owner: {3})",
                testCase.Name,
                testCase.Module.Name,
                (TestCategoryType)testCase.TestCategory,
                testCase.Owner);
            if (testCase.Disabled)
            {
                if (testCase.DisabledReason != null)
                {
                    node.ToolTipText += string.Format("\n\n{0}", testCase.DisabledReason);
                }
                node.ForeColor = Color.Red;
            }
            

			return node;			
		}

		private TestInfoCollection GetTestCasesList(TreeNode node)
		{
			TestInfoCollection tests = new TestInfoCollection();
			if(node != null)
			{
				GetTestCasesList(node, tests);
			}

			return tests;
		}

		private void GetTestCasesList(TreeNode testInfo, TestInfoCollection tests)
		{
			TestCase testCase = null;
			
			if(testInfo == null)
			{
				return;
			}

			if(tests == null)
			{
				tests = new TestInfoCollection();
			}

			testCase = testInfo.Tag as TestCase;

			if(testCase != null)
			{
				tests.Add(testCase);									
			}

			foreach(TreeNode node in testInfo.Nodes)
			{
				GetTestCasesList(node, tests);							
			}
			return;
		}

        public bool expandTree(string fullPath) {
            fullPath = fullPath.Replace(".", "\\");
            fullPath = fullPath.Replace("%20", " ");

            TreeNode target = null;

            foreach (TreeNode tn in TestAreaControlTree.Nodes)
            {
                if (tn.FullPath == fullPath)
                {
                    target = tn;
                }
                else
                {
                    target = findNode(tn, fullPath);
                }
            }

            if (target != null)
            {
                if (target.Parent != null)
                {
                    target.Parent.Expand();
                }

                TestAreaControlTree.SelectedNode = target;

                return true;
            }

            return false;
        }

        private TreeNode findNode(TreeNode parent, string fullPath)
        {
            foreach (TreeNode tn in parent.Nodes)
            {
                if (tn.FullPath == fullPath)
                {
                    return tn;
                }
                else
                {
                    TreeNode child = findNode(tn, fullPath);
                    if (child != null)
                    {
                        return child;
                    }
                }
            }

            return null;
        }
			
		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
    		base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.ToolStripMenuItem donotdeletethisToolStripMenuItem;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TestAreaControl));
            this.TestAreaControlTree = new System.Windows.Forms.TreeView();
            this.m_contextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.IconImageList = new System.Windows.Forms.ImageList(this.components);
            donotdeletethisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.m_contextMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // donotdeletethisToolStripMenuItem
            // 
            donotdeletethisToolStripMenuItem.Name = "donotdeletethisToolStripMenuItem";
            donotdeletethisToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            donotdeletethisToolStripMenuItem.Text = "do_not_delete_this";
            // 
            // TestAreaControlTree
            // 
            this.TestAreaControlTree.AllowDrop = true;
            this.TestAreaControlTree.ContextMenuStrip = this.m_contextMenu;
            this.TestAreaControlTree.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TestAreaControlTree.HideSelection = false;
            this.TestAreaControlTree.ImageIndex = 0;
            this.TestAreaControlTree.ImageList = this.IconImageList;
            this.TestAreaControlTree.Location = new System.Drawing.Point(0, 0);
            this.TestAreaControlTree.Name = "TestAreaControlTree";
            this.TestAreaControlTree.SelectedImageIndex = 0;
            this.TestAreaControlTree.ShowNodeToolTips = true;
            this.TestAreaControlTree.Size = new System.Drawing.Size(312, 424);
            this.TestAreaControlTree.TabIndex = 0;
            this.TestAreaControlTree.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.TestAreaControlTree_AfterSelect);
            this.TestAreaControlTree.ItemDrag += new System.Windows.Forms.ItemDragEventHandler(this.TestAreaControlTree_ItemDrag);
            // 
            // m_contextMenu
            // 
            this.m_contextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            donotdeletethisToolStripMenuItem});
            this.m_contextMenu.Name = "m_contextMenu";
            this.m_contextMenu.Size = new System.Drawing.Size(179, 26);
            this.m_contextMenu.Opening += new System.ComponentModel.CancelEventHandler(this.m_contextMenu_Opening);
            // 
            // IconImageList
            // 
            this.IconImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("IconImageList.ImageStream")));
            this.IconImageList.TransparentColor = System.Drawing.Color.Transparent;
            this.IconImageList.Images.SetKeyName(0, "");
            this.IconImageList.Images.SetKeyName(1, "");
            this.IconImageList.Images.SetKeyName(2, "ManualTestCaseIcon.bmp");
            // 
            // TestAreaControl
            // 
            this.Controls.Add(this.TestAreaControlTree);
            this.Name = "TestAreaControl";
            this.Size = new System.Drawing.Size(312, 424);
            this.m_contextMenu.ResumeLayout(false);
            this.ResumeLayout(false);

		}
		#endregion		
             
        #region Context menu handler code
        /// <summary>
        /// Represents a delegate-driven, context-sensitive context menu item.
        /// </summary>
        public class ContextMenuHandler
        {
            /// <summary>
            /// Acts as a TreeNode-based filter to determine when to show context menu items.
            /// </summary>
            /// <param name="node">The TreeNode to filter off of.</param>
            /// <returns>True if this node should produce a context menu item, false otherwise.</returns>
            public delegate bool AcceptsTreeNodeDelegate(TreeNode node);

            /// <summary>
            /// Performs a custom action on a TreeNode when invoked via context menu.
            /// </summary>
            /// <param name="node">The TreeNode to act upon.</param>
            public delegate void HandleTreeNodeDelegate(TreeNode node);

            /// <summary>
            /// The filter delegate to test each TreeNode.
            /// </summary>
            AcceptsTreeNodeDelegate m_accepts = null;

            // the following are used to build the ToolStripMenuItem
            string m_text = String.Empty;
            Image m_image = null;
            Keys m_keys = Keys.None;

            // this is used to connect the appropriate TreeNode to the click event
            HandleTreeNodeDelegate m_handler = null;

            /// <summary>
            /// Tests this ContextMenuHandler to see if the menu should be displayed or not, based upon the TreeNode.  If it should be displayed,
            /// it returns a new ToolStripMenuItem related to the current tree node.
            /// </summary>
            /// <param name="node">The TreeNode to test to see if the context menu should be displayed.</param>
            /// <param name="contextMenu">The ContextMenuStrip to add the menu item to, if this should be displayed.</param>
            /// <returns>The menu item if accepted, null otherwise.</returns>
            public ToolStripMenuItem GetMenuItem(TreeNode node)
            {
                if (m_accepts(node))
                {
                    return new ToolStripMenuItem(m_text, m_image, delegate(object o, EventArgs args) { m_handler(node); }, m_keys);
                }
                else
                {
                    return null;
                }
            }

            /// <summary>
            /// Accepts all tree nodes.
            /// </summary>
            public static bool AcceptsAllNodes(TreeNode node)
            {
                return true;
            }

            /// <summary>
            /// Full constructor.  Accepts all parameters to build a ToolStripMenuItem, as well as a filter delegate and a handler delegate.
            /// </summary>
            /// <param name="text"><see cref="ToolStripMenuItem.Text"/></param>
            /// <param name="handler">Delegate to handle this menu item when invoked.</param>
            /// <param name="accepts">Delegate to determine whether to show this menu item.</param>
            /// <param name="image"><see cref="ToolStripMenuItem.Image"/></param>
            /// <param name="shortcutKeys"><see cref="ToolStripMenuItem.Keys"/></param>
            public ContextMenuHandler(string text, HandleTreeNodeDelegate handler, AcceptsTreeNodeDelegate accepts, Image image, Keys shortcutKeys)
            {
                m_accepts = accepts;
                m_handler = handler;
                m_text = text;
                m_image = image;
            }

            /// <summary>
            ///  Constructor.  Accepts "text" parameter to build a ToolStripMenuItem, as well as a filter delegate and a handler delegate.
            /// </summary>
            /// <param name="text"><see cref="ToolStripMenuItem.Text"/></param>
            /// <param name="handler">Delegate to handle this menu item when invoked.</param>
            /// <param name="accepts">Delegate to determine whether to show this menu item.</param>
            public ContextMenuHandler(string text, HandleTreeNodeDelegate handler, AcceptsTreeNodeDelegate accepts)
                : this(text, handler, accepts, null, Keys.None)
            {
            }

            /// <summary>
            ///  Constructor.  Accepts "text" parameter to build a ToolStripMenuItem, as well as a handler delegate.
            /// </summary>
            /// <param name="text"><see cref="ToolStripMenuItem.Text"/></param>
            /// <param name="handler">Delegate to handle this menu item when invoked.</param>
            public ContextMenuHandler(string text, HandleTreeNodeDelegate handler)
                : this(text, handler, ContextMenuHandler.AcceptsAllNodes)
            {
            }
        }

        List<ContextMenuHandler> m_contextMenuHandlers = new List<ContextMenuHandler>();
        /// <summary>
        /// A list of ContextMenuHandlers to selectively and intelligently handle context menu popup events.
        /// </summary>
        public List<ContextMenuHandler> ContextMenuHandlers { get { return m_contextMenuHandlers; } }

        /// <summary>
        /// Called by Windows.Forms when the user right-clicks on the TestAreaControl.
        /// </summary>
        private void m_contextMenu_Opening(object sender, CancelEventArgs e)
        {
            TreeNode node = this.TestAreaControlTree.GetNodeAt(PointToClient(Cursor.Position));
            e.Cancel = true;
            m_contextMenu.Items.Clear();

            if ((node != null) && m_selectOnRightClick)
            {
                TestAreaControlTree.SelectedNode = node;
            }
            foreach (ContextMenuHandler handler in m_contextMenuHandlers)
            {
                ToolStripMenuItem menuItem = handler.GetMenuItem(node);
                if (menuItem != null)
                {
                    m_contextMenu.Items.Add(menuItem);
                    e.Cancel = false;
                }
            }
        }
        #endregion
	}
}
