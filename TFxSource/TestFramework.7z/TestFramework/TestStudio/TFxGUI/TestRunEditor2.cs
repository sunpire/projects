using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TestRunEditor2.
	/// </summary>
	public class TestRunEditor2 : System.Windows.Forms.UserControl
	{
		private System.Windows.Forms.Panel panel1;
		private NJFLib.Controls.CollapsibleSplitter collapsibleSplitter1;
		private Expedia.Test.Framework.TestCaseSelectionControl4 testCaseSelectionControl41;
		private System.Windows.Forms.DataGrid AssignmentDataGrid;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public TestRunEditor2()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitForm call

		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panel1 = new System.Windows.Forms.Panel();
			this.AssignmentDataGrid = new System.Windows.Forms.DataGrid();
			this.collapsibleSplitter1 = new NJFLib.Controls.CollapsibleSplitter();
			this.testCaseSelectionControl41 = new Expedia.Test.Framework.TestCaseSelectionControl4();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.AssignmentDataGrid)).BeginInit();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.AssignmentDataGrid});
			this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel1.Location = new System.Drawing.Point(448, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(200, 568);
			this.panel1.TabIndex = 0;
			// 
			// AssignmentDataGrid
			// 
			this.AssignmentDataGrid.CaptionBackColor = System.Drawing.SystemColors.AppWorkspace;
			this.AssignmentDataGrid.CaptionText = "Assignments";
			this.AssignmentDataGrid.DataMember = "";
			this.AssignmentDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
			this.AssignmentDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.AssignmentDataGrid.Name = "AssignmentDataGrid";
			this.AssignmentDataGrid.SelectionBackColor = System.Drawing.SystemColors.AppWorkspace;
			this.AssignmentDataGrid.Size = new System.Drawing.Size(200, 568);
			this.AssignmentDataGrid.TabIndex = 15;
			// 
			// collapsibleSplitter1
			// 
			this.collapsibleSplitter1.AnimationDelay = 20;
			this.collapsibleSplitter1.AnimationStep = 20;
			this.collapsibleSplitter1.BorderStyle3D = System.Windows.Forms.Border3DStyle.Flat;
			this.collapsibleSplitter1.ControlToHide = this.panel1;
			this.collapsibleSplitter1.Dock = System.Windows.Forms.DockStyle.Right;
			this.collapsibleSplitter1.ExpandParentForm = false;
			this.collapsibleSplitter1.Location = new System.Drawing.Point(440, 0);
			this.collapsibleSplitter1.Name = "collapsibleSplitter1";
			this.collapsibleSplitter1.TabIndex = 1;
			this.collapsibleSplitter1.TabStop = false;
			this.collapsibleSplitter1.UseAnimations = false;
			this.collapsibleSplitter1.VisualStyle = NJFLib.Controls.VisualStyles.Mozilla;
			// 
			// testCaseSelectionControl41
			// 
			this.testCaseSelectionControl41.AllowDrop = true;
			this.testCaseSelectionControl41.Dock = System.Windows.Forms.DockStyle.Fill;
			this.testCaseSelectionControl41.Name = "testCaseSelectionControl41";
			this.testCaseSelectionControl41.Size = new System.Drawing.Size(440, 568);
			this.testCaseSelectionControl41.TabIndex = 2;
			// 
			// TestRunEditor2
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.testCaseSelectionControl41,
																		  this.collapsibleSplitter1,
																		  this.panel1});
			this.Name = "TestRunEditor2";
			this.Size = new System.Drawing.Size(648, 568);
			this.panel1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.AssignmentDataGrid)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion
	}
}
