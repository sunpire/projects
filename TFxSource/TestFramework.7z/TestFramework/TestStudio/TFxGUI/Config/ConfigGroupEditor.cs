using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ConfigGroupEditor.
	/// </summary>
	public class ConfigGroupEditor : GenericEditor
	{

		/// <summary> 
		/// Required designer variable.
		/// </summary>
		/// 
		
		private System.ComponentModel.Container components = null;
		protected System.Windows.Forms.Panel panelName;
		protected System.Windows.Forms.TextBox textBoxName;
		protected System.Windows.Forms.Button buttonSave;
		private Expedia.Test.Framework.ConfigEditor configEditor;
		protected System.Windows.Forms.Button buttonDelete;
		protected System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.TreeView treeView;
		protected System.Windows.Forms.Panel panelSave;
		protected System.Windows.Forms.Panel panelDelete;
		protected System.Windows.Forms.Panel panelCancel;
		protected System.Windows.Forms.Label labelName;		

		

		public ConfigGroupEditor()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitForm call
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.treeView = new System.Windows.Forms.TreeView();
			this.configEditor = new Expedia.Test.Framework.ConfigEditor();
			this.panelSave = new System.Windows.Forms.Panel();
			this.buttonSave = new System.Windows.Forms.Button();
			this.panelDelete = new System.Windows.Forms.Panel();
			this.buttonDelete = new System.Windows.Forms.Button();
			this.panelCancel = new System.Windows.Forms.Panel();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.panelName = new System.Windows.Forms.Panel();
			this.textBoxName = new System.Windows.Forms.TextBox();
			this.labelName = new System.Windows.Forms.Label();
			this.panelTop1.SuspendLayout();
			this.panelBottom1.SuspendLayout();
			this.panelCenter.SuspendLayout();
			this.panelLeft.SuspendLayout();
			this.panelRight.SuspendLayout();
			this.panelUpper.SuspendLayout();
			this.panelMiddle.SuspendLayout();
			this.panelSave.SuspendLayout();
			this.panelDelete.SuspendLayout();
			this.panelCancel.SuspendLayout();
			this.panelName.SuspendLayout();
			this.SuspendLayout();
			// 
			// panelTop1
			// 
			this.panelTop1.Visible = false;
			// 
			// panelBottom1
			// 
			this.panelBottom1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					   this.panelSave,
																					   this.panelDelete,
																					   this.panelCancel});
			// 
			// panelLeft
			// 
			this.panelLeft.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.treeView});
			// 
			// panelUpper
			// 
			this.panelUpper.Controls.AddRange(new System.Windows.Forms.Control[] {
																					 this.panelName});
			// 
			// panelLower
			// 
			this.panelLower.Visible = false;
			// 
			// panelMiddle
			// 
			this.panelMiddle.Controls.AddRange(new System.Windows.Forms.Control[] {
																					  this.configEditor});
			// 
			// treeView
			// 
			this.treeView.Dock = System.Windows.Forms.DockStyle.Fill;
			this.treeView.ImageIndex = -1;
			this.treeView.Name = "treeView";
			this.treeView.SelectedImageIndex = -1;
			this.treeView.Size = new System.Drawing.Size(144, 304);
			this.treeView.TabIndex = 0;
			this.treeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterSelect);
			// 
			// configEditor
			// 
			this.configEditor.Dock = System.Windows.Forms.DockStyle.Fill;
			this.configEditor.Name = "configEditor";
			this.configEditor.Size = new System.Drawing.Size(400, 224);
			this.configEditor.TabIndex = 0;
			// 
			// panelSave
			// 
			this.panelSave.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.buttonSave});
			this.panelSave.Dock = System.Windows.Forms.DockStyle.Right;
			this.panelSave.Location = new System.Drawing.Point(360, 0);
			this.panelSave.Name = "panelSave";
			this.panelSave.Size = new System.Drawing.Size(64, 40);
			this.panelSave.TabIndex = 11;
			// 
			// buttonSave
			// 
			this.buttonSave.Location = new System.Drawing.Point(0, 8);
			this.buttonSave.Name = "buttonSave";
			this.buttonSave.Size = new System.Drawing.Size(61, 20);
			this.buttonSave.TabIndex = 0;
			this.buttonSave.Text = "&Save";
			this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
			// 
			// panelDelete
			// 
			this.panelDelete.Controls.AddRange(new System.Windows.Forms.Control[] {
																					  this.buttonDelete});
			this.panelDelete.Dock = System.Windows.Forms.DockStyle.Right;
			this.panelDelete.Location = new System.Drawing.Point(424, 0);
			this.panelDelete.Name = "panelDelete";
			this.panelDelete.Size = new System.Drawing.Size(64, 40);
			this.panelDelete.TabIndex = 10;
			// 
			// buttonDelete
			// 
			this.buttonDelete.Location = new System.Drawing.Point(0, 8);
			this.buttonDelete.Name = "buttonDelete";
			this.buttonDelete.Size = new System.Drawing.Size(61, 20);
			this.buttonDelete.TabIndex = 0;
			this.buttonDelete.Text = "&Delete";
			this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
			// 
			// panelCancel
			// 
			this.panelCancel.Controls.AddRange(new System.Windows.Forms.Control[] {
																					  this.buttonCancel});
			this.panelCancel.Dock = System.Windows.Forms.DockStyle.Right;
			this.panelCancel.Location = new System.Drawing.Point(488, 0);
			this.panelCancel.Name = "panelCancel";
			this.panelCancel.Size = new System.Drawing.Size(64, 40);
			this.panelCancel.TabIndex = 9;
			// 
			// buttonCancel
			// 
			this.buttonCancel.Location = new System.Drawing.Point(0, 8);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Size = new System.Drawing.Size(61, 20);
			this.buttonCancel.TabIndex = 0;
			this.buttonCancel.Text = "&Cancel";
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// panelName
			// 
			this.panelName.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.textBoxName,
																					this.labelName});
			this.panelName.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panelName.Name = "panelName";
			this.panelName.Size = new System.Drawing.Size(400, 40);
			this.panelName.TabIndex = 10;
			// 
			// textBoxName
			// 
			this.textBoxName.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.textBoxName.Location = new System.Drawing.Point(48, 8);
			this.textBoxName.Name = "textBoxName";
			this.textBoxName.Size = new System.Drawing.Size(340, 20);
			this.textBoxName.TabIndex = 1;
			this.textBoxName.Text = "";
			// 
			// labelName
			// 
			this.labelName.Location = new System.Drawing.Point(8, 8);
			this.labelName.Name = "labelName";
			this.labelName.Size = new System.Drawing.Size(100, 20);
			this.labelName.TabIndex = 0;
			this.labelName.Text = "Name";
			this.labelName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// ConfigGroupEditor
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.panelCenter,
																		  this.panelBottom1,
																		  this.panelTop1});
			this.Name = "ConfigGroupEditor";
			this.Load += new System.EventHandler(this.ConfigGroupEditor_Load);
			this.panelTop1.ResumeLayout(false);
			this.panelBottom1.ResumeLayout(false);
			this.panelCenter.ResumeLayout(false);
			this.panelLeft.ResumeLayout(false);
			this.panelRight.ResumeLayout(false);
			this.panelUpper.ResumeLayout(false);
			this.panelMiddle.ResumeLayout(false);
			this.panelSave.ResumeLayout(false);
			this.panelDelete.ResumeLayout(false);
			this.panelCancel.ResumeLayout(false);
			this.panelName.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void ConfigGroupEditor_Load(object sender, System.EventArgs e)
		{
			LoadUIState();
			
			//Get all the stored config values and update the tree
			string[] configNames = this.configEditor.GetConfigListRequest();

			if(configNames != null)
			{
				//Load the Tree View				 
				LoadTree(configNames);
			}			

			this.treeView.ExpandAll();
			
		}

		private void treeView1_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			if(e.Node.Nodes.Count ==0)
			{
				configEditor.GetConfig(e.Node.Text);
				this.textBoxName.Text = e.Node.Text;
			}					
		}

		private void buttonSave_Click(object sender, System.EventArgs e)
		{
			this.configEditor.SaveConfig(this.textBoxName.Text);
			
			//Load the Tree
			LoadTree(this.configEditor.GetConfigListRequest());
			this.treeView.ExpandAll();

			//Clean Up
			this.textBoxName.Text = "";						
		}

		private void buttonDelete_Click(object sender, System.EventArgs e)
		{
			//Need to delete the selected config name
			if(this.textBoxName.Text == "")
			{
				if(this.panelTop1.Visible == false)
				{
					this.panelTop1.Visible = true;
					return;
				}
			}

			this.configEditor.DeleteConfig(this.textBoxName.Text);
			
			//Load the Tree
			LoadTree(this.configEditor.GetConfigListRequest());
			this.treeView.ExpandAll();

			//Clean Up
			this.textBoxName.Text = "";
				
				
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{

			//Load the Tree
			LoadTree(configEditor.GetConfigListRequest());
			this.treeView.ExpandAll();

			//Clean Up
			this.textBoxName.Text = "";
			configEditor.Cleanup();
		
		}
			
		private void LoadTree(string[] Nodes)
		{
			this.treeView.Nodes.Clear();
			if((Nodes != null) && (Nodes.Length >0))
			{
				TreeNode rootNode = new TreeNode("Configs");
				this.treeView.Nodes.Add(rootNode);

				foreach(string nodes in Nodes)
				{
					TreeNode node = new TreeNode(nodes);
					rootNode.Nodes.Add(node);
				}				
			}
		}


		public override void PersistUIState()
		{
			Profile profile = base.GetProfile();
			if(profile == null)
			{
				profile = new Profile();
			}
			profile.ConfigSettings.splitterLeft = new SplitterState(this.splitterLeft.ControlToHide.Size, this.splitterLeft.IsCollapsed); 			
			configEditor.PersistUIState(profile);
			base.UpdateProfile(profile);
		}

		private void LoadUIState()
		{
			Profile profile = base.GetProfile();
			
			if(profile != null && profile.ConfigSettings != null)
			{
				base.LoadUIState(profile.ConfigSettings.splitterLeft);	
				configEditor.LoadUIState(profile);
			}	
		
			
		}

		

		

	}
}
