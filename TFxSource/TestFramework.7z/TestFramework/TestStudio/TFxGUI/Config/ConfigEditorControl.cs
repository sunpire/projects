//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: ConfigEditorControl.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;

using System.Windows.Forms;


namespace Expedia.Test.Framework
{
	public class ConfigEditorControl : Expedia.Test.Framework.BaseSelectionEditorControl
	{
//		public override event EventHandler EditorDone;
//		public override event EventHandler EditorCancel;

		private Expedia.Test.Framework.ConfigBodyControl configBodyControl;
		private System.ComponentModel.IContainer components = null;

		public ConfigEditorControl()
		{
			// This call is required by the Windows Form Designer.
			InitializeComponent();

			this.simpleEditorControl = this.configBodyControl;
			this.advancedEditorControl = null;

			ConfigSet newConfig = new ConfigSet();

			// Create some sample configs
			ConfigSet config1 = new ConfigSet("Config 1");
			config1.AddVariable(new ConfigVariable("Variable1", "Value1"));
			config1.AddVariable(new ConfigVariable("Variable2", "Value2"));
			config1.AddVariable(new ConfigVariable("Variable3", "Value3"));

			ConfigSet config2 = new ConfigSet("Config 2");
			config2.AddVariable(new ConfigVariable("username", "coreAutomation"));
			config2.AddVariable(new ConfigVariable("password", "test123"));

			// Populate the combobox with static data
			// TODO: Replace this with a repository request
			this.SelectorComboBox.DataSource = new ArrayList(new ConfigSet[]{config1, config2});

			this.SelectorComboBox.DisplayMember = "Name";
			this.SelectorComboBox.SelectedIndex = -1;

			this.SelectorComboBox.SelectionChangeCommitted += new EventHandler(this.SelectorComboBoxSelectionChange);
			this.SelectorComboBox.TextChanged += new EventHandler(this.SelectorComboBoxTextChange);

			this.configBodyControl.ConfigSet = newConfig;
		}

		public override object CurrentSelectedObject
		{
			get
			{
				return this.configBodyControl.ConfigSet;
			}
			set
			{
				if(this.SelectorComboBox.Items.Contains(value))
				{
					this.SelectorComboBox.SelectedItem = value;
				}
			}
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.configBodyControl = new Expedia.Test.Framework.ConfigBodyControl();
			this.bodyPanel.SuspendLayout();
			this.SuspendLayout();
			// 
			// bodyPanel
			// 
			this.bodyPanel.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.configBodyControl});
			// 
			// configBodyControl
			// 
			this.configBodyControl.Dock = System.Windows.Forms.DockStyle.Fill;
			this.configBodyControl.Location = new System.Drawing.Point(8, 8);
			this.configBodyControl.Name = "configBodyControl";
			this.configBodyControl.Size = new System.Drawing.Size(472, 256);
			this.configBodyControl.TabIndex = 0;
			// 
			// ConfigEditorControl
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.bodyPanel});
			this.EditorName = "Config Name";
			this.ModeSelectionEnabled = false;
			this.Name = "ConfigEditorControl";
			this.CancelButtonClick += new System.EventHandler(this.CancelButtonClicked);
			this.SaveButtonClick += new System.EventHandler(this.SaveButtonClicked);
			this.bodyPanel.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region Event Handlers
		private void SelectorComboBoxSelectionChange(object sender, EventArgs e)
		{
			ConfigSet config = this.SelectorComboBox.SelectedItem as ConfigSet;
			if(config != null)
			{
				this.configBodyControl.ConfigSet = config;
				this.SelectorComboBoxTextChange(this, null);
			}
		}

		private void SelectorComboBoxTextChange(object sender, EventArgs e)
		{
			if(this.SelectorComboBox.Text.Trim() != String.Empty)
			{
				foreach(ConfigSet config in this.SelectorComboBox.Items)
				{
					if(config.Name == this.SelectorComboBox.Text)
					{
						this.CurrentSaveMode = SaveSelectionMode.Overwrite;
						return;
					}
				}
				this.CurrentSaveMode = SaveSelectionMode.CreateNew;
			}
			else
			{
				this.CurrentSaveMode = SaveSelectionMode.Disabled;
			}
		}

		private void SaveButtonClicked(object sender, EventArgs e)
		{
			this.configBodyControl.ConfigSet.Name = this.SelectorComboBox.Text;
//			this.EditorDone(this, e);
		}

		private void CancelButtonClicked(object sender, EventArgs e)
		{
//			this.EditorCancel(this, e);
		}
		#endregion
	}
}

