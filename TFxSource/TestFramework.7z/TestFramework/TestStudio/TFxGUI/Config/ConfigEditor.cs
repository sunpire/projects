using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for ConfigEditor.
    /// </summary>
    public class ConfigEditor : Expedia.Test.Framework.RepositoryDelegateUI
    {
        public Expedia.Test.Framework.GenericExpressionEditorControl editor;
        private System.Windows.Forms.Panel panelConfigViewer;
        public System.Windows.Forms.DataGrid configViewer;
        private NJFLib.Controls.CollapsibleSplitter configSplitter;

        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;

        public ConfigEditor()
        {
            // This call is required by the Windows.Forms Form Designer.
            InitializeComponent();

            // TODO: Add any initialization after the InitForm call
            //ConfigEngin engin = new ConfigEngin();
        }

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code
        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            //System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ConfigEditor));
            this.editor = new Expedia.Test.Framework.GenericExpressionEditorControl();
            this.configSplitter = new NJFLib.Controls.CollapsibleSplitter();
            this.panelConfigViewer = new System.Windows.Forms.Panel();
            this.configViewer = new System.Windows.Forms.DataGrid();
            this.panelConfigViewer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.configViewer)).BeginInit();
            this.SuspendLayout();
            // 
            // editor
            // 
            this.editor.Dock = System.Windows.Forms.DockStyle.Top;
            this.editor.Location = new System.Drawing.Point(0, 0);
            this.editor.Name = "editor";
            this.editor.Size = new System.Drawing.Size(592, 168);
            this.editor.TabIndex = 0;
            this.editor.ValueList += new Expedia.Test.Framework.GetFieldValuesHandler(this.editor_ValueList);
            this.editor.GetFieldInfo += new Expedia.Test.Framework.GetFieldInfoHandler(this.editor_GetFieldInfo);
            this.editor.FilterExpressionChanged += new System.EventHandler(this.editor_FilterExpressionChanged);
            this.editor.FieldList += new Expedia.Test.Framework.GetValuesHandler(this.editor_FieldList);
            // 
            // configSplitter
            // 
            this.configSplitter.AnimationDelay = 20;
            this.configSplitter.AnimationStep = 20;
            this.configSplitter.BorderStyle3D = System.Windows.Forms.Border3DStyle.Flat;
            this.configSplitter.ControlToHide = this.editor;
            this.configSplitter.Dock = System.Windows.Forms.DockStyle.Top;
            this.configSplitter.ExpandParentForm = false;
            this.configSplitter.Location = new System.Drawing.Point(0, 168);
            this.configSplitter.Name = "configSplitter";
            this.configSplitter.TabIndex = 1;
            this.configSplitter.TabStop = false;
            this.configSplitter.UseAnimations = false;
            this.configSplitter.VisualStyle = NJFLib.Controls.VisualStyles.Mozilla;
            // 
            // panelConfigViewer
            // 
            this.panelConfigViewer.Controls.Add(this.configViewer);
            this.panelConfigViewer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelConfigViewer.Location = new System.Drawing.Point(0, 176);
            this.panelConfigViewer.Name = "panelConfigViewer";
            this.panelConfigViewer.Size = new System.Drawing.Size(592, 232);
            this.panelConfigViewer.TabIndex = 2;
            // 
            // configViewer
            // 
            this.configViewer.DataMember = "";
            this.configViewer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.configViewer.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.configViewer.Location = new System.Drawing.Point(0, 0);
            this.configViewer.Name = "configViewer";
            this.configViewer.Size = new System.Drawing.Size(592, 232);
            this.configViewer.TabIndex = 0;
            // 
            // ConfigEditor
            // 
            this.Controls.Add(this.panelConfigViewer);
            this.Controls.Add(this.configSplitter);
            this.Controls.Add(this.editor);
            this.Name = "ConfigEditor";
            this.Size = new System.Drawing.Size(592, 408);
            this.panelConfigViewer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.configViewer)).EndInit();
            this.ResumeLayout(false);

        }
        #endregion

        //Changed it to the constructor
        ConfigEngin engin = new ConfigEngin();

        private ArrayList editor_FieldList(int rowNum)
        {
            return engin.GetFields(rowNum, editor.Expression);
        }

        private ArrayList editor_ValueList(string fieldName)
        {
            return engin.GetValues(fieldName, editor.Expression);
        }

        private ArrayList editor_OperatorList(string fieldName)
        {
            ConfigFieldInfo fi = engin.FindField(fieldName, editor.Expression);
            if (fi != null)
            {
                return fi.SupportedOperators;
            }
            return new ArrayList();
        }

        private ConfigFieldInfo editor_GetFieldInfo(string fieldName)
        {

            return this.engin.FindField(fieldName, editor.Expression);
        }

        private void editor_FilterExpressionChanged(object sender, System.EventArgs e)
        {
            ConfigData data = this.engin.Evaluate(editor.Expression);
            if (data != null)
            {
                if (data.ConfigTable != null && !engin.IsEditable(editor.Expression))
                {
                    data.ConfigTable.DefaultView.AllowDelete = false;
                    data.ConfigTable.DefaultView.AllowEdit = false;
                }

                this.configViewer.DataSource = data.ConfigTable;
            }
        }

        public void GetConfig(string configName)
        {

            if (configName != null && configName != "")
            {
                ConfigRequest configRequest = new ConfigRequest(RepositoryRequestType.Get);
                configRequest.InstanceName = configName;
                this.GetData(configRequest);

                engin = new ConfigEngin();

                //Get the config
                if (configRequest.ConfigExpression != null)
                {
                    this.engin.InitConfigData(configRequest.ConfigData, configRequest.Expression);
                    this.editor.Expression.ExpressionDataTable = configRequest.Expression.ExpressionDataTable;
                    this.editor.DataSource = this.editor.Expression.ExpressionDataTable;
                    ConfigData configData = engin.Evaluate(this.editor.Expression);
                    if (configData != null)
                    {
                        this.configViewer.DataSource = configData.ConfigTable;
                    }
                }
            }
        }

        public void SaveConfig(string configName)
        {
            if (configName != null && configName != "")
            {
                ConfigRequest configRequest = null;
                string[] configNames = GetConfigListRequest();

                if (configNames != null && ContainsConfig(configNames, configName))
                {
                    configRequest = new ConfigRequest(RepositoryRequestType.Update);
                }
                else
                {
                    configRequest = new ConfigRequest(RepositoryRequestType.Create);
                }

                configRequest.InstanceName = configName;
                configRequest.Expression = new FieldExpression();
                configRequest.Expression.ExpressionDataTable = editor.Expression.ExpressionDataTable;
                configRequest.ConfigData = new ConfigData();
                configRequest.ConfigData.ConfigTable = this.configViewer.DataSource as DataTable;

                //remove the deleted row and which has null value in column['value']
                //so it will not be saved in config.xml
                for (int i = 0; i < configRequest.Expression.ExpressionDataTable.Rows.Count; i++)
                {
                    if (configRequest.Expression.ExpressionDataTable.Rows[i].RowState== DataRowState.Deleted
                        || configRequest.Expression.ExpressionDataTable.Rows[i][2] is DBNull)
                    {
                        configRequest.Expression.ExpressionDataTable.Rows.RemoveAt(i);
                        i--;
                    }
                }
                //remove the deleted row
                //so it will not be saved in config.xml 
                for (int i = 0; i < configRequest.ConfigData.ConfigTable.Rows.Count; i++)
                {
                    if (configRequest.ConfigData.ConfigTable.Rows[i].RowState == DataRowState.Deleted)
                    {
                        configRequest.ConfigData.ConfigTable.Rows.RemoveAt(i);
                        i--;
                    }
                }
                this.GetData(configRequest);
                this.NotifyUIAsync(new ConfigChangeNotification());

                Cleanup();
            }
        }

        public void DeleteConfig(string configName)
        {
            if (configName != null && configName != "")
            {
                ConfigRequest configRequest = new ConfigRequest(RepositoryRequestType.Delete);
                configRequest.InstanceName = configName;
                this.GetData(configRequest);

                this.NotifyUIAsync(new ConfigChangeNotification());

                Cleanup();
            }
        }

        public void Cleanup()
        {
            editor.Cleanup();
            configViewer.DataSource = null;
        }

        public string[] GetConfigListRequest()
        {
            ConfigListRequest configListRequest = new ConfigListRequest();
            this.GetData(configListRequest);

            if ((configListRequest.Objects != null) && (configListRequest.Objects.Length > 0))
            {
                return configListRequest.Objects;
            }
            else
            {
                return null;
            }
        }

        private bool ContainsConfig(string[] configNames, string configName)
        {
            if ((configNames != null) && (configName != null))
            {
                for (int index = 0; index < configNames.Length; index++)
                {
                    if (configName.CompareTo(configNames[index]) == 0)
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        public override void PersistUIState(Profile profile)
        {
            if (profile != null)
            {
                profile.ConfigSettings.configSplitter = new SplitterState(this.configSplitter.ControlToHide.Size, this.configSplitter.IsCollapsed);
            }
        }

        public void LoadUIState(Profile profile)
        {
            SplitterState currentSplitter = null;
            if (profile != null && profile.ConfigSettings != null)
            {
                currentSplitter = profile.ConfigSettings.configSplitter;

                if (currentSplitter != null)
                {
                    this.configSplitter.ControlToHide.Size = new Size(currentSplitter.ControlToHideSize.Width, currentSplitter.ControlToHideSize.Height);
                    if (currentSplitter.isCollapsed)
                    {
                        this.configSplitter.ControlToHide.Visible = false;
                    }
                    else
                    {
                        this.configSplitter.ControlToHide.Visible = true;
                    }
                }
            }
        }

        //		private Profile GetProfile()
        //		{
        //			ProfileRequest profileRequest = new ProfileRequest(RepositoryRequestType.Get);
        //			profileRequest.ProfileName = Enum.GetName(typeof(ProfileName), ProfileName.DefaultProfile);
        //			this.GetData(profileRequest);
        //
        //			return profileRequest.Profile;
        //
        //		}
        //
        //		private void UpdateProfile(Profile profile)
        //		{
        //			if(profile != null)
        //			{
        //				ProfileRequest profileRequest = new ProfileRequest(RepositoryRequestType.Update);
        //				profileRequest.Profile =profile;
        //				profileRequest.ProfileName = Enum.GetName(typeof(ProfileName), ProfileName.DefaultProfile);
        //				GetData(profileRequest);
        //			}
        //		}

    }
}
