//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: ConfigBodyControl.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ConfigBodyControl.
	/// </summary>
	public class ConfigBodyControl : System.Windows.Forms.UserControl
	{
		private ConfigSet m_configSet;
		private bool m_refreshingDataGrid = false;

		private DataTable m_configDataTable;
		private System.Windows.Forms.DataGrid m_configDataGrid;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public event System.EventHandler ConfigSetChanged;

		public ConfigBodyControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			this.m_configSet = new ConfigSet();

			this.m_configDataTable = new DataTable("Config Variables");
			this.m_configDataTable.Columns.Add("Name", typeof(string));
			this.m_configDataTable.Columns.Add("Value", typeof(object));
			this.m_configDataTable.RowChanged += new DataRowChangeEventHandler(this.DataTableRowChange);
			this.m_configDataTable.RowDeleting += new DataRowChangeEventHandler(this.DataTableRowDeleted);

			this.m_configDataGrid.DataSource = this.m_configDataTable;

			//this.ConfigSetChanged += new EventHandler(this.TextChange);
		}

		public ConfigSet ConfigSet
		{
			get
			{
				return this.m_configSet;
			}
			set
			{
				this.m_configSet = value;
				this.RefreshDataGrid();
				if(this.ConfigSetChanged != null)
				{
					this.ConfigSetChanged(this.m_configSet, null);
				}
			}
		}

		private void RefreshDataGrid()
		{
			this.m_refreshingDataGrid = true;
			this.m_configDataTable.Rows.Clear();
			for(int i = 0;i < this.m_configSet.Count;i++)
			{
				this.m_configDataTable.Rows.Add(new object[]{this.m_configSet[i].Name, this.m_configSet[i].Value});
			}
			this.m_refreshingDataGrid = false;
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.m_configDataGrid = new System.Windows.Forms.DataGrid();
			((System.ComponentModel.ISupportInitialize)(this.m_configDataGrid)).BeginInit();
			this.SuspendLayout();
			// 
			// m_configDataGrid
			// 
			this.m_configDataGrid.CaptionText = "Config Variables";
			this.m_configDataGrid.DataMember = "";
			this.m_configDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
			this.m_configDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.m_configDataGrid.Name = "m_configDataGrid";
			this.m_configDataGrid.Size = new System.Drawing.Size(150, 150);
			this.m_configDataGrid.TabIndex = 0;
			// 
			// ConfigBodyControl
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.m_configDataGrid});
			this.Name = "ConfigBodyControl";
			((System.ComponentModel.ISupportInitialize)(this.m_configDataGrid)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

//		private void TextChange(object sender, EventArgs e)
//		{
//			this.m_configDataGrid.CaptionText = this.ConfigSet.ToString();
//		}
		
		private void DataTableRowChange(object sender, DataRowChangeEventArgs e)
		{
			if(!this.m_refreshingDataGrid)
			{
				if(e.Action == DataRowAction.Add)
				{
					this.ConfigSet.AddVariable(new ConfigVariable((string)e.Row["Name"], e.Row["Value"]));
				}
				else if(e.Action == DataRowAction.Change)
				{
					int rowIndex = -1;
					for(int i = 0;i < e.Row.Table.Rows.Count;i++)
					{
						if(e.Row.Table.Rows[i] == e.Row)
						{
							rowIndex = i;
							break;
						}
					}

					this.ConfigSet[rowIndex].Name = (string)e.Row["Name"];
					this.ConfigSet[rowIndex].Value = e.Row["Value"];
				}
				else
				{
					return;
				}
				if(this.ConfigSetChanged != null)
				{
					this.ConfigSetChanged(this.m_configSet, null);
				}
			}
		}

		private void DataTableRowDeleted(object sender, DataRowChangeEventArgs e)
		{
			int rowIndex = -1;
			for(int i = 0;i < e.Row.Table.Rows.Count;i++)
			{
				if(e.Row.Table.Rows[i] == e.Row)
				{
					rowIndex = i;
					break;
				}
			}

			this.ConfigSet.RemoveVariable(this.ConfigSet[rowIndex]);

			if(this.ConfigSetChanged != null)
			{
				this.ConfigSetChanged(this.m_configSet, null);
			}
		}
	}
}
