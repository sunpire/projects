using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for UnloadDllControl.
    /// </summary>
    public class UnloadDllControl : System.Windows.Forms.Form
    {
        private System.Windows.Forms.CheckedListBox checkedListBoxDLLNames;
        private System.Windows.Forms.Button buttonUnload;
        private System.Windows.Forms.Button buttonCancel;
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;

        private ArrayList m_moduleNames;
        public ArrayList ModuleNames
        {
            get
            {
                return m_moduleNames;
            }
            set
            {
                m_moduleNames = value;
                BindData();
            }
        }

        public int ModuleCount
        {
            get
            {
                if (this.m_moduleNames != null)
                {
                    return m_moduleNames.Count;
                }
                return -1;
            }
        }

        public ArrayList m_checkedModuleNames;
        public ArrayList CheckedModuleNames
        {
            get
            {
                return m_checkedModuleNames;
            }
            set
            {
                m_checkedModuleNames = value;
            }
        }

        public UnloadDllControl()
        {
            // This call is required by the Windows.Forms Form Designer.
            InitializeComponent();
        }

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code
        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkedListBoxDLLNames = new System.Windows.Forms.CheckedListBox();
            this.buttonUnload = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // checkedListBoxDLLNames
            // 
            this.checkedListBoxDLLNames.CheckOnClick = true;
            this.checkedListBoxDLLNames.Location = new System.Drawing.Point(8, 8);
            this.checkedListBoxDLLNames.Name = "checkedListBoxDLLNames";
            this.checkedListBoxDLLNames.Size = new System.Drawing.Size(192, 109);
            this.checkedListBoxDLLNames.TabIndex = 0;
            // 
            // buttonUnload
            // 
            this.buttonUnload.Location = new System.Drawing.Point(12, 123);
            this.buttonUnload.Name = "buttonUnload";
            this.buttonUnload.Size = new System.Drawing.Size(75, 23);
            this.buttonUnload.TabIndex = 1;
            this.buttonUnload.Text = "Unload";
            this.buttonUnload.Click += new System.EventHandler(this.buttonUnload_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.Location = new System.Drawing.Point(122, 123);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(75, 23);
            this.buttonCancel.TabIndex = 2;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // UnloadDllControl
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(209, 154);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonUnload);
            this.Controls.Add(this.checkedListBoxDLLNames);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "UnloadDllControl";
            this.Text = "Unload DLLs";
            this.ResumeLayout(false);
        }
        #endregion
        
        private void BindData()
        {
            this.checkedListBoxDLLNames.Items.Clear();

            if (m_moduleNames != null)
            {
                foreach (TestBuildModule buildModule in this.m_moduleNames)
                {
                    this.checkedListBoxDLLNames.Items.Add(buildModule.Name);
                }
            }
        }

        private void buttonUnload_Click(object sender, System.EventArgs e)
        {
            //Get the names of the all checked names
            ArrayList checkedModuleNames = new ArrayList();
            if (checkedListBoxDLLNames.CheckedItems.Count != 0)
            {
                for (int x = 0; x <= checkedListBoxDLLNames.CheckedItems.Count - 1; x++)
                {
                    checkedModuleNames.Add(checkedListBoxDLLNames.CheckedItems[x].ToString());
                }
            }

            this.m_checkedModuleNames = new ArrayList(checkedModuleNames);
            this.Close();
        }

        private void buttonCancel_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }
    }
}
