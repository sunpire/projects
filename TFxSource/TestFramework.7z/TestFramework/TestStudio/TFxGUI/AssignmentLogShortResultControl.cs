using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.Reflection;
using System.IO;
using System.Globalization;

namespace Expedia.Test.Framework
{

	/// <summary>
	/// Summary description for AssignmentShortResultControl.
	/// </summary>
	public class AssignmentLogShortResultControl : System.Windows.Forms.UserControl
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public AssignmentLogShortResultControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitForm call

		}

		private System.Windows.Forms.Panel panelResult;
		private System.Windows.Forms.Panel panelErrorLog;
		private System.Windows.Forms.Splitter splitter1;
		private System.Windows.Forms.LinkLabel linkLogView;
		private System.Windows.Forms.TextBox textBoxFailureReason;
		private ILog m_longLog;
		private bool m_shortView = true;
		private Expedia.Test.Framework.LogViewer logViewer;




		private AssignmentResult m_result;

		public string FailureReason
		{
			get
			{
				return textBoxFailureReason.Text;
			}
			set
			{
				textBoxFailureReason.Text = value;
			}

		}


		public void BindData(ILog longLog)
		{
			m_longLog = longLog;
			this.logViewer.BindData(m_longLog as IPersistableLog);
		}


		public void BindData(AssignmentResult result, ILog longLog, bool shortView)
		{
            //
            // Replace any SOAMessage log text with path only
            // This is because some soa message can be couples MB in size and it will cause
            // GDI exception in TestStudio when try to display it in the log.
            //
            string logDirectory = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + "\\Log\\SOA";
            TFxLog logs = (TFxLog)longLog;

            for (Int32 i = 0; i < logs.LogEntries.Count; i++)
            {
                LogEntry currLog = logs.LogEntries[i];

                if ((logs.LogEntries[i].Level == LogLevelType.SOAMessage) ||
                    (logs.LogEntries[i].Level == LogLevelType.SOARawMessage))
                {
                    string text = "Please check the soa message at " + logDirectory;
                    if (currLog.AdditionalInfo.Count > 2)
                    {
                        text = text + Path.Combine(logDirectory,
                            string.Concat(currLog.AdditionalInfo[0] + currLog.AdditionalInfo[1], ".*.", currLog.EntryTime.ToString("MM-dd-yyyy_HH-mm-ss-fff", CultureInfo.InvariantCulture))) +
                            (currLog.AdditionalInfo[2].Equals("binary", StringComparison.InvariantCultureIgnoreCase) ? ".binary" : ".xml");
                    }

                    LogEntry newLog = new LogEntry(currLog.Severity, currLog.Level, text, currLog.Module, currLog.Function, currLog.Type, null);

                    newLog.EntryId = currLog.EntryId;
                    newLog.EntryTime = currLog.EntryTime;
                    newLog.AdditionalInfo.AddRange(currLog.AdditionalInfo);

                    logs.LogEntries[i] = newLog;
                }
            }

            //
            // Perform the binding of log results
            //
			if (result !=null)
			{
				m_longLog = longLog;
				m_result = result;

				this.textBoxFailureReason.Text = result.FailureReason;
				IPersistableLog log = result.Log as IPersistableLog;

				if (!shortView)
				{
					this.linkLogView.Text = "Error Log";
					m_shortView = false;

					this.logViewer.BindData(m_longLog as IPersistableLog);
				}
				else
				{
					this.linkLogView.Text = "Full Log";
					m_shortView = true;

					this.logViewer.BindData(log);
				}

			}
			else
			{	
				this.logViewer.BindData(null);
				this.textBoxFailureReason.Text = null;
				m_longLog = null;
				m_result = null;
			}
		}

        public void Clear()
        {
            this.logViewer.BindData(null);
            this.textBoxFailureReason.Text = null;
            m_longLog = null;
            m_result = null;

        }


		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panelResult = new System.Windows.Forms.Panel();
			this.textBoxFailureReason = new System.Windows.Forms.TextBox();
			this.linkLogView = new System.Windows.Forms.LinkLabel();
			this.splitter1 = new System.Windows.Forms.Splitter();
			this.logViewer = new Expedia.Test.Framework.LogViewer();
			this.panelErrorLog = new System.Windows.Forms.Panel();
			this.panelResult.SuspendLayout();
			this.panelErrorLog.SuspendLayout();
			this.SuspendLayout();
			// 
			// panelResult
			// 
			this.panelResult.Controls.Add(this.textBoxFailureReason);
			this.panelResult.Controls.Add(this.linkLogView);
			this.panelResult.Dock = System.Windows.Forms.DockStyle.Top;
			this.panelResult.Location = new System.Drawing.Point(0, 0);
			this.panelResult.Name = "panelResult";
			this.panelResult.Size = new System.Drawing.Size(704, 80);
			this.panelResult.TabIndex = 0;
			// 
			// textBoxFailureReason
			// 
			this.textBoxFailureReason.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBoxFailureReason.Location = new System.Drawing.Point(0, 0);
			this.textBoxFailureReason.Multiline = true;
			this.textBoxFailureReason.Name = "textBoxFailureReason";
			this.textBoxFailureReason.ReadOnly = true;
			this.textBoxFailureReason.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBoxFailureReason.Size = new System.Drawing.Size(704, 64);
			this.textBoxFailureReason.TabIndex = 1;
			this.textBoxFailureReason.Text = "";
			// 
			// linkLogView
			// 
			this.linkLogView.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.linkLogView.Location = new System.Drawing.Point(0, 64);
			this.linkLogView.Name = "linkLogView";
			this.linkLogView.Size = new System.Drawing.Size(704, 16);
			this.linkLogView.TabIndex = 0;
			this.linkLogView.TabStop = true;
			this.linkLogView.Text = "Full Log";
			this.linkLogView.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLogView_LinkClicked);
			// 
			// splitter1
			// 
			this.splitter1.Dock = System.Windows.Forms.DockStyle.Top;
			this.splitter1.Location = new System.Drawing.Point(0, 0);
			this.splitter1.Name = "splitter1";
			this.splitter1.Size = new System.Drawing.Size(704, 3);
			this.splitter1.TabIndex = 0;
			this.splitter1.TabStop = false;
			// 
			// logViewer
			// 
			this.logViewer.Dock = System.Windows.Forms.DockStyle.Fill;
			this.logViewer.Location = new System.Drawing.Point(0, 3);
			this.logViewer.Name = "logViewer";
			this.logViewer.SelectedEntryId = -1;
			this.logViewer.Size = new System.Drawing.Size(704, 477);
			this.logViewer.TabIndex = 0;
			// 
			// panelErrorLog
			// 
			this.panelErrorLog.Controls.Add(this.logViewer);
			this.panelErrorLog.Controls.Add(this.splitter1);
			this.panelErrorLog.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panelErrorLog.Location = new System.Drawing.Point(0, 80);
			this.panelErrorLog.Name = "panelErrorLog";
			this.panelErrorLog.Size = new System.Drawing.Size(704, 480);
			this.panelErrorLog.TabIndex = 1;
			// 
			// AssignmentLogShortResultControl
			// 
			this.Controls.Add(this.panelErrorLog);
			this.Controls.Add(this.panelResult);
			this.Name = "AssignmentLogShortResultControl";
			this.Size = new System.Drawing.Size(704, 560);
			this.panelResult.ResumeLayout(false);
			this.panelErrorLog.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void linkLogView_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{


			// cross referencing LogEntry			
			int selectedId = this.logViewer.SelectedEntryId;
	
			this.Cursor = Cursors.WaitCursor;

			if (m_shortView)
			{
				this.linkLogView.Text = "Error Log";
				m_shortView = false;

				BindData(m_longLog);
			}
			else
			{
				this.linkLogView.Text = "Full Log";
				m_shortView = true;

				BindData(m_result, m_longLog, m_shortView);
			}

			if ( selectedId >= 0)
			{
				this.logViewer.SelectedEntryId = selectedId;
			}

			this.Cursor = Cursors.Default;

		}
	}
}
