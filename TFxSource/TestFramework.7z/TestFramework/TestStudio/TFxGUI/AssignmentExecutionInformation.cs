﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
    public partial class AssignmentExecutionInformation : Form
    {
        /// <summary>
        /// Construct the Execution Information winform
        /// </summary>
        /// <param name="assignment">The current selected Assignment </param>
        public AssignmentExecutionInformation(Assignment assignment)
        {
            InitializeComponent();

            //
            // Clear all fields
            //
            this.txtBranch.Text = String.Empty;
            this.txtNamespace.Text = String.Empty;

            //
            // Initialize the fields
            //
            foreach (String key in assignment.TestCase.TestConfigs.Keys)
            {
                if (String.Compare(key, "__releaseinfo", StringComparison.InvariantCultureIgnoreCase) == 0)
                {
                    this.txtBranch.Text = assignment.TestCase.TestConfigs[key];
                }
                else if (String.Compare(key, "__testnamespace", StringComparison.InvariantCultureIgnoreCase) == 0)
                {
                    this.txtNamespace.Text = assignment.TestCase.TestConfigs[key];
                }
                else if (key.IndexOf("__") != 0)
                {
                    this.dgvTestConfigs.Rows.Add(key, assignment.TestCase.TestConfigs[key]);
                }
            }
        }

        /// <summary>
        /// Close the current dialogbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
