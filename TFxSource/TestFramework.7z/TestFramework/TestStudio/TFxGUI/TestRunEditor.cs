//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: TestRunEditor.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 

using System;
using System.Threading;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for abc.
	/// </summary>
	public class TestRunEditor : System.Windows.Forms.UserControl
	{
		private System.Windows.Forms.LinkLabel Reload;
		private System.Windows.Forms.LinkLabel SaveDoneLink;
		private System.Windows.Forms.ComboBox LabRunIDCombo;
		private System.Windows.Forms.Label LabRunIDLabel;
		private Expedia.Test.Framework.LabRunEditControl labRunEditControl1;
		private System.Windows.Forms.Panel panel1;
		private RepositoryChangelist m_changelist;
		bool dirty = false;

		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public TestRunEditor()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Reload = new System.Windows.Forms.LinkLabel();
			this.SaveDoneLink = new System.Windows.Forms.LinkLabel();
			this.LabRunIDCombo = new System.Windows.Forms.ComboBox();
			this.LabRunIDLabel = new System.Windows.Forms.Label();
			this.labRunEditControl1 = new Expedia.Test.Framework.LabRunEditControl();
			this.panel1 = new System.Windows.Forms.Panel();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// Reload
			// 
			this.Reload.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
			this.Reload.Location = new System.Drawing.Point(392, 16);
			this.Reload.Name = "Reload";
			this.Reload.Size = new System.Drawing.Size(40, 16);
			this.Reload.TabIndex = 23;
			this.Reload.TabStop = true;
			this.Reload.Text = "Reload";
			this.Reload.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Reload_LinkClicked);
			// 
			// SaveDoneLink
			// 
			this.SaveDoneLink.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
			this.SaveDoneLink.Location = new System.Drawing.Point(464, 16);
			this.SaveDoneLink.Name = "SaveDoneLink";
			this.SaveDoneLink.Size = new System.Drawing.Size(32, 23);
			this.SaveDoneLink.TabIndex = 22;
			this.SaveDoneLink.TabStop = true;
			this.SaveDoneLink.Text = "Save";
			this.SaveDoneLink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.SaveDoneLink_LinkClicked);
			// 
			// LabRunIDCombo
			// 
			this.LabRunIDCombo.Location = new System.Drawing.Point(112, 16);
			this.LabRunIDCombo.Name = "LabRunIDCombo";
			this.LabRunIDCombo.Size = new System.Drawing.Size(120, 21);
			this.LabRunIDCombo.TabIndex = 21;
			// 
			// LabRunIDLabel
			// 
			this.LabRunIDLabel.Location = new System.Drawing.Point(8, 16);
			this.LabRunIDLabel.Name = "LabRunIDLabel";
			this.LabRunIDLabel.Size = new System.Drawing.Size(76, 23);
			this.LabRunIDLabel.TabIndex = 20;
			this.LabRunIDLabel.Text = "LabRunId:";
			// 
			// labRunEditControl1
			// 
			this.labRunEditControl1.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.labRunEditControl1.EditingLabRun = null;
			this.labRunEditControl1.Location = new System.Drawing.Point(0, 48);
			this.labRunEditControl1.Name = "labRunEditControl1";
			this.labRunEditControl1.Size = new System.Drawing.Size(520, 456);
			this.labRunEditControl1.TabIndex = 24;
			// 
			// panel1
			// 
			this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.panel1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.LabRunIDLabel,
																				 this.SaveDoneLink,
																				 this.LabRunIDCombo,
																				 this.Reload});
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(520, 40);
			this.panel1.TabIndex = 25;
			// 
			// TestRunEditor
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.panel1,
																		  this.labRunEditControl1});
			this.Name = "TestRunEditor";
			this.Size = new System.Drawing.Size(520, 504);
			this.Load += new System.EventHandler(this.TestRunEditor_Load);
			this.panel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion


		private void TestRunEditor_Load(object sender, System.EventArgs e)
		{
			ThreadStart myThreadStart = new ThreadStart(this.LazyLoad);
			Thread myWorkerThread = new Thread(myThreadStart);
			myWorkerThread.Name = "Created at " + DateTime.Now.ToString();
			myWorkerThread.Start();

			labRunEditControl1.OnChange +=new RepositoryChangeEventHandler(this.labRunEditControl1_Change);
			labRunEditControl1.OnSelectAssignmentGrid += new EventHandler(this.labRunEditControl1_CurrentCellChanged);

			m_changelist = new RepositoryChangelist();
			dirty = false;
		}

		DataTable labRunList = null;

		void LazyLoad()
		{
			using(TFx tfx = new TFx(DBUserType.Client))
			{
				//labRunList = tfx.GetLabRunList();
			}	

			if (UpdateDataDelegate == null)
			{
				UpdateDataDelegate = new ThreadStart(UpdateData);
			}

			this.BeginInvoke(UpdateDataDelegate);

		}

		ThreadStart UpdateDataDelegate = null;

		void UpdateData()
		{
			LabRunIDCombo.DataSource = labRunList;
			LabRunIDCombo.DisplayMember = "labRunId";
			LabRunIDCombo.ValueMember = "labRunId";

			LabRunIDCombo.SelectedIndexChanged += new System.EventHandler(this.LabRunIDCombo_Selected);

		}

		private void labRunEditControl1_CurrentCellChanged(object sender, EventArgs e)
		{
			// TODO: need to implement changes events for assignment grid
			if (!dirty) 
				dirty = true;
		}

		private void LabRunIDCombo_Selected(object sender, EventArgs e)
		{

			if (dirty || m_changelist.Count > 0)
			{
				DialogResult result = MessageBox.Show("Do you want to save LabRun changes?", "LabRun change", MessageBoxButtons.YesNoCancel);

				if (result == DialogResult.Cancel)
				{
					return;
				}
				else if (result == DialogResult.Yes)
				{
					SaveDoneLink_LinkClicked(this,null);
				}
				else
				{
					// reset changelist and dirty bit
					m_changelist.Clear();
					dirty = false;
				}
			}


			int labrunid = (int) LabRunIDCombo.SelectedValue;

			if (labrunid > 0)
			{
				LabRun labrun = new LabRun();
				//labrun.LoadLabRun(labrunid);
				labRunEditControl1.LoadLabRun(labrun);
			}

		}


		private void labRunEditControl1_Change(object sender, RepositoryChangeEventArgs e)
		{
			if (e !=null && e.Change !=null)
			{
				m_changelist.Add(e.Change);
			}
		}

		private void Reload_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			m_changelist.Clear();
			dirty = false;
			LabRunIDCombo_Selected(this, new EventArgs());
		}

		private void SaveDoneLink_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			try
			{
				labRunEditControl1.AddAssignmentChanges();

				if ( m_changelist.Count > 0 && labRunEditControl1.EditingLabRun !=null)
				{

					using (TFx tfx = new TFx(DBUserType.Client))
					{
						//tfx.UpdateLabRun(labRunEditControl1.EditingLabRun, m_changelist);
						
					}
				}

				MessageBox.Show("Saved LabRun Successfully"); 

				// Reload the LabRun
				Reload_LinkClicked(this, null);

			}
			catch (Exception ex)
			{
				MessageBox.Show( "Cannot save LabRun: " +  ex.Message);	
			}
		}




	}
}
