using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.Reflection;

namespace Expedia.Test.Framework
{

	/// <summary>
	/// Summary description for AssignmentStatusColumn.
	/// </summary>
	public class AssignmentStatusColumn : DataGridTextBoxColumn
	{


		public AssignmentStatusColumnType StatusColumnType = AssignmentStatusColumnType.Status;


		public AssignmentStatusColumn(AssignmentStatusColumnType type) : base()
		{
			StatusColumnType = type;

		}


		protected override void Paint(System.Drawing.Graphics g, System.Drawing.Rectangle bounds, System.Windows.Forms.CurrencyManager 
			source, int rowNum, System.Drawing.Brush backBrush, System.Drawing.Brush 
			foreBrush, bool alignToRight) 
		{
			try
			{ 
				DataRowView view = source.Current as DataRowView ;
				DataTable dt = view.Row.Table;

				DataRow row = dt.Rows[rowNum];

 
				if( row != null) 
				{ 
					if (row["Disabled"].ToString().ToLower() == "true")
					{
						backBrush = new SolidBrush(Color.Gray); 
					}



				}
 
				DataGrid dg = this.DataGridTableStyle.DataGrid;

				if (dg !=null && !dg.IsSelected(rowNum))
				{
					string status =  this.GetColumnValueAtRow(source, rowNum) as string;
	
					switch (status)
					{
						case "Executing":
							foreBrush = new SolidBrush(Color.White);
							backBrush = new SolidBrush(Color.RoyalBlue);
							break;
						case "ExecutionError":
							foreBrush = new SolidBrush(Color.White);
							backBrush = new SolidBrush(Color.Red);
							break;
						case "Pass":
							foreBrush = new SolidBrush(Color.White);
							backBrush = new SolidBrush(Color.Green);
							break;
						case "Timeout":
							foreBrush = new SolidBrush(Color.White);
							backBrush = new SolidBrush(Color.Orange);
							break;
					}

				}		

			}
			catch(Exception){}
			finally
			{ 
				base.Paint(g, bounds, source, rowNum, backBrush, foreBrush, alignToRight); 
			} 
 
		} 

	}
}
