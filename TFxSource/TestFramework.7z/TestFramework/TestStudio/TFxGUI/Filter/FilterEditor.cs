using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for FilterEditor.
	/// </summary>
	public class FilterEditor : GenericEditor
	{
		protected System.Windows.Forms.Panel panelName;
		protected System.Windows.Forms.TextBox textBoxName;
		private Expedia.Test.Framework.GenericExpressionEditorControl editor;
		protected System.Windows.Forms.Button buttonSave;
		private System.Windows.Forms.TreeView treeView;
		protected System.Windows.Forms.Button buttonDelete;
		protected System.Windows.Forms.Button buttonCancel;
		protected System.Windows.Forms.Panel panelSave;
		protected System.Windows.Forms.Panel panelDelete;
		protected System.Windows.Forms.Panel panelCancel;
		protected System.Windows.Forms.Label labelName;
		private System.Windows.Forms.Label labelMessage;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public FilterEditor()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitForm call
			this.Filter.FilterType = typeof(TestCase);	
			
		}

		FilterExpression m_filter;
		public FilterExpression Filter
		{
			get
			{
				if(m_filter == null)
				{
					m_filter = new FilterExpression();
				}
				return m_filter;
			}
			set
			{
				m_filter = value;
			}
		}
		public Type FilterType
		{
			get
			{
				return this.Filter.FilterType;
			}
			set
			{
				this.Filter.FilterType = value;
			}
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			//System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FilterEditor));
			this.treeView = new System.Windows.Forms.TreeView();
			this.panelSave = new System.Windows.Forms.Panel();
			this.buttonSave = new System.Windows.Forms.Button();
			this.panelDelete = new System.Windows.Forms.Panel();
			this.buttonDelete = new System.Windows.Forms.Button();
			this.panelCancel = new System.Windows.Forms.Panel();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.panelName = new System.Windows.Forms.Panel();
			this.textBoxName = new System.Windows.Forms.TextBox();
			this.labelName = new System.Windows.Forms.Label();
			this.labelMessage = new System.Windows.Forms.Label();
			this.editor = new Expedia.Test.Framework.GenericExpressionEditorControl();
			this.panelTop1.SuspendLayout();
			this.panelBottom1.SuspendLayout();
			this.panelCenter.SuspendLayout();
			this.panelLeft.SuspendLayout();
			this.panelRight.SuspendLayout();
			this.panelUpper.SuspendLayout();
			this.panelMiddle.SuspendLayout();
			this.panelSave.SuspendLayout();
			this.panelDelete.SuspendLayout();
			this.panelCancel.SuspendLayout();
			this.panelName.SuspendLayout();
			this.SuspendLayout();
			// 
			// panelTop1
			// 
			this.panelTop1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.labelMessage});
			this.panelTop1.Visible = false;
			// 
			// panelBottom1
			// 
			this.panelBottom1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					   this.panelSave,
																					   this.panelDelete,
																					   this.panelCancel});
			// 
			// panelCenter
			// 
			this.panelCenter.Location = new System.Drawing.Point(0, 0);
			this.panelCenter.Size = new System.Drawing.Size(552, 328);
			// 
			// panelLeft
			// 
			this.panelLeft.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.treeView});
			this.panelLeft.Size = new System.Drawing.Size(144, 328);
			// 
			// panelRight
			// 
			this.panelRight.Size = new System.Drawing.Size(400, 328);
			// 
			// panelUpper
			// 
			this.panelUpper.Controls.AddRange(new System.Windows.Forms.Control[] {
																					 this.panelName});
			// 
			// panelLower
			// 
			this.panelLower.Location = new System.Drawing.Point(0, 288);
			this.panelLower.Visible = false;
			// 
			// panelMiddle
			// 
			this.panelMiddle.Controls.AddRange(new System.Windows.Forms.Control[] {
																					  this.editor});
			this.panelMiddle.Size = new System.Drawing.Size(400, 248);
			// 
			// treeView
			// 
			this.treeView.Dock = System.Windows.Forms.DockStyle.Fill;
			this.treeView.ImageIndex = -1;
			this.treeView.Name = "treeView";
			this.treeView.SelectedImageIndex = -1;
			this.treeView.Size = new System.Drawing.Size(144, 304);
			this.treeView.TabIndex = 0;
			this.treeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView_AfterSelect);
			// 
			// panelSave
			// 
			this.panelSave.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.buttonSave});
			this.panelSave.Dock = System.Windows.Forms.DockStyle.Right;
			this.panelSave.Location = new System.Drawing.Point(360, 0);
			this.panelSave.Name = "panelSave";
			this.panelSave.Size = new System.Drawing.Size(64, 40);
			this.panelSave.TabIndex = 11;
			// 
			// buttonSave
			// 
			this.buttonSave.Location = new System.Drawing.Point(0, 8);
			this.buttonSave.Name = "buttonSave";
			this.buttonSave.Size = new System.Drawing.Size(61, 20);
			this.buttonSave.TabIndex = 0;
			this.buttonSave.Text = "&Save";
			this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
			// 
			// panelDelete
			// 
			this.panelDelete.Controls.AddRange(new System.Windows.Forms.Control[] {
																					  this.buttonDelete});
			this.panelDelete.Dock = System.Windows.Forms.DockStyle.Right;
			this.panelDelete.Location = new System.Drawing.Point(424, 0);
			this.panelDelete.Name = "panelDelete";
			this.panelDelete.Size = new System.Drawing.Size(64, 40);
			this.panelDelete.TabIndex = 10;
			// 
			// buttonDelete
			// 
			this.buttonDelete.Location = new System.Drawing.Point(0, 8);
			this.buttonDelete.Name = "buttonDelete";
			this.buttonDelete.Size = new System.Drawing.Size(61, 20);
			this.buttonDelete.TabIndex = 0;
			this.buttonDelete.Text = "&Delete";
			this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
			// 
			// panelCancel
			// 
			this.panelCancel.Controls.AddRange(new System.Windows.Forms.Control[] {
																					  this.buttonCancel});
			this.panelCancel.Dock = System.Windows.Forms.DockStyle.Right;
			this.panelCancel.Location = new System.Drawing.Point(488, 0);
			this.panelCancel.Name = "panelCancel";
			this.panelCancel.Size = new System.Drawing.Size(64, 40);
			this.panelCancel.TabIndex = 9;
			// 
			// buttonCancel
			// 
			this.buttonCancel.Location = new System.Drawing.Point(0, 8);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Size = new System.Drawing.Size(61, 20);
			this.buttonCancel.TabIndex = 0;
			this.buttonCancel.Text = "&Cancel";
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// panelName
			// 
			this.panelName.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.textBoxName,
																					this.labelName});
			this.panelName.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panelName.Name = "panelName";
			this.panelName.Size = new System.Drawing.Size(400, 40);
			this.panelName.TabIndex = 10;
			// 
			// textBoxName
			// 
			this.textBoxName.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.textBoxName.Location = new System.Drawing.Point(48, 8);
			this.textBoxName.Name = "textBoxName";
			this.textBoxName.Size = new System.Drawing.Size(340, 20);
			this.textBoxName.TabIndex = 1;
			this.textBoxName.Text = "";
			// 
			// labelName
			// 
			this.labelName.Location = new System.Drawing.Point(8, 8);
			this.labelName.Name = "labelName";
			this.labelName.Size = new System.Drawing.Size(100, 20);
			this.labelName.TabIndex = 0;
			this.labelName.Text = "Name";
			this.labelName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// labelMessage
			// 
			this.labelMessage.Location = new System.Drawing.Point(24, 8);
			this.labelMessage.Name = "labelMessage";
			this.labelMessage.TabIndex = 0;
			this.labelMessage.Text = "label2";
			// 
			// editor
			// 
			this.editor.Dock = System.Windows.Forms.DockStyle.Fill;
			//this.editor.Expression = ((Expedia.Test.Framework.FieldExpression)(resources.GetObject("editor.Expression")));
			this.editor.Name = "editor";
			this.editor.Size = new System.Drawing.Size(400, 248);
			this.editor.TabIndex = 0;
			this.editor.ValueList += new Expedia.Test.Framework.GetFieldValuesHandler(this.editor_ValueList);
			this.editor.GetFieldInfo += new Expedia.Test.Framework.GetFieldInfoHandler(this.editor_GetFieldInfo);
			this.editor.FilterExpressionChanged += new System.EventHandler(this.editor_FilterExpressionChanged);
			this.editor.FieldList += new Expedia.Test.Framework.GetValuesHandler(this.editor_FieldList);
			// 
			// FilterEditor
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.panelCenter,
																		  this.panelBottom1,
																		  this.panelTop1});
			this.Name = "FilterEditor";
			this.Load += new System.EventHandler(this.FilterEditor_Load);
			this.panelTop1.ResumeLayout(false);
			this.panelBottom1.ResumeLayout(false);
			this.panelCenter.ResumeLayout(false);
			this.panelLeft.ResumeLayout(false);
			this.panelRight.ResumeLayout(false);
			this.panelUpper.ResumeLayout(false);
			this.panelMiddle.ResumeLayout(false);
			this.panelSave.ResumeLayout(false);
			this.panelDelete.ResumeLayout(false);
			this.panelCancel.ResumeLayout(false);
			this.panelName.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private System.Collections.ArrayList editor_FieldList(int rowNum)
		{
			ArrayList list = new ArrayList();

			list.AddRange(this.Filter.Fields);

			return list;
		}

		private void editor_FilterExpressionChanged(object sender, System.EventArgs e)
		{
		
		}

		private Expedia.Test.Framework.ConfigFieldInfo editor_GetFieldInfo(string fieldName)
		{
			ConfigFieldInfo fi = this.Filter.FindField(fieldName);
			return fi;
		}


		private System.Collections.ArrayList editor_ValueList(string fieldName)
		{
			ArrayList list = new ArrayList();
			list.AddRange(this.Filter.GetSupportedValues(fieldName));
			return list;	
		}

		

		private void FilterEditor_Load(object sender, System.EventArgs e)
		{
			LoadUIState();
			string[] filterNames = GetFilterListRequest();
			if(filterNames != null)
			{
				//Load the Tree View				
				LoadTree(filterNames);
			}			
		}

		private void treeView_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			//Get the Filter Request Object
			if(e.Node.Nodes.Count ==0)
			{
				FilterRequest filterRequest = new FilterRequest(RepositoryRequestType.Get);
				filterRequest.FilterType = typeof(TestCase);
				filterRequest.InstanceName = e.Node.Text;
				this.GetData(filterRequest);

				if(filterRequest.Filter != null)
				{
					DataSet ds = filterRequest.Filter.GetDataSet();

					if((ds != null)&&(ds.Tables.Count >0))
					{
						this.textBoxName.Text = e.Node.Text;
						this.editor.Expression.ExpressionDataTable = ds.Tables[0];
						this.editor.DataSource = this.editor.Expression.ExpressionDataTable;
					}
				}
			}
		}

		private void buttonSave_Click(object sender, System.EventArgs e)
		{
			if (this.textBoxName.Text.Trim() == "") {
				InfoNotification error = new InfoNotification();
				error.MessageType = SeverityType.Error;
				error.Message = "Please enter a name for the filter";
				this.NotifyUI(error);
			}
			else
			{
				FieldExpression fieldExpression = new FieldExpression();
				FilterRequest filterRequest = null;

				if(editor.Expression != null)
				{
					fieldExpression = editor.Expression;
				}

				//Filter Update or Filter Create
				string[] filterNames = GetFilterListRequest();

				if(filterNames != null && ContainsFilter(filterNames, this.textBoxName.Text))
				{
					filterRequest = new FilterRequest(RepositoryRequestType.Update);
				}
				else
				{
					filterRequest = new FilterRequest(RepositoryRequestType.Create);
				}				
			

				//Save the filter to the local file			
				filterRequest.Filter = new FieldExpressionData( this.textBoxName.Text.ToString(),this.FilterType.ToString(),editor.Expression.ExpressionDataTable);
				filterRequest.FilterType = this.Filter.FilterType;
				filterRequest.InstanceName = this.textBoxName.Text.ToString();
		
				this.GetData(filterRequest);


				this.NotifyUI(new FilterChangeNotification());

				//Load the Tree again
				LoadTree(GetFilterListRequest());
				this.treeView.ExpandAll();

				Cleanup();
			}
		}

		private void buttonDelete_Click(object sender, System.EventArgs e)
		{
			//Need to delete the selected config name
			if(this.textBoxName.Text == "")
			{
				if(this.panelTop1.Visible == false)
				{
					this.panelTop1.Visible = true;
					labelMessage.Text = "Hello";
					this.labelMessage.Text = "Please select the config to be deleted";
					return;
				}
			}

			FilterRequest filterRequest  = new FilterRequest(RepositoryRequestType.Delete);
			filterRequest.InstanceName = this.textBoxName.Text.ToString();
			this.GetData(filterRequest);

			this.NotifyUI(new FilterChangeNotification());

			//Load the Tree again
			LoadTree(GetFilterListRequest());
			this.treeView.ExpandAll();

			Cleanup();
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{

			//Load the Tree again
			LoadTree(GetFilterListRequest());
			this.treeView.ExpandAll();

			Cleanup();
		}

		private void Cleanup()
		{
			this.textBoxName.Text = "";
			this.editor.Cleanup();
		}

		private void LoadTree(string[] Nodes)
		{
			this.treeView.Nodes.Clear();
			if((Nodes != null) && (Nodes.Length >0))
			{
				TreeNode rootNode = new TreeNode("Filters");
				this.treeView.Nodes.Add(rootNode);

				foreach(string nodes in Nodes)
				{
					TreeNode node = new TreeNode(nodes);
					rootNode.Nodes.Add(node);
				}
				
				this.treeView.ExpandAll();
			}
			
		}

		private string[] GetFilterListRequest()
		{
			FilterListRequest filterListRequest = new FilterListRequest();
			this.GetData(filterListRequest);

			if((filterListRequest.Objects != null)&&(filterListRequest.Objects.Length >0))
			{
				return filterListRequest.Objects;
			}
			else
			{
				return null;
			}
		}

		private bool ContainsFilter(string[] filterNames, string filterName)
		{
			if((filterNames != null) && (filterName != null))
			{
				for(int index =0 ; index < filterNames.Length ; index++)
				{
					if(filterName.CompareTo(filterNames[index]) == 0)
					{
						return true;
					}
				}
			}

			return false;
		}

		
		public override void PersistUIState()
		{
			Profile profile = base.GetProfile();

			if(profile == null)
			{
				profile = new Profile();
			}

			profile.FilterSettings.splitterLeft = new SplitterState(this.splitterLeft.ControlToHide.Size, this.splitterLeft.IsCollapsed); 							
			base.UpdateProfile(profile);

		}

		private void LoadUIState()
		{
			Profile profile = base.GetProfile();
			
			if(profile != null && profile.FilterSettings != null)
			{
				base.LoadUIState(profile.FilterSettings.splitterLeft);				
			}					
		}

		

	

		

		

		

		
		

		
			
	}
}
