using System;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for TestModuleFilter.
    /// </summary>
    /// 
    [SupportedType(typeof(TestCase))]
    public class TestModuleFilter : StringFilter
    {
        public TestModuleFilter()
            : base()
        {
        }

        public TestModuleFilter(FilterOperator selectedOperator, string selectedValue)
            : base(selectedOperator, selectedValue)
        {
        }

        public override bool Filter(object obj)
        {
            TestCase testCase = obj as TestCase;
            if (testCase == null)
            {
                return false;
            }
            else
            {
                return base.Filter(testCase.Module.Name);
            }
        }

        public override string ToString()
        {
            return "Test Module";
        }
    }
}
