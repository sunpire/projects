using System;

namespace Expedia.Test.Framework 
{
	/// <summary>
	/// Summary description for TestOwnerFilter.
	/// </summary>
	/// 

	[SupportedType(typeof(TestCase))]
	public class TestOwnerFilter: StringFilter
	{
		public TestOwnerFilter(): base()
		{
			
		}

		public TestOwnerFilter(FilterOperator selectedOperator, string selectedValue): base(selectedOperator, selectedValue)
		{
			
		}

		public override bool Filter(object obj)
		{
			TestCase testCase = obj as TestCase;
			if(testCase == null)
			{
				return false;
			}
			else
			{
				return base.Filter(testCase.Owner);
			}
		}

		
		
		public override string ToString()
		{
			return "Test Owner";
		}
	}
}
