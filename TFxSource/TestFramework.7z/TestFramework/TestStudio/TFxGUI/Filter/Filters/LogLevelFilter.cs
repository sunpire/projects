//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: CategoryFilter.cs 
// 
// Desc: 
// 
// Note: 
// 
// History: 
// 
//========================================================================== 
using System;
using System.Collections;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for FilterExpression.
	/// </summary>
	[SupportedType(typeof(LogEntry))]
	public class LogLevelFilter : IFilter
	{
		private FilterOperator m_operator;
		private LogLevelType m_value;

		public LogLevelFilter()
		{
			this.Operator = FilterOperator.Equals;
			this.Value = (LogLevelType)this.SupportedValues[0];
		}

		public LogLevelFilter(FilterOperator selectedOperator, TestCategoryType selectedValue)
		{
			this.Operator = selectedOperator;
			this.Value = selectedValue;
		}

		public bool Filter(object obj)
		{
			LogEntry entry = obj as LogEntry;

			if(entry == null)
			{
				return false;
			}
			else
			{
				switch(this.m_operator)
				{
					case FilterOperator.Equals:
						return ((entry.Level & this.m_value) == this.m_value);
					default:
						return false;
				}
			}
		}

		public bool IsRestrictedToValueList
		{
			get
			{
				return true;
			}
		}

		public IFilter[] Fields
		{
			get
			{
				return new IFilter[]{this};
			}
		}

		public FilterOperator[] SupportedOperators
		{
			get
			{
				return new FilterOperator[]{FilterOperator.Equals};
			}
		}

		public object[] SupportedValues
		{
			get
			{
				ArrayList values = new ArrayList();

				foreach(long category in Enum.GetValues(typeof(LogLevelType)))
				{
					values.Add((LogLevelType)category);
				}

				return (object[])values.ToArray(typeof(object));
			}
		}

		public FilterExpressionElementType[] SupportedFilterExpressionElementType
		{
			get
			{
				return new FilterExpressionElementType[]{FilterExpressionElementType.And, FilterExpressionElementType.Or};
			}
		}

		public FilterOperator Operator
		{
			get
			{
				return this.m_operator;
			}
			set
			{
				ArrayList supportedOperators = new ArrayList(this.SupportedOperators);
				if(supportedOperators.Contains(value))
				{
					this.m_operator = value;
				}
				else
				{
					throw new Exception(String.Format("{0} is not a supported operator!", value));
				}
			}
		}

		public object Value
		{
			get
			{
				return this.m_value;
			}
			set
			{
				if(value is LogLevelType || value is long)
				{
					this.m_value = (LogLevelType)value;
				}
				else
				{
					throw new Exception("Invalid value type: Value must be a LogLevelType or long.");
				}
			}
		}

		public string Name
		{
			get
			{
				return this.ToString();
			}
			set
			{
				throw new Exception("Cannot change LogLevelFilter name!");
			}
		}
		
		public override string ToString()
		{
			return "Level";
		}
	}
}
