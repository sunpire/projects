//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: FunctionFilter.cs 
// 
// Desc: 
// 
// Note: 
// 
// History: 
// 
//========================================================================== 
using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TestModuleFilter.
	/// </summary>
	/// 
	[SupportedType(typeof(LogEntry))]
	public class FunctionFilter : StringFilter
	{
		public FunctionFilter(): base()
		{
			this.Operator = FilterOperator.Equals;
		}

		public FunctionFilter(FilterOperator selectedOperator, string selectedValue): base(selectedOperator, selectedValue)
		{
			
		}

		public override bool Filter(object obj)
		{
			LogEntry entry = obj as LogEntry;

			if(entry == null)
			{
				return false;
			}
			else
			{
				return base.Filter(entry.Function);
			}			
		}

		
		
		public override string ToString()
		{
			return "Function";
		}
	}
}
