//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: CategoryFilter.cs 
// 
// Desc: 
// 
// Note: 
// 
// History: 
// 
//========================================================================== 
using System;
using System.Collections;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for FilterExpression.
	/// </summary>
	[SupportedType(typeof(TestCase))]
	public class CategoryFilter : IFilter
	{
		private FilterOperator m_operator;
		private TestCategoryType m_value;

		public CategoryFilter()
		{
			this.Operator = this.SupportedOperators[0];
			this.Value = (TestCategoryType)this.SupportedValues[0];
		}

		public CategoryFilter(FilterOperator selectedOperator, TestCategoryType selectedValue)
		{
			this.Operator = selectedOperator;
			this.Value = selectedValue;
		}

		public bool Filter(object obj)
		{
			TestCase testCase = obj as TestCase;
			if(testCase == null)
			{
				return false;
			}
			else
			{
				switch(this.m_operator)
				{
					case FilterOperator.Contains:
						return (testCase.TestCategory & (long)this.m_value) != 0;
					case FilterOperator.NotContains:
						return (testCase.TestCategory & (long)this.m_value) == 0;
					default:
						return false;
				}
			}
		}

		public bool IsRestrictedToValueList
		{
			get
			{
				return true;
			}
		}

		public IFilter[] Fields
		{
			get
			{
				return new IFilter[]{this};
			}
		}

		public FilterOperator[] SupportedOperators
		{
			get
			{
				return new FilterOperator[]{FilterOperator.Contains, FilterOperator.NotContains};
			}
		}

		public object[] SupportedValues
		{
			get
			{
				ArrayList values = new ArrayList();

				foreach(long category in Enum.GetValues(typeof(TestCategoryType)))
				{
					values.Add((TestCategoryType)category);
				}

				return (object[])values.ToArray(typeof(object));
			}
		}

		public FilterExpressionElementType[] SupportedFilterExpressionElementType
		{
			get
			{
				return new FilterExpressionElementType[]{FilterExpressionElementType.And, FilterExpressionElementType.Or};
			}
		}

		public FilterOperator Operator
		{
			get
			{
				return this.m_operator;
			}
			set
			{
				ArrayList supportedOperators = new ArrayList(this.SupportedOperators);
				if(supportedOperators.Contains(value))
				{
					this.m_operator = value;
				}
				else
				{
					throw new Exception(String.Format("{0} is not a supported operator!", value));
				}
			}
		}

		public object Value
		{
			get
			{
				return this.m_value;
			}
			set
			{
				if(value is TestCategoryType || value is long)
				{
					this.m_value = (TestCategoryType)value;
				}
				else
				{
					throw new Exception("Invalid value type: Value must be a TestCategoryType or long.");
				}
			}
		}

		public string Name
		{
			get
			{
				return this.ToString();
			}
			set
			{
				throw new Exception("Cannot change CategoryFilter name!");
			}
		}
		
		public override string ToString()
		{
			return "Category";
		}
	}
}
