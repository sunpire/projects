//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: TestNameFilter.cs 
// 
// Desc: 
// 
// Note: 
// 
// History: 
// 
//========================================================================== 
using System;
using System.Collections;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TestNameFilter.
	/// </summary>
	[SupportedType(typeof(TestCase))]
	public class TestNameFilter : StringFilter
	{
		public TestNameFilter() : base()
		{
			
		}

		public TestNameFilter(FilterOperator selectedOperator, string selectedValue): base(selectedOperator, selectedValue)
		{
			
		}

		public override bool Filter(object obj)
		{
			TestCase testCase = obj as TestCase;
			if(testCase == null)
			{
				return false;
			}
			else
			{
				return base.Filter(testCase.FullName);
			}
		}		
		
		public override string ToString()
		{
			return "Test Name";
			
		}

		
		
		
	}
}
