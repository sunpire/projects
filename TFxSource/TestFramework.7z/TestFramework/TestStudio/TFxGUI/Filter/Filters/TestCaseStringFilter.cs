using System;
using System.Collections;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for StringFilter.
    /// </summary>
    /// 

    public class StringFilter : IFilter
    {
        protected FilterOperator m_operator;
        protected string m_value = String.Empty;

        public StringFilter()
        {
            this.Operator = this.SupportedOperators[0];
        }

        public StringFilter(FilterOperator selectedOperator, string selectedValue)
        {
            this.Operator = selectedOperator;
            this.Value = selectedValue;
        }

        public virtual bool Filter(object obj)
        {
            if (obj != null && obj is string)
            {
                string str = (string)obj;
                switch (this.m_operator)
                {
                    case FilterOperator.Contains:
                        return str.IndexOf(this.m_value, StringComparison.InvariantCultureIgnoreCase) != -1;
                    case FilterOperator.NotContains:
                        return str.IndexOf(this.m_value, StringComparison.InvariantCultureIgnoreCase) == -1;
                    case FilterOperator.Equals:
                        return (string.Compare(str, this.m_value, true) == 0);
                    case FilterOperator.NotEqual:
                        return (string.Compare(str, this.m_value, true) != 0);
                    case FilterOperator.GreaterThan:
                        return (string.Compare(str, this.m_value, true) > 0);
                    case FilterOperator.GreaterThanEquals:
                        return (string.Compare(str, this.m_value, true) >= 0);
                    case FilterOperator.LessThan:
                        return (string.Compare(str, this.m_value, true) < 0);
                    case FilterOperator.LessThanEquals:
                        return (string.Compare(str, this.m_value, true) <= 0);

                    default:
                        return false;
                }
            }
            return false;
        }

        public virtual bool IsRestrictedToValueList
        {
            get
            {
                return false;
            }
        }

        public virtual IFilter[] Fields
        {
            get
            {
                return new IFilter[] { this };
            }
        }

        public virtual FilterOperator[] SupportedOperators
        {
            get
            {
                return new FilterOperator[]{
											   FilterOperator.Contains,
											   FilterOperator.NotContains,
											   FilterOperator.Equals,
											   FilterOperator.NotEqual,
											   FilterOperator.GreaterThan,
											   FilterOperator.GreaterThanEquals,
											   FilterOperator.LessThan,
                                               FilterOperator.LessThanEquals};
            }
        }

        public virtual object[] SupportedValues
        {
            get
            {
                return new object[] { String.Empty };
            }
        }

        public virtual FilterExpressionElementType[] SupportedFilterExpressionElementType
        {
            get
            {
                return new FilterExpressionElementType[] { FilterExpressionElementType.And, FilterExpressionElementType.Or };
            }
        }

        public virtual FilterOperator Operator
        {
            get
            {
                return this.m_operator;
            }
            set
            {
                ArrayList supportedOperators = new ArrayList(this.SupportedOperators);
                if (supportedOperators.Contains(value))
                {
                    this.m_operator = value;
                }
                else
                {
                    throw new Exception(String.Format("{0} is not a supported operator!", value));
                }
            }
        }

        public virtual object Value
        {
            get
            {
                return this.m_value;
            }
            set
            {
                if (value is string)
                {
                    this.m_value = (string)value;
                }
                else
                {
                    throw new Exception("Invalid value type: Value must be a string.");
                }
            }
        }

        public virtual string Name
        {
            get
            {
                return this.ToString();
            }
            set
            {
                throw new Exception("Cannot change TestNameFilter name!");
            }
        }

        //		public virtual string ToString()
        //		{
        //			return "String Filter";
        //			
        //		}
    }
}
