using System;
using System.Reflection;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Resources;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for ErrorDisplayControl.
    /// </summary>
    public class ErrorDisplayControl : RepositoryDelegateUI
    {
        private System.Windows.Forms.Panel panelLeft;
        private System.Windows.Forms.ImageList ErrorImageList;
        private System.Windows.Forms.PictureBox pictureBoxErrorType;
        private System.Windows.Forms.Panel panelRight;
        private System.Windows.Forms.Panel panelMiddle;
        private System.Windows.Forms.Label labelMessage;
        private System.Windows.Forms.Button buttonOK;
        private System.ComponentModel.IContainer components;

        public ErrorDisplayControl()
        {
            // This call is required by the Windows.Forms Form Designer.
            InitializeComponent();
        }

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        private SeverityType m_errorType;

        public void ClearError()
        {
            this.pictureBoxErrorType.Image = null;
            this.labelMessage.Text = null;
        }

        public void SetError(SeverityType type, string message)
        {
            m_errorType = type;

            if (ErrorImageList.Images.Count < 3)
            {
                ResourceManager resources = new ResourceManager(typeof(ErrorDisplayControl));
           	    this.ErrorImageList.ImageStream = ((ImageListStreamer)(resources.GetObject("ErrorImageList.ImageStream")));
            }
            
            switch (m_errorType)
            {
                case SeverityType.Error:
                    this.pictureBoxErrorType.Image = ErrorImageList.Images[0];
                    break;
                case SeverityType.Warning:
                    this.pictureBoxErrorType.Image = ErrorImageList.Images[1];
                    break;
                case SeverityType.Info:
                    this.pictureBoxErrorType.Image = ErrorImageList.Images[2];
                    break;
            }

            labelMessage.Text = message;
            int i = this.panelMiddle.Height - this.pictureBoxErrorType.Image.Height;
            this.panelLeft.Width = this.pictureBoxErrorType.Image.Width + 10;

            Point p = this.pictureBoxErrorType.Location;
            p.X = 5;

            if (i > 0)
            {
                p.Y = i / 2;
            }
            else
            {
                p.Y = 0;
            }
            this.pictureBoxErrorType.Location = p;
            this.Visible = true;
        }

        #region Component Designer generated code
        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ErrorDisplayControl));
            this.panelLeft = new System.Windows.Forms.Panel();
            this.pictureBoxErrorType = new System.Windows.Forms.PictureBox();
            this.ErrorImageList = new System.Windows.Forms.ImageList(this.components);
            this.buttonOK = new System.Windows.Forms.Button();
            this.panelRight = new System.Windows.Forms.Panel();
            this.panelMiddle = new System.Windows.Forms.Panel();
            this.labelMessage = new System.Windows.Forms.Label();
            this.panelLeft.SuspendLayout();
            this.panelRight.SuspendLayout();
            this.panelMiddle.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelLeft
            // 
            this.panelLeft.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.pictureBoxErrorType});
            this.panelLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelLeft.Name = "panelLeft";
            this.panelLeft.Size = new System.Drawing.Size(16, 64);
            this.panelLeft.TabIndex = 0;
            // 
            // pictureBoxErrorType
            // 
            this.pictureBoxErrorType.Name = "pictureBoxErrorType";
            this.pictureBoxErrorType.Size = new System.Drawing.Size(64, 64);
            this.pictureBoxErrorType.TabIndex = 0;
            this.pictureBoxErrorType.TabStop = false;
            // 
            // ErrorImageList
            // 
            this.ErrorImageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.ErrorImageList.ImageSize = new System.Drawing.Size(12, 12);
            this.ErrorImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ErrorImageList.ImageStream")));
            this.ErrorImageList.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // buttonOK
            // 
            this.buttonOK.BackColor = System.Drawing.SystemColors.Control;
            this.buttonOK.Name = "buttonOK";
            this.buttonOK.Size = new System.Drawing.Size(29, 25);
            this.buttonOK.TabIndex = 0;
            this.buttonOK.Text = "&OK";
            this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
            // 
            // panelRight
            // 
            this.panelRight.Controls.AddRange(new System.Windows.Forms.Control[] {
																					 this.buttonOK});
            this.panelRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelRight.Location = new System.Drawing.Point(512, 0);
            this.panelRight.Name = "panelRight";
            this.panelRight.Size = new System.Drawing.Size(48, 64);
            this.panelRight.TabIndex = 1;
            // 
            // panelMiddle
            // 
            this.panelMiddle.Controls.AddRange(new System.Windows.Forms.Control[] {
																					  this.labelMessage});
            this.panelMiddle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMiddle.Location = new System.Drawing.Point(16, 0);
            this.panelMiddle.Name = "panelMiddle";
            this.panelMiddle.Size = new System.Drawing.Size(496, 64);
            this.panelMiddle.TabIndex = 0;
            // 
            // labelMessage
            // 
            this.labelMessage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelMessage.Name = "labelMessage";
            this.labelMessage.Size = new System.Drawing.Size(496, 64);
            this.labelMessage.TabIndex = 11;
            this.labelMessage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ErrorDisplayControl
            // 
            this.BackColor = System.Drawing.SystemColors.Info;
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.panelMiddle,
																		  this.panelRight,
																		  this.panelLeft});
            this.Name = "ErrorDisplayControl";
            this.Size = new System.Drawing.Size(560, 64);
            this.Load += new System.EventHandler(this.ErrorDisplayControl_Load);
            this.panelLeft.ResumeLayout(false);
            this.panelRight.ResumeLayout(false);
            this.panelMiddle.ResumeLayout(false);
            this.ResumeLayout(false);

        }
        #endregion

        private void HandleInfoNotification(NotificationRequest request)
        {
            InfoNotification info = request as InfoNotification;

            if (info != null && info.Message != null)
            {
                SetError(info.MessageType, info.Message);
            }

        }

        private void ErrorDisplayControl_Load(object sender, System.EventArgs e)
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            this.AddNotificationHandler(typeof(InfoNotification), new NotificationRequestHandler(this.HandleInfoNotification));
        }

        private void buttonOK_Click(object sender, System.EventArgs e)
        {
            ClearError();

            InfoActionNotification action = new InfoActionNotification();
            action.MessageType = m_errorType;
            action.Message = labelMessage.Text;

            this.NotifyUI(action);
        }
    }
}
