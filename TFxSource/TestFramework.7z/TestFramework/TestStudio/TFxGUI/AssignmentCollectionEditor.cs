using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using Expedia.Test.Framework.Log;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for AssignmentCollectionEditor.
    /// </summary>
    /// 

    public class AssignmentCollectionEditor : Expedia.Test.Framework.RepositoryDelegateUI
    {
        private AssignmentCollection m_assignments;
        public bool dirtyBit = false;
        public bool reloadResults = false;

        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;
        private Expedia.Test.Framework.SelectionControl selectionControl1;
        private System.Windows.Forms.Panel panelPicker;
        private System.Windows.Forms.Panel panelAddVariable;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelAssignment;
        private System.Windows.Forms.Panel panelFilterEditor;
        private System.Windows.Forms.Panel panelAssignmentEditorLower;
        private NJFLib.Controls.CollapsibleSplitter splitterAssignmentEditorBottom;
        private System.Windows.Forms.Panel panelAssignmentEditorRight;
        private NJFLib.Controls.CollapsibleSplitter splitterAssignmentEditorRight;

        private List<string> m_columnNames;
        private Expedia.Test.Framework.AssignmentResultControl assignmentShortResult;
        private System.Windows.Forms.DataGrid dataGridAssignments;

        //		public event EventHandler OnSelectAssignmentGrid;

        public event EventHandler OnExportAssignments;

        [
        Category("Appearance"),
        Description("DataSource of Type AssignmentCollection"),
        Browsable(false)
        ]
        public AssignmentCollection Assignments
        {
            get
            {
                return m_assignments;
            }
            set
            {
                m_assignments = value;
                BindDataGrid();
            }
        }

        public AssignmentCollection SelectedAssignments
        {
            get
            {
                return GetSelected();
            }
        }

        [
        Category("Appearance"),
        Description("Show Filter Editor"),
        ]
        public bool ShowFilterEditor
        {
            get
            {
                return this.panelFilterEditor.Visible;
            }
            set
            {
                this.panelFilterEditor.Visible = value;
            }
        }

        [
        Category("Appearance"),
        Description("Show Result pan"),
        ]
        public bool ShortResultRightVisible
        {
            get
            {
                return this.panelAssignmentEditorRight.Visible;
            }
            set
            {
                this.panelAssignmentEditorRight.Visible = value;
                this.splitterAssignmentEditorRight.Visible = value;
            }
        }

        [
        Category("Appearance"),
        Description("Show Result pan"),
        ]
        public bool ShortResultBottomVisible
        {
            get
            {
                return this.panelAssignmentEditorLower.Visible;
            }
            set
            {
                this.panelAssignmentEditorLower.Visible = value;
                this.splitterAssignmentEditorBottom.Visible = value;
            }
        }

        public AssignmentCollectionEditor()
        {
            // This call is required by the Windows.Forms Form Designer.
            InitializeComponent();

            // TODO: Add any initialization after the InitForm call	
            m_columnNames = new List<string>();
        }

        public void ClearResult()
        {
            BindDataGrid();
        }

        public void BindDataGrid()
        {
            UserSettingRequest request = new UserSettingRequest(RepositoryRequestType.Get);
            GetData(request);
            TestStudioUsersSetting settings = request.Settings as TestStudioUsersSetting;
            GetUniqueColumns();
            GenerateDataTable(settings);
        }

        /// <summary>
        /// Find out the unique columns in the AssignmentCollection List
        /// </summary>
        private void GetUniqueColumns()
        {
            this.m_columnNames.Clear();

            if (this.m_assignments != null)
            {
                foreach (Assignment assign in this.m_assignments)
                {
                    //Get only the first config of the assignment, for display purposes
                    if (assign.ConfigData.ConfigTable != null)
                    {
                        foreach (DataColumn col in assign.ConfigData.ConfigTable.Columns)
                        {
                            if (null == m_columnNames.Find(
                                delegate(string str)
                                {
                                    return String.Equals(str, col.ColumnName, StringComparison.CurrentCultureIgnoreCase);
                                }
                                ))
                            {
                                m_columnNames.Insert(0, col.ColumnName);
                            }
                        }
                    }
                }
            }
        }

        private AssignmentCollection GetSelected()
        {
            Assignment assignment = null;

            AssignmentCollection col = new AssignmentCollection();

            if (dataGridAssignments.DataSource != null)
            {
                CurrencyManager manager = (CurrencyManager)this.BindingContext[dataGridAssignments.DataSource, dataGridAssignments.DataMember];
                DataView dv = (DataView)manager.List;

                for (int i = 0; i < dv.Count; ++i)
                {

                    if (dataGridAssignments.IsSelected(i))
                    {
                        DataRow row = dv[i].Row;
                        if (row != null)
                        {
                            assignment = this.FindAssignment(Convert.ToInt32(row.ItemArray[0]));
                            if (assignment != null)
                            {
                                col.Add(assignment);
                            }
                        }
                    }
                }
            }

            return col;
        }


        public void DeleteSelected()
        {
            AssignmentCollection col = GetSelected();

            if (col != null && col.Count > 0)
            {
                dirtyBit = true;
                foreach (Assignment assignment in col)
                {
                    if (Assignments.Contains(assignment))
                    {
                        Assignments.Remove(assignment);
                    }
                }

                BindDataGrid();
            }
        }

        public void ApplyConfigChange()
        {
            DataTable dt = this.dataGridAssignments.DataSource as DataTable;

            if (dt != null)
            {
                dt.AcceptChanges();

                string columnName = string.Empty;
                bool isContainColumn = false;
                bool isValidValue = false;

                foreach (DataRow row in dt.Rows)
                {
                    int id = int.Parse(row["Id"].ToString());

                    Assignment assignment = FindAssignment(id);

                    if (assignment != null && assignment.ConfigData != null)
                    {
                        #region check column & copy value
                        DataRow configRow = assignment.ConfigData.ConfigTable.Rows[0];
                        if (configRow != null)
                        {
                            foreach (DataColumn col in dt.Columns)
                            {
                                columnName = col.ColumnName;
                                if (m_columnNames!= null && !m_columnNames.Contains(columnName))
                                {
                                    continue;
                                }

                                isValidValue = row[columnName] != DBNull.Value && row[columnName] != null;
                                isContainColumn = assignment.ConfigData.ConfigTable.Columns.Contains(columnName);

                                // 1. check to add column to assignment's DataTable or not
                                // Columns don't contain the column & the value isn't null and empty value
                                if (!isContainColumn && isValidValue && !row[columnName].ToString().Trim().Equals(string.Empty))
                                {
                                    assignment.ConfigData.ConfigTable.Columns.Add(columnName, typeof(System.String), string.Empty);
                                    isContainColumn = true;
                                }

                                // 2. copy value from DataGrid
                                if (isContainColumn &&
                                    isValidValue &&
                                    (
                                        configRow[columnName] == DBNull.Value ||
                                        configRow[columnName] == null ||
                                        configRow[columnName].ToString() != row[columnName].ToString()
                                    )
                                )
                                {
                                    dirtyBit = true;
                                    assignment.Changed = true;
                                    configRow[columnName] = row[columnName].ToString();
                                }
                            }
                        }
                        #endregion
                    }
                }
            }
        }

        Assignment FindAssignment(int id)
        {

            foreach (Assignment assignment in Assignments)
            {
                if (id == assignment.AssignmentId)
                {
                    return assignment;
                }
            }

            return null;
        }

        private void UpdateDeletedAssignment(object sender, DataRowChangeEventArgs args)
        {
            if (args.Action == DataRowAction.Delete)
            {
                int id = int.Parse(args.Row["Id"].ToString());

                Assignment deletingAssignment = FindAssignment(id);

                if (deletingAssignment != null)
                {
                    dirtyBit = true;
                    this.Assignments.Remove(deletingAssignment);
                }
            }
        }

        public void AppendAssignments(AssignmentCollection newAssignments)
        {
            if (newAssignments != null && newAssignments.Count > 0)
            {
                if (this.m_assignments != null)
                {
                    m_assignments.AddRange(newAssignments);
                }
                else
                {
                    m_assignments = newAssignments;
                }

                this.BindDataGrid();
            }
        }

        private int CalculateRowWidth(DataColumn dataColumn)
        {
            int iWidth = 0;
            DataTable dataTable = dataColumn.Table;

            using (Graphics g = CreateGraphics())
            {

                iWidth = (int)(g.MeasureString(dataColumn.ColumnName,
                    this.dataGridAssignments.Font).Width);

                DataRow dataRow;
                for (int iRow = 0; iRow < dataTable.Rows.Count; iRow++)
                {
                    dataRow = dataTable.Rows[iRow];

                    if (null != dataRow[dataColumn.ColumnName])
                    {
                        int iColWidth = (int)(g.MeasureString(dataRow[dataColumn].ToString(),
                            this.dataGridAssignments.Font).Width);
                        iWidth = (int)System.Math.Max(iWidth, iColWidth);
                    }
                }
            }

            return iWidth;
        }

        private DataGridTableStyle CreateDataTableStyle(DataTable dt, TestStudioUsersSetting settings)
        {
            DataGridTableStyle oldStyle = null;
            bool oldStyleExists = false;

            if (this.dataGridAssignments.TableStyles != null && this.dataGridAssignments.TableStyles.Count > 0)
            {
                oldStyle = this.dataGridAssignments.TableStyles[0];
            }

            if (oldStyle != null)
            {
                oldStyleExists = true;
            }

            if (dt != null)
            {
                DataGridTableStyle style = new DataGridTableStyle();
                style.MappingName = "TestCases";

                foreach (DataColumn col in dt.Columns)
                {
                    if (col.Caption != c_ResultCaption && col.Caption != c_DisabledCaption)
                    {
                        DataGridColoredTextBoxColumn styleColumn = new DataGridColoredTextBoxColumn();
                        styleColumn.MappingName = col.ColumnName;
                        styleColumn.HeaderText = col.ColumnName;

                        if (oldStyleExists && oldStyle.GridColumnStyles.Contains(col.ColumnName))
                        {
                            styleColumn.Width = oldStyle.GridColumnStyles[col.ColumnName].Width;
                        }
                        else
                        {
                            styleColumn.Width = CalculateRowWidth(col) + 10;
                        }

                        style.GridColumnStyles.Add(styleColumn);
                    }

                    else if (settings != null)
                    {
                        AssignmentStatusColumn statusColumn = null;

                        if (settings.StatusColumn1 + "1" == col.ColumnName)
                        {
                            statusColumn = new AssignmentStatusColumn(settings.StatusColumn1);

                            if (oldStyleExists && oldStyle.GridColumnStyles.Contains(col.ColumnName))
                            {
                                statusColumn.Width = oldStyle.GridColumnStyles[col.ColumnName].Width;
                            }
                            else
                            {
                                statusColumn.Width = CalculateRowWidth(dt.Columns[settings.StatusColumn1.ToString() + "1"]) + 10; ;
                            }

                            statusColumn.HeaderText = settings.StatusColumn1.ToString();
                            statusColumn.MappingName = settings.StatusColumn1.ToString() + "1";
                            style.GridColumnStyles.Add(statusColumn);
                        }

                        if (settings.StatusColumn2 + "2" == col.ColumnName)
                        {
                            statusColumn = new AssignmentStatusColumn(settings.StatusColumn2);
                            statusColumn.HeaderText = settings.StatusColumn2.ToString();
                            statusColumn.MappingName = settings.StatusColumn2.ToString() + "2";

                            if (oldStyleExists && oldStyle.GridColumnStyles.Contains(col.ColumnName))
                            {
                                statusColumn.Width = oldStyle.GridColumnStyles[col.ColumnName].Width;
                            }
                            else
                            {
                                statusColumn.Width = CalculateRowWidth(dt.Columns[settings.StatusColumn2.ToString() + "2"]) + 10;
                            }

                            style.GridColumnStyles.Add(statusColumn);
                        }
                    }
                }

                return style;
            }

            return null;
        }

        private readonly string c_ResultCaption = "Result";
        private readonly string c_DisabledCaption = "Disabled";

        private void GenerateDataTable(TestStudioUsersSetting settings)
        {
            DataTable dt = null;

            AppConfigRequest appRequest = new AppConfigRequest(RepositoryRequestType.Get);
            this.GetData(appRequest);

            if ((this.m_columnNames != null))
            {
                dt = new DataTable("TestCases");
                dt.RowDeleting += new DataRowChangeEventHandler(this.UpdateDeletedAssignment);

                DataColumn col0 = dt.Columns.Add("Id");
                col0.DataType = typeof(int);
                DataColumn col1 = dt.Columns.Add("SoftTest Name");
                DataColumn colMethodName = dt.Columns.Add("Method Name");

                //Do not show Status and FailureReason columns when executing in LabRun mode
                if (appRequest.AppConfig == null || appRequest.AppConfig.Mode != ApplicationMode.LabRun)
                {
                    DataColumn col2 = dt.Columns.Add("Status1");
                    col2.Caption = c_ResultCaption;
                    DataColumn col3 = dt.Columns.Add("FailureReason1");
                    col3.Caption = c_ResultCaption;
                    DataColumn col4 = dt.Columns.Add("Status2");
                    col4.Caption = c_ResultCaption;
                    DataColumn col5 = dt.Columns.Add("FailureReason2");
                    col5.Caption = c_ResultCaption;

                    col2.ReadOnly = true;
                    col3.ReadOnly = true;
                    col4.ReadOnly = true;
                    col5.ReadOnly = true;
                }

                DataColumn col6 = dt.Columns.Add("Disabled");
                col6.Caption = c_DisabledCaption;

                foreach (string keys in this.m_columnNames)
                {
                    if (!TFxConst.IsSystemVar(keys) || keys.Equals("__manager", StringComparison.InvariantCultureIgnoreCase))
                    {
                        if (!dt.Columns.Contains(keys))
                        {
                            DataColumn col = dt.Columns.Add(keys);
                            col.ReadOnly = false;
                        }
                    }
                }
                col0.ReadOnly = true;
                col1.ReadOnly = true;
            }

            if (this.m_assignments != null)
            {
                foreach (Assignment assign in m_assignments)
                {
                    DataRow row = dt.NewRow();

                    if (String.IsNullOrEmpty(assign.TestCase.SoftTestName))
                        row["SoftTest Name"] = assign.TestCase.FullName;
                    else
                        row["SoftTest Name"] = assign.TestCase.SoftTestName + ((assign.TestCase.SoftTestId > 0) ? " (" + Convert.ToString(assign.TestCase.SoftTestId) + ")" : "");

                    row["Method Name"] = assign.TestCase.FullName;
                    row["Id"] = assign.AssignmentId;
                    row["Disabled"] = assign.Disabled.ToString();

                    AssignmentResult result = null;

                    if (appRequest.AppConfig == null || appRequest.AppConfig.Mode != ApplicationMode.LabRun)
                    {
                        if (assign.Result != null)
                        {
                            result = assign.Result;
                            row["Status1"] = result.Status;
                            row["Status2"] = result.Status;
                        }
                        else
                        {
                            result = new AssignmentResult();
                            result.RunStatus = assign.RunStatus;
                            row["Status1"] = result.RunStatus;
                            row["Status2"] = result.RunStatus;
                        }

                        row["FailureReason1"] = result.FailureReason;
                        row["FailureReason2"] = result.FailureReason;
                    }

                    //Get only the first config of the assignment, for display purposes
                    StringConfig config = (StringConfig)assign.ConfigData.GetIConfig(0);
                    if (config != null)
                    {
                        foreach (object key in config.Config.Keys)
                        {
                            // The configuration name should be case insensitive
                            string keyValue = key.ToString();

                            if (!TFxConst.IsSystemVar(keyValue) || keyValue.Equals("__manager", StringComparison.InvariantCultureIgnoreCase))
                            {
                                string tableColumnName = this.m_columnNames.Find(
                                    delegate(string str)
                                    {
                                        return String.Equals(str, keyValue, StringComparison.CurrentCultureIgnoreCase);
                                    }
                                    );

                                if (tableColumnName == null)
                                    throw new ApplicationException("Cannot locate the column name for config key [" + keyValue + "]");

                                row[tableColumnName] = config.Config[keyValue];
                            }
                        }
                    }

                    dt.Rows.Add(row);
                }

                if (dt != null)
                {
                    dt.AcceptChanges();
                    dt.DefaultView.AllowEdit = true;
                    dt.DefaultView.AllowNew = false;
                    dt.DefaultView.AllowDelete = true;
                }

                this.dataGridAssignments.TableStyles.Clear();

                DataGridTableStyle style = this.CreateDataTableStyle(dt, settings);
                this.dataGridAssignments.DataSource = dt;

                if (style != null)
                {
                    this.dataGridAssignments.TableStyles.Add(style);
                }
            }
        }

        public void UpdateAssignmentDataColumn(int assignmentid, AssignmentStatusType type)
        {
            DataTable dt = this.dataGridAssignments.DataSource as DataTable;

            if (dt != null && dt.Rows.Count >= assignmentid)
            {
                DataRow row = dt.Rows[assignmentid];

                row["Status"] = type.ToString();
                this.dataGridAssignments.DataSource = dt;
            }
        }

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code
        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.selectionControl1 = new Expedia.Test.Framework.SelectionControl();
            this.panelPicker = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panelAddVariable = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panelAssignment = new System.Windows.Forms.Panel();
            this.dataGridAssignments = new System.Windows.Forms.DataGrid();
            this.splitterAssignmentEditorRight = new NJFLib.Controls.CollapsibleSplitter();
            this.panelAssignmentEditorRight = new System.Windows.Forms.Panel();
            this.splitterAssignmentEditorBottom = new NJFLib.Controls.CollapsibleSplitter();
            this.panelAssignmentEditorLower = new System.Windows.Forms.Panel();
            this.assignmentShortResult = new Expedia.Test.Framework.AssignmentResultControl();
            this.panelFilterEditor = new System.Windows.Forms.Panel();
            this.panelPicker.SuspendLayout();
            this.panelAddVariable.SuspendLayout();
            this.panelAssignment.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridAssignments)).BeginInit();
            this.panelAssignmentEditorLower.SuspendLayout();
            this.SuspendLayout();
            // 
            // selectionControl1
            // 
            this.selectionControl1.Editable = false;
            this.selectionControl1.Editor = null;
            this.selectionControl1.Location = new System.Drawing.Point(104, 8);
            this.selectionControl1.Name = "selectionControl1";
            this.selectionControl1.SelectedItem = null;
            this.selectionControl1.SelectionType = Expedia.Test.Framework.SelectionControlType.FilterEditor;
            this.selectionControl1.Size = new System.Drawing.Size(168, 21);
            this.selectionControl1.TabIndex = 0;
            // 
            // panelPicker
            // 
            this.panelPicker.Controls.Add(this.label1);
            this.panelPicker.Controls.Add(this.panelAddVariable);
            this.panelPicker.Controls.Add(this.selectionControl1);
            this.panelPicker.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelPicker.Location = new System.Drawing.Point(0, 0);
            this.panelPicker.Name = "panelPicker";
            this.panelPicker.Size = new System.Drawing.Size(520, 40);
            this.panelPicker.TabIndex = 1;
            this.panelPicker.Visible = false;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(8, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 23);
            this.label1.TabIndex = 4;
            this.label1.Text = "Filter";
            // 
            // panelAddVariable
            // 
            this.panelAddVariable.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panelAddVariable.Controls.Add(this.textBox1);
            this.panelAddVariable.Controls.Add(this.button1);
            this.panelAddVariable.Location = new System.Drawing.Point(320, 8);
            this.panelAddVariable.Name = "panelAddVariable";
            this.panelAddVariable.Size = new System.Drawing.Size(192, 24);
            this.panelAddVariable.TabIndex = 3;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(48, 0);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(136, 20);
            this.textBox1.TabIndex = 2;
            this.textBox1.Text = "";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(40, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "&Add Variable";
            // 
            // panelAssignment
            // 
            this.panelAssignment.Controls.Add(this.dataGridAssignments);
            this.panelAssignment.Controls.Add(this.splitterAssignmentEditorRight);
            this.panelAssignment.Controls.Add(this.panelAssignmentEditorRight);
            this.panelAssignment.Controls.Add(this.splitterAssignmentEditorBottom);
            this.panelAssignment.Controls.Add(this.panelAssignmentEditorLower);
            this.panelAssignment.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelAssignment.Location = new System.Drawing.Point(0, 104);
            this.panelAssignment.Name = "panelAssignment";
            this.panelAssignment.Size = new System.Drawing.Size(520, 248);
            this.panelAssignment.TabIndex = 3;
            // 
            // dataGridAssignments
            // 
            this.dataGridAssignments.CaptionText = "Assignments";
            this.dataGridAssignments.DataMember = "";
            this.dataGridAssignments.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridAssignments.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dataGridAssignments.Location = new System.Drawing.Point(0, 0);
            this.dataGridAssignments.Name = "dataGridAssignments";
            this.dataGridAssignments.Size = new System.Drawing.Size(312, 152);
            this.dataGridAssignments.TabIndex = 6;
            this.dataGridAssignments.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dataGridAssignments_MouseDown);
            this.dataGridAssignments.CurrentCellChanged += new System.EventHandler(this.dataGridAssignments_CurrentCellChanged);
            // 
            // splitterAssignmentEditorRight
            // 
            this.splitterAssignmentEditorRight.AnimationDelay = 20;
            this.splitterAssignmentEditorRight.AnimationStep = 20;
            this.splitterAssignmentEditorRight.BorderStyle3D = System.Windows.Forms.Border3DStyle.Flat;
            this.splitterAssignmentEditorRight.ControlToHide = this.panelAssignmentEditorRight;
            this.splitterAssignmentEditorRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.splitterAssignmentEditorRight.ExpandParentForm = false;
            this.splitterAssignmentEditorRight.Location = new System.Drawing.Point(312, 0);
            this.splitterAssignmentEditorRight.Name = "splitterAssignmentEditorRight";
            this.splitterAssignmentEditorRight.TabIndex = 3;
            this.splitterAssignmentEditorRight.TabStop = false;
            this.splitterAssignmentEditorRight.UseAnimations = false;
            this.splitterAssignmentEditorRight.VisualStyle = NJFLib.Controls.VisualStyles.Mozilla;
            // 
            // panelAssignmentEditorRight
            // 
            this.panelAssignmentEditorRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelAssignmentEditorRight.Location = new System.Drawing.Point(320, 0);
            this.panelAssignmentEditorRight.Name = "panelAssignmentEditorRight";
            this.panelAssignmentEditorRight.Size = new System.Drawing.Size(200, 152);
            this.panelAssignmentEditorRight.TabIndex = 2;
            // 
            // splitterAssignmentEditorBottom
            // 
            this.splitterAssignmentEditorBottom.AnimationDelay = 20;
            this.splitterAssignmentEditorBottom.AnimationStep = 20;
            this.splitterAssignmentEditorBottom.BorderStyle3D = System.Windows.Forms.Border3DStyle.Flat;
            this.splitterAssignmentEditorBottom.ControlToHide = this.panelAssignmentEditorLower;
            this.splitterAssignmentEditorBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitterAssignmentEditorBottom.ExpandParentForm = false;
            this.splitterAssignmentEditorBottom.Location = new System.Drawing.Point(0, 152);
            this.splitterAssignmentEditorBottom.Name = "splitterAssignmentEditorBottom";
            this.splitterAssignmentEditorBottom.TabIndex = 1;
            this.splitterAssignmentEditorBottom.TabStop = false;
            this.splitterAssignmentEditorBottom.UseAnimations = false;
            this.splitterAssignmentEditorBottom.VisualStyle = NJFLib.Controls.VisualStyles.Mozilla;
            // 
            // panelAssignmentEditorLower
            // 
            this.panelAssignmentEditorLower.Controls.Add(this.assignmentShortResult);
            this.panelAssignmentEditorLower.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelAssignmentEditorLower.Location = new System.Drawing.Point(0, 160);
            this.panelAssignmentEditorLower.Name = "panelAssignmentEditorLower";
            this.panelAssignmentEditorLower.Size = new System.Drawing.Size(520, 88);
            this.panelAssignmentEditorLower.TabIndex = 0;
            // 
            // assignmentShortResult
            // 
            this.assignmentShortResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.assignmentShortResult.Location = new System.Drawing.Point(0, 0);
            this.assignmentShortResult.Name = "assignmentShortResult";
            this.assignmentShortResult.Size = new System.Drawing.Size(520, 88);
            this.assignmentShortResult.TabIndex = 0;
            // 
            // panelFilterEditor
            // 
            this.panelFilterEditor.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelFilterEditor.Location = new System.Drawing.Point(0, 40);
            this.panelFilterEditor.Name = "panelFilterEditor";
            this.panelFilterEditor.Size = new System.Drawing.Size(520, 64);
            this.panelFilterEditor.TabIndex = 2;
            this.panelFilterEditor.Visible = false;
            // 
            // AssignmentCollectionEditor
            // 
            this.Controls.Add(this.panelAssignment);
            this.Controls.Add(this.panelFilterEditor);
            this.Controls.Add(this.panelPicker);
            this.Name = "AssignmentCollectionEditor";
            this.Size = new System.Drawing.Size(520, 352);
            this.panelPicker.ResumeLayout(false);
            this.panelAddVariable.ResumeLayout(false);
            this.panelAssignment.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridAssignments)).EndInit();
            this.panelAssignmentEditorLower.ResumeLayout(false);
            this.ResumeLayout(false);

        }
        #endregion

        ILog GetLog(Assignment assignment)
        {
            IConfig config = assignment.ConfigData.GetIConfig(0);
            string logFolder = config[TFxConst.c_LogInfo];
            string fileName = logFolder + "\\" + assignment.LabRun.Name + "." + assignment.AssignmentId.ToString() + ".xml";

            return DirectFileLog.GetLog(fileName);
        }

        private int previousRowIndex = -1;

        private void dataGridAssignments_CurrentCellChanged(object sender, System.EventArgs e)
        {
            int currentRowIndex = dataGridAssignments.CurrentRowIndex;

            // Check for changed row...avoid reloading if moving on same row.
            if (currentRowIndex != this.previousRowIndex || this.reloadResults)
            {
                this.previousRowIndex = currentRowIndex;

                int id = int.Parse(dataGridAssignments[currentRowIndex, 0].ToString());

                foreach (Assignment assignment in m_assignments)
                {
                    if (assignment.AssignmentId == id /*&& assignment.Result !=null*/)
                    {
                        if (assignment.Result != null)
                        {
                            this.Cursor = Cursors.WaitCursor;
                        }
                        this.assignmentShortResult.BindData(assignment.Result, GetLog(assignment));
                        this.reloadResults = false;

                        if (assignment.Result != null)
                        {
                            this.Cursor = Cursors.Default;
                        }
                        return;
                    }
                }
            }
        }

        /// <summary>
        /// Function called from the TestRunEditor when the UI state
        /// is executing
        /// </summary>
        /// <param name="profile"></param>
        public override void PersistUIState(Profile profile)
        {
            if (profile != null)
            {
                profile.TestRunExecutingSettings.splitterAssignmentEditorBottom = new SplitterState(this.splitterAssignmentEditorBottom.ControlToHide.Size, this.splitterAssignmentEditorBottom.IsCollapsed);
                this.assignmentShortResult.PersistUIState(profile);
            }
        }


        public void LoadUIState(Profile profile)
        {
            SplitterState currentSplitter = null;

            if (profile != null && profile.TestRunExecutingSettings != null)
            {
                this.assignmentShortResult.LoadUIState(profile);
                currentSplitter = profile.TestRunExecutingSettings.splitterAssignmentEditorBottom;

                if (currentSplitter != null)
                {
                    this.splitterAssignmentEditorBottom.Visible = true;
                    this.splitterAssignmentEditorBottom.ControlToHide.Size = new Size(currentSplitter.ControlToHideSize.Width, currentSplitter.ControlToHideSize.Height);
                    if (currentSplitter.isCollapsed)
                    {
                        this.splitterAssignmentEditorBottom.ControlToHide.Visible = false;
                    }
                    else
                    {
                        this.splitterAssignmentEditorBottom.ControlToHide.Visible = true;
                    }
                }
            }
        }
        private void dataGridAssignments_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (OnExportAssignments != null)
            {
                OnExportAssignments(sender, e);
            }
        }

        /// <summary>
        /// Used For: Bulk Edit
        /// Get the unique columns from the assignment config
        /// Make sure not to include the system variables
        /// from teh TFxConst
        /// </summary>
        /// <returns></returns>

        public ArrayList GetUniqueColumnNames()
        {
            Type t = typeof(TFxConst);

            ArrayList fieldNames = new ArrayList();
            ArrayList columnNames = new ArrayList();

            FieldInfo[] fieldInfo = t.GetFields();

            foreach (FieldInfo info in fieldInfo)
            {
                if (info.GetValue(null) != null)
                {
                    fieldNames.Add(info.GetValue(null));
                }
            }

            if (this.m_columnNames != null && this.m_columnNames.Count > 0)
            {
                foreach (string key in this.m_columnNames)
                {
                    if (!fieldNames.Contains(key))
                    {
                        columnNames.Add(key);
                    }
                }

                return columnNames;
            }

            return null;
        }

        /// <summary>
        /// Purpose: Bulk Edit
        /// For each entry in the columnd hashtable the assignements
        /// config value will be updated
        /// 
        /// </summary>
        /// <param name="columns"></param>
        public void UpdateAssignmentConfig(Hashtable columns)
        {
            AssignmentCollection selectedAssignments = this.GetSelected();
            DataRow configRow;

            ApplyConfigChange();//save the edited config in grid before save bulk edit

            foreach (Assignment assignment in selectedAssignments)
            {
                ConfigData additionalConfig = new ConfigData();
                StringConfig strConfig = new StringConfig();
                foreach (string key in columns.Keys)
                {
                    configRow = assignment.ConfigData.ConfigTable.Rows[0];

                    if (assignment.ConfigData.ConfigTable.Columns.Contains(key))
                    {
                        configRow[key] = columns[key];
                    }
                    else
                    {
                        strConfig.Config.Add(key, columns[key].ToString());
                    }
                }

                if (strConfig.Config.Count > 0)
                {
                    additionalConfig.Append((IConfig)strConfig);
                    if (assignment.ConfigData.ConfigTable != null && assignment.ConfigData.ConfigTable.Rows.Count > 0)
                    {
                        assignment.ConfigData.Merge(additionalConfig, false);
                    }
                    else
                    {
                        //Hack: Merge is not working when the config data rows count is 0
                        assignment.ConfigData.Append(additionalConfig);
                    }
                }
            }

            this.BindDataGrid();
        }

        public void SelectAssignments(AssignmentCollection Select)
        {
            Assignment assignment = null;

            if (dataGridAssignments.DataSource != null)
            {
                CurrencyManager manager = (CurrencyManager)this.BindingContext[dataGridAssignments.DataSource, dataGridAssignments.DataMember];
                DataView dv = (DataView)manager.List;

                for (int i = 0; i < dv.Count; ++i)
                {
                    foreach (Assignment a in Select)
                    {
                        DataRow row = dv[i].Row;
                        if (row != null)
                        {
                            assignment = this.FindAssignment(Convert.ToInt32(row.ItemArray[0]));
                            if (assignment != null && assignment.AssignmentId == a.AssignmentId)
                            {
                                //dv.Rows[i].Selected = true;

                                dataGridAssignments.Select(i);
                            }
                        }
                    }
                }
            }
        }
    }
}
