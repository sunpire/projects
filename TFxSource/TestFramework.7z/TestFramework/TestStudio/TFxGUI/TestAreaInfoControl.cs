//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: TestAreaInfoControl.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;



namespace Expedia.Test.Framework
{
	public class TestAreaInfoControl : Expedia.Test.Framework.TestInfoControl
	{
		private System.ComponentModel.IContainer components = null;

		public TestAreaInfoControl()
		{
			// This call is required by the Windows Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call
		}

		#region InternalMethods
		protected override void DisplayTestDetails()
		{
			if(TestDetails !=null)
			{
				base.DisplayTestDetails();
			}
		

		}
		#endregion

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.SuspendLayout();
			// 
			// TestAreaInfoControl
			// 
			this.Name = "TestAreaInfoControl";
			this.Resize += new System.EventHandler(this.TestAreaInfoControl_Resize);
			this.ResumeLayout(false);

		}
		#endregion

		private void TestAreaInfoControl_Resize(object sender, System.EventArgs e)
		{
			base.ReSizeForm(sender);		
		}
	}
}

