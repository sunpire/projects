//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: TestInfoControl.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;


namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for TestInfoControl.
    /// </summary>
    public class TestInfoControl : System.Windows.Forms.UserControl
    {
        public System.Windows.Forms.Label Title;
        public System.Windows.Forms.TextBox TitleTextBox;
        public System.Windows.Forms.Label CreatedDate;
        public System.Windows.Forms.TextBox CreatedDateTextBox;
        public System.Windows.Forms.Label Owner;
        public System.Windows.Forms.TextBox OwnerTextBox;
        public System.Windows.Forms.Label ChangedDate;
        public System.Windows.Forms.TextBox ChangedDateTextBox;
        public System.Windows.Forms.Label Description;
        public System.Windows.Forms.RichTextBox DescriptionTextBox;
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;
        ToolTip toolTip = new ToolTip();

        //Properties
        #region  Properties

        private TestInfo m_testDetails;

        public TestInfo TestDetails
        {
            get
            {
                return m_testDetails;
            }
            set
            {
                m_testDetails = value;
                DisplayTestDetails();
            }
        }

        public TestInfo GetTestInfo()
        {
            m_testDetails = new TestCase(m_testDetails.Path, this.TitleTextBox.Text);
            m_testDetails.Owner = this.OwnerTextBox.Text;
            m_testDetails.Description = this.DescriptionTextBox.Text;
            return m_testDetails;
        }

        #endregion

        public TestInfoControl()
        {
            // This call is required by the Windows.Forms Form Designer.
            InitializeComponent();

            // TODO: Add any initialization after the InitForm call
        }

        protected virtual void DisplayTestDetails()
        {
            if (TestDetails != null)
            {
                this.TitleTextBox.Text = TestDetails.Name;
                toolTip.SetToolTip(this.TitleTextBox, TestDetails.Name);

                this.OwnerTextBox.Text = TestDetails.Owner;
                toolTip.SetToolTip(this.OwnerTextBox, TestDetails.Owner);

                this.DescriptionTextBox.Text = TestDetails.Description;
            }
            else
            {
                this.TitleTextBox.Text = "";
                toolTip.SetToolTip(this.TitleTextBox, "");

                this.OwnerTextBox.Text = "";
                toolTip.SetToolTip(this.OwnerTextBox, "");

                this.DescriptionTextBox.Text = "";
            }
        }

        protected virtual void ReSizeForm(object sender)
        {
            const double textBoxPercent = 30.0 / 100.0;
            const double labelPercent = 20 / 100.0;

            int textBoxWidth = (int)(((double)this.Width) * textBoxPercent);
            int labelWidth = (int)(((double)this.Width) * labelPercent);

            this.TitleTextBox.Size = new Size(textBoxWidth, this.Height);
            this.OwnerTextBox.Size = new Size(textBoxWidth, this.Height);
            //			this.ChangedDate.Size = new Size(labelWidth, this.Height);
            //			this.CreatedDate.Size = new Size(labelWidth, this.Height);
            this.CreatedDateTextBox.Size = new Size(textBoxWidth, this.Height);
            this.ChangedDateTextBox.Size = new Size(textBoxWidth, this.Height);
            this.DescriptionTextBox.Size = new Size(this.Width, this.DescriptionTextBox.Height);
        }

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code
        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Title = new System.Windows.Forms.Label();
            this.TitleTextBox = new System.Windows.Forms.TextBox();
            this.CreatedDate = new System.Windows.Forms.Label();
            this.CreatedDateTextBox = new System.Windows.Forms.TextBox();
            this.Owner = new System.Windows.Forms.Label();
            this.OwnerTextBox = new System.Windows.Forms.TextBox();
            this.ChangedDate = new System.Windows.Forms.Label();
            this.ChangedDateTextBox = new System.Windows.Forms.TextBox();
            this.Description = new System.Windows.Forms.Label();
            this.DescriptionTextBox = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.Location = new System.Drawing.Point(8, 16);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(56, 23);
            this.Title.TabIndex = 0;
            this.Title.Text = "Name";
            // 
            // TitleTextBox
            // 
            this.TitleTextBox.Location = new System.Drawing.Point(48, 16);
            this.TitleTextBox.Name = "TitleTextBox";
            this.TitleTextBox.Size = new System.Drawing.Size(152, 20);
            this.TitleTextBox.TabIndex = 1;
            this.TitleTextBox.Text = "";
            // 
            // CreatedDate
            // 
            this.CreatedDate.Location = new System.Drawing.Point(208, 16);
            this.CreatedDate.Name = "CreatedDate";
            this.CreatedDate.TabIndex = 2;
            this.CreatedDate.Text = "Created Date";
            // 
            // CreatedDateTextBox
            // 
            this.CreatedDateTextBox.Location = new System.Drawing.Point(288, 16);
            this.CreatedDateTextBox.Name = "CreatedDateTextBox";
            this.CreatedDateTextBox.Size = new System.Drawing.Size(80, 20);
            this.CreatedDateTextBox.TabIndex = 3;
            this.CreatedDateTextBox.Text = "";
            // 
            // Owner
            // 
            this.Owner.Location = new System.Drawing.Point(8, 48);
            this.Owner.Name = "Owner";
            this.Owner.TabIndex = 4;
            this.Owner.Text = "Owner";
            // 
            // OwnerTextBox
            // 
            this.OwnerTextBox.Location = new System.Drawing.Point(48, 48);
            this.OwnerTextBox.Name = "OwnerTextBox";
            this.OwnerTextBox.Size = new System.Drawing.Size(152, 20);
            this.OwnerTextBox.TabIndex = 5;
            this.OwnerTextBox.Text = "";
            // 
            // ChangedDate
            // 
            this.ChangedDate.Location = new System.Drawing.Point(208, 48);
            this.ChangedDate.Name = "ChangedDate";
            this.ChangedDate.Size = new System.Drawing.Size(88, 23);
            this.ChangedDate.TabIndex = 6;
            this.ChangedDate.Text = "Changed Date";
            // 
            // ChangedDateTextBox
            // 
            this.ChangedDateTextBox.Location = new System.Drawing.Point(288, 48);
            this.ChangedDateTextBox.Name = "ChangedDateTextBox";
            this.ChangedDateTextBox.Size = new System.Drawing.Size(80, 20);
            this.ChangedDateTextBox.TabIndex = 7;
            this.ChangedDateTextBox.Text = "";
            // 
            // Description
            // 
            this.Description.Location = new System.Drawing.Point(8, 80);
            this.Description.Name = "Description";
            this.Description.Size = new System.Drawing.Size(120, 23);
            this.Description.TabIndex = 8;
            this.Description.Text = "Description";
            // 
            // DescriptionTextBox
            // 
            this.DescriptionTextBox.Location = new System.Drawing.Point(8, 104);
            this.DescriptionTextBox.Name = "DescriptionTextBox";
            this.DescriptionTextBox.Size = new System.Drawing.Size(368, 88);
            this.DescriptionTextBox.TabIndex = 9;
            this.DescriptionTextBox.Text = "";
            // 
            // TestInfoControl
            // 
            this.AccessibleDescription = "";
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.DescriptionTextBox,
																		  this.Description,
																		  this.ChangedDateTextBox,
																		  this.ChangedDate,
																		  this.OwnerTextBox,
																		  this.Owner,
																		  this.CreatedDateTextBox,
																		  this.CreatedDate,
																		  this.TitleTextBox,
																		  this.Title});
            this.Name = "TestInfoControl";
            this.Size = new System.Drawing.Size(384, 336);
            this.ResumeLayout(false);

        }
        #endregion
    }
}
