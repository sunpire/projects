//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: ConfigPickerControl.cs 
// 
// Desc: 
// 
// Note: 
// 
// History: 
// 
//========================================================================== 
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ConfigPickerControl.
	/// </summary>
	public class ConfigPickerControl : RepositoryDelegateUI
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.Panel panelRadio;
		private System.Windows.Forms.Panel panelListBox;
		private System.Windows.Forms.RadioButton radioAny;
		private System.Windows.Forms.RadioButton radioAll;
		private System.Windows.Forms.ListBox listBoxConfigs;


		ConfigData[] m_selectedConfigs;

		public ConfigData[] SelectedConfigs
		{
			get
			{
				if(this.m_selectedConfigs == null)
				{
					GetConfigData();
				}
				return m_selectedConfigs;
			}
			set
			{
				m_selectedConfigs = value;
			}

		}

		object ConfigsSource
		{
			get
			{
				return this.listBoxConfigs.DataSource;
			}
			set
			{
				this.listBoxConfigs.DataSource = value;
			}

		}


		public ConfigPickerControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();			
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panelRadio = new System.Windows.Forms.Panel();
			this.radioAll = new System.Windows.Forms.RadioButton();
			this.radioAny = new System.Windows.Forms.RadioButton();
			this.panelListBox = new System.Windows.Forms.Panel();
			this.listBoxConfigs = new System.Windows.Forms.ListBox();
			this.panelRadio.SuspendLayout();
			this.panelListBox.SuspendLayout();
			this.SuspendLayout();
			// 
			// panelRadio
			// 
			this.panelRadio.Controls.AddRange(new System.Windows.Forms.Control[] {
																					 this.radioAll,
																					 this.radioAny});
			this.panelRadio.Dock = System.Windows.Forms.DockStyle.Top;
			this.panelRadio.Name = "panelRadio";
			this.panelRadio.Size = new System.Drawing.Size(150, 32);
			this.panelRadio.TabIndex = 0;
			// 
			// radioAll
			// 
			this.radioAll.Location = new System.Drawing.Point(88, 8);
			this.radioAll.Name = "radioAll";
			this.radioAll.TabIndex = 1;
			this.radioAll.Text = "All";
			// 
			// radioAny
			// 
			this.radioAny.Checked = true;
			this.radioAny.Location = new System.Drawing.Point(8, 8);
			this.radioAny.Name = "radioAny";
			this.radioAny.TabIndex = 0;
			this.radioAny.TabStop = true;
			this.radioAny.Text = "Any";
			// 
			// panelListBox
			// 
			this.panelListBox.Controls.AddRange(new System.Windows.Forms.Control[] {
																					   this.listBoxConfigs});
			this.panelListBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panelListBox.Location = new System.Drawing.Point(0, 32);
			this.panelListBox.Name = "panelListBox";
			this.panelListBox.Size = new System.Drawing.Size(150, 118);
			this.panelListBox.TabIndex = 1;
			// 
			// listBoxConfigs
			// 
			this.listBoxConfigs.Dock = System.Windows.Forms.DockStyle.Fill;
			this.listBoxConfigs.Name = "listBoxConfigs";
			this.listBoxConfigs.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
			this.listBoxConfigs.Size = new System.Drawing.Size(150, 108);
			this.listBoxConfigs.TabIndex = 0;
			// 
			// ConfigPickerControl
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.panelListBox,
																		  this.panelRadio});
			this.Name = "ConfigPickerControl";
			this.Load += new System.EventHandler(this.ConfigPickerControl_Load);
			this.panelRadio.ResumeLayout(false);
			this.panelListBox.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		
		private void GetConfigData()
		{
			ConfigEngin engin = new ConfigEngin();	
			string configName = "";
			ArrayList configsList = new ArrayList();

			//Get the selected values from the listbox				
			foreach(object selectedConfigs in this.listBoxConfigs.SelectedItems)
			{
				configName = selectedConfigs.ToString();
				ConfigRequest configRequest = new ConfigRequest(RepositoryRequestType.Get);
				configRequest.InstanceName = configName;
				this.GetData(configRequest);
			
				engin = new ConfigEngin();

				if(configRequest.ConfigExpression != null)
				{

					engin.InitConfigData(configRequest.ConfigData, configRequest.Expression);						
					ConfigData configData =  engin.Evaluate(configRequest.Expression);

					if(configData != null)
					{
						configsList.Add(configData);

					}																
				}

				m_selectedConfigs = (ConfigData[])configsList.ToArray(typeof(ConfigData));
			}						
		}			
			

		//Examlpe on how to generate the config data
		void ExampleConfigData()
		{
			//Create the DataTable here
			DataTable dt = CreateDataTable();

			//Get the HardCorded ConfigData for now
			ConfigData[] Data =  new ConfigData[1];
			
			for(int i =0; i < Data.Length; i++)
			{
				Data[i] = new ConfigData();
				Data[i].ConfigTable = dt;
			}

			//this.m_selectedConfigs = Data;
		}
		
		//Creating the DataTable, need to be deleted later		
		private DataTable CreateDataTable()
		{
			DataTable dt = new DataTable("Example");
			dt.Columns.Add("TPID");
			dt.Columns.Add("Cities");
			dt.Columns.Add("LangId");

			DataRow row = dt.NewRow();
			row["TPID"] = "1";
			row["Cities"]="City1";
			row["LangId"]="1033";

			dt.Rows.InsertAt(row,0);

			DataRow row1 = dt.NewRow();

			row1["TPID"] = "1";
			row1["Cities"]="City3";
			row1["LangId"]="1030";

			dt.Rows.InsertAt(row1,1);


			DataRow row2 = dt.NewRow();

			row2["TPID"] = "1";
			row2["Cities"]="City4";
			row2["LangId"]="1035";

			dt.Rows.InsertAt(row2,2);

			dt.AcceptChanges();

			return dt;
		}

		private void HandleUpdateControlsNotification(NotificationRequest request)
		{
			LoadConfigs();
		}

		private void LoadConfigs()
		{
			ConfigListRequest configListRequest = new ConfigListRequest();
			this.GetData(configListRequest);

			if((configListRequest.Objects != null)&&(configListRequest.Objects.Length >0))
			{
				this.ConfigsSource = configListRequest.Objects;
			}
		}

		private void ConfigPickerControl_Load(object sender, System.EventArgs e)
		{
			AddNotificationHandler(typeof(ConfigChangeNotification), new NotificationRequestHandler(this.HandleUpdateControlsNotification) );
			LoadConfigs();
		}
	}
}
