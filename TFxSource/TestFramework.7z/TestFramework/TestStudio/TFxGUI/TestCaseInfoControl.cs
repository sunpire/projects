//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: TestCaseInfoControl.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;


namespace Expedia.Test.Framework
{
	public class TestCaseInfoControl : Expedia.Test.Framework.TestInfoControl
	{
		private System.Windows.Forms.RichTextBox CategoriesTextBox;
		private System.Windows.Forms.Label Categories;
		private System.ComponentModel.IContainer components = null;

		public TestCaseInfoControl()
		{
			// This call is required by the Windows Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call
		}

		#region InternalMethods
		protected override void DisplayTestDetails()
		{
			
			if(TestDetails !=null)
			{
				base.DisplayTestDetails();
				TestCase TC = TestDetails as TestCase;
				this.CategoriesTextBox.Text = TC.TestCategory.ToString();
			}
		}
		#endregion

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.CategoriesTextBox = new System.Windows.Forms.RichTextBox();
			this.Categories = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// CategoriesTextBox
			// 
			this.CategoriesTextBox.Location = new System.Drawing.Point(8, 232);
			this.CategoriesTextBox.Name = "CategoriesTextBox";
			this.CategoriesTextBox.Size = new System.Drawing.Size(368, 88);
			this.CategoriesTextBox.TabIndex = 10;
			this.CategoriesTextBox.Text = "";
			// 
			// Categories
			// 
			this.Categories.Location = new System.Drawing.Point(8, 208);
			this.Categories.Name = "Categories";
			this.Categories.TabIndex = 11;
			this.Categories.Text = "Categories";
			// 
			// TestCaseInfoControl
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.DescriptionTextBox,
																		  this.Description,
																		  this.ChangedDateTextBox,
																		  this.ChangedDate,
																		  this.OwnerTextBox,
																		  this.Owner,
																		  this.CreatedDateTextBox,
																		  this.CreatedDate,
																		  this.TitleTextBox,
																		  this.Title,
																		  this.Categories,
																		  this.CategoriesTextBox});
			this.Name = "TestCaseInfoControl";
			this.Size = new System.Drawing.Size(400, 352);
			this.Resize += new System.EventHandler(this.TestCaseInfoControl_Resize);
			this.ResumeLayout(false);

		}
		#endregion

		private void TestCaseInfoControl_Resize(object sender, System.EventArgs e)
		{
			base.ReSizeForm(sender);
			//this.CategoriesTextBox.Size = new Size(this.Width, this.CategoriesTextBox.Height);
		
		}

		
	}
}

