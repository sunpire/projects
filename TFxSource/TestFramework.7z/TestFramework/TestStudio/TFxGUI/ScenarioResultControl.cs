using System.Collections.Generic;
using System.Data;

namespace Expedia.Test.Framework
{
    public delegate void ScenarioResultChangeHandler(ScenarioResult result);

    /// <summary>
    /// Summary description for ScenarioResultControl.
    /// </summary>
    public class ScenarioResultControl : System.Windows.Forms.UserControl
    {
        private System.Windows.Forms.DataGrid dataGridScenarios;
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;

        public event ScenarioResultChangeHandler OnScenarioResultChanged;

        public ScenarioResultControl()
        {
            // This call is required by the Windows.Forms Form Designer.
            InitializeComponent();

            // TODO: Add any initialization after the InitForm call
        }

        private List<ScenarioResult> m_scenarios = new List<ScenarioResult>();

        public List<ScenarioResult> Scenarios
        {
            get
            {
                return this.m_scenarios;
            }
            set
            {
                this.m_scenarios = value;
            }
        }

        int m_lastRowIndex = -1;

        public void BindData(AssignmentResult result)
        {
            if (result != null /*&& result.Status != AssignmentRunResultType.Pass*/)
            {
                //Scenarios = result.Scenarios;

                DataTable dt = new DataTable();
                dt.Columns.Add("ScenarioName");
                dt.Columns.Add("Status");

                foreach (ScenarioResult scen in result.Scenarios)
                {
                    DataRow row = dt.NewRow();
                    row["ScenarioName"] = scen.ScenarioName;
                    row["Status"] = scen.Status;

                    dt.Rows.Add(row);
                }

                this.Scenarios = result.Scenarios;
                dataGridScenarios.DataSource = dt;
            }
            else
            {
                this.Scenarios = null;
                dataGridScenarios.DataSource = null;
            }
        }

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code
        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridScenarios = new System.Windows.Forms.DataGrid();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridScenarios)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridScenarios
            // 
            this.dataGridScenarios.CaptionText = "ScenarioResults";
            this.dataGridScenarios.DataMember = "";
            this.dataGridScenarios.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridScenarios.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dataGridScenarios.Name = "dataGridScenarios";
            this.dataGridScenarios.ReadOnly = true;
            this.dataGridScenarios.Size = new System.Drawing.Size(72, 152);
            this.dataGridScenarios.TabIndex = 0;
            this.dataGridScenarios.CurrentCellChanged += new System.EventHandler(this.dataGridScenarios_CurrentCellChanged);
            // 
            // ScenarioResultControl
            // 
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.dataGridScenarios});
            this.Name = "ScenarioResultControl";
            this.Size = new System.Drawing.Size(72, 152);
            this.Load += new System.EventHandler(this.ScenarioResultControl_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridScenarios)).EndInit();
            this.ResumeLayout(false);

        }
        #endregion

        private void ScenarioResultControl_Load(object sender, System.EventArgs e)
        {
        }

        private void dataGridScenarios_CurrentCellChanged(object sender, System.EventArgs e)
        {
            if (m_lastRowIndex == -1 || dataGridScenarios.CurrentRowIndex != m_lastRowIndex)
            {
                ScenarioResult result = this.Scenarios[dataGridScenarios.CurrentRowIndex] as ScenarioResult;

                OnScenarioResultChanged(result);

                m_lastRowIndex = dataGridScenarios.CurrentRowIndex;
            }
        }
    }
}
