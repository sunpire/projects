//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: AdvancedFilterBodyControl.cs 
// 
// Desc: 
// 
// Note: 
// 
// History: 
// 
//========================================================================== 
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
	public delegate ConfigFieldInfo GetFieldInfoHandler(string fieldName);
	/// <summary>
	/// Summary description for AdvancedFilterBodyControl.
	/// </summary>
	public class GenericExpressionEditorControl : System.Windows.Forms.UserControl
	{
		private FieldExpression m_expression;
		//public FieldExpression Expression = new FieldExpression();

		private DataGridComboBoxColumn m_fieldColumn;
		private DataGridComboBoxColumn m_operatorColumn;
		private DataGridComboBoxColumn m_valueColumn;
		private DataGridComboBoxColumn m_andorColumn;
		private System.Windows.Forms.DataGrid m_filterDataGrid;


		public void Cleanup()
		{
			Expression.ExpressionDataTable.Clear();
			this.RowCount = 0;
		}


		[Browsable(false)]
		public FieldExpression Expression
		{
			get
			{
				if(m_expression == null)
				{
					m_expression = new FieldExpression();
					//this.m_expression.ExpressionDataTable.RowChanged += new DataRowChangeEventHandler(this.DataRowChanged);
				}

				return m_expression;
			}
			set
			{
				m_currentRow = 0;
				m_currentColumn = 0;
				m_rowCount = 0;
				m_expression = value;
				this.m_expression.ExpressionDataTable.RowChanged += new DataRowChangeEventHandler(this.DataRowChanged);
				SetDataGrid();
			}

		}
		public event GetValuesHandler FieldList
		{
			add
			{
				this.m_fieldColumn.GetValues += value;
			}
			remove
			{
				this.m_fieldColumn.GetValues -= value;
			}
		}

//		public event GetFieldValuesHandler OperatorList;
		public event GetFieldValuesHandler ValueList;
		public event GetFieldInfoHandler GetFieldInfo;
 
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public event System.EventHandler FilterExpressionChanged;

		public GenericExpressionEditorControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
			
			//this.Expression.ExpressionDataTable.RowChanged += new DataRowChangeEventHandler(this.DataRowChanged);
			this.Expression.ExpressionDataTable.RowDeleting += new DataRowChangeEventHandler(this.DeleteFilterField);
			this.Expression.ExpressionDataTable.RowChanged += new DataRowChangeEventHandler(this.DataRowChanged);
			this.SetDataGrid();
		
		}

		private void SetDataGrid()
		{
			this.m_filterDataGrid.TableStyles.Clear();

			// Create a DataGridTableStyle object.
			DataGridTableStyle tableStyle = new DataGridTableStyle();
			tableStyle.RowHeadersVisible = true;
			tableStyle.RowHeaderWidth = 20;
			tableStyle.AllowSorting = false;

			// Add customized columns.
			this.m_fieldColumn = new DataGridComboBoxColumn();
			this.m_fieldColumn.comboBox.Parent = this; // Commit dataset.
			//this.m_fieldColumn.comboBox.SelectionChangeCommitted += new EventHandler(FieldNameSelected);
			this.m_fieldColumn.SelectedColumnChange += new SelectedColumnChangeHandler( FieldColumnSelectionChanged );
			this.m_fieldColumn.MappingName = "FieldName";
			this.m_fieldColumn.HeaderText = "Field Name";
			this.m_fieldColumn.Width = 200;
			tableStyle.GridColumnStyles.Add(this.m_fieldColumn);

			this.m_operatorColumn = new DataGridComboBoxColumn();
			this.m_operatorColumn.comboBox.Parent = this; // Commit dataset.
			this.m_operatorColumn.comboBox.DataSource = null;
			this.m_operatorColumn.MappingName = "Operators";
			this.m_operatorColumn.HeaderText = "Operator";
			this.m_operatorColumn.Width = 100;
			this.m_operatorColumn.SelectedColumnChange += new SelectedColumnChangeHandler( this.OperatorColumnSelectionChanged );

			tableStyle.GridColumnStyles.Add(this.m_operatorColumn);

			this.m_valueColumn = new DataGridComboBoxColumn();
			this.m_valueColumn.comboBox.Parent = this; // Commit dataset.
			this.m_valueColumn.comboBox.DataSource = null;
			this.m_valueColumn.MappingName = "Values";
			this.m_valueColumn.HeaderText = "Value";
			this.m_valueColumn.Width = 200;
			this.m_valueColumn.SelectedColumnChange += new SelectedColumnChangeHandler( this.ValueColumnSelectionChanged );
			//this.m_valueColumn.comboBox.SelectionChangeCommitted += new EventHandler(this.ValueSelectionCommitted);

			tableStyle.GridColumnStyles.Add(this.m_valueColumn);

			this.m_andorColumn = new DataGridComboBoxColumn();
			this.m_andorColumn.comboBox.Parent = this; // Commit dataset.
			this.m_andorColumn.comboBox.DataSource = new ArrayList(new string[]{"And", "Or"});
			//this.m_andorColumn.comboBox.SelectionChangeCommitted += new EventHandler(this.SetFilterExpressionElementTypeForRow);
			//this.m_andorColumn.GetValues += new GetValuesHandler( this.GetExpressionOperators );
			
			this.m_andorColumn.MappingName = "AndOr";
			this.m_andorColumn.HeaderText = "And/Or";
			this.m_andorColumn.Width = 50;
			//this.m_andorColumn.SelectedColumnChange += new SelectedColumnChangeHandler( this.AndOrColumnSelectionChanged );

			tableStyle.GridColumnStyles.Add(this.m_andorColumn);

			// Add the custom TableStyle to the DataGrid.
			tableStyle.MappingName = this.Expression.ExpressionDataTable.TableName;
			this.m_filterDataGrid.TableStyles.Clear();
			this.m_filterDataGrid.TableStyles.Add(tableStyle);
			
			this.m_filterDataGrid.DataSource = this.Expression.ExpressionDataTable;
		}


		//Properties

		int m_currentRow;
		int m_currentColumn;
		int m_rowCount;

		int CurrentRow
		{
			get
			{
				return m_currentRow;
			}
			set
			{
				m_currentRow = value;
			}
		}

		int CurrentColumn
		{
			get
			{
				return m_currentColumn;
			}
			set
			{
				m_currentColumn = value;
			}
		}

		int RowCount
		{
			get
			{
				return m_rowCount;
			}
			set
			{
				m_rowCount = value;
			}
		}

		public object DataSource
		{
			set
			{
				if(value != null)
				{
					this.m_filterDataGrid.DataSource = value;
					this.m_filterDataGrid.Refresh();
					RowCount = ((DataTable)this.m_filterDataGrid.DataSource).Rows.Count;
				}
				
			}
		}

		//End of Proporties

		ArrayList m_opertorList = ArrayList.ReadOnly(new ArrayList(new string[]{"And", "Or"}));
		public ArrayList GetExpressionOperators(int rowNum)
		{
			return m_opertorList;
		}

		private void ChangeFilterExpression(object sender, DataColumnChangeEventArgs e)
		{
			if(this.FilterExpressionChanged != null)
			{
				this.FilterExpressionChanged(this.Expression, null);
			}
		}
	
		void OperatorColumnSelectionChanged(int rowNum)
		{
			this.SelectionChanged(rowNum, 1);
		}
		
		void ValueColumnSelectionChanged(int rowNum)
		{
			this.SelectionChanged(rowNum, 2);
		}
		
		private void ValueSelectionCommitted(object sender, System.EventArgs e)
		{
			//Get the current row index
			this.SelectionChanged(this.m_filterDataGrid.CurrentRowIndex, 2);
		}
		
		void AndOrColumnSelectionChanged(int rowNum)
		{
			this.SelectionChanged(rowNum, 3);
		}

		void SelectionChanged(int row, int column)
		{
			if(row != this.CurrentRow)
			{
				RowSelectionChanged(row);
			}
			if(row != this.CurrentRow ||  column != this.CurrentColumn)
			{
				FieldSelectionChanged(row);
			}

			//If both the rows and the column are equal then we need to change the data that is bind
			if(row == this.CurrentRow || column == this.CurrentColumn)
			{
				if(this.FilterExpressionChanged != null)
				{
					this.FilterExpressionChanged(this.Expression, null);
				}

			}
			this.CurrentRow = row;
			this.CurrentColumn = column;
		}

		void RowSelectionChanged(int newRow)
		{
			
		}
		
		private void DeleteFilterField(object sender, DataRowChangeEventArgs e)
		{
			if(this.FilterExpressionChanged != null)
			{
				this.FilterExpressionChanged(this.Expression, null);
			}
		}

	
		/// <summary>
		/// This function is called when the FieldColumn Selection has changed
		/// </summary>
		/// <param name="rowNum"></param>
		void FieldColumnSelectionChanged(int rowNum)
		{
			this.FieldSelectionChanged(rowNum);
		}
		
		void FieldSelectionChanged(int row)
		{
			ArrayList operators;

			this.CurrentRow = row;

			if(this.CurrentRow == RowCount)
			{
				//Add a new row to the DataTable
				this.Expression.ExpressionDataTable = this.m_filterDataGrid.DataSource as DataTable;				
				this.Expression.ExpressionDataTable.Rows.Add(this.Expression.ExpressionDataTable.NewRow());
				this.Expression.ExpressionDataTable.AcceptChanges();
				this.m_filterDataGrid.DataSource = this.Expression.ExpressionDataTable;	
				this.RowCount++;
			}

			ConfigFieldInfo fi = new ConfigFieldInfo();
			if(this.GetFieldInfo != null)
			{
				CurrencyManager cm  = (CurrencyManager) this.m_filterDataGrid.BindingContext[ this.Expression.ExpressionDataTable ];
				fi = GetFieldInfo(m_fieldColumn.GetLastValue(cm, row));

				//TODO: Not Sure whether this is required here
				//Intialize the m_operator column
				operators = this.GetExpressionOperators(row);
				this.m_andorColumn.comboBox.DataSource = operators;
				this.m_andorColumn.SetLastValue(cm, row, operators[0]);

				if(fi == null)
				{
					return;
				}

				this.m_operatorColumn.comboBox.DataSource = fi.SupportedOperators;
				this.m_filterDataGrid[row,1] = fi.SupportedOperators[0];
				//this.m_operatorColumn.SetLastValue(cm,row,fi.SupportedOperators[0]);
			}			
			
			if(this.ValueList != null)
			{
				CurrencyManager cm  = (CurrencyManager) this.m_filterDataGrid.BindingContext[ this.Expression.ExpressionDataTable ];
				this.m_valueColumn.comboBox.DataSource = this.ValueList(m_fieldColumn.GetLastValue(cm, row));				
				this.m_valueColumn.AllowInplaceEdit = !fi.IsRestrictedToValueList;				
			}	
		
			if(this.FilterExpressionChanged != null)
			{
				this.FilterExpressionChanged(this.Expression, null);
			}
		}

		private void DataRowChanged(object sender, DataRowChangeEventArgs e)
		{
			if(e.Action == DataRowAction.Change)
			{
				this.m_expression.ExpressionDataTable.AcceptChanges();

				if(this.FilterExpressionChanged != null)
				{
					this.FilterExpressionChanged(this.Expression, null);
				}
		
			}
		}

		void RowChanged()
		{

		}

		/// <summary>
		/// Field name is selected now init to default operators/values etc
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		//		private void FieldNameSelected(object sender, EventArgs e)
		//		{
		//			ComboBox comboBox = sender as ComboBox;
		//			
		//			if(comboBox != null)
		//			{
		//				int currentRow = this.m_filterDataGrid.CurrentRowIndex;
		//
		//				for(int i = 1;i < this.m_filterDataTable.Columns.Count;i++)
		//				{
		//					switch(this.m_filterDataTable.Columns[i].ColumnName)
		//					{
		//						case "Operators":
		//							this.m_filterDataGrid[currentRow, i] = "OPi";
		//							break;
		//						case "Values":
		//							this.m_filterDataGrid[currentRow, i] = "Valuei";
		//							break;
		//						case "AndOr":
		//							this.m_filterDataGrid[currentRow, i] = "Andi";
		//							break;
		//					}
		//				}
		//			}
		//		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.m_filterDataGrid = new System.Windows.Forms.DataGrid();
			((System.ComponentModel.ISupportInitialize)(this.m_filterDataGrid)).BeginInit();
			this.SuspendLayout();
			// 
			// m_filterDataGrid
			// 
			this.m_filterDataGrid.AllowSorting = false;
			this.m_filterDataGrid.CaptionText = "Filter Properties";
			this.m_filterDataGrid.DataMember = "";
			this.m_filterDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
			this.m_filterDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.m_filterDataGrid.Name = "m_filterDataGrid";
			this.m_filterDataGrid.Size = new System.Drawing.Size(176, 152);
			this.m_filterDataGrid.TabIndex = 0;
			// 
			// AdvancedFilterBodyControl
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.m_filterDataGrid});
			this.Name = "AdvancedFilterBodyControl";
			this.Size = new System.Drawing.Size(176, 152);
			((System.ComponentModel.ISupportInitialize)(this.m_filterDataGrid)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion
	}
}
