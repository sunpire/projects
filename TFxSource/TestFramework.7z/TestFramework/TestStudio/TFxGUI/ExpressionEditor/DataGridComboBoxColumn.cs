//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: DataGridComboBoxColumn.cs 
// 
// Desc: 
// 
// Note: 
// 
// History: 
// 
//========================================================================== 
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Expedia.Test.Framework {

	public delegate ArrayList GetValuesHandler(int rowNum);
	public delegate ArrayList GetFieldValuesHandler(string fieldName);
	public delegate void SelectedColumnChangeHandler(int rowNum);
	//**********************************************************************************************
	//	DataGridTextBoxColumn
	//**********************************************************************************************
	public class DataGridComboBoxColumn : DataGridColumnStyle { //DataGridTextBoxColumn {
		//private	MTGCComboBox combobox;
		private	ComboBox combobox;
		private TextBox		textBox;
		private	bool				edit;
		public event GetValuesHandler GetValues;
		public bool AllowInplaceEdit=false;
		
		public event SelectedColumnChangeHandler SelectedColumnChange;
		//-------------------------------------------------------------------------------------------
		//	Constructors and destructors
		//-------------------------------------------------------------------------------------------
		public DataGridComboBoxColumn() {
//			combobox							= new MTGCComboBox();
			combobox							= new ComboBox();
			textBox								= new TextBox();
			combobox.Visible					= false;
			//combobox.DropDownStyle				= MTGCComboBox.CustomDropDownStyle.DropDownList; //ComboBoxStyle.DropDownList;
			combobox.DropDownStyle				= ComboBoxStyle.DropDownList;
			combobox.Leave						+= new EventHandler(ComboHide);
			combobox.SelectionChangeCommitted	+= new EventHandler(ComboStartEditing);
			combobox.TextChanged				+= new EventHandler(ComboTextChanged);

			textBox.Leave 						+= new EventHandler(ComboHide);
			
			edit								= false;


//	    this.combobox.DisplayMember = "Text";
//        this.combobox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
//        this.combobox.DropDownArrowBackColor = System.Drawing.Color.FromArgb(136,169,223);
//        this.combobox.DropDownBackColor = System.Drawing.Color.FromArgb(193, 210, 238);
//        this.combobox.DropDownForeColor = System.Drawing.Color.Black;
//        this.combobox.DropDownStyle = MTGCComboBox.CustomDropDownStyle.DropDown;
//        this.combobox.DropDownWidth = 400;
//        this.combobox.GridLineColor = System.Drawing.Color.LightGray;
//        this.combobox.GridLineHorizontal = false;
//        this.combobox.GridLineVertical = false;
//        this.combobox.HighlightBorderColor = System.Drawing.Color.Blue;
//        this.combobox.HighlightBorderOnMouseEvents = true;
//        this.combobox.LoadingType = MTGCComboBox.CaricamentoCombo.DataTable;
//        this.combobox.Location = new System.Drawing.Point(8, 196);
//        this.combobox.ManagingFastMouseMoving = true;
//        this.combobox.ManagingFastMouseMovingInterval = 30;
//        this.combobox.Name = "combobox";
//        this.combobox.NormalBorderColor = System.Drawing.Color.Black;

		} // DataGridComboBoxColumn

		//-------------------------------------------------------------------------------------------
		//	Properties
		//-------------------------------------------------------------------------------------------
		public ComboBox comboBox {
			get {
				return combobox;
			}
		} // comboBox

		//-------------------------------------------------------------------------------------------
		//	ComboBox event handlers
		//-------------------------------------------------------------------------------------------
		private void ComboHide(object sender, EventArgs e) {
			// When the ComboBox looses focus, then simply hide it.
			textBox.Hide();
			combobox.Hide();
			//combobox.DropDownStyle = MTGCComboBox.CustomDropDownStyle.DropDownList;;
		} // ComboHide

		private void ComboTextChanged(object sender, EventArgs e) 
		{
			edit = true;
//			if(combobox.DropDownStyle == ComboBoxStyle.DropDown)
//			{
//				this.ComboStartEditing(sender, e);
//			}
		}

		private void ComboStartEditing(object sender, EventArgs e) {
			// Enter edit mode.
			edit = true;
			base.ColumnStartedEditing((Control)sender);
		} // ComboStartEditing

		//-------------------------------------------------------------------------------------------
		//	Override DataGridColumnStyle
		//-------------------------------------------------------------------------------------------
		protected override void SetDataGridInColumn(DataGrid value) {
			// Add the ComboBox to the DataGrids controls collection.
			// This ensures correct DataGrid scrolling.
			value.Controls.Add(combobox);
			base.SetDataGridInColumn(value);
		} // SetDataGridInColumn

		protected override void Abort(int rowNum) {
			// Abort edit mode, discard changes and hide the ComboBox.
			edit = false;
			Invalidate();
			combobox.Hide();
			//combobox.DropDownStyle = MTGCComboBox.CustomDropDownStyle.DropDownList;;
		} // Abort


		public string GetLastValue(CurrencyManager source, int row)
		{
			return base.GetColumnValueAtRow(source, row).ToString();
		}

		public void SetLastValue(CurrencyManager source, int row, object value)
		{
			base.SetColumnValueAtRow(source,row, value);
		}
		protected override void Edit(System.Windows.Forms.CurrencyManager source, int rowNum, System.Drawing.Rectangle bounds, bool readOnly, string instantText, bool cellIsVisible) {

			this.edit = true;
	//		ArrayList values;
			if(SelectedColumnChange != null)
			{
				SelectedColumnChange(rowNum);
			}

			string tempValue = base.GetColumnValueAtRow(source, rowNum).ToString();
			
			if(GetValues !=  null)
			{
				ArrayList fieldList = GetValues(rowNum);
				combobox.DataSource = fieldList;

				if(fieldList.Count >0)
				{
					combobox.SelectedItem = fieldList[0];
					
					//Set the DataGrid to the selected value so that it will not clear the combo box
					base.SetColumnValueAtRow(source, rowNum,comboBox.SelectedItem.ToString());	
				}
			
			
						
			}
			
			if(AllowInplaceEdit)
			{
				textBox.Text = tempValue;
				textBox.Parent = this.DataGridTableStyle.DataGrid;
				textBox.Bounds = bounds;
				//textBox.Size = new Size(this.Width, this.comboBox.Height);
				textBox.Show();
				textBox.Focus();
			}
			else
			{
				
				// Setup the ComboBox for action.
				// This includes positioning the ComboBox and showing it.
				// Also select the correct item in the ComboBox before it is shown.
				combobox.BeginUpdate();


				combobox.Parent	= this.DataGridTableStyle.DataGrid;
				combobox.Bounds	= bounds;
				combobox.Size	= new Size(this.Width, this.comboBox.Height);

				foreach(object obj in comboBox.Items)
				{
					if(obj.ToString() == tempValue)
					{
						comboBox.SelectedItem = obj;
						break;
					}
				}
				int tempIndex = comboBox.SelectedIndex;

				combobox.Visible = (cellIsVisible == true) && (readOnly == false);
				//combobox.DropDownStyle = MTGCComboBox.CustomDropDownStyle.DropDownList;;

				combobox.SelectedIndex = tempIndex;
				combobox.BringToFront();
				combobox.Focus();
				combobox.EndUpdate();

			}
		} // Edit

		protected override bool Commit(System.Windows.Forms.CurrencyManager source, int rowNum) 
		{
			// Commit the selected value from the ComboBox to the DataGrid.
			if (edit == true) 
			{
				edit = false;
				if(this.AllowInplaceEdit)
				{
					this.SetColumnValueAtRow(source, rowNum, textBox.Text);
				}
				else
				{
					this.SetColumnValueAtRow(source, rowNum, combobox.SelectedValue);
				}
			}
			this.textBox.Hide();
			this.ComboHide(this, null);
			return true;
		} // Commit

		protected override object GetColumnValueAtRow(System.Windows.Forms.CurrencyManager source, int rowNum) {
			// Return the display text associated with the data, insted of the
			// data from the DataGrid datasource.
			return combobox.GetItemText((base.GetColumnValueAtRow(source, rowNum)));
		} // GetColumnValueAtRow

		protected override void SetColumnValueAtRow(CurrencyManager source, int rowNum, object value) {
			// Save the data (value) to the DataGrid datasource.
			// I try a few different types, because I often uses GUIDs as keys in my
			// data.

			// String.
			try {
				base.SetColumnValueAtRow(source, rowNum, value.ToString());
				return;
			} catch {}

			// Guid.
			try {
				base.SetColumnValueAtRow(source, rowNum, new Guid(value.ToString()));
				return;
			} catch {}

			// Object (default).
			if (value == null)
			{
				base.SetColumnValueAtRow(source, rowNum, DBNull.Value);
				
			}
			else
			{
				base.SetColumnValueAtRow(source, rowNum, value);
			}
		} // SetColumnValueAtRow

		protected override int GetMinimumHeight() {
			// Return the ComboBox preferred height, plus a few pixels.
			return combobox.PreferredHeight + 2;
		} // GetMinimumHeight
		
		protected override int GetPreferredHeight(Graphics g, object val) {
			// Return the font height, plus a few pixels.
			return FontHeight + 2;
		} // GetPreferredHeight

		protected override Size GetPreferredSize(Graphics g, object val) {
			// Return the preferred width.
			// Iterate through all display texts in the dropdown, and measure each
			// text width.
			int		widest		= 0;
			SizeF		stringSize	= new SizeF(0, 0);
			foreach (object text in combobox.Items) {
				stringSize	= g.MeasureString(text.ToString(), base.DataGridTableStyle.DataGrid.Font);
				if (stringSize.Width > widest) {
					widest = (int)Math.Ceiling(stringSize.Width);
				}
			}

			return new Size(widest + 25, combobox.PreferredHeight + 2);
		} // GetPreferredSize

		protected override void Paint(Graphics g, Rectangle bounds, CurrencyManager source, int rowNum) {
			Paint(g, bounds, source, rowNum, false);
		} // Paint

		protected override void Paint(Graphics g, Rectangle bounds, CurrencyManager source, int rowNum, bool alignToRight) {
			string			text		= this.GetColumnValueAtRow(source, rowNum).ToString();
			Brush			backBrush	= new SolidBrush(base.DataGridTableStyle.BackColor);
			Brush			foreBrush	= new SolidBrush(base.DataGridTableStyle.ForeColor);
			Rectangle		rect		= bounds;
			StringFormat	format		= new StringFormat();

			// Handle that the row can be selected.
			if (base.DataGridTableStyle.DataGrid.IsSelected(rowNum) == true) {
				backBrush	= new SolidBrush(base.DataGridTableStyle.SelectionBackColor);
				foreBrush	= new SolidBrush(base.DataGridTableStyle.SelectionForeColor);
			}

			// Handle align to right.
			if (alignToRight == true) {
				format.FormatFlags	= StringFormatFlags.DirectionRightToLeft;
			}

			// Handle alignment.
			switch (this.Alignment) {
				case HorizontalAlignment.Left:
					format.Alignment = StringAlignment.Near;
					break;
				case HorizontalAlignment.Right:
					format.Alignment = StringAlignment.Far;
					break;
				case HorizontalAlignment.Center:
					format.Alignment = StringAlignment.Center;
					break;
			}

			// Paint.
			format.FormatFlags		= StringFormatFlags.NoWrap;
			g.FillRectangle(backBrush, rect);
			rect.Offset(0, 2);
			rect.Height -= 2;
			g.DrawString(text, this.DataGridTableStyle.DataGrid.Font, foreBrush, rect, format);
			format.Dispose();
		} // PaintText

	} // DataGridComboBoxColumn


	public class LookupComboBox : ComboBox
	{
		/// <summary>
		/// OnKeyPress event component checks that user entered a correct symbol, 
		/// which corresponds to item in item list. If symbol is correct the field takes value true, otherwise - false
		/// Field is used when allowTypeAllSymbols is true. 
		/// </summary>
		private bool isTextCorrect;

		private bool allowTypeAllSymbols = true;

		public LookupComboBox() : base()
		{

		}

		/// <summary>
		/// If the property is true you can type any symbols in combo-box textbox. 
		/// The item will be selected according to first correctly entered symbols. 
		/// For example, combobox holds "Item 1", "Item 2", "Test 1", "Test 2", "Combo", "Box"
		/// If you enter "it" the Item 1 will be selected. Then if you enter "itm". 
		/// The "Item 1" still will be selected. You can continue to enter any amount of symbols. 
		/// 
		/// If AllTypeAllSymbols is false. You will be able to enter only those symbols, 
		/// that are defined in strings of Items (or bound DateSource) propert�. For this example 
		/// you will be able to enter only i, t, c, b as a first symbol. If you enter "i" as a 
		/// first symbol � "Item 1" will be automatically selected, the second symbol can be 
		/// only "t", you will be not able to enter any other symbol. "Item 2" will be selected, 
		/// until you type the whole string "Item 2". 
		/// </summary>
		[Browsable(true)]
		public bool AllowTypeAllSymbols
		{
			set
			{
				allowTypeAllSymbols = value;
			}
			get
			{
				return allowTypeAllSymbols;
			}
		}

		protected override void OnKeyPress(KeyPressEventArgs e)
		{
			if (!allowTypeAllSymbols)
			{
				isTextCorrect = false;
				if (!char.IsControl(e.KeyChar))
				{
					string actual = this.Text.Substring(0, SelectionStart) + e.KeyChar;

					// Find the first match for the typed value.
					int index = this.FindString(actual);

					// if correspondig item is found set isTextCorrect property to true.
					if (index > -1)
					{
						isTextCorrect = true;
						base.OnKeyPress(e);
					}
					else
						e.Handled = true;
				}

			}
		}

		protected override void OnKeyUp(KeyEventArgs e)
		{
			int index;
			string actual;
			string found;

			// Do nothing for certain keys, such as navigation keys.
			if ((e.KeyCode == Keys.Back) ||
				(e.KeyCode == Keys.Left) ||
				(e.KeyCode == Keys.Right) ||
				(e.KeyCode == Keys.Up) ||
				(e.KeyCode == Keys.Down) ||
				(e.KeyCode == Keys.Delete) ||
				(e.KeyCode == Keys.PageUp) ||
				(e.KeyCode == Keys.PageDown) ||
				(e.KeyCode == Keys.Home) ||
				(e.KeyCode == Keys.End) ||
				(e.KeyCode == Keys.ShiftKey) ||
				(e.KeyCode == Keys.Tab) ||
				(e.KeyCode == Keys.Menu))
			{
				return;
			}

			// Store the actual text that has been typed.
			actual = this.Text.Substring(0, this.SelectionStart);

			// Find the first match for the typed value.
			index = this.FindString(actual);

			// If current text is correct
			if (index > -1)
			{
				if ((!allowTypeAllSymbols && isTextCorrect) || (allowTypeAllSymbols))
				{
					// If data are bound to combo-box
					if (this.DataSource != null && this.DisplayMember != "")
						found = ((DataRowView)(this.Items[index]))[this.DisplayMember].ToString();
					else
						found = this.Items[index].ToString();

					// Select this item from the list.
					this.SelectedIndex = index;
					this.Text = found;

					// Select the portion of the text that was automatically
					// added so that additional typing replaces it.
					this.SelectionStart = actual.Length;
					this.SelectionLength = found.Length;
					base.OnKeyUp(e);
				}
			}
		}








	}
}