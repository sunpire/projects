//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: SelectionControl.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
	public enum SelectionControlType
	{
		FilterEditor,
		ConfigEditor,
		SiteTypeEditor
	}

	/// <summary>
	/// Summary description for SelectionControl.
	/// </summary>
	public class SelectionControl : System.Windows.Forms.UserControl
	{
		private SelectionControlType m_type;
		private bool m_editable = false;
		private EditObject m_editObject = new EditObject();
		private BaseSelectionEditorControl m_editor = null;
		private Form m_editorForm;

		public event EventHandler SelectionChangeCommitted;

		private class EditObject
		{
			public string Name
			{
				get
				{
					return "<< New >>";
				}
			}
		}

		private System.Windows.Forms.ComboBox selectorComboBox;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public SelectionControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			this.m_editorForm = new Form();
			this.m_editorForm.Text = this.SelectionType.ToString();
		}

		public SelectionControlType SelectionType
		{
			get
			{
				return this.m_type;
			}
			set
			{
				this.m_type = value;
			}
		}

		public object SelectedItem
		{
			get
			{
				if(this.selectorComboBox.SelectedItem != (object)this.m_editObject)
				{
					return this.selectorComboBox.SelectedItem;
				}
				else
				{
					return null;
				}
			}
			set
			{
				if(value != null && this.selectorComboBox.Items.Contains(value))
				{
					this.selectorComboBox.SelectedItem = value;
				}
			}
		}

		public BaseSelectionEditorControl Editor
		{
			get
			{
				return this.m_editor;
			}
			set
			{
				this.m_editor = value;
				if(value != null)
				{
					this.m_editorForm.Controls.Clear();
					this.m_editorForm.Controls.Add(value);
//					value.EditorDone += new EventHandler(this.EditorDone);
//					value.EditorCancel += new EventHandler(this.EditorCancel);
					value.Visible = true;
				}
			}
		}

		public bool Editable
		{
			get
			{
				return this.m_editable;
			}
			set
			{
				if(this.m_editable != value)
				{
					if(value)
					{
						this.selectorComboBox.Items.Add(this.m_editObject);
					}
					else
					{
						this.selectorComboBox.Items.Remove(this.m_editObject);
					}
					this.m_editable = value;
				}
			}
		}

		// TODO: Is this the right way to lock the control's height???
		protected override void OnResize(EventArgs e)
		{
			base.OnResize(e);
			this.Height = 21;
		}

		// TODO: Implement loading .filter or .config files from filesystem
		private void InitComboBox()
		{
			throw new NotImplementedException("Populating ComboBox from filesystem not implemented!");
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.selectorComboBox = new System.Windows.Forms.ComboBox();
			this.SuspendLayout();
			// 
			// selectorComboBox
			// 
			this.selectorComboBox.DisplayMember = "Name";
			this.selectorComboBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.selectorComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.selectorComboBox.Name = "selectorComboBox";
			this.selectorComboBox.Size = new System.Drawing.Size(144, 21);
			this.selectorComboBox.TabIndex = 0;
			this.selectorComboBox.SelectionChangeCommitted += new System.EventHandler(this.selectorComboBox_SelectionChangeCommitted);
			// 
			// SelectionControl
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.selectorComboBox});
			this.Name = "SelectionControl";
			this.Size = new System.Drawing.Size(144, 21);
			this.ResumeLayout(false);

		}
		#endregion

		private void selectorComboBox_SelectionChangeCommitted(object sender, System.EventArgs e)
		{
			if(this.Editable == true && this.selectorComboBox.SelectedItem == (object)this.m_editObject && this.Editor != null)
			{
				//this.m_editorForm.ShowDialog();
			}
			if(this.SelectionChangeCommitted != null)
			{
				this.SelectionChangeCommitted(this.SelectedItem, e);
			}
		}

		private void EditorCancel(object sender, EventArgs e)
		{
			this.m_editorForm.DialogResult = DialogResult.Cancel;
		}

		private void EditorDone(object sender, EventArgs e)
		{
			this.m_editorForm.DialogResult = DialogResult.OK;
			//this.InitComboBox();
			if(this.Editor.CurrentSelectedObject != null &&
				!this.selectorComboBox.Items.Contains(this.Editor.CurrentSelectedObject))
			{
				this.selectorComboBox.Items.Insert(0, this.Editor.CurrentSelectedObject);
			}
		}
	}
}
