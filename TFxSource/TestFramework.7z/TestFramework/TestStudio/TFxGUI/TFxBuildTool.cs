using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.IO;
using System.Xml;
using System.Windows.Forms;

namespace Expedia.Test.Framework 
{
    public partial class TFxBuildTool : RepositoryDelegateUI
    {
        DirectoryInfo m_dirInfo;
        Hashtable projguids = new Hashtable();
        

        public TFxBuildTool()
        {
            InitializeComponent();
        }

        private void pleaseSelectFolderToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (this.folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                if (this.folderBrowserDialog.SelectedPath != "")
                {
                    this.textBoxDestinationFolder.Text = this.folderBrowserDialog.SelectedPath;
                    m_dirInfo = new DirectoryInfo(this.folderBrowserDialog.SelectedPath);
                    FileInfo[] fileNames = m_dirInfo.GetFiles("*.csproj", SearchOption.AllDirectories);
                    ArrayList files = new ArrayList(fileNames);
                    files.Sort(new FileInfoComparer());
                    

                    this.listBoxAllFiles.Items.Clear();
                    
                    foreach (FileInfo file in files)
                    {
                        this.listBoxAllFiles.Items.Add(file);
                    }

                }
            }
        }

        private void TFxBuildTool_Click(object sender, EventArgs e)
        {

        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            ArrayList selectedItems = new ArrayList();
            if (this.listBoxAllFiles.SelectedItems != null)
            {

                foreach (FileInfo item in this.listBoxAllFiles.SelectedItems)
                {
                    this.listBoxSelectedFiles.Items.Add(item);
                    selectedItems.Add(item);


                }

                foreach (FileInfo item in selectedItems)
                {
                    this.listBoxAllFiles.Items.Remove(item);

                }


            }
        }


        private void buttonAddAll_Click(object sender, EventArgs e)
        {
            ArrayList items = new ArrayList();
            if (this.listBoxAllFiles.Items != null)
            {
                foreach (FileInfo item in this.listBoxAllFiles.Items)
                {
                    this.listBoxSelectedFiles.Items.Add(item);
                    items.Add(item);
                }

                foreach (FileInfo item in items)
                {
                    this.listBoxAllFiles.Items.Remove(item);
                }
            }
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            ArrayList selectedItems = new ArrayList();

            if (this.listBoxSelectedFiles.SelectedItems != null)
            {

                foreach (FileInfo item in this.listBoxSelectedFiles.SelectedItems)
                {
                    this.listBoxAllFiles.Items.Add(item);
                    selectedItems.Add(item);
                }

                foreach (FileInfo item in selectedItems)
                {
                    this.listBoxSelectedFiles.Items.Remove(item);

                }

            }

        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            ArrayList selectedItems = new ArrayList();

            foreach (FileInfo item in this.listBoxSelectedFiles.Items)
            {
                this.listBoxAllFiles.Items.Add(item);
                selectedItems.Add(item);

            }

            foreach (FileInfo item in selectedItems)
            {
                this.listBoxSelectedFiles.Items.Remove(item);

            }

        }

        private void buttonDestinationFolder_Click(object sender, EventArgs e)
        {
            if (this.folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                if (this.folderBrowserDialog.SelectedPath != "")
                {
                    this.textBoxDestinationFolder.Text = this.folderBrowserDialog.SelectedPath;
                }

            }

        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            string fileName = "";

            if (this.textBoxFileName.Text == "")
            {
                this.NotifyUI(InfoNotification.GetInfoNotification(SeverityType.Error, "Please specify file name"));
                return;
            }

            if (this.textBoxDestinationFolder.Text == "")
            {
                this.NotifyUI(InfoNotification.GetInfoNotification(SeverityType.Error, "Please specify destination folder"));
                return;
            }

            if (this.listBoxSelectedFiles.Items == null || this.listBoxSelectedFiles.Items.Count == 0)
            {
                this.NotifyUI(InfoNotification.GetInfoNotification(SeverityType.Error, "Please select projects to include in new solution"));
                return;
            }

            try
            {
                fileName = this.textBoxDestinationFolder.Text + "\\" + this.textBoxFileName.Text;
                if(!fileName.EndsWith(".sln"))
                    fileName = fileName +".sln";
                if (File.Exists(fileName))
                {
                    //confirm overwrite
                    if (MessageBox.Show(fileName + " already exists. Do you want to replace it?",
                                            "Warning",
                                            MessageBoxButtons.YesNo,
                                            MessageBoxIcon.Exclamation) == DialogResult.No)
                    {
                        return;
                    }
                }
                FileStream file = new FileStream(fileName, FileMode.Create);
                StreamWriter sw = new StreamWriter(file);
                this.GenerateSolutionFile(sw);              
                sw.Close();

                this.NotifyUI(InfoNotification.GetInfoNotification(SeverityType.Info, String.Format("File {0} saved successfully", fileName)));
            }
            catch (Exception exp)
            {
                this.NotifyUI(InfoNotification.GetInfoNotification(SeverityType.Error, exp.Message));

            }

           

        }

        private void GenerateSolutionFile(StreamWriter sw)
        {
            sw.WriteLine("Microsoft Visual Studio Solution File, Format Version 9.00");
            sw.WriteLine("# Visual Studio 2005");

            this.GenerateProject(sw);
            this.GenerateGlobalSection(sw);
            
        }

        private void GenerateProject(StreamWriter sw)
        {
            string project = "";
            string projectName = "";
            string guid = "FAE04EC0-301F-11D3-BF4B-00C04F79EFBC";
            string fileName = "";
            string relativePath = "";
            string fileGuid = "";
            string identStr = "";
            string farIdentStr = "";

            FileInfo[] files = m_dirInfo.GetFiles();

            Hashtable selectedFiles = new Hashtable();
            foreach (FileInfo item in this.listBoxSelectedFiles.Items)
            {
                selectedFiles.Add(item.Name, item);
            }

            foreach (FileInfo item in this.listBoxSelectedFiles.Items)
            {
                projectName = "Project(\"{" + guid + "}\")";
                fileName = this.getFileName(item.Name);
                relativePath = this.getRelativePath(item.FullName,textBoxDestinationFolder.Text);
                fileGuid = this.getGuid(item.FullName);

                project = projectName + "=" + fileName +relativePath+ fileGuid;
                sw.WriteLine(project);

                // Find dependencies
                identStr = new string(' ', 8);
                farIdentStr = identStr + new string(' ', 8);

                ArrayList dependencies = this.getDependencies(item.FullName);
                if (dependencies != null)
                {
                    sw.WriteLine(identStr + "ProjectSection(ProjectDependencies) = postProject");
                    foreach (String dep in dependencies)
                    {
                        if (selectedFiles.Contains(dep + ".csproj"))
                        {
                            String depGuid = this.getGuid(((FileInfo)selectedFiles[dep + ".csproj"]).FullName);
                            depGuid = depGuid.Remove(0, 1);
                            depGuid = depGuid.Remove(depGuid.Length - 1);
                            sw.WriteLine(farIdentStr + depGuid + " = " + depGuid);
                        }
                    }
                    sw.WriteLine(identStr + "EndProjectSection");
                }
               
                sw.WriteLine("EndProject");
            }
            
        }

        private void GenerateProjectSection(StreamWriter sw)
        {
            
        }

        private void GenerateGlobalSection(StreamWriter sw)
        {
            string identStr="";
            string farIdentStr = "";
            sw.WriteLine("Global");
            
            identStr = new string(' ',8);
            sw.WriteLine(identStr + "GlobalSection(SolutionConfigurationPlatforms) = preSolution");

            farIdentStr = identStr + new string(' ', 8);
            sw.WriteLine(farIdentStr + "Debug|.NET = Debug|.NET");
            sw.WriteLine(farIdentStr + "Debug|Any CPU = Debug|Any CPU");
            sw.WriteLine(farIdentStr + "Debug|Mixed Platforms = Debug|Mixed Platforms");
            sw.WriteLine(farIdentStr + "Release|.NET = Release|.NET");
            sw.WriteLine(farIdentStr + "Release|Any CPU = Release|Any CPU");
            sw.WriteLine(farIdentStr + "Release|Mixed Platforms = Release|Mixed Platforms");

            sw.WriteLine(identStr + "EndGlobalSection");

            sw.WriteLine(identStr + "GlobalSection(ProjectConfigurationPlatforms) = postSolution");

            String[] suffix = {   
                                "Debug|.NET.ActiveCfg = Debug|Any CPU",
                                "Debug|Any CPU.ActiveCfg = Debug|Any CPU",
                                "Debug|Any CPU.Build.0 = Debug|Any CPU",
                                "Debug|Mixed Platforms.ActiveCfg = Debug|Any CPU",
                                "Debug|Mixed Platforms.Build.0 = Debug|Any CPU",
                                "Release|.NET.ActiveCfg = Release|Any CPU",
                                "Release|Any CPU.ActiveCfg = Release|Any CPU",
                                "Release|Any CPU.Build.0 = Release|Any CPU",
                                "Release|Mixed Platforms.ActiveCfg = Release|Any CPU",
                                "Release|Mixed Platforms.Build.0 = Release|Any CPU"
                              };

            FileInfo[] files = m_dirInfo.GetFiles();

            foreach (FileInfo item in this.listBoxSelectedFiles.Items)
            {
                foreach (String s in suffix)
                {
                    String guid = projguids[item.FullName] as String;
                    if (guid == null)
                    {
                        guid = getGuid(item.FullName);
                    }
                    String line = guid + "." + s;
                    sw.WriteLine(farIdentStr + line);
                }
            }
            sw.WriteLine(identStr + "EndGlobalSection");

            sw.WriteLine(identStr + "GlobalSection(SolutionProperties) = preSolution");
            sw.WriteLine(farIdentStr + "HideSolutionNode = FALSE");
            sw.WriteLine(identStr + "EndGlobalSection");
	

            sw.WriteLine("EndGlobal");
            
            


        }

        private string getFileName(string file)
        {
            string fileName = "";
            bool firstTime = true;
            string[] tokens = file.Split('.');

            for (int i = 0; i < tokens.Length - 1; i++)
            {
                if (!firstTime)
                {
                    fileName = fileName + "." + tokens[i];
                }
                else
                {
                    fileName = fileName + tokens[i];
                    firstTime = false;
                }

            }

            return "\"" + fileName + "\",";
        }

        private string getGuid(string fileName)
        {
            // check the hash table first
            if (projguids.Contains(fileName))
            {
                return "\"" + projguids[fileName] + "\"";
            }

            XmlDocument sourceXml = new XmlDocument();
            sourceXml.Load(fileName);

            String guid;
            XmlNode xmlNode = sourceXml.GetElementsByTagName("ProjectGuid")[0];
            if (xmlNode != null)
            {
                guid = xmlNode.InnerText;
            }
            else
            {
                //often ProjectGuid is an attribute of the CSHARP tag
                xmlNode = sourceXml.GetElementsByTagName("CSHARP")[0];
                guid = xmlNode.Attributes["ProjectGuid"].Value;
            }

            if (xmlNode != null)
            {
                //add to hash table
                projguids.Add(fileName, guid);
                    
                return "\""+guid+"\"";
            }
            return null;
        }

        private string getRelativePath(string projFilePath, string slnFilePath)
        {   

            string projName = projFilePath.Substring(projFilePath.LastIndexOf('\\')+1);
            string relPath = "";
            projFilePath = projFilePath.Remove(projFilePath.LastIndexOf('\\'));
            
            while (true)
            {
                if (projFilePath.Equals(slnFilePath))
                {
                    //The directories are the same
                    return "\"" + relPath + "\\" + projName + "\",";
                }
                else if (projFilePath.Contains(slnFilePath))
                {
                    //projFile is deeper in tree
                    relPath = relPath + projFilePath.Substring(slnFilePath.Length+1);
                    projFilePath = slnFilePath;
                }
                else
                {
                    //projFile is shallower in tree or files are in different branches
                    relPath = "..\\" + relPath;
                    slnFilePath = slnFilePath.Remove(slnFilePath.LastIndexOf('\\'));
                }

            }
            
        }

        private ArrayList getDependencies(string fileName)
        {
            XmlDocument sourceXml = new XmlDocument();
            sourceXml.Load(fileName);
            XmlNodeList nodes = sourceXml.GetElementsByTagName("Reference");

            if (nodes != null)
            {
                ArrayList list = new ArrayList();
                foreach (XmlNode xnode in nodes)
                {
                    list.Add(xnode.Attributes["Include"].Value);
                }
                return list;
            }
            return null;
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("BuildToolHelp.htm");                                        
            
        }


        private class FileInfoComparer : IComparer
        {
            #region IComparer Members

            public int Compare(object x, object y)
            {
                FileInfo file1 = x as FileInfo;
                FileInfo file2 = y as FileInfo;

                return (new CaseInsensitiveComparer().Compare(
                        file1 == null ? null : file1.Name,
                        file2 == null ? null : file2.Name));
            }

            #endregion
        }
    }

}
