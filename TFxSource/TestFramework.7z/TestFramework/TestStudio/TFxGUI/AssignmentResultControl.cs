using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for AssignmentResultControl.
	/// </summary>
	public class AssignmentResultControl : Expedia.Test.Framework.RepositoryDelegateUI
	{

		private Expedia.Test.Framework.ScenarioResultControl scenarioResultControl1;
		private Expedia.Test.Framework.AssignmentLogShortResultControl assignmentLogShortResultControl1;
		private System.Windows.Forms.Splitter splitter1;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public AssignmentResultControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitForm call
			scenarioResultControl1.OnScenarioResultChanged += new ScenarioResultChangeHandler(this.ScenarioResultChange);

		}

		


		void ScenarioResultChange(ScenarioResult result)
		{
			if (result !=null)
			{
				assignmentLogShortResultControl1.FailureReason = result.FailureReason + "\r\n" + result.FailureDetail;
			}
		}

		public void BindData(AssignmentResult result, ILog longLog)
		{
            
			UserSettingRequest request = new UserSettingRequest(RepositoryRequestType.Get);
			this.GetData(request);
                      
            TestStudioUsersSetting userSetting = request.Settings as TestStudioUsersSetting;

            //Clear all the old log first
            assignmentLogShortResultControl1.Clear();
            assignmentLogShortResultControl1.BindData(result, longLog, userSetting != null && userSetting.DisplayLogType == ResultLogType.ShortLog);
            scenarioResultControl1.BindData(result);
			
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.scenarioResultControl1 = new Expedia.Test.Framework.ScenarioResultControl();
			this.assignmentLogShortResultControl1 = new Expedia.Test.Framework.AssignmentLogShortResultControl();
			this.splitter1 = new System.Windows.Forms.Splitter();
			this.SuspendLayout();
			// 
			// scenarioResultControl1
			// 
			this.scenarioResultControl1.Dock = System.Windows.Forms.DockStyle.Right;
			this.scenarioResultControl1.Location = new System.Drawing.Point(832, 0);
			this.scenarioResultControl1.Name = "scenarioResultControl1";
			this.scenarioResultControl1.Size = new System.Drawing.Size(200, 496);
			this.scenarioResultControl1.TabIndex = 1;
			// 
			// assignmentLogShortResultControl1
			// 
			this.assignmentLogShortResultControl1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.assignmentLogShortResultControl1.FailureReason = "";
			this.assignmentLogShortResultControl1.Location = new System.Drawing.Point(0, 0);
			this.assignmentLogShortResultControl1.Name = "assignmentLogShortResultControl1";
			this.assignmentLogShortResultControl1.Size = new System.Drawing.Size(832, 496);
			this.assignmentLogShortResultControl1.TabIndex = 2;
			// 
			// splitter1
			// 
			this.splitter1.Dock = System.Windows.Forms.DockStyle.Right;
			this.splitter1.Location = new System.Drawing.Point(829, 0);
			this.splitter1.Name = "splitter1";
			this.splitter1.Size = new System.Drawing.Size(3, 496);
			this.splitter1.TabIndex = 3;
			this.splitter1.TabStop = false;
			// 
			// AssignmentResultControl
			// 
			this.Controls.Add(this.splitter1);
			this.Controls.Add(this.assignmentLogShortResultControl1);
			this.Controls.Add(this.scenarioResultControl1);
			this.Name = "AssignmentResultControl";
			this.Size = new System.Drawing.Size(1032, 496);
			this.ResumeLayout(false);

		}
		#endregion

		public override void PersistUIState(Profile profile)
		{
			if(profile != null)
			{
				profile.TestRunExecutingSettings.splitterResultRight  = new SplitterState(this.scenarioResultControl1); 		
			}

		}


		//Load from the File, called by the TestRunEditor.cs when the mode is executing
		public void LoadUIState(Profile profile)
		{		
			SplitterState currentSplitter = null;
			
			if(profile != null && profile.TestRunExecutingSettings != null)
			{
				currentSplitter = profile.TestRunExecutingSettings.splitterResultRight;
				
				if(currentSplitter != null)
				{
					this.scenarioResultControl1.Size = new Size(currentSplitter.ControlToHideSize.Width, currentSplitter.ControlToHideSize.Height); 
					this.scenarioResultControl1.Location = new Point(currentSplitter.splitterLocation.X, currentSplitter.splitterLocation.Y);			

				}
				
			}
			
		}


	}
}
