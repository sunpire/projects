using System;
using System.Data;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for AssignmentBulkEditForm.
	/// </summary>
	public class AssignmentBulkEditForm : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.Button buttonDone;
		private System.Windows.Forms.Button buttonCancel;

		private ArrayList m_configNames;

		public ArrayList ConfigNames
		{
			get
			{
				return m_configNames;
			}
			set
			{
				m_configNames	 = value;
				LoadDataGrid();
			}
		}

		private System.Windows.Forms.Panel panelTop;
		private System.Windows.Forms.Panel panelBottom;
		private System.Windows.Forms.DataGrid dataGridBulkEdit;

		

		private Hashtable m_updatedConfigValues = new Hashtable();
		public Hashtable UpdatedConfigValues
		{
			get
			{
				return m_updatedConfigValues;
			}			
		}

		public AssignmentBulkEditForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.buttonDone = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.panelTop = new System.Windows.Forms.Panel();
			this.panelBottom = new System.Windows.Forms.Panel();
			this.dataGridBulkEdit = new System.Windows.Forms.DataGrid();
			this.panelTop.SuspendLayout();
			this.panelBottom.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridBulkEdit)).BeginInit();
			this.SuspendLayout();
			// 
			// buttonDone
			// 
			this.buttonDone.Location = new System.Drawing.Point(24, 8);
			this.buttonDone.Name = "buttonDone";
			this.buttonDone.TabIndex = 0;
			this.buttonDone.Text = "Done";
			this.buttonDone.Click += new System.EventHandler(this.buttonDone_Click);
			// 
			// buttonCancel
			// 
			this.buttonCancel.Location = new System.Drawing.Point(176, 8);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.TabIndex = 1;
			this.buttonCancel.Text = "Cancel";
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// panelTop
			// 
			this.panelTop.Controls.Add(this.dataGridBulkEdit);
			this.panelTop.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panelTop.Location = new System.Drawing.Point(0, 0);
			this.panelTop.Name = "panelTop";
			this.panelTop.Size = new System.Drawing.Size(304, 262);
			this.panelTop.TabIndex = 3;
			// 
			// panelBottom
			// 
			this.panelBottom.Controls.Add(this.buttonDone);
			this.panelBottom.Controls.Add(this.buttonCancel);
			this.panelBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panelBottom.Location = new System.Drawing.Point(0, 214);
			this.panelBottom.Name = "panelBottom";
			this.panelBottom.Size = new System.Drawing.Size(304, 48);
			this.panelBottom.TabIndex = 4;
			// 
			// dataGridBulkEdit
			// 
			this.dataGridBulkEdit.CaptionText = "Configs";
			this.dataGridBulkEdit.DataMember = "";
			this.dataGridBulkEdit.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGridBulkEdit.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGridBulkEdit.Location = new System.Drawing.Point(0, 0);
			this.dataGridBulkEdit.Name = "dataGridBulkEdit";
			this.dataGridBulkEdit.Size = new System.Drawing.Size(304, 262);
			this.dataGridBulkEdit.TabIndex = 0;
			// 
			// AssignmentBulkEditForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(304, 262);
			this.Controls.Add(this.panelBottom);
			this.Controls.Add(this.panelTop);
			this.Name = "AssignmentBulkEditForm";
			this.Text = "Bulk Edit ";
			this.panelTop.ResumeLayout(false);
			this.panelBottom.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dataGridBulkEdit)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion




		private void LoadDataGrid()
		{
			
			DataTable dt = null;


			if((this.m_configNames != null)&&(this.m_configNames.Count > 0))
			{
				dt = new DataTable("BulkEditValues");				
				DataColumn colConfigName = dt.Columns.Add("ConfigName");			
				DataColumn colConfigValue = dt.Columns.Add("ConfigValue");

				colConfigName.ReadOnly = true;
				colConfigValue.ReadOnly = false;
				

				foreach(string str in this.m_configNames)
				{
					DataRow row = dt.NewRow();
					row["ConfigName"] = str;

					dt.Rows.Add(row);
				}
				
				dt.AcceptChanges();
				dt.DefaultView.AllowEdit = true;
				dt.DefaultView.AllowNew = false;
				dt.DefaultView.AllowDelete = true;					
			
				this.dataGridBulkEdit.DataSource = dt;			
				
			}
		}


		private void buttonDone_Click(object sender, System.EventArgs e)
		{
			DataTable dt = this.dataGridBulkEdit.DataSource as DataTable;
			if(dt != null)
			{
				foreach(DataRow row in dt.Rows)
				{
					if(row["ConfigValue"] != System.DBNull.Value)
					{
						this.m_updatedConfigValues.Add(row["ConfigName"].ToString(),row["ConfigValue"].ToString());
					}
				}
			}		
			
			this.Close();
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			this.Close();
		
		}

		
	}
}
