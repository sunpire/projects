using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Xml;
using System.Xml.Serialization;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TestStudioUsersSetting.
	/// </summary>
	[Serializable]
	public class TestStudioUsersSetting: UsersSetting
	{
		public TestStudioUsersSetting()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		bool m_browserAutoMinimize=false;
		int m_numberofClients=1;	
	
		
		string  m_logLevel = "Default";		
		
		SeverityType  m_severityLevel = SeverityType.Error;
		Mode m_applicationMode = Mode.Simple;
		AssignmentStatusColumnType m_statusColumn1 = AssignmentStatusColumnType.Status;
		AssignmentStatusColumnType m_statusColumn2 = AssignmentStatusColumnType.FailureReason;

		string m_defaultLabRunName = "default";
		string m_defaultbuildName = "default";
		ResultLogType m_displayLogType;
		string m_recorderUrl = @"http://www.expedia.com";
		string m_sourcePath = @"c:\src\tfx\automation\expweb\";
		string m_sdFile = @"c:\src\tfx\sd.ini";
		string m_dllName = "ExpWeb";

		[Category("Recorder Settings"),
		Description("SD File")]
		public string SDFile
		{
			get
			{
				return m_sdFile;
			}
			set
			{
				m_sdFile = value;

			}
		}	

		[Category("Recorder Settings"),
		Description("Dll Name")]
		public string DLLName
		{
			get
			{
				return m_dllName;
			}
			set
			{
				m_dllName = value;

			}
		}


		[Category("Recorder Settings"),
		Description("Recorder URL")]
		public string RecorderURL
		{
			get
			{
				return m_recorderUrl;
			}
			set
			{
				m_recorderUrl = value;

			}
		}	

		[Category("Recorder Settings"),
		Description("Source Path")]
		public string SourcePath
		{
			get
			{
				return m_sourcePath;
			}
			set
			{
				if (!value.EndsWith("\\") && !value.EndsWith("/")) {
					m_sourcePath = value + "\\";
				}
				else 
				{
					m_sourcePath = value;
				}
			}
		}	


		[Category("Web Automation Settings"),
		Description("Browser Settings")]
		public bool BrowserAutoMinimize
		{
			get
			{
				return m_browserAutoMinimize;
			}

			set
			{
				m_browserAutoMinimize = value;
			}
		}		

		[Category("Test Execution  Settings"),
		Description("Number of Clients")]
		public int ClientCount
		{
			get
			{
				return m_numberofClients;
			}
			set
			{
				m_numberofClients = value;

			}
		}


		

		[Category("Log Settings"),
		Description("Log Level Type")]
		public string LogLevel
		{
			get
			{
				return m_logLevel;
			}
			set
			{
				m_logLevel = value;

			}
		}

		[Category("Log Settings"),
		Description("Display Log")]
		public ResultLogType DisplayLogType
		{
			get
			{
				return m_displayLogType;
			}
			set
			{
				m_displayLogType = value;

			}
		}

		[Category("Result Settings"),
		Description("Result Severity Type")]
		public SeverityType SeverityLevel
		{
			get
			{
				return m_severityLevel;
			}
			set
			{
				m_severityLevel = value;

			}
		}
	
		[Category("Result Settings"),
		Description("Assignment Status Column 1")]
		public AssignmentStatusColumnType StatusColumn1
		{
			get
			{
				return m_statusColumn1;
			}
			set
			{
				m_statusColumn1 = value;

			}
		}

		[Category("Result Settings"),
		Description("Assignment Status Column 2")]
		public AssignmentStatusColumnType StatusColumn2
		{
			get
			{
				return m_statusColumn2;
			}
			set
			{
				m_statusColumn2 = value;

			}
		}	




		[Category("Application Settings"),
		Description("Simple/Advanced")]
		public Mode ApplicationMode
		{
			get
			{
				return m_applicationMode;
			}
			set
			{
				m_applicationMode = value;

			}
		}

		[Category("Application Settings"),
		Description("Simple/Advanced")]
		public string DefaultLabRunName
		{
			get
			{
				return m_defaultLabRunName;
			}
			set
			{
				m_defaultLabRunName = value;
			}
		}


		[Category("Application Settings"),
		Description("Simple/Advanced")]
		public string DefaultBuildName
		{
			get
			{
				return m_defaultbuildName;
			}
			set
			{
				m_defaultbuildName = value;
			}
		}
	}
}
