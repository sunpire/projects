//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: TestPlayerRepository.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//==========================================================================
using System;
using System.Collections;

namespace Expedia.Test.Framework
{

	public class TestDriverRepository : Repository
	{

		public FileRepository FileRepository;
		public class LoadModuleRequest : RepositoryRequest
		{
		
			public TestBuildModule[] TestModule;
			public string BuildName;
			
			

			public LoadModuleRequest(TestBuildModule[] testModule, RepositoryRequestType requestType) : base(requestType)
			{
				this.TestModule = testModule;
			}			
			
		}

		
		TestBuild m_build;
		TFxTeam m_team;

		public TestDriverRepository()
		{
			m_build = null;		

			m_team = new TFxTeam();
			m_team.Manager = new TFxUser();
			m_team.Manager.IsManager = true;
			m_team.Manager.Name = "TP_Manager";

			m_team.Clients = new ClientCollection();
			LocalClient client = new LocalClient(15, null);
			client.Name = "TP_Client";
			m_team.Clients.Add(client);
		}

		
		

		public void ProcessRequest(TestCaseListRequest testList)
		{
			ArrayList areas = new ArrayList();
			CreateTestBuild(testList.BuildName);
			
			if (m_build !=null && m_build.Modules !=null && m_build.Modules.Length > 0)
			{
			
				TestArea[] roots = TFxEngine.Load( m_build );
				foreach(TestArea testArea in roots)
				{
					foreach(TestInfo ti in testArea.GetAllTestCases())
					{
						TestArea rootArea = FindTestArea(areas, ti.Path, testArea.FullName);
						if(rootArea != null)
						{
							TestArea area = rootArea.CreateFindTestSuite(ti.Path);
							area.Tests.Add(ti.Name, ti);

						}
					}

				}
				testList.TestAreaRoots = (TestArea[]) areas.ToArray(typeof(TestArea));

			}

		}

        /// <summary>
        /// Comments: 	Changed the related test id from int to GUID
        /// </summary>
        /// <param name="request"></param>
		public void ProcessRequest(RepositorySyncTestArea request)
		{
			
			TestArea LocalTests = request.TestAreaToSync;
				
			string moduleName = this.m_build.Modules[0].ModuleName;

			TestBuildModuleRequest buildModuleRequest = new TestBuildModuleRequest(RepositoryRequestType.Get);
			buildModuleRequest.ReleaseName = request.Release;
			buildModuleRequest.BuildType = BuildType.Latest;
			buildModuleRequest.ModuleName = moduleName;
			request.RightRepository.ExecuteRequest(buildModuleRequest);

			TestBuildRequest testbuildRequest = new TestBuildRequest(RepositoryRequestType.Get);
			testbuildRequest.Release = request.Release;
			testbuildRequest.BuildType = BuildType.Latest;
			request.RightRepository.ExecuteRequest(testbuildRequest);

			if (testbuildRequest.Build == null)
			{
				System.Windows.Forms.MessageBox.Show("There is no build to published to!");
				return;
			}
			if (buildModuleRequest.Module !=null && buildModuleRequest.Module.BuildName == testbuildRequest.Build.Name)
			{
				System.Windows.Forms.MessageBox.Show("Database is up-to-date. No publishing required!");
				return;
			}

			TestArea TFxTests = null;

			if (buildModuleRequest.Module !=null)
			{
				// Load the test area from the database
				TestCaseListRequest allTestRequest = new TestCaseListRequest(RepositoryRequestType.Get);
				allTestRequest.ModuleName = moduleName;
				allTestRequest.BuildName = buildModuleRequest.Module.BuildName;
				request.RightRepository.ExecuteRequest(allTestRequest);
			
			
				if (allTestRequest.TestAreaRoots !=null && allTestRequest.TestAreaRoots.Length > 0)
				{
					TFxTests = allTestRequest.TestAreaRoots[0];
				}
			}

			// Set up our resolver GUI
			ResolverGUI resolver = new ResolverGUI();
			resolver.TreeLabel1 = String.Format("Test Module DLL ({0})", moduleName);
			//resolver.TreeLabel2 = String.Format("TFx Database ({0}\\{1})", TFx.ServerName, TFx.DatabaseName);
				
			// Create the publishing object
			TestPublish publishObject = new TestPublish(LocalTests, TFxTests, resolver);

			resolver.Resolve(publishObject);
			resolver.Focus();

			RepositoryChangelist list = new RepositoryChangelist();
			bool deleted = false;
			bool added = false;

			foreach (TestCaseDifference difference in publishObject.Differences.Differences)
			{
				if (difference.DifferenceType == TestCaseDifferenceType.NoMatchFound
					&& difference.TestCase2 == null)
				{
					// new test case
					list.Add(new TestCaseChange(RepositoryRequestType.Create, difference.TestCase1));
					added = true;
				}
				else if (difference.DifferenceType == TestCaseDifferenceType.NoMatchFound
					&& difference.TestCase1 == null)
				{
					// deleted test cases
					// don't have to do anything
					deleted = true;
				}
				else if (difference.TestCase2 !=null && difference.TestCase1 !=null)
				{
					// change related test id
					difference.TestCase1.RelatedTestGid = difference.TestCase2.RelatedTestGid;
					list.Add(new TestCaseChange(RepositoryRequestType.Create, difference.TestCase1));
				}
			

				if (added && deleted)
				{
					System.Windows.Forms.MessageBox.Show("Unresolved differences still exist. No test cases were published!");
					return;
				}
			}

			if(list.Count > 0)
			{
				// Try to apply changes, and display error messages if any
				try
				{									
					//	TODO: Before applying changes, check against a 'Silver' copy
					//	of the DB to ensure that no changes have been made since publishing
					//	began.


					BuildPublishRequest dbRequest = new BuildPublishRequest(RepositoryRequestType.Update);
					dbRequest.ChangeList = list;
					dbRequest.PublishBuild = testbuildRequest.Build;
					request.RightRepository.ExecuteRequest(dbRequest);


					System.Windows.Forms.MessageBox.Show("Changes published successfully!");
				}
				catch (Exception exception)
				{
					System.Windows.Forms.MessageBox.Show(String.Format("Error: {0}", exception.Message));
				}
			}
			else
			{
				System.Windows.Forms.MessageBox.Show("No changes were made to the database!");
			}
		}
		
		public void ProcessRequest(ManagerRequest request)
		{
			switch(request.RequestType)
			{
				case RepositoryRequestType.Get :
					request.ManagersList = new TFxUser[1]{m_team.Manager};
					break;
			}
		}

		public void ProcessRequest(BuildListRequest request)
		{			
		}

		public void ProcessRequest(TestBuildRequest request)
		{
			switch(request.RequestType)
			{
				case RepositoryRequestType.Get:
					request.Build = m_build;
					break;
			}
		}
		public void ProcessRequest(LoadModuleRequest request)
		{
			ArrayList modules = null;
			int moduleIndex;
			TestBuildModule testModule;
			

			if(m_build == null)
			{
				m_build = new TestBuild();
				modules = new ArrayList();
			}
			else
			{
				modules = new ArrayList(m_build.Modules);
			}

			if(request.BuildName != null)
			{
				m_build.Name = request.BuildName;
			}
            			
			switch(request.RequestType)
			{
				case RepositoryRequestType.Delete: 
					for(int i =0 ; i < request.TestModule.Length; i ++)
					{
						if(Contains(modules,request.TestModule[i].DllFullName))
						{
							modules.Remove(request.TestModule[i]);					
						}
					}

					m_build.Modules = (TestBuildModule[])modules.ToArray(typeof(TestBuildModule));
						
					this.FileRepository.SaveTestBuild(m_build,request.BuildName);
				
					break;
				case RepositoryRequestType.Get: //Add to list
					for(int i =0 ; i < request.TestModule.Length; i ++)
					{
						if(!Contains(modules,request.TestModule[i].DllFullName))
						{
							if(ModuleInDiffFolder(modules, request.TestModule[i].ModuleName)== -1)
							{
								modules.Add(request.TestModule[i]);
								m_build.Modules = (TestBuildModule[])modules.ToArray(typeof(TestBuildModule));
								this.FileRepository.SaveTestBuild(m_build,request.BuildName);	
							}
							else
							{
								testModule = m_build.GetModule(request.TestModule[i].ModuleName);
								if(testModule != null)
								{
									request.Message = testModule.DllFullName;	

								}
													
							}						
						}

					}
					
					break;
				case RepositoryRequestType.Update: //Update the list
					for(int i =0 ; i < request.TestModule.Length; i ++)
					{
						if(!Contains(modules,request.TestModule[i].DllFullName))
						{
							moduleIndex = ModuleInDiffFolder(modules,request.TestModule[i].ModuleName);

							if(moduleIndex != -1)
							{
								modules.RemoveAt(moduleIndex);
								modules.Add(request.TestModule[i]);
								m_build.Modules = (TestBuildModule[])modules.ToArray(typeof(TestBuildModule));
								this.FileRepository.SaveTestBuild(m_build,request.BuildName);	
							}						
						}	

					}
								
					break;
			}

			

		}

		public bool Contains(ArrayList modules,string moduleDllFullName)
		{
			if(modules!= null)
			{
				foreach(TestBuildModule testModule in modules)
				{
					if(testModule.DllFullName.CompareTo(moduleDllFullName)== 0) 
					{
						return true;
					}
				}
             }
			return false;
		}

		
		

		private int ModuleInDiffFolder(ArrayList modules, string moduleName)
		{
			int index = 0;
			if(modules != null)
			{
				foreach(TestBuildModule testModule in modules)
				{
					if(testModule.ModuleName.CompareTo(moduleName)==0)
					{
						return index;
					}
					index++;
				}
			}

			return -1;
		}

		public void CreateTestBuild(string buildName)
		{
			m_build = this.FileRepository.GetTestBuild(buildName);
		}

		TestArea FindTestArea(ArrayList areas, string path, string location)
		{
			string []pathparts = path.Split('.');

			if(areas != null && pathparts != null && pathparts.Length > 0)
			{
				foreach(TestArea area in areas)
				{
					if(area.Name == pathparts[0])
					{
						return area;
					}
				}
				TestArea newArea = new TestArea(pathparts[0]);				
				areas.Add( newArea);
				return newArea;
			}
			
			return null;
		}
	
	}
	/// <summary>
	/// Summary description for TestPlayerRepository.
	/// </summary>
	public class TestPlayerRepository : MultiRepository
	{
		const string c_BaseFolderForTestPlayerFileRepository = @"c:\teststudio";

		public TestPlayerRepository() : base(new Repository[]{new TestDriverRepository(), new FileRepository()})
		{
			ExecuteRequest( new FileRepository.InitFileRepositoryRequest(c_BaseFolderForTestPlayerFileRepository));		
			TestDriverRepository DriverRepository = m_respositories[0] as TestDriverRepository;
			DriverRepository.FileRepository = m_respositories[1] as FileRepository;
		}

	
		bool m_devMode = false;

		public void ProcessRequest(AppConfigRequest request)
		{
			switch(request.RequestType)
			{
				case RepositoryRequestType.Get:
					request.AppConfig = new AppConfig();
					request.AppConfig.DevMode = m_devMode;
					request.AppConfig.Mode = ApplicationMode.TestPlayer;						
					break;
				case RepositoryRequestType.Update:
					m_devMode = request.DevMode;
					break;
			}
		}
	}
}
