//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: Main.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using Expedia.Test.Framework;
using System.Text;


namespace TestStudioApp
{
    /// <summary>
    /// Summary description for Form1.
    /// </summary>
    public class Main : System.Windows.Forms.Form
    {
        private System.Windows.Forms.MainMenu mainMenu1;
        private System.Windows.Forms.MenuItem menuItem1;
        private System.Windows.Forms.MenuItem addAppTab;
        private System.Windows.Forms.ToolBar toolBar1;
        private TestStudio testStudio1;
        private System.Windows.Forms.StatusBar statusBar1;
        private System.Windows.Forms.StatusBarPanel statusBarPanel1;
        private System.Windows.Forms.StatusBarPanel statusBarPanel2;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.ToolBarButton testRunEditor;
        private System.Windows.Forms.ToolBarButton devDebug1;
        private System.Windows.Forms.ToolBarButton close;
        private System.Windows.Forms.ToolBarButton configEditor;
        private System.Windows.Forms.ToolBarButton filterEditor;
        private System.Windows.Forms.MenuItem menuItem4;
        private System.Windows.Forms.MenuItem menuItem5;
        private System.Windows.Forms.MenuItem helpMenuItem;
        private System.Windows.Forms.MenuItem openTestRunEditor;
        private System.Windows.Forms.MenuItem openFileEditor;
        private System.Windows.Forms.MenuItem openConfigEditor;
        private System.Windows.Forms.MenuItem closeCurrentTab;
        private System.Windows.Forms.MenuItem openDLL;
        private System.Windows.Forms.MenuItem menuItemTestRun;
        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.MenuItem openTemplateEditor;
        private System.Windows.Forms.MenuItem dllLocation;
        private System.Windows.Forms.MenuItem menuItemUnload;
        private System.Windows.Forms.MenuItem recorder;
        private System.Windows.Forms.MenuItem importAssignment;
        private System.Windows.Forms.MenuItem exportAssignment;
        private MenuItem menuItemBuildUpgradeTool;
        private System.ComponentModel.IContainer components;

        System.Windows.Forms.TabControl appTab
        {
            get
            {
                return testStudio1.appTab;
            }
        }

        public Main(string[] args)
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            //if (args.GetLength(0) > 1 && args[1] == "-lab")
            //{
            //    this.testStudio1.InitRepository(true);
            //}
            //else
            //{
                this.testStudio1.InitRepository(false);
            //}

            if (args.GetLength(0) > 0 && args[0] == "-dev")
            {
                this.devDebug1.Visible = true;
                this.openTemplateEditor.Visible = true;

                AppConfigRequest request = new AppConfigRequest(RepositoryRequestType.Update);
                request.DevMode = true;
                this.testStudio1.GetData(request);
            }
            else
            {
                this.devDebug1.Visible = false;
                //this.devDebug2.Visible = false;
            }

            if (args.Length > 0 && args[0] == "cmd")
            {
                AppStudio.OpenTab(appTab, new TestRunEditor(args[1], false));

            }

            if (args.Length > 0 && args[0].ToLower() == "-debugtest")
            {
                string defaultFile = "TSExecutedAssignmentList";
                AppStudio.OpenTab(appTab, new TestRunEditor(defaultFile, true));
            }

            System.IO.Directory.SetCurrentDirectory(Application.StartupPath);
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.mainMenu1 = new System.Windows.Forms.MainMenu(this.components);
            this.menuItem1 = new System.Windows.Forms.MenuItem();
            this.openDLL = new System.Windows.Forms.MenuItem();
            this.dllLocation = new System.Windows.Forms.MenuItem();
            this.menuItemUnload = new System.Windows.Forms.MenuItem();
            this.importAssignment = new System.Windows.Forms.MenuItem();
            this.exportAssignment = new System.Windows.Forms.MenuItem();
            this.addAppTab = new System.Windows.Forms.MenuItem();
            this.openTestRunEditor = new System.Windows.Forms.MenuItem();
            this.openFileEditor = new System.Windows.Forms.MenuItem();
            this.openConfigEditor = new System.Windows.Forms.MenuItem();
            this.openTemplateEditor = new System.Windows.Forms.MenuItem();
            this.recorder = new System.Windows.Forms.MenuItem();
            this.closeCurrentTab = new System.Windows.Forms.MenuItem();
            this.menuItemTestRun = new System.Windows.Forms.MenuItem();
            this.menuItem4 = new System.Windows.Forms.MenuItem();
            this.menuItem5 = new System.Windows.Forms.MenuItem();
            this.helpMenuItem = new System.Windows.Forms.MenuItem();
            this.menuItemBuildUpgradeTool = new System.Windows.Forms.MenuItem();
            this.toolBar1 = new System.Windows.Forms.ToolBar();
            this.testRunEditor = new System.Windows.Forms.ToolBarButton();
            this.filterEditor = new System.Windows.Forms.ToolBarButton();
            this.configEditor = new System.Windows.Forms.ToolBarButton();
            this.devDebug1 = new System.Windows.Forms.ToolBarButton();
            this.close = new System.Windows.Forms.ToolBarButton();
            this.statusBar1 = new System.Windows.Forms.StatusBar();
            this.statusBarPanel1 = new System.Windows.Forms.StatusBarPanel();
            this.statusBarPanel2 = new System.Windows.Forms.StatusBarPanel();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.buttonClose = new System.Windows.Forms.Button();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.testStudio1 = new TestStudioApp.TestStudio();
            ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).BeginInit();
            this.SuspendLayout();
            // 
            // mainMenu1
            // 
            this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem1,
            this.menuItemTestRun,
            this.menuItem4,
            this.menuItem5,
            this.helpMenuItem});
            // 
            // menuItem1
            // 
            this.menuItem1.Index = 0;
            this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.openDLL,
            this.dllLocation,
            this.menuItemUnload,
            this.importAssignment,
            this.exportAssignment,
            this.addAppTab,
            this.closeCurrentTab});
            this.menuItem1.Text = "&File";
            // 
            // openDLL
            // 
            this.openDLL.Index = 0;
            this.openDLL.Text = "&Open DLL";
            this.openDLL.Click += new System.EventHandler(this.openDLL_Click);
            // 
            // dllLocation
            // 
            this.dllLocation.Index = 1;
            this.dllLocation.Text = "&DLL Locations";
            this.dllLocation.Click += new System.EventHandler(this.dllLocation_Click);
            // 
            // menuItemUnload
            // 
            this.menuItemUnload.Index = 2;
            this.menuItemUnload.Text = "&Unload DLLs";
            this.menuItemUnload.Click += new System.EventHandler(this.menuItemUnload_Click);
            // 
            // importAssignment
            // 
            this.importAssignment.Index = 3;
            this.importAssignment.Text = "&Import Assignment";
            this.importAssignment.Click += new System.EventHandler(this.importAssignment_Click);
            // 
            // exportAssignment
            // 
            this.exportAssignment.Index = 4;
            this.exportAssignment.Text = "&Export Assignment";
            this.exportAssignment.Click += new System.EventHandler(this.exportAssignment_Click);
            // 
            // addAppTab
            // 
            this.addAppTab.Index = 5;
            this.addAppTab.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.openTestRunEditor,
            this.openFileEditor,
            this.openConfigEditor,
            this.openTemplateEditor,
            this.recorder});
            this.addAppTab.Text = "&Add Tab To Open";
            // 
            // openTestRunEditor
            // 
            this.openTestRunEditor.Index = 0;
            this.openTestRunEditor.Text = "&Test Run Editor";
            this.openTestRunEditor.Click += new System.EventHandler(this.openTestRunEditor_Click);
            // 
            // openFileEditor
            // 
            this.openFileEditor.Index = 1;
            this.openFileEditor.Text = "&Filter Editor";
            this.openFileEditor.Click += new System.EventHandler(this.openFileEditor_Click);
            // 
            // openConfigEditor
            // 
            this.openConfigEditor.Index = 2;
            this.openConfigEditor.Text = "&Config Editor";
            this.openConfigEditor.Click += new System.EventHandler(this.openConfigEditor_Click);
            // 
            // openTemplateEditor
            // 
            this.openTemplateEditor.Index = 3;
            this.openTemplateEditor.Text = "Template Editor";
            this.openTemplateEditor.Visible = false;
            // 
            // recorder
            // 
            this.recorder.Index = 4;
            this.recorder.Text = "Recorder";
            this.recorder.Click += new System.EventHandler(this.Recorder_Click);
            // 
            // closeCurrentTab
            // 
            this.closeCurrentTab.Index = 6;
            this.closeCurrentTab.Text = "&Close Current Tab";
            this.closeCurrentTab.Click += new System.EventHandler(this.closeCurrentTab_Click);
            // 
            // menuItemTestRun
            // 
            this.menuItemTestRun.Index = 1;
            this.menuItemTestRun.Text = "Test Run Editor";
            this.menuItemTestRun.Click += new System.EventHandler(this.menuItemTestRun_Click);
            // 
            // menuItem4
            // 
            this.menuItem4.Index = 2;
            this.menuItem4.Text = "Settings";
            this.menuItem4.Click += new System.EventHandler(this.menuUserSettings_Click);
            // 
            // menuItem5
            // 
            this.menuItem5.Index = 3;
            this.menuItem5.Text = "Config Editor";
            this.menuItem5.Click += new System.EventHandler(this.openConfigEditor_Click);
            // 
            // helpMenuItem
            // 
            this.helpMenuItem.Index = 4;
            this.helpMenuItem.Text = "Help";
            this.helpMenuItem.Click += new System.EventHandler(this.helpMenu_Click);
            // 
            // menuItemBuildUpgradeTool
            // 
            this.menuItemBuildUpgradeTool.Index = -1;
            this.menuItemBuildUpgradeTool.Text = "";
            // 
            // toolBar1
            // 
            this.toolBar1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.toolBar1.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
            this.testRunEditor,
            this.filterEditor,
            this.configEditor,
            this.devDebug1,
            this.close});
            this.toolBar1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolBar1.DropDownArrows = true;
            this.toolBar1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolBar1.Location = new System.Drawing.Point(0, 0);
            this.toolBar1.Name = "toolBar1";
            this.toolBar1.ShowToolTips = true;
            this.toolBar1.Size = new System.Drawing.Size(657, 42);
            this.toolBar1.TabIndex = 2;
            this.toolBar1.Visible = false;
            this.toolBar1.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.toolBar1_ButtonClick);
            // 
            // testRunEditor
            // 
            this.testRunEditor.Name = "testRunEditor";
            this.testRunEditor.Tag = "testruneditor";
            this.testRunEditor.Text = "TestRun Editor";
            // 
            // filterEditor
            // 
            this.filterEditor.Name = "filterEditor";
            this.filterEditor.Tag = "filtereditor";
            this.filterEditor.Text = "Filter Editor";
            this.filterEditor.Visible = false;
            // 
            // configEditor
            // 
            this.configEditor.Name = "configEditor";
            this.configEditor.Tag = "configeditor";
            this.configEditor.Text = "Config Editor";
            this.configEditor.Visible = false;
            // 
            // devDebug1
            // 
            this.devDebug1.Name = "devDebug1";
            this.devDebug1.Tag = "dev1";
            this.devDebug1.Text = "devDebug1";
            // 
            // close
            // 
            this.close.Name = "close";
            this.close.Tag = "close";
            this.close.Text = "Close";
            this.close.ToolTipText = "Close";
            // 
            // statusBar1
            // 
            this.statusBar1.Location = new System.Drawing.Point(0, 466);
            this.statusBar1.Name = "statusBar1";
            this.statusBar1.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
            this.statusBarPanel1,
            this.statusBarPanel2});
            this.statusBar1.Size = new System.Drawing.Size(656, 20);
            this.statusBar1.TabIndex = 4;
            this.statusBar1.Visible = false;
            // 
            // statusBarPanel1
            // 
            this.statusBarPanel1.Name = "statusBarPanel1";
            this.statusBarPanel1.Text = "statusBarPanel1";
            // 
            // statusBarPanel2
            // 
            this.statusBarPanel2.Alignment = System.Windows.Forms.HorizontalAlignment.Right;
            this.statusBarPanel2.Name = "statusBarPanel2";
            this.statusBarPanel2.Text = "statusBarPanel2";
            // 
            // buttonClose
            // 
            this.buttonClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonClose.Location = new System.Drawing.Point(624, 0);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(24, 18);
            this.buttonClose.TabIndex = 5;
            this.buttonClose.Text = "X";
            this.toolTip1.SetToolTip(this.buttonClose, "Close Current Tab");
            this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "");
            // 
            // testStudio1
            // 
            this.testStudio1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.testStudio1.LabRunMode = false;
            this.testStudio1.Location = new System.Drawing.Point(0, 0);
            this.testStudio1.Name = "testStudio1";
            this.testStudio1.Repository = null;
            this.testStudio1.Size = new System.Drawing.Size(656, 486);
            this.testStudio1.TabIndex = 3;
            // 
            // Main
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(656, 486);
            this.Controls.Add(this.buttonClose);
            this.Controls.Add(this.statusBar1);
            this.Controls.Add(this.testStudio1);
            this.Controls.Add(this.toolBar1);
            this.Menu = this.mainMenu1;
            this.MinimumSize = new System.Drawing.Size(592, 520);
            this.Name = "Main";
            this.Text = "Test Studio";
            this.Closing += new System.ComponentModel.CancelEventHandler(this.Main_Closing);
            ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion



        private void openTestRunEditor_Click(object sender, System.EventArgs e)
        {
            AppStudio.OpenTab(appTab, new TestRunEditor());

        }

        private void openFileEditor_Click(object sender, System.EventArgs e)
        {
            AppStudio.OpenTab(appTab, new Expedia.Test.Framework.FilterEditor());
        }

        private void openConfigEditor_Click(object sender, System.EventArgs e)
        {
            AppStudio.OpenTab(appTab, new Expedia.Test.Framework.ConfigGroupEditor());

        }

        private void menuUserSettings_Click(object sender, System.EventArgs e)
        {
            AppStudio.OpenTab(appTab, new UserSettingsEditor());
        }


        private void closeCurrentTab_Click(object sender, System.EventArgs e)
        {
            CloseCurrentTab();

        }

        private void CloseCurrentTab()
        {
            TabPage page = appTab.SelectedTab;

            if (page != null)
            {
                if (page.Controls.Count == 1)
                {
                    foreach (Control control in page.Controls)
                    {
                        RepositoryDelegateUI delagateUI = control as RepositoryDelegateUI;

                        if (delagateUI != null)
                        {
                            delagateUI.PersistUIState();
                        }
                    }
                }

            }

            AppStudio.CloseCurrentTabPage(appTab);

        }

        private void toolBar1_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
        {
            switch ((string)e.Button.Tag)
            {
                case "testruneditor":
                    AppStudio.OpenTab(appTab, new TestRunEditor());
                    break;
                case "configeditor":
                    AppStudio.OpenTab(appTab, new Expedia.Test.Framework.ConfigGroupEditor());
                    break;
                case "filtereditor":
                    AppStudio.OpenTab(appTab, new Expedia.Test.Framework.FilterEditor());
                    break;
                case "close":
                    closeCurrentTab_Click(this, e);
                    break;
                case "dev1":
                    //AppStudio.OpenTab(appTab, new TestRunTemplateEditor());
                    break;
            }
        }

        private void openDLL_Click(object sender, System.EventArgs e)
        {
            if (this.openFileDialog.ShowDialog(this) == System.Windows.Forms.DialogResult.OK)
            {

                string path = this.openFileDialog.FileName;
                string moduleName = null;
                string[] names = path.Split('\\');
                DialogResult dlgRes;
                string strMessage;
                TestDriverRepository.LoadModuleRequest loadModule;


                foreach (string str in names)
                {
                    if (str.IndexOf(".dll") != -1 || str.IndexOf(".xml") != -1 || str.IndexOf(".jar") != -1)
                    {
                        moduleName = str;
                    }
                }
                if (moduleName != null)
                {
                    ExecuteTestModule buildModule = new ExecuteTestModule(this.openFileDialog.FileName);

                    loadModule = new TestDriverRepository.LoadModuleRequest(new TestBuildModule[] { buildModule }, RepositoryRequestType.Get);
                    loadModule.BuildName = this.GetBuildName();
                    this.testStudio1.Repository.ExecuteRequest(loadModule);

                    if (loadModule.Message != null && loadModule.Message != "")
                    {
                        strMessage = String.Format("Module {0} is already loaded from this location {1}. Do you want to replace?", moduleName, loadModule.Message);


                        dlgRes = MessageBox.Show(strMessage,
                            "Confirm Document Close",
                            MessageBoxButtons.YesNo,
                            MessageBoxIcon.Question);

                        if (dlgRes == DialogResult.Yes)
                        {
                            //Update the exisiting module
                            loadModule = new TestDriverRepository.LoadModuleRequest(new TestBuildModule[] { buildModule }, RepositoryRequestType.Update);
                            loadModule.BuildName = this.GetBuildName();
                            this.testStudio1.Repository.ExecuteRequest(loadModule);

                        }
                    }
                    FileOpenNotification notification = new FileOpenNotification(buildModule);
                    this.testStudio1.NotifyUI(notification);
                }
            }
        }

        private void Main_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            ApplicationClosingNotification change = new ApplicationClosingNotification();
            change.WindowSize = new Rectangle(this.Location, this.Size);
            change.CloseTab = null;
            this.testStudio1.NotifyUI(change);
        }


        private void helpMenu_Click(object sender, System.EventArgs e)
        {
            string testStudioDir = new System.IO.FileInfo(
                System.Reflection.Assembly.GetExecutingAssembly().Location).DirectoryName;
            System.Diagnostics.Process.Start(
                System.IO.Path.Combine(testStudioDir, "TestStudioHelp.chm"));
        }

        private void menuItemTestRun_Click(object sender, System.EventArgs e)
        {
            AppStudio.OpenTab(appTab, new TestRunEditor());
        }

        private void buttonClose_Click(object sender, System.EventArgs e)
        {
            ApplicationClosingNotification change = new ApplicationClosingNotification();
            change.WindowSize = new Rectangle(this.Location, this.Size);
            change.CloseTab = appTab.SelectedTab;
            this.testStudio1.NotifyUI(change);
            CloseCurrentTab();
        }


        private string GetBuildName()
        {
            UserSettingRequest userSettings = new UserSettingRequest(RepositoryRequestType.Get);
            this.testStudio1.GetData(userSettings);

            TestStudioUsersSetting setting = userSettings.Settings as TestStudioUsersSetting;

            if (setting != null && setting.DefaultBuildName != null)
            {
                return setting.DefaultBuildName;
            }
            return null;
        }

        private void dllLocation_Click(object sender, System.EventArgs e)
        {
            StringBuilder str = new StringBuilder();
            TestBuildRequest buildRequest = new TestBuildRequest(RepositoryRequestType.Get);
            this.testStudio1.GetData(buildRequest);

            if (buildRequest.Build != null)
            {
                if (buildRequest.Build.Modules != null && buildRequest.Build.Modules.Length > 0)
                {
                    foreach (TestBuildModule module in buildRequest.Build.Modules)
                    {
                        str.Append(String.Format("ModuleName: {0}, Location: {1}\n", module.Name, module.DllFullName));
                    }

                    MessageBox.Show(str.ToString(), "Modules Location");
                }

            }
        }

        private void menuItemUnload_Click(object sender, System.EventArgs e)
        {
            TestDriverRepository.LoadModuleRequest loadModule;
            UnloadDllControl dllControl = new UnloadDllControl();
            ArrayList testBuildModules = new ArrayList();
            TestBuild testBuild = new TestBuild();

            TestBuildRequest buildRequest = new TestBuildRequest(RepositoryRequestType.Get);
            this.testStudio1.GetData(buildRequest);

            if (buildRequest.Build != null)
            {
                testBuild = buildRequest.Build;

                if (buildRequest.Build.Modules != null)
                {
                    dllControl.ModuleNames = new ArrayList(buildRequest.Build.Modules);
                }
            }

            if (dllControl.ModuleCount >= 0)
            {
                dllControl.ShowDialog();
            }

            if (dllControl.CheckedModuleNames != null && dllControl.CheckedModuleNames.Count > 0)
            {
                if (testBuild != null)
                {
                    foreach (string str in dllControl.CheckedModuleNames)
                    {
                        if (testBuild.GetModule(str) != null)
                        {
                            testBuildModules.Add(testBuild.GetModule(str));
                        }
                    }
                }

                loadModule = new TestDriverRepository.LoadModuleRequest((TestBuildModule[])testBuildModules.ToArray(typeof(TestBuildModule)), RepositoryRequestType.Delete);
                loadModule.BuildName = this.GetBuildName();


                this.testStudio1.Repository.ExecuteRequest(loadModule);

                FileOpenNotification notification = new FileOpenNotification(null);
                this.testStudio1.NotifyUI(notification);
            }

        }

        private void Recorder_Click(object sender, System.EventArgs e)
        {
            UserSettingRequest userRequest = new UserSettingRequest(RepositoryRequestType.Get);
            this.testStudio1.Repository.ExecuteRequest(userRequest);

            TestStudioUsersSetting settings = userRequest.Settings as TestStudioUsersSetting;

            if (settings != null)
            {
                try
                {
                    //AppStudio.OpenTab(appTab, new Expedia.Automation.WebFramework.Recorder.ExpTestStudio(settings.DLLName, settings.RecorderURL, settings.SourcePath, settings.SDFile));
                    MessageBox.Show("Recorder is no more supported in test studio, please contact autosup if you need more help", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Failed to open Recorder. Please check Recorder settings." + ex.ToString());
                }
            }
        }

        private void importAssignment_Click(object sender, System.EventArgs e)
        {
            FileAssignmentImportNotification notification = new FileAssignmentImportNotification();
            this.testStudio1.NotifyUI(notification);
        }

        private void exportAssignment_Click(object sender, System.EventArgs e)
        {
            FileAssignmentExportNotification notification = new FileAssignmentExportNotification();
            this.testStudio1.NotifyUI(notification);
        }
    }
}

