using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for AssignmentStatusColumnType.
	/// </summary>
	public enum AssignmentStatusColumnType: long
	{
		Status=0,
		FailureReason=1,
		None =2
	}
}
