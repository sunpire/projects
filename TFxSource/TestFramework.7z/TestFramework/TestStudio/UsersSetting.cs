using System;
using System.ComponentModel;
using System.Xml.Serialization;

namespace Expedia.Test.Framework
{
    public enum Mode
    {
        Simple,
        Advanced
    }
    /// <summary>
    /// Summary description for UsersSetting.
    /// </summary>
    [Serializable]
    public class UsersSetting
    {
        public UsersSetting()
        {
        }

        TimeSpan m_assignmentTimeOut = new TimeSpan(0, 0, 10, 0, 0);

        [Category("Test Execution  Settings"),
        Description("Assignment TimeOut")]
        [XmlIgnore]
        public TimeSpan AssignmentTimeOut
        {
            get
            {
                return m_assignmentTimeOut;
            }
            set
            {
                m_assignmentTimeOut = value;
            }
        }

        [BrowsableAttribute(false)]
        public long TimeOut
        {
            get
            {
                return m_assignmentTimeOut.Ticks;
            }
            set
            {
                m_assignmentTimeOut = new TimeSpan(value);
            }
        }
    }
}
