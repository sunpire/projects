using System;
using System.Windows.Forms;

namespace TestStudioApp
{
	/// <summary>
	/// Summary description for Program.
	/// </summary>
	public class Program
	{
		static Program()
		{
		}

		public Program()
		{
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
        [LoaderOptimization(LoaderOptimization.MultiDomainHost)]
		static void Main(string[] args) 
		{
			Application.Run(new Main(args));
		}
	}
}
