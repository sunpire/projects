//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: TestPublish.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;
using System.Collections;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TestPublish.
	/// </summary>
	public class TestPublish
	{
		private RepositoryChangelist m_changes = null;
		private TestDiff  m_differences = null;
		private TestInfo  m_updated     = null;
		private TestInfo  m_golden      = null;
		private IResolver m_resolver    = null;
		
		public TestPublish(TestInfo updated, TestInfo golden, IResolver resolver)
		{
			this.m_updated = updated;
			this.m_golden = golden;

			this.m_resolver = resolver;
			this.m_changes = new RepositoryChangelist();
			this.InitDifferences();
		}

		public TestInfo Updated
		{
			get
			{
				return this.m_updated;
			}
		}

		public TestInfo Golden
		{
			get
			{
				return this.m_golden;
			}
		}

		public TestDiff Differences
		{
			get
			{
				return this.m_differences;
			}
		}

		public bool IsPublishable
		{
			get
			{
				return this.m_differences.IsResolved;
			}
		}

		public IResolver Resolver
		{
			get
			{
				return this.m_resolver;
			}
			set
			{
				this.m_resolver = value;
			}
		}

		public RepositoryChangelist ChangeList
		{
			get
			{
				return this.m_changes;
			}
		}

		private void InitDifferences()
		{
			this.m_differences = this.m_updated.Diff(this.m_golden);
		}

		/// <summary>
		/// Adds a TestCaseChange to this difference object and re-calculates the differences after
		/// applying the change.
		/// </summary>
		/// <param name="change">The TestCaseChange object to add.</param>
		public void AddChange(TestCaseChange change)
		{
			if(this.m_golden is TestArea)
			{
				// If we are updating a TestArea, apply the change
				((TestArea)this.m_golden).ApplyChange(change);
			}
			else if(this.m_golden is TestCase)
			{
				// If we are updating a TestCase, check to make sure we are actually updating it
				if(change.RequestType != RepositoryRequestType.Update)
				{
					// A non-move change doesn't make sense for a single test case
					throw new Exception("Incorrect change added: change must be a TestCaseChangeMove!");
				}
				else
				{
					this.m_golden = change.NewTestCase;
				}
			}

			// Add the change to our change list
			this.ChangeList.Add(change);

			// Re-calculate the differences
			this.InitDifferences();
		}

		/// <summary>
		/// Attempts to automatically resolve differences between the two TestInfo obejcts in this diff object.
		/// </summary>
		private void AutoResolve()
		{
			// TODO: Implement AutoResolve.
			throw new NotImplementedException("AutoResolve not yet implemented.");
		}

		/// <summary>
		/// Generates a list of changes needed to be able to publish the updated TestInfo object to the
		/// golden TestInfo object.
		/// </summary>
		public void CreateChangeList()
		{
			// TODO: Not yet implemented -- will be used in the new algorithm
			//this.AutoResolve();

			this.m_resolver.Resolve(this);
		}
	}
}
