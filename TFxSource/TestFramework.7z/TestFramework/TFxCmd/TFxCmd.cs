using System;
using System.Net;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace Web
{
    #region Argument processing

    /// <summary>
    /// Contains command-line argument settings and performs argument processing code.
    /// </summary>
    class Args
    {
        private string m_url = null;
        /// <summary>
        /// Indicates the URL that the program will run against.
        /// </summary>
        public string URL
        {
            get { return m_url; }
        }

        const int DEFAULT_RETRIES = 3;
        private int m_retries = DEFAULT_RETRIES;
        /// <summary>
        /// The number of retries that the program will attempt before giving up.
        /// </summary>
        public int Retries
        {
            get { return m_retries; }
        }

        const int DEFAULT_RETRYINTERVALSECONDS = 60;
        private int m_retryIntervalSeconds = DEFAULT_RETRYINTERVALSECONDS;
        /// <summary>
        /// The amount of time, in seconds, that the program will wait between retries.
        /// </summary>
        public int RetryIntervalSeconds
        {
            get { return m_retryIntervalSeconds; }
        }

        const int DEFAULT_TIMEOUT = 60;
        private int m_timeOut = DEFAULT_TIMEOUT;
        /// <summary>
        /// The timeout of each connection attempt, in seconds.
        /// </summary>
        public int TimeOut
        {
            get { return m_timeOut; }
        }

        const bool DEFAULT_VERBOSE = false;
        private bool m_verbose = DEFAULT_VERBOSE;
        /// <summary>
        /// Indicates that the program should perform verbose command-line logging.
        /// </summary>
        public bool Verbose
        {
            get { return m_verbose; }
        }

        const bool DEFAULT_QUIET = false;
        private bool m_quiet = DEFAULT_QUIET;
        /// <summary>
        /// Indicates whether we should suppress the HTML output.
        /// </summary>
        public bool Quiet
        {
            get { return m_quiet; }
        }
	

        private bool m_success = false;
        /// <summary>
        /// Indicates that command-line argument parsing was successful.
        /// </summary>
        public bool Success
        {
            get { return m_success; }
        }

        /// <summary>
        /// Dumps formatted usage to the command-line.
        /// </summary>
        public static void ShowUsage()
        {
            Console.WriteLine("Usage: TFxCmd [-t:nnn] [-r:nnn] [-i:nnn] [-v] <URL>");
            Console.WriteLine("       -t:nnn -- indicates the timeout in seconds for the connection attempt.");
            Console.WriteLine("       -r:nnn -- indicates the number of times to retry this operation if it fails.");
            Console.WriteLine("       -i:nnn -- indicates the interval (in seconds) to wait between retries.");
            Console.WriteLine("       -q     -- indicates that we should suppress HTML output.");
            Console.WriteLine("       -v     -- indicates that verbose console logging should be used.");
            Console.WriteLine();
            Console.WriteLine("       The default values are:");
            Console.WriteLine("          -t: {0}", DEFAULT_TIMEOUT);
            Console.WriteLine("          -r: {0}", DEFAULT_RETRIES);
            Console.WriteLine("          -i: {0}", DEFAULT_RETRYINTERVALSECONDS);
            Console.WriteLine("          -q: {0}", DEFAULT_QUIET.ToString());
            Console.WriteLine("          -v: {0}", DEFAULT_VERBOSE.ToString());
        }

        Regex m_switchRegex = new Regex("[\\-\\/](t:\\d+|r:\\d+|i:\\d+|q|v)", RegexOptions.IgnoreCase | RegexOptions.Compiled);

        /// <summary>
        /// Processes a set of command-line arguments to produce program settings.
        /// </summary>
        /// <param name="rawArgs">The array of raw command-line arguments.</param>
        /// <returns>True if parsing succeeded, false otherwise.</returns>
        public bool Process(string[] rawArgs)
        {
            // reset all values
            this.m_success = false;
            this.m_retries = DEFAULT_RETRIES;
            this.m_retryIntervalSeconds = DEFAULT_RETRYINTERVALSECONDS;
            this.m_timeOut = DEFAULT_TIMEOUT;
            this.m_quiet = DEFAULT_QUIET;
            this.m_verbose = DEFAULT_VERBOSE;
            this.m_url = null;
            this.m_rawArgs = rawArgs; // save the original args

            foreach (string rawArg in rawArgs)
            {
                if (rawArg.IndexOfAny(new char[] { '-', '/' }) == 0)
                {
                    Match match = m_switchRegex.Match(rawArg);
                    if (match.Success)
                    {
                        string rawSwitch = match.Groups[1].Value;
                        char sw = rawSwitch[0];
                        string afterColon = null;
                        if (rawSwitch.IndexOf(':') == 1)
                        {
                            afterColon = rawSwitch.Substring(2);
                        }

                        switch (match.Groups[1].Value[0])
                        {
                            case 't':
                                m_timeOut = int.Parse(afterColon);
                                break;

                            case 'r':
                                m_retries = int.Parse(afterColon);
                                break;

                            case 'i':
                                m_retryIntervalSeconds = int.Parse(afterColon);
                                break;

                            case 'q':
                                m_quiet = true;
                                break;

                            case 'v':
                                m_verbose = true;
                                break;
                        }
                    }
                    else
                    {
                        Console.WriteLine("ERROR: unknown switch '{0}'\n", rawArg);
                        return false;
                    }
                }
                else
                {
                    m_url = rawArg;
                }
            }

            if (String.IsNullOrEmpty(m_url))
            {
                Console.WriteLine("ERROR: URL not specified.\n");
                return false;
            }
            else
            {
                m_success = true;
                return true;
            }
        }

        private string[] m_rawArgs;
        /// <summary>
        /// The original raw command-line arguments passed to contructor or Process()
        /// </summary>
        public string[] RawArgs
        {
            get { return m_rawArgs; }
        }
	
        /// <summary>
        /// Public constructor; takes a set of raw command-line args and produces
        /// a parsed switch settings object.
        /// </summary>
        /// <param name="rawArgs">A set of raw command-line arguments</param>
        public Args(string[] rawArgs)
        {
            Process(rawArgs);
        }
    }

    #endregion

    /// <summary>
	/// Summary description for Class1.
	/// </summary>
	class TFxCmd
	{
        static void Log(string format, params object[] args)
        {
            string message = String.Format("[{0}] {1}", DateTime.Now, args.Length > 0 ? String.Format(format, args) : format);
            Console.Error.WriteLine(message);
        }

        static void LogV(string format, params object[] args)
        {
            if (s_args.Verbose)
            {
                Log(format, args);
            }
        }

        static Args s_args;

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static int Main(string[] rawArgs)
		{
            s_args = new Args(rawArgs);
            if (!s_args.Success)
            {
                Args.ShowUsage();
                return 1;
            }

            LogV("Verbose logging enabled.");
            Log("Using URL     : '{0}'", s_args.URL);
            LogV("Retries       : {0}", s_args.Retries);
            LogV("Retry interval: {0}", s_args.RetryIntervalSeconds);
            LogV("Timeout       : {0}", s_args.TimeOut);
            
            int retries = s_args.Retries + 1; // have to add one for our initial attempt!
            while (retries > 0)
            {
                --retries;

                try
                {
                    // Create the request.
                    WebRequest myRequest = WebRequest.Create(s_args.URL);
                    myRequest.Credentials = System.Net.CredentialCache.DefaultCredentials;
                    myRequest.Timeout = s_args.TimeOut * 1000; // convert milliseconds to seconds

                    // Get the response. 
                    LogV("Attempting to connect to '{0}' ({1} retries remaining)...", s_args.URL, retries);

                    HttpWebResponse myWebResponse = (HttpWebResponse)myRequest.GetResponse();

                    LogV("Got a response from '{0}': {1}", s_args.URL, myWebResponse.StatusCode.ToString());

                    if (!s_args.Quiet)
                    {
                        // Obtain a 'Stream' object associated with the response object.
                        Stream ReceiveStream = myWebResponse.GetResponseStream();

                        Encoding encode = System.Text.Encoding.GetEncoding("utf-8");

                        LogV("Reading response...");
                        // Pipe the stream to a higher level stream reader with the required encoding format. 
                        StreamReader readStream = new StreamReader(ReceiveStream, encode);
                        string response = readStream.ReadToEnd();
                        int start = -1;
                        int end = -1;
                        start = response.IndexOf("\"LabelMessage\"");
                        if (start >= 0)
                        {
                            end = response.IndexOf("</span>", start);

                            if (end >= 0)
                            {
                                Console.WriteLine("{0}", response.Substring(start + 15, end - start - 15));
                                return 0;
                            }

                        }

                        Console.WriteLine("{0}", response);
                    }

                    // success!
                    return 0;
                }
                catch (Exception e)
                {
                    Log("Caught {0} exception: {1}", e.GetType().Name, e.Message); 

                    if (((e is System.Net.Sockets.SocketException) || (e is System.Net.WebException)) && (retries > 0))
                    {
                        Log("Waiting {0} seconds before retry ({1} retries remaining)...", s_args.RetryIntervalSeconds, retries);
                        System.Threading.Thread.Sleep(s_args.RetryIntervalSeconds * 1000);
                    }
                    else
                    {
                        // We've caught an exception.  Either it's an unknown exception type
                        // (and thus not handleable), or we're out of retries.  It's likely 
                        // that the last exception is the root cause of the problem.
                        
                        Log("-- ERROR: UNABLE TO CONTINUE --");
                        
                        // dump the full exception to the console
                        Log("Full exception:\n{0}", e.ToString());

                        LogV("Writing event log message...");
                        System.Diagnostics.EventLog el = new System.Diagnostics.EventLog();
                        StringBuilder sbMessage = new StringBuilder();
                        sbMessage.Append("TFxCmd.exe failed due to an exception.\n\n");
                        sbMessage.Append("Settings:\n");
                        sbMessage.AppendFormat("URL: {0}\n", s_args.URL);
                        sbMessage.AppendFormat("TimeOut: {0} seconds\n", s_args.TimeOut);
                        sbMessage.AppendFormat("Retry count: {0}\n", s_args.Retries);
                        sbMessage.AppendFormat("Retry interval: {0} seconds\n", s_args.RetryIntervalSeconds);
                        sbMessage.AppendFormat("Verbose log: {0}\n", s_args.Verbose.ToString());
                        sbMessage.Append("\n");
                        sbMessage.Append("Exception:\n");
                        sbMessage.Append(e.ToString());

                        el.Source = "TFxCmd.exe";
                        el.WriteEntry(sbMessage.ToString(), System.Diagnostics.EventLogEntryType.Error);

                        return 1;
                    }
                }
            }

            // if we got here, we exhausted all our retries
            // this should never happen, but VS complains about
            // no return for this branch...

            // since this is technically a failure case, we should report it...
            Log("ERROR: retries exhausted and no valid response received (SHOULD NOT BE HERE).");
            return 1;
    	}
	}
}
