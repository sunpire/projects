//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: BaseTestCategoryAttribute.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;

namespace Expedia.Test.Framework
{

	/// <summary>
	/// SetUpAttribute.
	/// </summary>
	/// 
	[AttributeUsage(AttributeTargets.Method | AttributeTargets.Assembly | AttributeTargets.Class, AllowMultiple=true)]
	public class BaseTestCategoryAttribute : Attribute
	{	
		long m_categoryId;

        /// <summary>
        /// Base Test Category Attribute
        /// </summary>
		public BaseTestCategoryAttribute()
		{}

        /// <summary>
        /// Base Test Category Attribute
        /// </summary>
        /// <param name="categoryId">Category Id</param>
		public BaseTestCategoryAttribute(long categoryId)
		{
			m_categoryId = categoryId;
		}

        /// <summary>
        /// Category Id
        /// </summary>
		public long CategoryId
		{
			get
			{
				return m_categoryId;
			}
			set
			{
				m_categoryId = value;	
			}
		}
	}
}