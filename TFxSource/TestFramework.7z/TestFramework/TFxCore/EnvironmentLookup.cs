﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Provides a mechanism for querying Labrun Manager's Environment database.
    /// </summary>
    /// <remarks>
    /// Labrun Manager has information on many of the environments and sites deployed 
    /// in both the Lab as well as Production.  This data is required for testing using
    /// Dynamic Templates, which are designed to push site data to the tests.  However, it
    /// may be required to query this information directly at runtime, which is what this 
    /// API is designed to facilitate.
    /// 
    /// There aren't many overloads for specific uses, but the IQueryable&lt;ServerSiteData&gt;
    /// interface allows for unlimited flexibility in filtering the available data.  In addition,
    /// LINQ queries can be written directly against the Data Context.
    /// </remarks>
    /// <example> This sample shows how to reference the Environments Data Context directly.
    /// <code>
    /// EnvironmentsDataContext db = new EnvironmentsDataContext();
    /// 
    /// IQueryable&lt;ServerSiteData&gt; sites = 
    ///     from site in db.ServerSiteDatas
    ///     where site.EnvironmentName == "CHE-RC01" and
    ///           site.TPID == 1
    ///     select site;
    /// Console.WriteLine("Site: {0}", sites.FirstOrDefault());
    /// </code>
    /// </example>
    public static class EnvironmentLookup
    {
        /// <summary>
        /// Db Context
        /// </summary>
        public static EnvironmentsDataContext dbContext = null;

        /// <summary>
        /// Environment Look up
        /// </summary>
        static EnvironmentLookup()
        {
            string connection = string.Format(CultureInfo.InvariantCulture,
                        "Data Source={0};Failover Partner={1};Initial Catalog={2};Integrated Security=SSPI",
                        TestContext.Runtime.LRMDBServer, TestContext.Runtime.LRMDBServerMirror, TestContext.Runtime.LRMDBName);
            EnvironmentLookup.dbContext = new EnvironmentsDataContext(connection);    
        }

        #region IQueryable Methods

        /// <summary>
        /// Returns an IQueryable object containing all environments.
        /// </summary>
        /// <returns>Typed IQueryable structure containing all environments in Labrun Manager.</returns>
        /// <example>
        /// <code>
        /// string e3striping = EnvironmentLookup.GetQueryableEnvironments().
        ///                 Where(environment => environment.Name == "LISQA1").FirstOrDefault().E3Striping;
        /// </code>
        /// </example>
        public static IQueryable<EnvironmentSitesConfiguration> GetQueryableEnvironments()
        {
            var environments = from environment in dbContext.EnvironmentSitesConfigurations
                               select environment;

            return environments;
        }

        /// <summary>
        /// Returns an IQueryable object containing all sites in a particular Environment.
        /// </summary>
        /// <param name="environmentName">The name of the Environment to return sites of.</param>
        /// <returns>Typed IQueryable structure containing all sites in the given Environment.</returns>
        /// <example>
        /// <code>
        /// string site = EnvironmentLookup.GetQueryableSites(envName).Where(site => site.TPID == 1).FirstOrDefault().Site;
        /// </code>
        /// </example>
        /// <exception cref="System.ArgumentNullException">environmentName is null or empty.</exception>
        public static IQueryable<EnvironmentSitesConfiguration> GetQueryableSites(string environmentName)
        {
            if (string.IsNullOrEmpty(environmentName))
            {
                throw new ArgumentNullException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Arg_Name", "environmentName"));
            }
            var environmentSites = from eView in dbContext.EnvironmentSitesConfigurations
                                   where eView.environmentName == environmentName
                                   select eView;

            return environmentSites;
        }

        #endregion

        #region Site Methods

        /// <summary>
        /// Returns the Environment name corresponding to a given site IP.
        /// </summary>
        /// <param name="site">The site IP to look up the Environment for.</param>
        /// <returns>The corresponding Environment name.</returns>
        /// <exception cref="System.ArgumentNullException">environmentName is null or empty.</exception>
        /// <exception cref="Expedia.Test.Framework.EnvironmentLookupException">The site was not found.</exception>
        public static string GetEnvironment(string site)
        {
            if (string.IsNullOrEmpty(site))
            {
                throw new ArgumentNullException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Arg_Name", "site"));
            }

            EnvironmentSitesConfiguration siteMatch = (from e in dbContext.EnvironmentSitesConfigurations
                                                       where e.site == site
                                                       select e).FirstOrDefault();
            if (siteMatch == null)
            {
                throw new EnvironmentLookupException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Env_SiteNotFound", site));
            }

            return siteMatch.environmentName;
        }

        /// <summary>
        /// Returns a list of IPs for all sites in a particular Environment.
        /// </summary>
        /// <param name="environmentName">The name of the Environment to return sites of.</param>
        /// <returns>A list of all IPs in the given Environment.</returns>
        /// <exception cref="System.ArgumentNullException">environmentName is null or empty.</exception>
        public static List<string> GetSites(string environmentName)
        {
            if (string.IsNullOrEmpty(environmentName))
            {
                throw new ArgumentNullException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Arg_Name","environmentName"));
            }

            var sites = from e in dbContext.EnvironmentSitesConfigurations
                        where e.environmentName == environmentName
                        select e.site;

            return sites.ToList<string>();
        }

        /// <summary>
        /// Returns the specific IP for the first site that 
        /// matches a combination of TPID/EAP/LANGID/Flags, in a particular Environment.
        /// </summary>
        /// <param name="environmentName">The name of the Environment to search.</param>
        /// <param name="tpid">The TPID value to search for.</param>
        /// <param name="eap">The EAP value to search for.</param>
        /// <param name="langid">The LANGID value to search for.</param>
        /// <param name="flags">The SiteFlag value to search for.</param>
        /// <returns>The matching site IP.</returns>
        /// <exception cref="System.ArgumentNullException">environmentName is null or empty.</exception>
        /// <exception cref="Expedia.Test.Framework.EnvironmentLookupException">No site matches the given criteria.</exception>
        public static string GetSite(string environmentName, int tpid, int eap, int langid, SiteFlags flags)
        {
            if (string.IsNullOrEmpty(environmentName))
            {
                throw new ArgumentNullException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Arg_Name","environmentName"));
            }

            EnvironmentSitesConfiguration sites = (from e in dbContext.EnvironmentSitesConfigurations
                                                   where e.environmentName == environmentName &&
                                                   Convert.ToInt32(e.tpid) == tpid &&
                                                   Convert.ToInt32(e.eap) == eap &&
                                                   Convert.ToInt32(e.langid) == langid &&
                                                   (!e.flags.HasValue || ((e.flags & (int)flags) == (int)flags))
                                                   select e).FirstOrDefault();

            if (sites == null)
            {
                throw new EnvironmentLookupException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Env_SiteNotMatched",
                    environmentName, tpid, eap, langid, flags));
            }

            return sites.site;
        }

        /// <summary>
        /// Returns the specific IP for the first HIMS site in a particular Environment.
        /// </summary>
        /// <remarks>HIMS site is defined as follows:  
        ///     TPID: 20001
        ///     SiteFlags: HIMS
        /// </remarks>
        /// <param name="environmentName">The name of the Environment to search.</param>
        /// <returns>The matching site IP.</returns>
        /// <exception cref="System.ArgumentNullException">environmentName is null or empty.</exception>
        /// <exception cref="Expedia.Test.Framework.EnvironmentLookupException">No site matches the given criteria.</exception>
        public static string GetHIMSSite(string environmentName)
        {
            if (string.IsNullOrEmpty(environmentName))
            {
                throw new ArgumentNullException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Arg_Name","environmentName"));
            }

            EnvironmentSitesConfiguration site = (from e in dbContext.EnvironmentSitesConfigurations
                                                   where e.environmentName == environmentName &&
                                                   Convert.ToInt32(e.tpid) == 20001 &&
                                                   (e.flags & (int)SiteFlags.HIMS) > 0
                                                   select e).FirstOrDefault();

            if (site == null)
            {
                throw new EnvironmentLookupException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Env_SiteNotMatched",
                    "", "20001", "", "", "HIMS"));
            }

            return site.site;
        }

        /// <summary>
        /// Returns the specific IP for the first HAWI site in a particular Environment.
        /// </summary>
        /// <remarks>HAWI site is defined as follows:  
        ///     TPID: 20002
        /// </remarks>
        /// <param name="environmentName">The name of the Environment to search.</param>
        /// <returns>The matching site IP.</returns>
        /// <exception cref="System.ArgumentNullException">environmentName is null or empty.</exception>
        /// <exception cref="Expedia.Test.Framework.EnvironmentLookupException">No site matches the given criteria.</exception>
        public static string GetHAWISite(string environmentName)
        {
            if (string.IsNullOrEmpty(environmentName))
            {
                throw new ArgumentNullException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Arg_Name", "environmentName"));
            }

            EnvironmentSitesConfiguration site = (from e in dbContext.EnvironmentSitesConfigurations
                                                  where e.environmentName == environmentName &&
                                                  Convert.ToInt32(e.tpid) == 20002
                                                  select e).FirstOrDefault();

            if (site == null)
            {
                throw new EnvironmentLookupException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Env_SiteNotMatched",
                    "", "20002", "", "", ""));
            }

            return site.site;
        }

        #endregion

        #region Environment Methods

        /// <summary>
        /// Determines whether or a not a given environment is Production
        /// </summary>
        /// <param name="environmentName">The name of the environment.</param>
        /// <returns>True if the given environment is Production, else false if it is Lab.</returns>
        /// <exception cref="System.ArgumentNullException">environmentName is null or empty.</exception>
        /// <exception cref="Expedia.Test.Framework.EnvironmentLookupException">The environment was not found.</exception>
        public static bool IsProduction(string environmentName)
        {
            return !(EnvironmentLookup.GetLRMEnvironment(environmentName).isLab);
        }

        /// <summary>
        /// Returns the E3 Environment Striping value for a given environment.
        /// </summary>
        /// <param name="environmentName">The name of the environment.</param>
        /// <returns>The corresponding E3 striping.</returns>
        /// <exception cref="System.ArgumentNullException">environmentName is null or empty.</exception>
        /// <exception cref="Expedia.Test.Framework.EnvironmentLookupException">The environment was not found.</exception>
        public static string GetE3Striping(string environmentName)
        {
            return EnvironmentLookup.GetLRMEnvironment(environmentName).e3Striping;
        }

        /// <summary>
        /// Returns the Net Scalar value for a given environment.
        /// </summary>
        /// <param name="environmentName">The name of the environment.</param>
        /// <returns>The corresponding Net Scalar striping.</returns>
        /// <exception cref="System.ArgumentNullException">environmentName is null or empty.</exception>
        /// <exception cref="Expedia.Test.Framework.EnvironmentLookupException">The environment was not found.</exception>
        public static string GetNetScalar(string environmentName)
        {
            return EnvironmentLookup.GetLRMEnvironment(environmentName).netScalar;
        }

        /// <summary>
        /// Returns the SOA Striping value for a given environment.
        /// </summary>
        /// <param name="environmentName">The name of the environment.</param>
        /// <returns>The corresponding SOA striping.</returns>
        /// <exception cref="System.ArgumentNullException">environmentName is null or empty.</exception>
        /// <exception cref="Expedia.Test.Framework.EnvironmentLookupException">The environment was not found.</exception>
        public static string GetSOAStriping(string environmentName)
        {
            return EnvironmentLookup.GetLRMEnvironment(environmentName).SOAStriping;
        }  


        #endregion

        #region Helper Methods

        /// <summary>
        /// Lookup an LRMEnvironment using the name
        /// </summary>
        /// <param name="environmentName">The name of the environment.</param>
        /// <returns>The matching LRMEnvironment object.</returns>
        private static EnvironmentSitesConfiguration GetLRMEnvironment(string environmentName)
        {
            if (string.IsNullOrEmpty(environmentName))
            {
                throw new ArgumentNullException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Arg_Name", "environmentName"));
            }

            EnvironmentSitesConfiguration match = (from e in dbContext.EnvironmentSitesConfigurations
                                                   where e.environmentName == environmentName
                                                   select e).FirstOrDefault();

            if (match == null)
            {
                throw new EnvironmentLookupException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Env_NotFound",
                    environmentName));
            }

            return match;
        }

        #endregion
    }

    /// <summary>
    /// Corresponds to the Flag values used in Labrun Manager's Environment table to identify sites.
    /// </summary>
    [Flags]
    public enum SiteFlags
    {
        /// <summary>
        /// Retail
        /// </summary>
        Retail = 1,
        /// <summary>
        /// Util
        /// </summary>
        Util = 2,
        /// <summary>
        /// XNet
        /// </summary>
        XNet = 4,
        /// <summary>
        /// HIMS
        /// </summary>
        HIMS = 8,
        /// <summary>
        /// Lab
        /// </summary>
        Lab = 16
    }
}
