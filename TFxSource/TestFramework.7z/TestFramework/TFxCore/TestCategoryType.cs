//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: TestBuild.cs 
// 
// Desc:  Categories of TestCases, used to filter in LabRunManager
// 
// Note:     
// 
// History: Last Change by Kaustubh Gawande 12/19/2005 
//			- Added Retail and Smoke Categories
// 
//========================================================================== 

using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TestCategoryType.
	/// </summary>
	[Flags]
	public enum TestCategoryType : long
	{
		// <summary>
        // LOB Mask only used by WWTE: Package for linkbuilder
        // Test Cases should use the specific package types
		// </summary>
        //Package = 1,
		/// <summary>
		/// LOB Mask: Package with Flight + Hotel
		/// </summary>
        Package_Flight_Hotel = 2,
		/// <summary>
		/// LOB Mask: Package with Flight + Car
		/// </summary>
        Package_Flight_Car = 4,
		/// <summary>
		/// LOB Mask: Package with Flight + Hotel + Car
		/// </summary>
        Package_Flight_Hotel_Car = 8,
		/// <summary>
		/// LOB Mask: Package with Hotel + Car
		/// </summary>
        Package_Hotel_Car = 16,
		/// <summary>
		/// LOB Mask: Package with Train + Hotel + Car
		/// </summary>
        Train_Hotel_Car = 32,
		/// <summary>
		/// LOB Mask: Package with Train + Hotel
		/// </summary>
        Train_Hotel = 64,
		/// <summary>
		/// LOB Mask: Package with Train + Car
		/// </summary>
        Train_Car = 128,
		/// <summary>
        /// LOB Mask: Package MultiDestination
		/// </summary>
        Package_MultiDest = 256,
		/// <summary>
        /// LOB Mask: Hotel (Merchant and/or Agency)
		/// </summary>
        Hotel = 512,
		/// <summary>
		/// LOB Mask: Agency Hotel
		/// </summary>
        HotelAgency = 1024,
		/// <summary>
		/// LOB Mask: Merchant Hotel
		/// </summary>
        HotelMerchant = 2048,
		/// <summary>
		/// LOB Mask: Air
		/// </summary>
        Air = 4096,
		/// <summary>
		/// LOB Mask: Car (Merchant and/or Agency)
		/// </summary>
        Car = 8192,
		/// <summary>
		/// LOB Mask: Agency Car
		/// </summary>
        CarAgency = 16384,
		/// <summary>
		/// LOB Mask: Merchant Car
		/// </summary>
        CarMerchant = 32768,
		/// <summary>
		/// LOB Mask: Standalone TShop
		/// </summary>
        StandAloneTShop = 65536,
		/// <summary>
		/// LOB Mask: Cruise
		/// </summary>
        Cruise = 131072,
        /// <summary>
        /// Package Train test category
        /// </summary>
        PackageTrain = 262144, //non-LOB mask
        /// <summary>
        /// Package with Train + Hotel + Car + TShop test category
        /// </summary>
        Train_Hotel_Car_TShop = 524288, //non-LOB mask
        
		/// <summary>
		/// BVT test case
		/// </summary>
        BVT = 67108864, //(2^26) non-LOB mask
		/// <summary>
		/// Smoke test case
		/// </summary>
        Smoke = 134217728, //(2^27) non-LOB mask
		// <summary>
		// Retail 
		// </summary>
        //Retail= 268435456, // (2^28) non-LOB mask
        /// <summary>
        /// Regression test case
        /// </summary>
        Regression = 536870912, //(2^29) non-LOB mask
        /// <summary>
        /// Upgrade test case
        /// </summary>
        Upgrade = 1073741824 //(2^30) non-LOB mask
	
        //
        // NOTE
        // ====
        // (2^20), (2^21), (2^22), (2^23), (2^24), (2^25)
        //
        // are taken and used by TierType enum
        //
	}
}
