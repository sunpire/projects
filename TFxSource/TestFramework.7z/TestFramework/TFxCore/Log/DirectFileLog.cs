using System;
using System.IO;
using System.Xml.Serialization;
using System.Xml;

namespace Expedia.Test.Framework.Log
{
	/// <summary>
	/// Summary description for DirectFileLog.
	/// </summary>
	public class DirectFileLog : IDirectLog
	{
		int CurrentHtmlDoc;
        int CurrentPicDoc;
		public string FileName;
		StreamWriter m_logFile;

		XmlSerializer serializer;
		XmlTextWriter doc;

		public DirectFileLog()
		{

		}

		//TODO: we can buffer these and write in bulk
		public void Add(LogEntry entry)
		{
            if (entry == null)
                return;
			if( m_logFile == null)
			{
				Start();
			}

            string logdir = Directory.GetCurrentDirectory() + "\\Log\\";

			if (entry.Type == EntryType.PlainText)
			{
				serializer.Serialize(doc, entry);
			}
			else if (entry.Type == EntryType.Html)
			{
                StreamWriter writer = File.CreateText(logdir + DateTime.Now.ToString("MMddyyyyhhmmss") + "." + CurrentHtmlDoc + ".htm");
				entry.Text.Replace("\r\n","<BR>");
				writer.Write(entry.Text);
				writer.Close();
				CurrentHtmlDoc++;
			}
            else if (entry.Type == EntryType.Picture)
            {
                BinaryWriter bw = new BinaryWriter(File.Create(logdir + DateTime.Now.ToString("MMddyyyyhhmmss") + "." + CurrentPicDoc + ".jpg"));
                bw.Write(entry.Array);
                bw.Close();
                CurrentPicDoc++;
                
            }
		}

		public void Start()
		{
			m_logFile = new StreamWriter(this.FileName, false); 
			doc = new System.Xml.XmlTextWriter(m_logFile);
			doc.WriteStartElement("Log");
			doc.WriteStartElement("LogEntries");
			serializer = new System.Xml.Serialization.XmlSerializer(typeof(LogEntry));
			CurrentHtmlDoc = 0;
            CurrentPicDoc = 0;

            if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\Log"))
            {
                Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\Log");
            }


		}


		public void End()
		{
			if(m_logFile != null)
			{
                doc.Close();
               
			}

            
		}

		public static ILog GetLog(string fileName)
		{

			TFxLog log = new TFxLog();

			if(System.IO.File.Exists(fileName))
			{
				XmlTextReader reader = null;
				
				try
				{
					XmlDocument doc = new XmlDocument();
					doc.Load(fileName);
					XmlNodeList nodeList = doc.SelectNodes("Log//LogEntries//LogEntry");
					XmlSerializer serializer = new XmlSerializer(typeof(LogEntry));
					

					foreach (XmlNode node in nodeList)
					{
						try
						{
							LogEntry entry = (LogEntry) serializer.Deserialize(new XmlTextReader(node.OuterXml, XmlNodeType.Element, null));
							log.Add(entry);
						}
						catch(Exception e)
						{
							Console.WriteLine(e);
						}
					}
					
				}
				catch(Exception e)
				{
					// Write exeption and return empty log.
					Console.WriteLine(e);
				}
				finally
				{
					if(reader != null)
					{
						reader.Close();
					}
				}
			}

			return log;

		}
	
	}
}
