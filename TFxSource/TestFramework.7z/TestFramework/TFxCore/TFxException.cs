using System;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Represents errors that occur during TFx Test execution.
    /// </summary>
    public class TFxException : ApplicationException
    {
        /// <summary>
        /// Initializes a new instance of the <typeparamref name="Expedia.Test.Framework.TFxException"/> class.
        /// </summary>
        public TFxException() { }

        /// <summary>
        /// Initializes a new instance of the <typeparamref name="Expedia.Test.Framework.TFxException"/> 
        /// class with a specified error message.
        /// </summary>
        /// <param name="message">The message that describes the error.</param>
        public TFxException(string message) : base(message) { }

        /// <summary>
        /// Initializes a new instance of the <typeparamref name="Expedia.Test.Framework.TFxException"/> 
        /// class with a specified error message and a reference to the inner exception that is the cause
        /// of this exception.
        /// </summary>
        /// <param name="message">The message that describes the error.</param>
        /// <param name="innerException">The exception that is the cause of the current exception or null reference if no inner exception is specified.</param>
        public TFxException(string message, Exception innerException) : base(message, innerException) { }

        /// <summary>
        /// Error category of failed test case 
        /// </summary>
        public TestErrorCategory ErrorCategory
        {
            get;
            set;
        }

        /// <summary>
        /// Detailed Infomation for describing the failed test case
        /// </summary>
        public string ErrorDetail
        {
            get;
            set;
        }
    }
}
