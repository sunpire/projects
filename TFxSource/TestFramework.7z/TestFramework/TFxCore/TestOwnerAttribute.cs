using System;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Attribute used to denote the owner of a test case.
    /// </summary>
    [AttributeUsage(AttributeTargets.Method |
        AttributeTargets.Assembly |
        AttributeTargets.Class,
        AllowMultiple = true)]
    public class TestOwnerAttribute : Attribute
    {
        private string m_owner;

        /// <summary>
        /// Test Owner Attribute
        /// </summary>
        public TestOwnerAttribute()
        { }

        /// <summary>
        /// Test Owner Attribute
        /// </summary>
        /// <param name="owner"></param>
        public TestOwnerAttribute(string owner)
        {
            this.m_owner = owner;
        }

        /// <summary>
        /// Ower
        /// </summary>
        public string Owner
        {
            get
            {
                return this.m_owner;
            }
            set
            {
                this.m_owner = value;
            }
        }
    }
}