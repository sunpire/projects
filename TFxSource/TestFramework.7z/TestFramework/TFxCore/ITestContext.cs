﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Expedia.Test.Framework
{
    public interface ITestContext
    {
        T GetConfig<T>(string configName);
        T GetConfig<T>(string configName, T defaultValue);

        void SetConfig<T>(string configName, T value);

        bool IsConfigDefined(string configName);
        bool IsProduction { get; }
        string Site { get; }
        string TVAServer { get; }
        string TravServer { get; }
        bool SOAConfigV2 { get; }
        string SOAEnvironment { get; }
        string SOAServiceName { get; }
        string SOAServiceDeploymentMachine { get; }
        int TPID { get; }
        int LangID { get; }
        int EAP { get; }
    }
}
