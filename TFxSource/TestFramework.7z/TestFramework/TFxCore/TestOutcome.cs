using System;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Used to determine the outcome of an executed test.
    /// </summary>
    public enum TestOutcome
    {
        /// <summary>
        /// Indicates that the test has no outcome.
        /// </summary>
        None,

        /// <summary>
        /// Indicates that the test has an inconclusive outcome that cannot be determined.
        /// </summary>
        Inconclusive,

        /// <summary>
        /// Indicates that the test has passed.
        /// </summary>
        Pass,

        /// <summary>
        /// Indicates that the test has failed.
        /// </summary>
        Fail,

        /// <summary>
        /// Indicates that the test has timed out.
        /// </summary>
        Timeout
    }
}
