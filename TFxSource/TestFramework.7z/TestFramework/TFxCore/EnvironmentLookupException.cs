﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Represents errors that are caused by the <typeparamref name="Expedia.Test.Framework.EnvironmentLookup"/> class.
    /// </summary>
    public class EnvironmentLookupException : TFxException
    {
        /// <summary>
        /// Initializes a new instance of the <typeparamref name="Expedia.Test.Framework.EnvironmentLookupException"/> class.
        /// </summary>
        public EnvironmentLookupException() { }

        /// <summary>
        /// Initializes a new instance of the <typeparamref name="Expedia.Test.Framework.EnvironmentLookupException"/> 
        /// class with a specified error message.
        /// </summary>
        /// <param name="message">The message that describes the error.</param>
        public EnvironmentLookupException(string message) : base(message) { }

        /// <summary>
        /// Initializes a new instance of the <typeparamref name="Expedia.Test.Framework.EnvironmentLookupException"/> 
        /// class with a specified error message.
        /// </summary>
        /// <param name="message">The message that describes the error.</param>
        /// <param name="args">Any arguments used by the message.</param>
        public EnvironmentLookupException(string message, params object[] args) : base(string.Format(message, args)) { }

        /// <summary>
        /// Initializes a new instance of the <typeparamref name="Expedia.Test.Framework.EnvironmentLookupException"/> 
        /// class with a specified error message and a reference to the inner exception that is the cause
        /// of this exception.
        /// </summary>
        /// <param name="message">The message that describes the error.</param>
        /// <param name="innerException">The exception that is the cause of the current exception or null reference if no inner exception is specified.</param>
        public EnvironmentLookupException(string message, Exception innerException) : base(message, innerException) { }
    }
}
