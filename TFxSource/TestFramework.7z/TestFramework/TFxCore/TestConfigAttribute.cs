﻿using System;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Attribute used to denote the owner of a test case.
    /// </summary>
    [AttributeUsage(AttributeTargets.Method |
        AttributeTargets.Assembly |
        AttributeTargets.Class,
        AllowMultiple = true)]
    public class ConfigAttribute: Attribute
    {
        private string m_name;
        private string m_defaultValue;

        /// <summary>
        /// Config Attribute
        /// </summary>
        public ConfigAttribute()
        { }

        /// <summary>
        /// Config Attribute
        /// </summary>
        /// <param name="name">Name</param>
        /// <param name="defaultValue">Default Value</param>
        public ConfigAttribute(string name, string defaultValue)
        {
            this.m_name = name;
            this.m_defaultValue = defaultValue;            
        }

        /// <summary>
        /// Name
        /// </summary>
        public string Name
        {
            get
            {
                return this.m_name;
            }
            set
            {
                this.m_name = value;
            }
        }

        /// <summary>
        /// Dafault Value
        /// </summary>
        public string DefaultValue
        {
            get
            {
                return this.m_defaultValue;
            }
            set
            {
                this.m_defaultValue = value;
            }
        }

    }

    /// <summary>
    /// ConfigAttributeComparer
    /// </summary>
    public class ConfigAttributeComparer : System.Collections.Generic.IEqualityComparer<ConfigAttribute>
    {

        #region IEqualityComparer<ConfigAttribute> Members

        /// <summary>
        /// Equals
        /// </summary>
        /// <param name="x">X</param>
        /// <param name="y">Y</param>
        /// <returns></returns>
        public bool Equals(ConfigAttribute x, ConfigAttribute y)
        {
            return x.Name == y.Name;
        }

        /// <summary>
        /// Get Hash Code
        /// </summary>
        /// <param name="obj">Obj</param>
        /// <returns></returns>
        public int GetHashCode(ConfigAttribute obj)
        {
            return obj.GetHashCode();
        }

        #endregion
    }
}