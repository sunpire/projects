//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: BuildNotFoundException.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 

using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for BuildNotFoundException.
	/// </summary>
	public class BuildNotFoundException : TFxException
	{
        /// <summary>
        /// Build Not Found Exception
        /// </summary>
        public BuildNotFoundException()
            : base(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Build_NotFound"))
		{
			
		}
	}
}
