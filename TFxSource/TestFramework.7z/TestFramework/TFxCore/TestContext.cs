using System;
using System.Linq;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using Expedia.Automation.Web.Registry;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Test context class used to define the context of the currently executing test.
    /// </summary>
    public sealed partial class TestContext
    {
        #region Constructor
        /// <summary>
        /// Private constructor to make sure singleton doesnt get initialized.
        /// </summary>
        private TestContext()
        {
            
        }
        #endregion

        #region Properties

        /// <summary>
        /// Gets the test context singleton instance.
        /// </summary>
        public static TestContext Instance
        {
            get
            {
                lock (padlock)
                {
                    if (instance == null)
                    {
                        instance = new TestContext();
                        
                    }
                    else if (!isInitialized)
                    {
                        throw new InvalidOperationException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_Init_NotInit"));
                    }
                    return instance;
                }
            }
        }

        /// <summary>
        ///  get test method from stack trace
        /// </summary>
        /// <param name="stack"></param>
        /// <returns></returns>
        private static MethodInfo GetTestMethod(StackTrace stack)
        {
            for (int i = 0; i < stack.FrameCount; i++)
            {
                var stackFrame = stack.GetFrame(i);
                var method = stackFrame.GetMethod();
                var atts = method.GetCustomAttributes(false);
                if (atts != null)
                {
                    foreach (var at in atts)
                    {
                        if (at.ToString() == "Expedia.Test.Framework.TestAttribute")
                        {
                            return method as MethodInfo;
                        }
                    }
                }

            }
            return null;
        }



        /// <summary>
        /// Gets the test full name of the currently running test.
        /// </summary>
        public string TestFullName
        {
            get
            {
                return this.currentTestFullName;
            }
        }

        /// <summary>
        /// Gets the test name of the currently running test.
        /// </summary>
        public string TestName
        {
            get
            {
                return this.currentTestName;
            }
        }

        /// <summary>
        /// Gets the test fixture (an instance of the class that
        /// declares the currently running test).
        /// </summary>
        public object TestFixture
        {
            get
            {
                return this.currentTestFixture;
            }
        }

        private static bool IsTestDataAvailable = true;
        #endregion

        #region Methods

        /// <summary>
        /// Inititializes the test context with a new test method and configs.
        /// </summary>
        /// <param name="assignmentConfigs">Assignments Configs</param>
        /// <param name="serverName"></param>
        /// <param name="dbName"></param>
        /// <param name="isTestDataAvailable">use Test Data or not</param>
        public static void Initialize(Dictionary<string, string> assignmentConfigs, string serverName, string dbName, bool isTestDataAvailable)
        {
            var stack = new StackTrace();
            if (stack.FrameCount < 2 || stack.GetFrame(2).GetMethod().DeclaringType.FullName != "Expedia.Test.Framework.Driver")
            {
                var method = GetTestMethod(stack);
                if (method == null)
                {
                    //Test has been kicked off by non exp test driver
                    //just send in empty values
                    method = MethodInfo.GetCurrentMethod() as MethodInfo;
                }

                if (method != null)
                {
                    IsTestDataAvailable = isTestDataAvailable;
                    if (assignmentConfigs.ContainsKey(c_runtime_lrmdbserver))
                        assignmentConfigs[c_runtime_lrmdbserver] = serverName == string.Empty ? assignmentConfigs[c_runtime_lrmdbserver] : serverName;

                    else if (serverName != string.Empty)
                        assignmentConfigs.Add(c_runtime_lrmdbserver, serverName);


                    if (assignmentConfigs.ContainsKey(c_runtime_lrmdbname))
                        assignmentConfigs[c_runtime_lrmdbname] = dbName == string.Empty ? assignmentConfigs[c_runtime_lrmdbname] : dbName;

                    else if (dbName != string.Empty)
                        assignmentConfigs.Add(c_runtime_lrmdbname, dbName);
                    
                    DriverOnly.Initialize(method, assignmentConfigs);
                    return;
                }
            }

            throw new InvalidOperationException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_Init_NotInit")); 
        }

        /// <summary>
        /// Driver Only
        /// </summary>
        public static class DriverOnly
        {
            /// <summary>
            /// Inititializes the test context with a new test method and configs.
            /// </summary>
            /// <param name="testMethod">The method info describing the test method.</param>
            /// <param name="assignmentConfigs">Assignments Configs</param>
            public static void Initialize(MethodInfo testMethod, Dictionary<string, string> assignmentConfigs)
            {
                //Initialize TestData
                if (IsTestDataAvailable)
                {
                    InitializeTestData(assignmentConfigs);
                }

                Dictionary<string, string> temp = new Dictionary<string, string>(StringComparer.CurrentCultureIgnoreCase);

                // make sure we only initialize this once.
                if (isInitialized)
                {
                    throw new InvalidOperationException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_Init_Initialized"));
                }

                // verify test method
                if (testMethod == null)
                {
                    throw new ArgumentNullException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Arg_Name", "testMethod"));
                }                         

                // get the only instance of this class
                TestContext onlyInstance = Instance;

                // set the current test
                onlyInstance.currentTestName = testMethod.Name;
                onlyInstance.currentTestFullName = string.Format("{0}.{1}", testMethod.DeclaringType.Namespace, testMethod.Name);

                // initialize the configs
                onlyInstance.configs = new ScopedConfig();
                onlyInstance.convertedConfigs = new Dictionary<string, object>(StringComparer.CurrentCultureIgnoreCase);
                onlyInstance.defaultTestConfigs = GetDefaultTestConfigs(testMethod);

                //
                // initialize the HashSet which store the list of configs being accessed
                //
                onlyInstance.accessedConfigs = new HashSet<string>();

                if (assignmentConfigs != null)
                {
                    //Add the assignment configs first

                    // load up all the configs here
                    foreach (string key in assignmentConfigs.Keys)
                    {
                        temp.Add(key, assignmentConfigs[key]);
                    }
                    onlyInstance.configs.Push(temp);
                }

                // initialize the result and scenario results
                onlyInstance.CurrentScenario = null;
                onlyInstance.scenarioResults = new List<TestRunResult>();                                            
                               
                //set start time for test
                onlyInstance.SetConfig<DateTime>(c_runtime_starttime, DateTime.Now);

                // mark as initialized
                isInitialized = true;

                //Subcribe to Expedia Registry Logging events
                ExpediaRegistry.Log += new ExpediaRegistry.LogHandler(ExpediaRegistry_Log);
                ExpediaRegistry.GetConfig += new Func<string, string>(TestContext.Instance.GetConfig);

                // set the logger net file share path
                try
                {
                    // First try to see if we can really use the AssignmentOutputDirectory
                    String logFileShare = onlyInstance.AssignmentOutputDirectory;

                    // if it success with no exception, we can set it to be used by the logger
                    Logger.Instance.SetLogFileShare(logFileShare);
                }
                catch { }
            }

            private static void InitializeTestData(Dictionary<string, string> assignmentConfigs)
            {
                int assignmentId = assignmentConfigs.ContainsKey(c_runtime_assignmentid) ? Convert.ToInt32(assignmentConfigs[c_runtime_assignmentid]) : 0;
                int labrunId = assignmentConfigs.ContainsKey(c_runtime_labrunid) ? Convert.ToInt32(assignmentConfigs[c_runtime_labrunid]) : 0;
                string ns = assignmentConfigs.ContainsKey(c_runtime_testnamespace) ? assignmentConfigs[c_runtime_testnamespace] : string.Empty;
                string branchName = assignmentConfigs.ContainsKey(c_runtime_releaseinfo) ? assignmentConfigs[c_runtime_releaseinfo] : "main";

                // get server and db to initialize
                string serverName = assignmentConfigs.ContainsKey(c_runtime_lrmdbserver) ? assignmentConfigs[c_runtime_lrmdbserver] : string.Empty;
                string serverMirrorName = assignmentConfigs.ContainsKey(c_runtime_lrmdbservermirror) ? assignmentConfigs[c_runtime_lrmdbservermirror] : string.Empty;
                string dbName = assignmentConfigs.ContainsKey(c_runtime_lrmdbname) ? assignmentConfigs[c_runtime_lrmdbname] : string.Empty;

                // run by test studio locally, then get serverName and dbName from tfxdb.config
                if (labrunId == 0 && ns != string.Empty)
                {
                    // initialize TFx to set serverName and dbName value from tfxdb.config,
                    // currently, if tfxdb.config does not exist or serverName and dbName are empty, there has default values in TFx,
                    // that means, if run by test studio, serverName and dbName always have values
                    TFxDBConfig dbConfig = new TFxDBConfig();
                    serverName = dbConfig.ServerName;
                    dbName = dbConfig.DBName;
                    serverMirrorName = dbConfig.ServerMirrorName;
                    if (!assignmentConfigs.ContainsKey(c_runtime_lrmdbserver))
                        assignmentConfigs.Add("__lrmdbserver", serverName);
                    if (!assignmentConfigs.ContainsKey(c_runtime_lrmdbservermirror))
                        assignmentConfigs.Add("__lrmdbservermirror", serverMirrorName);
                    if (!assignmentConfigs.ContainsKey(c_runtime_lrmdbname))
                        assignmentConfigs.Add("__lrmdbname", dbName);
                }

                if (serverName == string.Empty || dbName == string.Empty)
                {
                    LogError(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_Init_DBNotSpecified"));
                }

                //TODO: add mirror server
                LogComment(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_Init_TestData", 
                    assignmentId, labrunId, ns, branchName, serverName, dbName, serverMirrorName));

                if (TestDataWrapper.Initialize(assignmentId, labrunId, ns, branchName, serverName, dbName, serverMirrorName) == false)
                {
                    throw new TFxException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_Init_TestDataFailed"));
                }
                TestDataWrapper.AddAssignmentConfigs(assignmentConfigs);

                // Preload all SoftTest level test data
                TestDataWrapper.LoadAllSoftTestData();
            }


            /// <summary>
            /// Get the configs specified above the test code from published DLL.
            /// </summary>
            private static Dictionary<string, string> GetDefaultTestConfigs(MethodInfo methodInfo)
            {
                //Return the test code defined configs
                var testConfigList = (from cl in GetConfigList(methodInfo)
                                      select new { Name = ((ConfigAttribute)cl).Name, DefaultValue = ((ConfigAttribute)cl).DefaultValue });
                return testConfigList.ToDictionary(k => k.Name, k => k.DefaultValue);
            }

            private static object[] GetConfigList(MethodBase methodInfo)
            {
                List<object> configList = methodInfo.GetCustomAttributes(typeof(ConfigAttribute), false).ToList();
                List<object> classConfigList = methodInfo.DeclaringType.GetCustomAttributes(typeof(ConfigAttribute), false).ToList();
                List<object> assemblyConfigList = methodInfo.DeclaringType.Assembly.GetCustomAttributes(typeof(ConfigAttribute), false).ToList();
                
                foreach (object cl in classConfigList)
                {
                    if (!configList.Contains(cl))
                    {
                        configList.Add(cl);
                    }
                }

                foreach (object cl in assemblyConfigList)
                {
                    if (!configList.Contains(cl))
                    {
                        configList.Add(cl);
                    }
                }
               
                return configList.ToArray();
            }    

            /// <summary>
            /// Evaluate configs or parameters from specific expression.
            /// </summary>
            /// <param name="expression">Expression to evaluate.</param>
            /// <returns></returns>
            public static string EvalExpression(string expression)
            {
                return TestContext.IsTestDataAvailable ? TestDataWrapper.EvalExpression(expression) : expression;
            }

            /// <summary>
            /// Listens to the Expedia Registry Event to log information
            /// </summary>
            /// <param name="comment"></param>
            /// <param name="args"></param>
            static void ExpediaRegistry_Log(string comment, params object[] args)
            {
                LogComment(comment, args);
            }

            /// <summary>
            /// Inititializes the test context with the current test fixture.
            /// </summary>
            /// <param name="testFixture">The text fixture (an instance of the class declaring this test).</param>
            /// <exception cref="System.ArgumentNullException">testFixture is null.</exception>
            public static void SetTestFixture(object testFixture)
            {
                // verify test fixture
                if (testFixture == null)
                {
                    throw new ArgumentNullException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Arg_Name", "testFixture"));
                }

                TestContext.Instance.currentTestFixture = testFixture;
            }

            /// <summary>
            /// Cleans up all the test data and disposes
            /// test context and other related objects that
            /// need to be disposed.  Call this method when
            /// everything is done.
            /// </summary>
            public static void Cleanup()
            {
                // if we're not initialized just exit
                if (!isInitialized)
                {
                    return;
                }

                // clean up the cleaners
                foreach (CleanupDelegate cleaner in cleaners)
                {
                    try
                    {
                        cleaner.Invoke();
                    }
                    catch (Exception e)
                    {
                        // Eat up any exceptions thrown by the cleaner.
                        // TODO: Write log to the right place.
                        Console.WriteLine(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_Cleaner_Failed", e));
                    }
                }

                // clear all the converted configs
                instance.convertedConfigs.Clear();

                // clear all of the assignment configs
                instance.configs.Clear();

                // clear TestData
                TestDataWrapper.Dispose();

                //Unsubscribe to Expedia Registry Logging Events
                ExpediaRegistry.Log -= new ExpediaRegistry.LogHandler(ExpediaRegistry_Log);
                ExpediaRegistry.GetConfig -= new Func<string, string>(TestContext.Instance.GetConfig);

                // mark as not initialized
                isInitialized = false;
                instance = null;
            }


            /// <summary>
            /// Cleans up only config and convertedConfig.
            /// </summary>
            public static void Cleanup(bool externalUse=true)
            {
                // clear all the converted configs
                instance.convertedConfigs.Clear();

                // clear all of the assignment configs
                instance.configs.Clear();
            }

            /// <summary>
            /// Attaches a cleanup delegate to the test context so that when 
            /// the test context is cleaned up, all cleaners are automatically
            /// invoked so that they can also be cleaned up.
            /// </summary>
            /// <param name="cleaner">The cleanup delegate to attach.</param>
            public static void AttachCleaner(CleanupDelegate cleaner)
            {
                // only attach if it's not already attached.
                if (!cleaners.Contains(cleaner))
                {
                    cleaners.Add(cleaner);
                }
            }

            /// <summary>
            /// Marks a scenario as failed with an exception.
            /// </summary>
            /// <param name="exception">The exception that caused the test to fail.</param>
            public static void MarkTestFailed(Exception exception)
            {
                TestContext.Instance.ScenarioFail(exception);
            }

            /// <summary>
            /// Prepares the list of scenarios for assignment result 
            /// interpretation.  Driver should call this method before 
            /// accessing the scenarios property.
            /// </summary>
            public static void PrepareScenarios()
            {
                TestContext.Instance.PrepareScenarios();
            }

            /// <summary>
            /// Used to attach and detach cleaners which are automatically invoked
            /// during cleanup.
            /// </summary>
            private static List<CleanupDelegate> cleaners = new List<CleanupDelegate>();

            /// <summary>
            /// Used in the driver to get the test parameters
            /// </summary>
            public static Dictionary<string, string> TestParameters;
           
        }
        #endregion

        #region Fields

        /// <summary>
        /// The results of the individual scenarios.
        /// </summary>
        private List<TestRunResult> scenarioResults;

        /// <summary>
        /// The reference to the test fixture (class that contains the executing test).
        /// </summary>
        private object currentTestFixture;

        /// <summary>
        /// The name of the currently executing test.
        /// </summary>
        private string currentTestName;

        /// <summary>
        /// The full namespace + name of the currently executing test.
        /// </summary>
        private string currentTestFullName;

        /// <summary>
        /// The only instance of this class.
        /// </summary>
        private static TestContext instance = null;

        /// <summary>
        /// Used to lock the creation of an instance.
        /// </summary>
        private static readonly object padlock = new object();

        /// <summary>
        /// Indicates whether this instance has been initialized or not.
        /// </summary>
        private static bool isInitialized;      

        #endregion
    }
}
