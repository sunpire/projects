﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// The error category of the failed case
    /// </summary>
    public enum TestErrorCategory
    {
        /// <summary>
        /// Default category if not specify
        /// </summary>
        Unresolved = 1,

        /// <summary>
        /// Failed by environment issue
        /// </summary>
        Environment = 2,

        [EnumMember(Value = "Product Bug")]
        /// <summary>
        /// A known production bug
        /// </summary>
        ProductBug = 3,

        /// <summary>
        /// Failed by config setting
        /// </summary>
        Config = 4,

        [EnumMember(Value = "Automation Bug")]
        /// <summary>
        /// A known automation bug
        /// </summary>
        AutomationBug = 5,

        /// <summary>
        /// Failed by other issues
        /// </summary>
        Other = 6,

        /// <summary>
        /// Failed by framework issue
        /// </summary>
        Framework = 7
    }

    public static class EnumHelper
    {
        public static String ToValue(this Enum objEnum)
        {
            var value = objEnum.ToValue<String>();
            if (string.IsNullOrWhiteSpace(value))
            {
                value = objEnum.ToString();
            }
            return value;
        }

        public static T ToValue<T>(this Enum objEnum) //where T : Attribute
        {
            T value = default(T);
            bool hasError = false;
            var values = objEnum.GetType().GetMember(objEnum.ToString()).FirstOrDefault();
            var custom = (values == null) ? null : values.GetCustomAttributes(typeof(EnumMemberAttribute), true).FirstOrDefault();
            var actual = (custom == null) ? null : (custom as EnumMemberAttribute).Value;
            if (actual != null)
            {
                value = (T)(object)(actual);
                if (value == null)
                {
                    try
                    {
                        value = (T)(Object)(objEnum.ToString());
                    }
                    catch
                    {
                        hasError = true;
                    }
                }
            }
            if (hasError && value == null)
            {
                // unable to convert to type T
            }
            return value;
        }
    }
}
