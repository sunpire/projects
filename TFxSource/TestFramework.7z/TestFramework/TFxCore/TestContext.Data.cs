using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using Expedia.Automation.Web.Registry;
using Microsoft.Win32;

namespace Expedia.Test.Framework
{
    public partial class TestContext : ITestContext
    {
        private static bool isTestDataWrapperInitialized;

        #region Test Config Data

        #region Temp DTD 2.0 Constants

        /// <summary>
        /// The config which will force DynamicData to point to DTD 2.0
        /// </summary>
        const string c_ForceDynToUseDTDSwitch = "DDUseDTD20";

        /// <summary>
        /// Now DynamicData is sunset, we will always make the default to true,
        /// ie, always get data from DTD 2.0 now
        /// </summary>
        const bool ForceDynToUseDTDSwitch_Default = true;

        #endregion

        #region Data Constants
        const string c_tpid = "tpid";
        const string c_langid = "langid";
        const string c_eap = "eap";
        const string c_username = "username";
        const string c_password = "password";
        const string c_servername = "servername";
        const string c_firstname = "firstname";
        const string c_lastname = "lastname";
        const string c_site = "site";
        const string c_hostname = "hostname";
        const string c_usehostname = "usehostname";
        const string c_utilsite = "utilsite";
        const string c_himssite = "himssite";
        const string c_hawisite = "hawisite";
        const string c_isproduction = "isproduction";
        const string c_e3striping = "e3striping";
        const string c_email = "email";
        const string c_fram = "fram";
        const string c_upgradefolder = "upgradefolder";
        const string c_filedir = "filedir";
        const string c_server = "server";
        const string c_alias = "alias";
        const string c_auth_mode = "auth_mode";
        const string c_trav_server = "travserver";
        const string c_downloadorupload_file_fullpath = "downloadoruploadfilefullpath";
        const string c_data_output_directory = "dataoutputdirectory";
        const string c_assignment_output_directory = "assignmentoutputdirectory";
        const string c_source_output_directory = "sourceoutputdirectory";
        const string c_source_labrunid = "sourcelabrunid";
        const string c_page_load_timeout = "pageloadtimeout";
        const string c_wait_page_load_complete = "waitpageloadcomplete";
        const string c_auto_delete_itin = "autodeleteitin";
        const string c_saved_itinerary = "saveditinerary";
        const string c_tva_server = "tvaserver";
        private const string c_soa_environment = "Environment";
        private const string c_soa_configV2 = "SOAConfigV2";
        private const string c_soa_configV2_filePath = "SOAConfigV2FilePath";
        private const string c_soa_serviceName = "SOAServiceName";
        private const string c_soa_service_Deployment_Machine = "SOADeploymentMachine";
        private const string c_soa_machine = "SOAMachine";
        private const string c_soa_port = "SOAPort";
        private const string c_soa_log_fastInfoset_message = "LogFastInfoSetMessage";
        private const string c_hotwire_environment = "HotwireEnvironment";
        private const string c_opaque_server = "OpaqueServer";
        const string c_siteid = "siteid";

        #region Runtime Data Constants
        const string c_runtime_logtype = "__logtype";
        const string c_runtime_loginfo = "__loginfo";
        const string c_runtime_loglevel = "__loglevel";
        const string c_runtime_assignmenttimeout = "__assignmenttimeout";
        const string c_runtime_assignmentid = "__assignmentid";
        const string c_runtime_email = "__email";
        const string c_runtime_labrunname = "__labrunname";
        const string c_runtime_assignmentname = "__assignmentname";
        const string c_runtime_labrunid = "__labrunid";
        const string c_runtime_labrungid = "__labrungid";
        const string c_runtime_releaseinfo = "__releaseinfo";
        const string c_runtime_browsertype = "browsertype";
        const string c_runtime_createdby = "__createdby";
        const string c_runtime_emailonlyonfailures = "__emailOnlyOnFailures";
        const string c_runtime_manager = "__manager";
        const string c_runtime_starttime = "__starttime";
        const string c_runtime_lrmdbserver = "__lrmdbserver";
        const string c_runtime_lrmdbservermirror = "__lrmdbservermirror";

        const string c_runtime_lrmdbname = "__lrmdbname";
        const string c_runtime_environment = "__environmentName";

        const string c_runtime_testnamespace = "__testnamespace";
        #endregion

        const string c_dynamic_denver_adminuser = "User_Denver_Admin";
        const string c_dynamic_denver_adminpassword = "Password_Denver_Admin";
        const string c_dynamic_karmalab_adminuser = "User_Karmalab_Admin";
        const string c_dynamic_karmalab_adminpassword = "Password_Karmalab_Admin";
        const string c_dynamic_firstname = "Trav_FirstName";
        const string c_dynamic_lastname = "Trav_LastName";
        const string c_dynamic_email = "Trav_Email";

        #endregion

        #region Defaults

        /// <summary>
        /// Defalut TPID
        /// </summary>
        public static readonly int DefaultTPID = 1;

        /// <summary>
        /// Defalut Lang ID
        /// </summary>
        public static readonly int DefaultLangID = 1033;

        /// <summary>
        /// Defalut EAP
        /// </summary>
        public static readonly int DefaultEAP = 0;

        /// <summary>
        /// Default Page Load Time Out
        /// </summary>
        public static readonly int DefaultPageLoadTimeout = 120;

        /// <summary>
        /// Default Wait Page Load Complete
        /// </summary>
        public static readonly bool DefaultWaitPageLoadComplete = false;

        /// <summary>
        /// Defalut Browser Type
        /// </summary>
        public static readonly string DefaultBrowserType = "IEForm";

        private static readonly string FileLog = "FileLog";
        private static readonly string DenverManagerNames = "|tfxexecutionmanager|tfxchandlermanager|";
        private static readonly string LocalExecutionClientName = "teststudio";
        private static readonly string DefaultSharedDataDirectory = @"\\chelsqltfx01.idx.expedmz.com\TFxLabRunData\";


        private static readonly string DefaultSoaMachine = "h2bproxy.stable.chel.sb";
        private static readonly int DefaultSoaPort = 80;
        #endregion

        #region Runtime Configs

        /// <summary>
        /// Run Time
        /// </summary>
        public static class Runtime
        {
            private static ITestContext context;
            /// <summary>
            /// Gets the context on which the runtime will run
            /// </summary>
            public static ITestContext Context
            {
                get
                {
                    if (context == null)
                    {
                        context = TestContext.Instance;
                    }
                    return context;
                }
                set { context = value; }
            }

            /// <summary>
            /// Gets the start time of the test case, this will be set in the initialize method for testcontext
            /// </summary>
            public static DateTime StartTime
            {
                get
                {
                    return Context.GetConfig<DateTime>(c_runtime_starttime);
                }
            }

            /// <summary>
            /// Gets the notification email.
            /// </summary>
            public static string Email
            {
                get
                {
                    return Context.GetConfig<string>(c_runtime_email, string.Empty);
                }
            }

            /// <summary>
            /// Gets the manager name.
            /// </summary>
            public static string Manager
            {
                get
                {
                    return Context.GetConfig<string>(c_runtime_manager, string.Empty);
                }
            }

            /// <summary>
            /// Gets the name of the labrun.
            /// </summary>
            public static string LabRunName
            {
                get
                {
                    return Context.GetConfig<string>(c_runtime_labrunname, string.Empty);
                }
            }

            /// <summary>
            /// Gets the labrun id.
            /// </summary>
            public static int LabRunId
            {
                get
                {
                    return Context.GetConfig<int>(c_runtime_labrunid, -1);
                }
            }

            /// <summary>
            /// Gets the assignment id.
            /// </summary>
            public static int AssignmentId
            {
                get
                {
                    return Context.GetConfig<int>(c_runtime_assignmentid, -1);
                }
            }

            /// <summary>
            /// Gets the assignment timeout.
            /// </summary>
            public static TimeSpan AssignmentTimeout
            {
                get
                {
                    return Context.GetConfig<TimeSpan>(c_runtime_assignmenttimeout, TimeSpan.FromMinutes(10));
                }
            }

            /// <summary>
            /// Gets the log type (DBLog, FileLog).
            /// </summary>
            public static string LogType
            {
                get
                {
                    return Context.GetConfig<string>(c_runtime_logtype, FileLog);
                }
            }

            /// <summary>
            /// Gets the log level (Test, TFx, Browser, TFxConfig, TestApi, etc).
            /// </summary>
            public static LogLevelType LogLevel
            {
                get
                {
                    return Context.GetConfig<LogLevelType>(c_runtime_loglevel, default(LogLevelType));
                }
            }

            /// <summary>
            /// Gets the log connection string info.
            /// </summary>
            public static string LogInfo
            {
                get
                {
                    return Context.GetConfig<string>(c_runtime_loginfo,
                        Assembly.GetExecutingAssembly().Location);
                }
            }

            /// <summary>
            /// Gets the log LRM DB server name
            /// </summary>
            public static string LRMDBServer
            {
                get
                {
                    return Context.GetConfig<string>(c_runtime_lrmdbserver,
                        Assembly.GetExecutingAssembly().Location);
                }
            }

            /// <summary>
            /// Gets the log LRM DB server mirror name
            /// </summary>
            public static string LRMDBServerMirror
            {
                get
                {
                    return Context.GetConfig<string>(c_runtime_lrmdbservermirror,
                        Assembly.GetExecutingAssembly().Location);
                }
            }

            /// <summary>
            /// Gets the LRM DB Name.
            /// </summary>
            public static string LRMDBName
            {
                get
                {
                    return Context.GetConfig<string>(c_runtime_lrmdbname,
                        Assembly.GetExecutingAssembly().Location);
                }
            }
            /// <summary>
            /// Gets the release this assignment belongs to.
            /// </summary>
            public static string Branch
            {
                get
                {
                    return Context.GetConfig<string>(c_runtime_releaseinfo, string.Empty);
                }
            }

            /// <summary>
            /// Gets the browser type to use.
            /// </summary>
            public static string BrowserType
            {
                get
                {
                    return Context.GetConfig<string>(c_runtime_browsertype, DefaultBrowserType);
                }
            }

            /// <summary>
            /// Gets whether we are running locally or not.
            /// </summary>
            public static bool IsLocalExecution
            {
                get
                {
                    return Runtime.CurrentLocalExecutionClient.Equals(LocalExecutionClientName, StringComparison.CurrentCultureIgnoreCase);
                }
            }

            /// <summary>
            /// Gets the current local execution client (ie. the test runner - TestStudio).
            /// </summary>
            public static string CurrentLocalExecutionClient
            {
                get
                {
                    return Process.GetCurrentProcess().ProcessName;
                }
            }

            /// <summary>
            /// Gets the username of the person who created this labrun.
            /// </summary>
            public static string CreatedBy
            {
                get
                {
                    return Context.GetConfig<string>(c_runtime_createdby, string.Empty);
                }
            }

            /// <summary>
            /// Gets the username of the person who created this labrun.
            /// </summary>
            public static string EmailOnlyOnFailure
            {
                get
                {
                    return TestContext.Instance.GetConfig<string>(c_runtime_emailonlyonfailures, "false");
                }
            }

            /// <summary>
            /// Get the namespace of softtest
            /// </summary>
            public static string TestNamespace
            {
                get
                {
                    return Context.GetConfig<string>(c_runtime_testnamespace, string.Empty);
                }
            }

            /// <summary>
            /// Gets the environment this labrun is running on 
            /// </summary>
            public static string Environment
            {
                get
                {
                    string environment = string.Empty;

                    // Check for the runtime config
                    if (Context.IsConfigDefined(c_runtime_environment))
                    {
                        environment = Context.GetConfig<string>(c_runtime_environment);
                    }

                    // Check for not set/empty value
                    if (string.IsNullOrEmpty(environment))
                    {
                        // Lookup environment name based on site config
                        if (!Context.IsConfigDefined(c_site))
                        {
                            throw new TFxException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_NoEnvNoSite"));
                        }

                        Logger.Instance.WriteWarning(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_NoEnv"));

                        // Look up Environment, save to runtime config
                        environment = EnvironmentLookup.GetEnvironment(Context.GetConfig<string>(c_site));
                        Context.SetConfig<string>(c_runtime_environment, environment);
                    }

                    return environment;
                }
            }
        }
        #endregion

        #region Configs

        /// <summary>
        /// Gets common output folder to store your test data.
        /// </summary>
        public string DataOutputDirectory
        {
            get
            {
                String SharedDataDirectory = TestContext.Instance.GetConfig<String>("TestSharedDataDirectory", DefaultSharedDataDirectory);

                string path = Path.Combine(Runtime.LogInfo, "data");
                if (!Runtime.IsLocalExecution)
                {
                    path = Path.Combine(SharedDataDirectory, Runtime.LabRunId.ToString());
                }

                Logger.Instance.WriteInfo("DataOutputDirectory=" + path, LogViewType.LongAndShortLog);

                // ensure that the directory exists
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                // return the path
                return this.GetConfig<string>(c_data_output_directory, path);
            }
        }

        /// <summary>
        /// Gets assignment output folder .
        /// </summary>
        public string AssignmentOutputDirectory
        {
            get
            {
                string path = Path.Combine(Runtime.LogInfo, "data");
                if (!Runtime.IsLocalExecution)
                {

                    path = Path.Combine(DataOutputDirectory, Runtime.AssignmentId.ToString());
                }

                // ensure that the directory exists
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                // return the path
                return this.GetConfig<string>(c_assignment_output_directory, path);
            }
        }

        /// <summary>
        /// Gets common output folder used by a previous labrun.
        /// Note: You must define 'sourcelabrunid' config.
        /// </summary>
        public string SourceOutputDirectory
        {
            get
            {
                String SharedDataDirectory = TestContext.Instance.GetConfig<String>("TestSharedDataDirectory", DefaultSharedDataDirectory);

                string path = Path.Combine(Runtime.LogInfo, "data");
                if (!Runtime.IsLocalExecution)
                {
                    // get the source labrunid
                    int sourceLabRunId = this.GetConfig<int>(c_source_labrunid);

                    // append it to the path
                    path = Path.Combine(SharedDataDirectory, sourceLabRunId.ToString());
                }

                Logger.Instance.WriteInfo("SourceOutputDirectory=" + path, LogViewType.LongAndShortLog);

                // ensure that the directory exists
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                // return the path
                return this.GetConfig<string>(c_source_output_directory, path);
            }
        }

        /// <summary>
        /// Gets or sets the TPID (travel product id).
        /// </summary>
        public int TPID
        {
            get
            {
                return this.GetConfig<int>(c_tpid, DefaultTPID);
            }
            set
            {
                this.SetConfig<int>(c_tpid, value);
            }
        }

        /// <summary>
        /// Gets or sets the language id.
        /// </summary>
        public int LangID
        {
            get
            {
                return this.GetConfig<int>(c_langid, DefaultLangID);
            }
            set
            {
                this.SetConfig<int>(c_langid, value);
            }
        }

        /// <summary>
        /// Gets or sets the TVA server.
        /// </summary>
        public string TVAServer
        {
            get
            {
                return this.GetConfig<string>(c_tva_server, string.Empty);
            }
            set
            {
                this.SetConfig<string>(c_tva_server, value);
            }
        }

        /// <summary>
        /// Gets or sets the EAP (partner id).
        /// </summary>
        public int EAP
        {
            get
            {
                return this.GetConfig<int>(c_eap, DefaultEAP);
            }
            set
            {
                this.SetConfig<int>(c_eap, value);
            }
        }

        /// <summary>
        /// Gets or sets the site.  If config 'useHostname'=true, 
        /// the 'hostname' config will be returned instead of the 'site' config.
        /// </summary>
        public string Site
        {
            get
            {
                // Check for usehostname config
                bool useHostname = this.GetConfig<bool>(c_usehostname, false);
                if (useHostname)
                {
                    string hostname = this.GetConfig<string>(c_hostname, string.Empty);

                    // Verify the hostname exists
                    if (!string.IsNullOrEmpty(hostname))
                    {
                        return hostname;
                    }
                    // else return site
                }

                return this.GetConfig<string>(c_site);
            }
            set
            {
                this.SetConfig<string>(c_site, value);
            }
        }

        /// <summary>
        /// Gets or sets the Util/Agent site.
        /// </summary>
        public string UtilSite
        {
            get
            {
                return this.GetConfig<string>(c_utilsite, this.Site);
            }
            set
            {
                this.SetConfig<string>(c_utilsite, value);
            }
        }

        /// <summary>
        /// Gets the HIMS site associated with the site.
        /// </summary>
        public string HimsSite
        {
            get
            {
                if (!this.IsConfigDefined(c_himssite))
                {
                    string environmentName;

                    try
                    {
                        environmentName = TestContext.Runtime.Environment;
                    }
                    catch (TFxException ex)
                    {
                        throw new TFxException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_NotFound", "HimsSite"), ex);
                    }

                    this.SetConfig<string>(
                        c_himssite,
                        EnvironmentLookup.GetHIMSSite(environmentName));
                }
                return this.GetConfig<string>(c_himssite);
            }
        }

        /// <summary>
        /// Gets the HAWI site associated with the site.
        /// </summary>
        public string HawiSite
        {
            get
            {
                if (!this.IsConfigDefined(c_hawisite))
                {
                    string environmentName;

                    try
                    {
                        environmentName = TestContext.Runtime.Environment;
                    }
                    catch (TFxException ex)
                    {
                        throw new TFxException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_NotFound", "hawisite"), ex);
                    }

                    this.SetConfig<string>(
                        c_hawisite,
                        EnvironmentLookup.GetHAWISite(environmentName));
                }
                return this.GetConfig<string>(c_hawisite);
            }
        }

        /// <summary>
        /// Indicates whether the site/environment being tested 
        /// is Production or lab.
        /// </summary>
        /// <remarks>
        /// Requires <see cref="M:Expedia.Test.Framework.TestContext.Runtime.Environment"></see> to
        /// be set or able to be looked up, and uses that value.  To determine if an arbitrary 
        /// environment is production, use <see cref="M:Expedia.Test.Framework.EnvironmentLookup.IsProduction(System.String)"></see>.
        /// </remarks>
        public bool IsProduction
        {
            get
            {
                if (!this.isProduction.HasValue)
                {
                    // Lookup and cache isProduction;
                    if (!this.IsConfigDefined(c_isproduction))
                    {
                        string environmentName;

                        try
                        {
                            environmentName = TestContext.Runtime.Environment;
                        }
                        catch (TFxException ex)
                        {
                            throw new TFxException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_NotFound", "IsProduction"), ex);
                        }

                        this.SetConfig<bool>(
                            c_isproduction,
                            EnvironmentLookup.IsProduction(environmentName));
                    }
                    this.isProduction = this.GetConfig<bool>(c_isproduction);
                }

                return this.isProduction.Value;
            }
        }

        /// <summary>
        /// Returns the E3 striping string for the current environment.
        /// </summary>
        /// <remarks>
        /// Requires <see cref="M:Expedia.Test.Framework.TestContext.Runtime.Environment"></see> to
        /// be set or able to be looked up, and uses that value.  To get the striping for an 
        /// arbitrary environment, use <see cref="M:Expedia.Test.Framework.EnvironmentLookup.GetE3Striping(System.String)"></see>.
        /// </remarks>
        public string EnvironmentE3Striping
        {
            get
            {
                if (!this.IsConfigDefined(c_e3striping))
                {
                    string environmentName;

                    try
                    {
                        environmentName = TestContext.Runtime.Environment;
                    }
                    catch (TFxException ex)
                    {
                        throw new TFxException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_NotFound", "E3Striping"), ex);
                    }

                    this.SetConfig<string>(
                        c_e3striping,
                        EnvironmentLookup.GetE3Striping(environmentName));
                }
                return this.GetConfig<string>(c_e3striping);
            }
        }

        /// <summary>
        /// Gets the travel server associated with the site. (Required)
        /// </summary>
        public string TravServer
        {
            get
            {
                if (!this.IsConfigDefined(c_trav_server) && !this.IsProduction && this.IsConfigDefined(c_site))
                {
                    this.SetConfig<string>(
                        c_trav_server,
                        (string)ExpediaRegistry.GetRegistryValue(
                            this.GetConfig<string>(c_site),
                            RegistryHive.LocalMachine,
                            ExpediaRegistry.REGISTRY_TRAVELSERVER,
                            ExpediaRegistry.REGISTRY_TRAVELSERVER_VALUE));
                }
                return this.GetConfig<string>(c_trav_server);
            }
        }

        /// <summary>
        /// Gets or sets the server name.
        /// </summary>
        public string ServerName
        {
            get
            {
                return this.GetConfig<string>(c_servername, string.Empty);
            }
            set
            {
                this.SetConfig<string>(c_servername, value);
            }
        }

        /// <summary>
        /// Gets or sets the username.
        /// </summary>
        public string UserName
        {
            get
            {
                return this.GetConfig<string>(c_username, string.Empty);
            }
            set
            {
                this.SetConfig<string>(c_username, value);
            }
        }

        /// <summary>
        /// Gets or sets the password.
        /// </summary>
        public string Password
        {
            get
            {
                return this.GetConfig<string>(c_password, string.Empty);
            }
            set
            {
                this.SetConfig<string>(c_password, value);
            }
        }

        /// <summary>
        /// Gets or sets the admin username.
        /// </summary>
        public string Admin_UserName
        {
            get
            {
                string username = this.GetConfig<string>(c_username, string.Empty);
                if (string.IsNullOrEmpty(username))
                {
                    username = this.GetDynamicVar(this.IsProduction ?
                        c_dynamic_denver_adminuser : c_dynamic_karmalab_adminuser);
                    if (string.IsNullOrEmpty(username))
                    {
                        this.SetConfig<string>(c_username, username);
                    }
                }
                return username;
            }
            set
            {
                this.SetConfig<string>(c_username, value);
            }
        }

        /// <summary>
        /// Gets or sets the admin password.
        /// </summary>
        public string Admin_Password
        {
            get
            {
                string password = this.GetConfig<string>(c_password, string.Empty);
                if (string.IsNullOrEmpty(password))
                {
                    password = this.GetDynamicVar(this.IsProduction ?
                        c_dynamic_denver_adminpassword : c_dynamic_karmalab_adminpassword);
                    if (string.IsNullOrEmpty(password))
                    {
                        this.SetConfig<string>(c_password, password);
                    }
                }
                return password;
            }
            set
            {
                this.SetConfig<string>(c_password, value);
            }
        }

        /// <summary>
        /// Gets whether the current manager is a denver manager.
        /// </summary>
        [Obsolete("This function still works as before, but should probably be replaced with IsProduction")]
        public bool IsDenverManager
        {
            get
            {
                string manager = this.GetConfig<string>(c_runtime_manager, string.Empty);
                if (!string.IsNullOrEmpty(manager))
                {
                    return (DenverManagerNames.IndexOf("|" + manager + "|", StringComparison.CurrentCultureIgnoreCase) >= 0);
                }
                return false;
            }
        }

        /// <summary>
        /// Gets or sets the firstname.
        /// </summary>
        public string FirstName
        {
            get
            {
                string firstname = this.GetConfig<string>(c_firstname, string.Empty);
                if (string.IsNullOrEmpty(firstname))
                {
                    firstname = this.GetDynamicVar(c_dynamic_firstname);
                    if (!string.IsNullOrEmpty(firstname))
                    {
                        this.SetConfig<string>(c_firstname, firstname);
                    }
                }
                return firstname;
            }
            set
            {
                this.SetConfig<string>(c_firstname, value);
            }
        }

        /// <summary>
        /// Gets or sets the lastname.
        /// </summary>
        public string LastName
        {
            get
            {
                string lastname = this.GetConfig<string>(c_lastname, string.Empty);
                if (string.IsNullOrEmpty(lastname))
                {
                    lastname = this.GetDynamicVar(c_dynamic_lastname);
                    if (!string.IsNullOrEmpty(lastname))
                    {
                        this.SetConfig<string>(c_lastname, lastname);
                    }
                }
                return lastname;
            }
            set
            {
                this.SetConfig<string>(c_lastname, value);
            }
        }

        /// <summary>
        /// Gets the server.
        /// </summary>
        public string Server
        {
            get
            {
                return this.GetConfig<string>(c_server, string.Empty);
            }
        }

        /// <summary>
        /// Gets the alias.
        /// </summary>
        public string Alias
        {
            get
            {
                return this.GetConfig<string>(c_alias, string.Empty);
            }
        }

        /// <summary>
        /// Gets the email address.
        /// </summary>
        public string Email
        {
            get
            {
                // see if email exists
                string email = this.GetConfig<string>(c_email, string.Empty);
                if (string.IsNullOrEmpty(email))
                {
                    // try dynamic data
                    email = this.GetDynamicVar(c_dynamic_email);
                    if (!string.IsNullOrEmpty(email))
                    {
                        this.SetConfig<string>(c_email, email);
                    }
                }
                return email;
            }
        }

        /// <summary>
        /// Gets or sets the fram.
        /// </summary>
        public string Fram
        {
            get
            {
                return this.GetConfig<string>(c_fram, string.Empty);
            }
            set
            {
                this.SetConfig<string>(c_fram, value);
            }
        }

        /// <summary>
        /// Gets or sets the filedir (for upgrade testing).
        /// </summary>
        public string Filedir
        {
            get
            {
                return this.GetConfig<string>(c_filedir, string.Empty);
            }
            set
            {
                this.SetConfig<string>(c_filedir, value);
            }
        }

        /// <summary>
        /// Gets or sets the Upgrade Folder (for upgrade testing).
        /// </summary>
        public string UpgradeFolder
        {
            get
            {
                return this.GetConfig<string>(c_upgradefolder, string.Empty);
            }
            set
            {
                this.SetConfig<string>(c_upgradefolder, value);
            }
        }

        /// <summary>
        /// Gets the Authentication Mode set for the site. 0-Normal, 1-Single User Account, 2-Mixed.
        /// </summary>
        public string Auth_Mode
        {
            get
            {
                // get the authmode found in dynamic vars first
                string authmode = this.GetDynamicVar(c_auth_mode);
                if (string.IsNullOrEmpty(authmode))
                {
                    authmode = "0";
                }

                // and use that as a default value
                return this.GetConfig<string>(c_auth_mode, authmode);
            }
        }

        /// <summary>
        /// Gets or sets the maximum amount of time (in seconds) the browser should 
        /// wait for a page before it times out.  The default value is 120 seconds.
        /// </summary>
        public int PageLoadTimeout
        {
            get
            {
                return this.GetConfig<int>(c_page_load_timeout, DefaultPageLoadTimeout);
            }
            set
            {
                this.SetConfig<int>(c_page_load_timeout, value);
            }
        }

        /// <summary>
        /// Gets or sets the wait type of page load.
        /// true: wait page load till complete.
        /// false: wait page load till interactive.
        /// The default value is false.
        /// </summary>
        public bool WaitPageLoadComplete
        {
            get
            {
                return this.GetConfig<bool>(c_wait_page_load_complete, DefaultWaitPageLoadComplete);
            }
            set
            {
                this.SetConfig<bool>(c_wait_page_load_complete, value);
            }
        }

        /// <summary>
        /// Gets or sets whether we should automatically delete saved itineraries
        /// at the end of the test case.
        /// </summary>
        public bool AutoDeleteItin
        {
            get
            {
                return this.GetConfig<bool>(c_auto_delete_itin, false);
            }
            set
            {
                this.SetConfig<bool>(c_auto_delete_itin, value);
            }
        }

        /// <summary>
        /// Gets or sets the saved itinerary number.
        /// </summary>
        public string SavedItinerary
        {
            get
            {
                return this.GetConfig<string>(c_saved_itinerary, string.Empty);
            }
            set
            {
                this.SetConfig<string>(c_saved_itinerary, value);
            }
        }

        /// <summary>
        /// Gets or sets the siteid
        /// </summary>
        public int SiteID
        {
            get
            {
                return this.GetConfig<int>(c_siteid, 0);
            }
            set
            {
                this.SetConfig<int>(c_siteid, value);
            }
        }

        /// <summary>
        /// Gets or sets download or upload file full path
        /// </summary>
        public string DownloadOrUploadFileFullPath
        {
            get
            {
                return this.GetConfig<string>(c_downloadorupload_file_fullpath, string.Empty);
            }
            set
            {
                this.SetConfig<string>(c_downloadorupload_file_fullpath, " " + value);
            }
        }
        #endregion


        #endregion

        #region SOA Configs

        /// <summary>
        /// SOA Machine
        /// This is the machine on which HttpBusAdaptor is running
        /// </summary>
        public string SOAMachine
        {
            get { return this.GetConfig<string>(c_soa_machine, DefaultSoaMachine); }
            set { this.SetConfig(c_soa_machine, value); }
        }

        /// <summary>
        /// SOA Port
        /// This is the port on which HttpBusAdaptor is running
        /// </summary>
        public int SOAPort
        {
            get { return this.GetConfig<int>(c_soa_port, DefaultSoaPort); }
            set { this.SetConfig(c_soa_port, value); }
        }

        /// <summary>
        /// SOA Environment
        /// </summary>
        public string SOAEnvironment
        {
            get { return this.GetConfig<string>(c_soa_environment, null) ?? this.EnvironmentE3Striping; }
            set { this.SetConfig(c_soa_environment, value); }
        }

        /// <summary>
        /// If this is true, the service is configured to be on ConfigV2
        /// </summary>
        public bool SOAConfigV2
        {
            get { return this.GetConfig(c_soa_configV2, false); }
            set { this.SetConfig(c_soa_configV2, value); }
        }

        /// <summary>
        /// This is the ConfigV2 file used by the test to look up configuration
        /// </summary>
        public string SOAConfigV2FilePath
        {
            get { return this.GetConfig<string>(c_soa_configV2_filePath, null); }
            set { this.SetConfig(c_soa_configV2_filePath, value); }
        }

        /// <summary>
        /// Fully qualified name of the E3 service to be tested. Example: e3.ss.lodging.service.icprfacade
        /// </summary>
        public string SOAServiceName
        {
            get { return this.GetConfig<string>(c_soa_serviceName, null); }
            set { this.SetConfig(c_soa_serviceName, value); }
        }

        /// <summary>
        /// Machine where E3 Service is deployed on
        /// </summary>
        public string SOAServiceDeploymentMachine
        {
            get { return this.GetConfig<string>(c_soa_service_Deployment_Machine, null); }
            set { this.SetConfig(c_soa_service_Deployment_Machine, value); }
        }

        /// <summary>
        /// Specifically used to define the Hotwire environment that our machines communicate with.
        /// </summary>
        public string HotwireEnvironment
        {
            get { return this.GetConfig<string>(c_hotwire_environment, null); }
            set { this.SetConfig(c_hotwire_environment, value); }
        }

        /// <summary>
        /// Used to specify the Opaque .NET server in our environment.
        /// </summary>
        public string OpaqueServer
        {
            get { return this.GetConfig<string>(c_opaque_server, null); }
            set { this.SetConfig(c_opaque_server, value); }
        }

        /// <summary>
        /// Used to specify if we need to log fastinfoset message or not, by default, true
        /// </summary>
        public bool LogFastInfoSetMessage
        {
            get { return this.GetConfig(c_soa_log_fastInfoset_message, true); }
            set { this.SetConfig(c_soa_log_fastInfoset_message, value); }
        }

        #endregion

        #region Methods

        #region Dynamic Configs

        private bool dtd20OverrideLogged;

        /// <summary>
        /// Gets a dynamic variable value (or the first value if there are multiple).
        /// </summary>
        /// <param name="name">The name of the dynamic variable.</param>
        /// <returns>The value of the dynamic variable.</returns>
        public string GetDynamicVar(string name)
        {
            // verify the name
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentNullException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Arg_Name", "name"));
            }


            if (!this.dtd20OverrideLogged)
            {
                LogComment(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_DTD_Using", "GetDynamicVar()"));
                this.dtd20OverrideLogged = true;
            }

            if (!this.IsConfigDefined(name))
            {
                LogWarning(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_DTD_NotFound", name));
                return String.Empty;
            }
            else
            {
                return this.GetRandomConfig<string>(name);
            }
        }

        /// <summary>
        /// Gets a random dynamic variable value (or the only value if it is a single value).
        /// </summary>
        /// <param name="name">The name of the dynamic variable.</param>
        /// <returns>The value of the dynamic variable.</returns>
        public string GetRandomVar(string name)
        {
            // verify the name
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentNullException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Arg_Name", "name"));
            }

            LogComment(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_DTD_UsingFor", "GetRandomVar()"));

            if (!IsConfigDefined(name))
            {
                LogWarning(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_DTD_NotFound", name));
                return String.Empty;
            }
            else
            {
                return this.GetRandomConfig<String>(name);
            }
        }

        /// <summary>
        /// Gets an array of all values assigned to a dynamic variable.
        /// </summary>
        /// <param name="name">The name of the dynamic variable.</param>
        /// <returns>The values of the dynamic variable.</returns>
        public string[] GetDynamicVarArray(string name)
        {
            // verify the name
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentNullException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Arg_Name", "name"));
            }

            LogComment(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_DTD_UsingFor", "GetDynamicVarArray()"));

            if (!this.IsConfigDefined(name))
            {
                LogWarning(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_DTD_NotFound", name));
                return new string[1] { string.Empty };
            }
            else
            {
                List<String> list = this.GetConfig<List<string>>(name);
                return list.ToArray();
            }
        }
        #endregion

        #region DTD 2.0

        /// <summary>
        /// Gets the random value of the config with the given name.
        /// </summary>
        /// <param name="name">The name of the config.</param>
        /// <returns>The value of the given config (or null).</returns>
        public string GetRandomConfig(string name)
        {
            return this.GetRandomConfig<string>(name);
        }

        /// <summary>
        /// Gets the random value of the config with the given name.
        /// </summary>
        /// <param name="name">The name of the config.</param>
        /// <returns>The value of the given config (or null).</returns>
        public T GetRandomConfig<T>(string name)
        {
            // verify the name
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentNullException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Arg_Name", "name"));
            }

            // get all of the configs array
            T[] arrayConfigs = this.GetConfigArray<T>(name);

            if (arrayConfigs != null && arrayConfigs.Length > 0)
            {
                // return a random item
                Random random = new Random();
                int index = random.Next(arrayConfigs.Length);
                return arrayConfigs[index];
            }
            else
                throw new TestConfigException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_NotDefined", name));
        }

        /// <summary>
        /// Get the array value of the config with the given name.
        /// </summary>
        /// <param name="name">The name of the config.</param>
        /// <returns>The array value of the given config</returns>
        public T[] GetConfigArray<T>(string name)
        {
            Stopwatch timer = Stopwatch.StartNew();
            // verify the name
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentNullException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Arg_Name", "name"));
            }

            // lock the get config method until the config is returned
            lock (configlock)
            {
                // check the overrides first
                if (this.siteOverrideConfigs != null && this.siteOverrideConfigs.ContainsKey(name))
                {
                    T[] value = (this.siteOverrideConfigs[name] is T[]) ? (T[])this.siteOverrideConfigs[name] : (new T[] { (T)this.siteOverrideConfigs[name] });
                    LogConfigMessage(name, TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_UsingOverride", name, this.GetConfigDisplayValue(name, value), typeof(T).Name, "_"));
                    return value;
                }

                // get the converted value if already converted.
                if (!this.convertedConfigs.ContainsKey(name))
                {
                    // make sure this assignment config actually exists.
                    if (!this.configs.ContainsKey(name))
                    {
                        if (!TestContext.IsTestDataAvailable)
                            throw new TestConfigException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_NotDefined", name));

                        //get test data
                        string[] testData = TestDataWrapper.GetArrayConfig(name);

                        T[] convertedValue = this.GetArrayValues<T>(name, testData);

                        if (convertedValue != null)
                        {
                            // log that we loaded a config
                            timer.Stop();
                            LogConfigMessage(name, TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_DTD_Loading", name, this.GetConfigDisplayValue(name, convertedValue), typeof(T).Name, timer.Elapsed.TotalMilliseconds));
                            return convertedValue;
                        }
                    }
                    else
                    {
                        // convert the value to the right type.
                        string value = this.configs.FindVariable(name);
                        string[] evalValue = TestContext.IsTestDataAvailable ? TestDataWrapper.EvalArrayExpression(value) : value.Split(',');

                        T[] convertedValue = this.GetArrayValues<T>(name, evalValue);

                        if (convertedValue != null)
                        {
                            // log that we loaded a config
                            timer.Stop();
                            LogConfigMessage(name, TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_Loading", name, this.GetConfigDisplayValue(name, convertedValue), typeof(T).Name, timer.Elapsed.TotalMilliseconds));
                            return convertedValue;
                        }
                        else
                        {
                            if (this.defaultTestConfigs.ContainsKey(name, true, out value))
                            {
                                evalValue = TestContext.IsTestDataAvailable ? TestDataWrapper.EvalArrayExpression(value) : value.Split(',');

                                convertedValue = this.GetArrayValues<T>(name, evalValue);

                                if (convertedValue != null)
                                {
                                    // log that we loaded a config
                                    timer.Stop();
                                    LogConfigMessage(name, TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_LoadingDefault", name, this.GetConfigDisplayValue(name, convertedValue), typeof(T).Name, timer.Elapsed.TotalMilliseconds));
                                    return convertedValue;
                                }
                            }
                        }
                    }
                }

                if (!this.convertedConfigs.ContainsKey(name))
                    throw new TestConfigException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_NotDefined", name));

                // return the converted value from the cache.
                // if the value is null, return a empty array.
                if (this.convertedConfigs[name] is T[])
                {
                    return (T[])this.convertedConfigs[name];
                }
                else if (this.convertedConfigs[name] == null)
                {
                    return new T[] { };
                }
                else
                {
                    return (new T[] { (T)this.convertedConfigs[name] });
                }
            }
        }

        /// <summary>
        /// ChangeType Array Help
        /// </summary>
        /// <typeparam name="T">Type</typeparam>
        /// <param name="value">Change type value</param>
        /// <returns></returns>
        public static T[] ChangeTypeArray<T>(object value)
        {
            Type conversionType = typeof(T);
            if (conversionType.IsGenericType && conversionType.GetGenericTypeDefinition().Equals(typeof(Nullable<>)))
            {
                if (value == null) { return default(T[]); }
                conversionType = Nullable.GetUnderlyingType(conversionType); ;
            }
            return (T[])Convert.ChangeType(value, conversionType);
        }

        private T[] GetArrayValues<T>(string name, object value)
        {
            if (value == null)
            {
                return null;
            }
            else if (value is IList)
            {
                //convert to array if value is a list
                IList list = (IList)value;

                T[] convertedValue = new T[list.Count];

                for (int i = 0; i < list.Count; i++)
                {
                    convertedValue[i] = this.ConvertConfigValue<T>(name, (string)list[i]);
                }

                return convertedValue;
            }
            else
            {
                //convert to a array which have one element
                T[] convertedValue = new T[1] { this.ConvertConfigValue<T>(name, (string)value) };
                return convertedValue;
            }
        }

        #endregion

        #region Config Methods
        /// <summary>
        /// Gets the value of the environment property with the given name without "EP_" prefix.
        /// </summary>
        /// <param name="name">The name of the config without "EP_" prefix.</param>
        /// <returns>The value of the given config starts with "EP_" prefix (or null).</returns>
        public string GetEnvironmentProperty(string name)
        {
            return GetConfig("EP_" + name);
        }

        /// <summary>
        /// Gets the value of the config with the given name.
        /// </summary>
        /// <param name="name">The name of the config.</param>
        /// <returns>The value of the given config (or null).</returns>
        public string GetConfig(string name)
        {
            return GetConfig<string>(name);
        }

        /// <summary>
        /// Gets the value of the config with the given name.
        /// </summary>
        /// <param name="name">The name of the config.</param>
        /// <returns>The value of the given config (or null).</returns>
        /// <exception cref="System.ArgumentNullException">name is null.</exception>
        public T GetConfig<T>(string name)
        {
            Stopwatch timer = Stopwatch.StartNew();
            // verify the name
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentNullException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Arg_Name", "name"));
            }

            // lock the get config method until the config is returned
            lock (configlock)
            {
                //for xunit, get cofig from envrionment
                object obj = (object)GetXUnitTestDataValue(name, string.Empty);
                if (obj != null)
                {
                    return (T)obj;
                }

                // check the overrides first
                if (this.siteOverrideConfigs != null && this.siteOverrideConfigs.ContainsKey(name))
                {
                    T value = (T)this.siteOverrideConfigs[name];
                    LogConfigMessage(name, TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_UsingOverride", name, this.GetConfigDisplayValue(name, value), typeof(T).Name, "_"));
                    return value;
                }

                // get the converted value if already converted.
                if (!this.convertedConfigs.ContainsKey(name))
                {
                    // make sure this assignment config actually exists.
                    if (!this.configs.ContainsKey(name))
                    {
                        string value = null;

                        try
                        {
                            if (!TestContext.IsTestDataAvailable)
                            {
                                throw new TestConfigException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_NotDefined", name));
                            }

                            //get test data
                            value = TestDataWrapper.GetSingleValue(name);

                            T convertedValue = this.ConvertConfigValue<T>(name, value);

                            // log that we loaded a config
                            timer.Stop();
                            LogConfigMessage(name, TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_DTD_Loading", name, this.GetConfigDisplayValue(name, convertedValue), typeof(T).Name, timer.Elapsed.TotalMilliseconds));
                            return convertedValue;

                        }
                        catch (TestDataException ex)
                        {
                            if (this.defaultTestConfigs.ContainsKey(name, true, out value))
                            {
                                string evalValue = TestContext.IsTestDataAvailable ? TestDataWrapper.EvalExpression(value) : value;

                                T convertedValue = this.ConvertConfigValue<T>(name, evalValue);

                                // log that we loaded a config
                                timer.Stop();
                                LogConfigMessage(name, TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_LoadingDefault", name, this.GetConfigDisplayValue(name, convertedValue), typeof(T).Name, timer.Elapsed.TotalMilliseconds));
                                return convertedValue;
                            }
                            else
                            {
                                // Throw a better error message when the failure is due to Expression calculation
                                if (ex.Message.Contains("{" + name + "}"))
                                {
                                    throw new TestDataException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_TestDataNotFound", name), ex);
                                }
                                else
                                {
                                    string dependTestName = String.Empty;
                                    Regex regex = new Regex(": {(?<name>[^}]+)}");
                                    Match match = regex.Match(ex.Message);
                                    if (match.Success == true)
                                    {
                                        dependTestName = match.Groups["name"].Value;
                                        throw new TestDataException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_TestDataNoDependent", name, (String.IsNullOrEmpty(dependTestName) ? "" : "{" + dependTestName + "}")), ex);
                                    }
                                    else
                                    {
                                        throw ex;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        // convert the value to the right type.
                        string value = this.configs.FindVariable(name);
                        string evalValue = TestContext.IsTestDataAvailable ? TestDataWrapper.EvalExpression(value) : value;

                        T convertedValue = this.ConvertConfigValue<T>(name, evalValue);

                        // log that we loaded a config
                        timer.Stop();
                        LogConfigMessage(name, TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_Loading", name, this.GetConfigDisplayValue(name, convertedValue), typeof(T).Name, timer.Elapsed.TotalMilliseconds));
                        return convertedValue;
                    }
                }

                if (!this.convertedConfigs.ContainsKey(name))
                    throw new TestConfigException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_NotDefined", name));


                // return the converted value from the cache.
                return ChangeType<T>(this.convertedConfigs[name]);
            }
        }

        /// <summary>
        /// ChangeType Help
        /// </summary>
        /// <typeparam name="T">Type</typeparam>
        /// <param name="value">Change type value</param>
        /// <returns></returns>
        public static T ChangeType<T>(object value)
        {
            Type conversionType = typeof(T);
            if (conversionType.IsGenericType && conversionType.GetGenericTypeDefinition().Equals(typeof(Nullable<>)))
            {
                if (value == null) { return default(T); }
                conversionType = Nullable.GetUnderlyingType(conversionType); ;
            }
            return (T)Convert.ChangeType(value, conversionType);
        }

        /// <summary>
        /// Gets the value of the config with the given name (returns defaultValue if not found).
        /// </summary>
        /// <typeparam name="T">The type of the config.</typeparam>
        /// <param name="name">The name of the config.</param>
        /// <param name="defaultValue">The default value of the config.</param>
        /// <returns>The value or default value of the given config.</returns>
        public T GetConfig<T>(string name, T defaultValue)
        {
            return GetConfig<T>(name, defaultValue, false);
        }

        /// <summary>
        /// 
        /// Gets the value of the config with the given name (returns defaultValue if not found).
        /// </summary>
        /// <typeparam name="T">The type of the config.</typeparam>
        /// <param name="name">The name of the config.</param>
        /// <param name="defaultValue">The default value of the config.</param>
        /// <param name="cacheOnly">Indicate to read from cache or not only</param>
        /// <returns>The value or default value of the given config.</returns>
        public T GetConfig<T>(string name, T defaultValue, bool cacheOnly)
        {
            Stopwatch timer = Stopwatch.StartNew();
            // verify the name
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentNullException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Arg_Name", "name"));
            }

            // lock the get config method until the config is returned
            lock (configlock)
            {
                //for xunit, get cofig from envrionment
                object obj = (object)GetXUnitTestDataValue(name, defaultValue == null ? null : defaultValue.ToString());
                if (obj != null)
                {
                    return (T)obj;
                }

                // check the overrides first
                if (this.siteOverrideConfigs != null && this.siteOverrideConfigs.ContainsKey(name))
                {
                    T value = (T)this.siteOverrideConfigs[name];
                    timer.Stop();
                    LogConfigMessage(name, TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_UsingOverride", name, this.GetConfigDisplayValue(name, value), typeof(T).Name, timer.Elapsed.TotalMilliseconds));
                    return value;
                }

                // get the converted value if already converted.
                if (!this.convertedConfigs.ContainsKey(name))
                {
                    //get test data
                    string value = null;

                    // make sure this assignment config actually exists.
                    if (!this.configs.ContainsKey(name) ||
                        string.IsNullOrEmpty(this.configs.FindVariable(name)))
                    {
                        if (!TestContext.IsTestDataAvailable)
                        {
                            if (this.defaultTestConfigs.ContainsKey(name, true, out value))
                            {
                                if (!string.IsNullOrEmpty(value))
                                {
                                    T convertedValue = this.ConvertConfigValue<T>(name, value);

                                    // log that we loaded a config
                                    timer.Stop();
                                    LogConfigMessage(name, TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_LoadingDefault", name, this.GetConfigDisplayValue(name, convertedValue), typeof(T).Name, timer.Elapsed.TotalMilliseconds));
                                    return convertedValue;
                                }
                            }
                            // log that we're using the default value.
                            LogConfigMessage(name, TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_UsingDefault", name, defaultValue));
                            // special case: remove then add the null (or it will throw an error if you try to update)
                            this.convertedConfigs.Add(name, defaultValue);
                            return defaultValue;
                        }


                        try
                        {
                            //
                            // If the data is not in cache and we only want to retrieve data from cache only
                            // return the default
                            //
                            if ((cacheOnly == true) && (TestDataWrapper.IsDataInCache(name) == false))
                            {
                                // Before we return the defaultValue, we need to cache it
                                SetConfig<T>(name, defaultValue, false);

                                return defaultValue;
                            }

                            value = TestDataWrapper.GetSingleValue(name);

                            T convertedValue = this.ConvertConfigValue<T>(name, value);

                            // log that we loaded a config
                            timer.Stop();
                            LogConfigMessage(name, TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_DTD_Loading", name, this.GetConfigDisplayValue(name, convertedValue), typeof(T).Name, timer.Elapsed.TotalMilliseconds));
                            return convertedValue;
                        }
                        catch (TestDataException)
                        {
                            if (this.defaultTestConfigs.ContainsKey(name, true, out value))
                            {
                                string evalValue = TestContext.IsTestDataAvailable ? TestDataWrapper.EvalExpression(value) : value;

                                if (!string.IsNullOrEmpty(evalValue))
                                {
                                    T convertedValue = this.ConvertConfigValue<T>(name, evalValue);

                                    // log that we loaded a config
                                    timer.Stop();
                                    LogConfigMessage(name, TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_LoadingDefault", name, this.GetConfigDisplayValue(name, convertedValue), typeof(T).Name, timer.Elapsed.TotalMilliseconds));
                                    return convertedValue;
                                }
                            }
                        }
                    }
                    else
                    {
                        // Look into the assignment configs and convert the value to the right type.
                        value = this.configs.FindVariable(name);
                        string evalValue = TestContext.IsTestDataAvailable ? TestDataWrapper.EvalExpression(value) : value;

                        if (!string.IsNullOrEmpty(evalValue))
                        {
                            T convertedValue = this.ConvertConfigValue<T>(name, evalValue);

                            // log that we loaded a config
                            timer.Stop();
                            LogConfigMessage(name, TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_Loading", name, this.GetConfigDisplayValue(name, convertedValue), typeof(T).Name, timer.Elapsed.TotalMilliseconds));
                            return convertedValue;
                        }
                    }
                }
                else
                {
                    // return the converted value from the cache.
                    return ChangeType<T>(this.convertedConfigs[name]);
                }

                // log that we're using the default value.
                LogConfigMessage(name, TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_UsingDefault", name, defaultValue));

                if (TestContext.IsTestDataAvailable)
                    // Before we return the defaultValue, we need to cache it
                    SetConfig<T>(name, defaultValue, false);

                else
                    // special case: remove then add the null (or it will throw an error if you try to update)
                    this.convertedConfigs.Add(name, defaultValue);

                return defaultValue;
            }
        }

        /// <summary>
        /// Sets the value of the given config name to the given value.
        /// </summary>
        /// <param name="name">The name of the config to change.</param>
        /// <param name="value">The value to change the config.</param>
        public void SetConfig<T>(string name, T value)
        {
            SetConfig<T>(name, value, true);
        }

        /// <summary>
        /// Sets the value of the given config name to the given value.
        /// </summary>
        /// <param name="name">The name of the config to change.</param>
        /// <param name="value">The value to change the config.</param>
        /// <param name="writeLog">True will output and false will not write any log.</param>
        private void SetConfig<T>(string name, T value, bool writeLog)
        {
            // make sure the name is not empty and the value is not null
            if (string.IsNullOrEmpty(name))
            {
                throw new TestConfigException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_SetFailed", name, value));
            }

            // lock the set config until the config is set
            lock (configlock)
            {
                // check if it already exists
                if (this.configs.ContainsKey(name) &&
                    !(configs.FindVariable(name) == null) &&
                    !string.IsNullOrEmpty((String)configs.FindVariable(name)))
                {
                    // passed in configs should always trump over code generated configs
                    if (writeLog) LogWarning(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_RefusedChanging", name, value, this.configs.FindVariable(name)));
                }
                else if (value == null)
                {
                    // log that we set the value of this config to null and allow it
                    if (writeLog) LogComment(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_SetToNull", name));

                    // special case: remove then add the null (or it will throw an error if you try to update)
                    this.convertedConfigs.Remove(name);
                    this.convertedConfigs.Add(name, value);
                }
                else
                {
                    if (value is string)
                    {
                        // set config into TestData.dll
                        this.convertedConfigs.Remove(name);
                        if (TestContext.IsTestDataAvailable)
                            TestDataWrapper.SetSingleValue(name, value.ToString());
                    }
                    else if (value is IList)
                    {
                        IList list = (IList)value;

                        bool isStringValues = true;
                        StringBuilder sb = new StringBuilder();

                        foreach (object item in list)
                        {
                            if (item == null)
                            {
                                if (sb.Length > 0)
                                    sb.Append(",");
                            }
                            else if (item is string)
                            {
                                if (sb.Length > 0)
                                    sb.Append(",");

                                sb.Append(item);
                            }
                            else
                            {
                                isStringValues = false;
                                break;
                            }
                        }

                        if (isStringValues)
                        {
                            // set config into TestData.dll
                            this.convertedConfigs.Remove(name);
                            if (TestContext.IsTestDataAvailable)
                                TestDataWrapper.SetSingleValue(name, sb.ToString());
                        }
                        else
                        {
                            // update the converted config
                            this.convertedConfigs[name] = value;
                        }
                    }
                    else
                    {
                        // update the converted config
                        this.convertedConfigs[name] = value;
                    }

                    // log that we are setting a config
                    if (writeLog) LogComment(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_Set", name, value));
                }
            }
        }

        /// <summary>
        /// Gets the display value of a config.
        /// </summary>
        private string GetConfigDisplayValue(string name, object value)
        {
            // mask out passwords
            if (name.IndexOf("password", StringComparison.CurrentCultureIgnoreCase) >= 0)
            {
                return TFxCoreResourceManager.GetMessageFromRes("TFxCore_PSW");
            }
            // show null to be null
            if (value == null)
            {
                return TFxCoreResourceManager.GetMessageFromRes("TFxCore_Null");
            }

            if (value is IList)
            {
                //contact values for list
                StringBuilder sb = new StringBuilder();

                foreach (object item in (IList)value)
                {
                    if (sb.Length > 0)
                        sb.Append(",");

                    sb.Append(item);
                }

                return sb.ToString();
            }
            else
            {
                // use actual value
                return value.ToString();
            }
        }

        /// <summary>
        /// Indicates whether a given config has been defined.
        /// </summary>
        /// <param name="name">The name of the config to check if has been defined.</param>
        /// <returns>True if the config is defined, false otherwise.</returns>
        /// <exception cref="System.ArgumentNullException">name is null.</exception>
        public bool IsConfigDefined(string name)
        {
            // verify the name
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentNullException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Arg_Name", "name"));
            }

            // check if this config has been defined
            bool flag = this.configs.ContainsKey(name) || this.convertedConfigs.ContainsKey(name);

            // if not already defined, then check the TestData
            if (flag == false)
            {
                try
                {
                    GetConfig(name);
                    flag = true;
                }
                catch
                {
                    flag = false;
                }
            }

            return flag;
        }

        /// <summary>
        /// Indicates whether a given config was passed in or not
        /// Difference between this and IsConfigDefine is if you have a config that has a default value of 5
        /// when you read the config and get back value 5 you don't know if the user passed that in, or
        /// if you are using the default value because it wasn't passed in at all
        /// </summary>
        /// <param name="name">The name of the config to check if has been defined.</param>
        /// <returns>True if the config was passed in, false otherwise.</returns>
        /// <exception cref="System.ArgumentNullException">name is null.</exception>
        public bool WasConfigPassedIn(string name)
        {
            // verify the name
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentNullException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Arg_Name", "name"));
            }

            // check if this config has been defined
            //return this.configs.ContainsKey(name) ? !(this.configs.FindVariable(name) == null) : false;

            //Use C++ method
            return TestDataWrapper.WasConfigPassedIn(name);
        }

        /// <summary>
        /// Converts a value into the type specified by default value.
        /// </summary>
        /// <param name="name">The name of the config parameter.</param>
        /// <param name="value">A string representing the config value.</param>
        /// <returns>Converted object value if the config is found or the default object value.</returns>
        private T ConvertConfigValue<T>(string name, string value)
        {
            // the default type is the type of the generic parameter
            Type defaultType = typeof(T);
            Type nullableType = Nullable.GetUnderlyingType(defaultType);

            // handle nullable types
            if (nullableType != null)
            {
                if (defaultType != typeof(string) && value.Trim() == string.Empty)
                {
                    const object temp = null;
                    return (T)temp;
                }

                defaultType = nullableType;
            }

            // check for some basic types
            if (defaultType == typeof(string))
            {
                // Strings are special, we need no conversion to go from string to string.

                // For some reason, compiler does not allow casting a type 'string' to a type 'T'
                // But it allows casting type 'object' to type 'T' since object is a generic type.
                // My solution here is to first cast my string to an object, then cast it to T by
                // performing a boxing operation.
                return (T)((object)value);
            }
            else if (defaultType == typeof(bool))
            {
                // Booleans are special.  We need to convert both 0/1 or true/false.
                if (value == "0" || value.Equals("false", StringComparison.CurrentCultureIgnoreCase))
                {
                    // For some reason, compiler does not allow casting a type 'bool' to a type 'T'
                    // But it allows casting type 'object' to type 'T' since object is a generic type.
                    // My solution here is to first cast my bool to an object, then cast it to T by
                    // performing a boxing operation.
                    return (T)((object)false);
                }
                else if (value == "1" || value.Equals("true", StringComparison.CurrentCultureIgnoreCase))
                {
                    // For some reason, compiler does not allow casting a type 'bool' to a type 'T'
                    // But it allows casting type 'object' to type 'T' since object is a generic type.
                    // My solution here is to first cast my bool to an object, then cast it to T by
                    // performing a boxing operation.
                    return (T)((object)true);
                }
            }
            else if (defaultType == typeof(Guid))
            {
                // Guids are special. To convert from string to Guid, you must create a new Guid 
                // and pass the string representation to the constructor.

                // For some reason, compiler does not allow casting a type 'Guid' to a type 'T'
                // But it allows casting type 'object' to type 'T' since object is a generic type.
                // My solution here is to first cast my Guid to an object, then cast it to T by
                // performing a boxing operation.
                return (T)((object)new Guid(value));
            }
            else if (defaultType.IsEnum)
            {
                // Enums are special.  We can convert an enum using the 
                return (T)Enum.Parse(defaultType, value, true);
            }
            else if (defaultType == typeof(DateTime))
            {
                // DateTime is special. We have to respect the date format.
                CultureInfo cultureInfo;

                if (this.LangID == 3084 || this.LangID == 1054)
                {
                    // For CA Fr site(langid=3084), .NET returns date format as yyyy-MM-dd however the site uses dd/MM/yyyy format
                    // Thailand has a different calander from the other courtry. Year 2011 in Europe is year 2554 in Thailand.
                    // Change the format to fr-FR
                    cultureInfo = new CultureInfo(1036);
                }
                else if (this.TPID == 18)
                {
                    // For HK (tpid=18), .NET returns date format as MM-DD-yyyy however the site uses yyyy-MM-dd
                    // Change the format to JP
                    cultureInfo = new CultureInfo(1041);
                }
                else
                {
                    cultureInfo = new CultureInfo(this.LangID);
                }

                LogComment(TFxCoreResourceManager.GetMessageFromRes("TFxCore_DateTimeConverted", value, this.LangID, cultureInfo.DateTimeFormat.FullDateTimePattern));

                return (T)((object)DateTime.Parse(value, cultureInfo.DateTimeFormat));
            }
            else if (defaultType == typeof(TimeSpan))
            {
                if (value.Contains(":"))
                {
                    return (T)((object)TimeSpan.Parse(value));
                }
                else
                {
                    return (T)((object)new TimeSpan(0, 0, 0, 0, int.Parse(value)));
                }
            }

            // Most basic types (built in types) have a TryParse method, so we will use that
            // to try and parse the string into the right type.
            MethodInfo mi = defaultType.GetMethod("TryParse",
                new Type[] { typeof(string), defaultType.MakeByRefType() });
            object propertyValue = null;
            object[] args = new object[] { value, propertyValue };
            if ((mi != null) && ((bool)mi.Invoke(null, args) == true))
            {
                return (T)args[1];
            }

            // could not convert the config 'name' to type 'defaultType'
            throw new TestConfigException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_TypeConvertedFailed",
                name, defaultType.Name, value));
        }

        #endregion

        #region Enter/Exit Site

        /// <summary>
        /// Enters a new site by saving the original site and replacing it 
        /// with the new site.
        /// </summary>
        /// <param name="site">The site to enter.</param>
        public void EnterSite(string site)
        {
            this.EnterSite(site, null);
        }

        /// <summary>
        /// Enters a new site by saving the original site and replacing it 
        /// with the new site.
        /// </summary>
        /// <param name="site">The site to enter.</param>
        /// <param name="overrideConfigs">The configs to use with this new site.</param>
        public void EnterSite(string site, IDictionary<string, object> overrideConfigs)
        {
            // verify the site
            if (string.IsNullOrEmpty(site))
            {
                throw new ArgumentNullException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Arg_Name", "site"));
            }

            // create the override configs
            this.siteOverrideConfigs = new Dictionary<string, object>(StringComparer.CurrentCultureIgnoreCase);

            // load the site override configs
            if (overrideConfigs != null)
            {
                foreach (var item in overrideConfigs)
                {
                    this.siteOverrideConfigs.Add(item.Key, item.Value);
                }
            }

            // override the site
            this.siteOverrideConfigs[c_site] = site;
        }

        /// <summary>
        /// Exits an entered site by restoring the original site.
        /// </summary>
        public void ExitSite()
        {
            // verify the entered site
            if (this.siteOverrideConfigs == null || !this.siteOverrideConfigs.ContainsKey(c_site))
            {
                throw new TestConfigException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_Site_RefusedExit"));
            }

            // clear override variables
            this.siteOverrideConfigs = null;
        }

        #endregion

        #region Date and Time Globalization
        /// <summary>
        /// Returns the date in the correct format (according to the current LangID).
        /// </summary>
        /// <param name="date">DateTime Object that has the user set value.</param>
        /// <returns>A string representing the formatted date.</returns>
        public string GetDate(DateTime date)
        {
            CultureInfo cultureInfo = new CultureInfo(this.LangID);
            string dateString = date.ToString(cultureInfo.DateTimeFormat.ShortDatePattern);

            // for CA Fr site(langid=3084), .NET returns date format as yyyy-MM-dd however the site uses dd/MM/yyyy format
            // So change the format for this specific lang
            if (this.LangID == 3084)
            {
                dateString = date.ToString("dd/MM/yyyy");
            }

            // for Hongkong(18/0/3076, 18/0/2057), .Net reutrns date format as dd/mm/yyyy format, howerver the site uses yyyy/MM/dd
            // So change the format for these specific langs
            if ((this.LangID == 3076 && this.TPID == 18) || (this.LangID == 2057 && this.TPID == 18))
            {
                dateString = date.ToString("yyyy/MM/dd");
            }


            return dateString;
        }
        #endregion

        private string GetXUnitTestDataValue(string name, string defaultValue)
        {
            var driver = Environment.GetEnvironmentVariable("lrm.__labrundriver");
            if (!string.IsNullOrWhiteSpace(driver) && string.Compare(driver, "xunit", true) == 0)
            {
                isInitialized = true;
                var envrionmentName = name.StartsWith("lrm.", true, CultureInfo.CurrentCulture) ? name : "lrm." + name;
                var value = Environment.GetEnvironmentVariable(envrionmentName);
                if (string.IsNullOrWhiteSpace(value))
                {
                    try
                    {
                        if (!isTestDataWrapperInitialized)
                        {
                            InitializeTestDataForXUnit();
                            isTestDataWrapperInitialized = true;
                        }

                        value = TestDataWrapper.GetSingleValue(name);
                    }
                    catch (Exception e)
                    {
                        throw new TFxException(TFxCoreResourceManager.GetMessageFromRes(e.Message));
                    }

                    if (string.IsNullOrWhiteSpace(value))
                    {
                        return defaultValue;
                    }
                }
                return value;
            }
            else
            {
                return null;
            }
        }

        private void InitializeTestDataForXUnit()
        {
            var labrunId = int.Parse(Environment.GetEnvironmentVariable("lrm.__labrunid"));
            var assignmentId = int.Parse(Environment.GetEnvironmentVariable("lrm.__assignmentid"));
            var ns = Environment.GetEnvironmentVariable("lrm.__testnamespace");
            var branchName = Environment.GetEnvironmentVariable("lrm.branchName");
            var serverName = Environment.GetEnvironmentVariable("lrm.__lrmdbserver");
            var dbName = Environment.GetEnvironmentVariable("lrm.__lrmdbname");
            var serverMirrorName = Environment.GetEnvironmentVariable("lrm.__lrmdbservermirror");

            if (TestDataWrapper.Initialize(assignmentId, labrunId, ns, branchName, serverName, dbName, serverMirrorName) == false)
            {
                throw new TFxException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_Init_TestDataFailed"));
            }

            var assignmentConfigs = new Dictionary<string, string>();
            var variables = Environment.GetEnvironmentVariables();
            foreach (DictionaryEntry entry in variables)
            {
                var key = (string)entry.Key;
                if (key.StartsWith("lrm."))
                {
                    assignmentConfigs.Add(key.Substring(4, key.Length - 4), (string)entry.Value);
                }
            }

            TestDataWrapper.AddAssignmentConfigs(assignmentConfigs);

            // Preload all SoftTest level test data
            TestDataWrapper.LoadAllSoftTestData();
        }
        #endregion

        #region Fields

        #region Locks/Synchronization

        /// <summary>
        /// Used to lock the get/set config functions to support synchronization.
        /// </summary>
        private static readonly object configlock = new object();

        /// <summary>
        /// Used to lock the create dynamic variable function to support synchronization.
        /// </summary>
        private static readonly object dynvarlock = new object();

        #endregion

        /// <summary>
        /// Stores the assignment configs.
        /// </summary>
        private ScopedConfig configs;


        /// <summary>
        /// Caches the converted assignment configs.
        /// </summary>
        private Dictionary<string, object> convertedConfigs;

        /// <summary>
        /// Caches the configs specified above the test code from published DLL.
        /// </summary>
        private Dictionary<string, string> defaultTestConfigs;

        /// <summary>
        /// Used by enter/exit site to store override configs
        /// </summary>
        private Dictionary<string, object> siteOverrideConfigs;

        /// <summary>
        /// Store the list of Configs that have been accessed
        /// </summary>
        private HashSet<string> accessedConfigs;

        // Cached fields for Config Properties
        private bool? isProduction = null;

        #endregion
    }

    /// <summary>
    /// Scoped Config
    /// </summary>
    internal class ScopedConfig
    {
        /// <summary>
        /// Data
        /// </summary>
        public List<Dictionary<string, string>> data = new List<Dictionary<string, string>>();

        /// <summary>
        /// Push
        /// </summary>
        /// <param name="config"></param>
        public void Push(Dictionary<string, string> config)
        {
            data.Add(config);
        }

        /// <summary>
        /// Pop
        /// </summary>
        public void Pop()
        {
            if (data.Count > 0)
            {
                data.RemoveAt(data.Count - 1);
            }
        }

        /// <summary>
        /// Find Variable
        /// </summary>
        /// <param name="configName">Config Name</param>
        /// <returns></returns>
        public string FindVariable(string configName)
        {
            if (configName == null)
            {
                throw new ArgumentNullException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Arg_Name", "configName"));
            }
            for (int i = data.Count - 1; i >= 0; i--)
            {
                if (data[i].ContainsKey(configName))
                {
                    return data[i][configName];
                }
            }
            return null;
        }

        /// <summary>
        /// Contains Key
        /// </summary>
        /// <param name="configName">Config Name</param>
        /// <returns></returns>
        internal bool ContainsKey(string configName)
        {
            if (configName == null)
            {
                throw new ArgumentNullException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Arg_Name", "configName"));
            }
            for (int i = data.Count - 1; i >= 0; i--)
            {
                if (data[i].ContainsKey(configName))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Clear
        /// </summary>
        internal void Clear()
        {
            for (int i = data.Count - 1; i >= 0; i--)
            {
                data[i].Clear();
            }
        }
    }
}
