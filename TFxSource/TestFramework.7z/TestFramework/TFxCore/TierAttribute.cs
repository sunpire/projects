//========================================================================== 
// 
// Copyright (C) 2008, Expedia, Inc.  All rights reserved. 
// 
// File: TierAttribute.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Tier Attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Method, AllowMultiple=false)]
    public class TierAttribute : BaseTestCategoryAttribute
    {
        /// <summary>
        /// Tier Attribute constructor
        /// </summary>
        /// <param name="tier">Tier for the test associated</param>
        public TierAttribute(TierType tier)
        {
            this.CategoryId = (long)tier;
        }
    }
}
