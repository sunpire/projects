using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// TestData Wrapper
    /// </summary>
    internal static class TestDataWrapper
    {
        #region Import Methods From C++

        [DllImport("TestData.dll", EntryPoint = "Initialize", CharSet = CharSet.Auto)]
        private static extern int DTD_Initialize(int assignmentId, int labrunId, string testNamespace, string branchName, string serverName, string dbName, string serverMirrorName);

        [DllImport("TestData.dll", EntryPoint = "AddAssignmentConfig", CharSet = CharSet.Auto)]
        private static extern int AddAssignmentConfig(string configName, string configValue);

        [DllImport("TestData.dll", EntryPoint = "Dispose", CharSet = CharSet.Auto)]
        public static extern int Dispose();

        [DllImport("TestData.dll", EntryPoint = "EvalExpression", CharSet = CharSet.Auto)]
        private static extern IntPtr DTD_EvalExpression(string pExpression);

        [DllImport("TestData.dll", EntryPoint = "GetSingleValue", CharSet = CharSet.Auto)]
        private static extern IntPtr DTD_GetSingleValue(string dataName);

        [DllImport("TestData.dll", EntryPoint = "SetSingleConfig", CharSet = CharSet.Auto)]
        private static extern void SetSingleConfig(string dataName, string singleValue);

        [DllImport("TestData.dll", EntryPoint = "SetConfigArraySize", CharSet = CharSet.Auto)]
        private static extern void SetConfigArraySize(string dataName, int sizeOfArray);

        [DllImport("TestData.dll", EntryPoint = "SetConfigArrayValue", CharSet = CharSet.Auto)]
        private static extern void SetConfigArrayValue(string dataName, string value, int index);

        [DllImport("TestData.dll", EntryPoint = "GetArrayValuesLength", CharSet = CharSet.Auto)]
        private static extern int GetArrayValuesLength(string dataName);

        [DllImport("TestData.dll", EntryPoint = "GetArrayValueByIndex", CharSet = CharSet.Auto)]
        private static extern IntPtr GetArrayValueByIndex(int index, string dataName);

        [DllImport("TestData.dll", EntryPoint = "DisposeArray", CharSet = CharSet.Auto)]
        private static extern void DisposeArray(string dataName);

        [DllImport("TestData.dll", EntryPoint = "GetDtdLastError", CharSet = CharSet.Auto)]
        private static extern IntPtr GetDtdLastError();

        [DllImport("TestData.dll", EntryPoint = "ClearDtdLastError", CharSet = CharSet.Auto)]
        private static extern void ClearDtdLastError();

        [DllImport("TestData.dll", EntryPoint = "IsDataInCache", CharSet = CharSet.Auto)]
        private static extern bool DTD_IsDataInCache(string dataName);

        [DllImport("TestData.dll", EntryPoint = "LoadAllSoftTestData", CharSet = CharSet.Auto)]
        private static extern void DTD_LoadAllSoftTestData();

        [DllImport("TestData.dll", EntryPoint = "WasConfigPassedIn", CharSet = CharSet.Auto)]
        private static extern bool DTD_WasConfigPassedIn(string dataName);

        #endregion

        #region Extend Helper Methods

        /// <summary>
        /// Preload all the test data of the current executing SoftTest into the C++ Cache
        /// </summary>
        /// <remarks>
        /// For any test data that is already in cache, it will not override it.
        /// </remarks>
        public static void LoadAllSoftTestData()
        {
            try
            {
                DTD_LoadAllSoftTestData();
            }
            catch (SEHException)
            {
                string error = Marshal.PtrToStringUni(GetDtdLastError());
                ClearDtdLastError();

                //Logger.Instance.Write(new StackFrame(1, true), SeverityType.Error, LogLevelType.TFxConfig, error);
            }
        }

        /// <summary>
        /// Check if a test data is already in the C++ cache
        /// </summary>
        /// <param name="dataName">Name of the test data to check whether in cache or not</param>
        /// <returns>True if the data is already in cache</returns>
        public static bool IsDataInCache(String dataName)
        {
            return DTD_IsDataInCache(dataName);
        }


        public static bool Initialize(int assignmentId, int labrunId, string testNamespace, string branchName, string serverName, string dbName, string serverMirrorName)
        {
            try
            {
                int result = DTD_Initialize(assignmentId, labrunId, testNamespace, branchName, serverName, dbName, serverMirrorName);

                if (result <= 0)
                {
                    string error = Marshal.PtrToStringUni(GetDtdLastError());
                    ClearDtdLastError();

                    Logger.Instance.Write(new StackFrame(1, true), SeverityType.Error, LogLevelType.TFxConfig, error);
                    return false;
                }

                return true;
            }
            catch (SEHException)
            {
                string error = Marshal.PtrToStringUni(GetDtdLastError());
                ClearDtdLastError();

                Logger.Instance.Write(new StackFrame(1, true), SeverityType.Error, LogLevelType.TFxConfig, error);

                return false;
            }
        }

        public static string GetSingleValue(string dataName)
        {
            try
            {
                return Marshal.PtrToStringUni(DTD_GetSingleValue(dataName));
            }
            catch (SEHException ex)
            {
                string error = Marshal.PtrToStringUni(GetDtdLastError());
                ClearDtdLastError();

                //
                // # We are not logging since in the case for default value do specify for GetConfig, we
                // # should not log an error or warning
                //
                //Logger.Instance.Write(new StackFrame(1, true), SeverityType.Error, LogLevelType.TFxConfig, error);
                throw new TestDataException(error, ex);
            }
        }

        public static void SetSingleValue(string dataName, string singleValue)
        {
            try
            {
                SetSingleConfig(dataName, singleValue);
            }
            catch (SEHException)
            {
                string error = Marshal.PtrToStringUni(GetDtdLastError());
                ClearDtdLastError();

                Logger.Instance.Write(new StackFrame(1, true), SeverityType.Error, LogLevelType.TFxConfig, error);
            }
        }

        public static string EvalExpression(string pExpression)
        {
            try
            {
                if (pExpression == null)
                    return null;

                return Marshal.PtrToStringUni(DTD_EvalExpression(pExpression));
            }
            catch (SEHException)
            {
                string error = Marshal.PtrToStringUni(GetDtdLastError());
                ClearDtdLastError();

                Logger.Instance.Write(new StackFrame(1, true), SeverityType.Error, LogLevelType.TFxConfig, error);
                return pExpression;
            }
        }

        public static string[] EvalArrayExpression(string pExpression)
        {
            try
            {
                if (pExpression == null)
                    return null;

                string value = Marshal.PtrToStringUni(DTD_EvalExpression(pExpression));

                if (string.IsNullOrEmpty(value))
                    return null;

                return FormatStringList(value).ToArray();
            }
            catch (SEHException)
            {
                string error = Marshal.PtrToStringUni(GetDtdLastError());
                ClearDtdLastError();

                Logger.Instance.Write(new StackFrame(1, true), SeverityType.Error, LogLevelType.TFxConfig, error);
                return null;
            }
        }

        public static string[] GetArrayConfig(string dataName)
        {
            try
            {
                int len = GetArrayValuesLength(dataName);

                string[] configs = new string[len];
                for (int i = 0; i < len; i++)
                {
                    configs[i] = Marshal.PtrToStringUni(GetArrayValueByIndex(i, dataName));
                }

                DisposeArray(dataName);

                return configs;
            }
            catch (SEHException)
            {
                string error = Marshal.PtrToStringUni(GetDtdLastError());
                ClearDtdLastError();

                Logger.Instance.Write(new StackFrame(1, true), SeverityType.Error, LogLevelType.TFxConfig, error);
                return null;
            }
        }

        public static void SetArrayConfig(string dataName, string[] configs)
        {
            try
            {
                if (configs == null)
                    return;

                SetConfigArraySize(dataName, configs.Length);

                for (int i = 0; i < configs.Length; i++)
                {
                    SetConfigArrayValue(dataName, configs[i], i);
                }
            }
            catch (SEHException)
            {
                string error = Marshal.PtrToStringUni(GetDtdLastError());
                ClearDtdLastError();

                Logger.Instance.Write(new StackFrame(1, true), SeverityType.Error, LogLevelType.TFxConfig, error);
            }
        }

        public static void AddAssignmentConfigs(Dictionary<string, string> assignmentConfigs)
        {
            try
            {
                foreach (KeyValuePair<string, string> kvp in assignmentConfigs)
                {
                    if (!string.IsNullOrEmpty(kvp.Value) && !string.IsNullOrEmpty(kvp.Value.Trim()))
                    {
                        AddAssignmentConfig(kvp.Key, kvp.Value);
                    }
                }
            }
            catch (SEHException)
            {
                string error = Marshal.PtrToStringUni(GetDtdLastError());
                ClearDtdLastError();

                Logger.Instance.Write(new StackFrame(1, true), SeverityType.Error, LogLevelType.TFxConfig, error);
            }
        }

        private static bool IsTestDataFilter(string configName)
        {
            //TBD:need check these filters dynamic.

            if (string.Equals(configName, "tpid", StringComparison.CurrentCultureIgnoreCase))
                return true;

            if (string.Equals(configName, "eap", StringComparison.CurrentCultureIgnoreCase))
                return true;

            if (string.Equals(configName, "langid", StringComparison.CurrentCultureIgnoreCase))
                return true;

            if (string.Equals(configName, "environment", StringComparison.CurrentCultureIgnoreCase))
                return true;

            return false;
        }

        public static List<string> FormatStringList(string listString)
        {
            char[] charList = listString.ToCharArray();
            List<string> str = new List<string>();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < charList.Length; i++)
            {
                if (charList[i] == ',')
                {
                    str.Add(sb.ToString());
                    sb = new StringBuilder();
                }
                else if (charList[i] == '@')
                {
                    if (i + 1 < charList.Length && charList[i + 1] == '@')
                    {
                        sb.Append('@');
                    }
                    else if (i + 1 < charList.Length && charList[i + 1] == ',')
                    {
                        sb.Append(',');
                    }
                    i++;
                }
                else
                {
                    sb.Append(charList[i]);
                }

            }
            str.Add(sb.ToString());
            return str;
        }

        public static bool WasConfigPassedIn(string dataName)
        {
            try
            {
                return DTD_WasConfigPassedIn(dataName);
            }
            catch (SEHException)
            {
                string error = Marshal.PtrToStringUni(GetDtdLastError());
                ClearDtdLastError();

                Logger.Instance.Write(new StackFrame(1, true), SeverityType.Error, LogLevelType.TFxConfig, error);
                return false;
            }
        }

        #endregion
    }
}
