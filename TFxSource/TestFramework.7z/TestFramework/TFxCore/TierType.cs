//========================================================================== 
// 
// Copyright (C) 2008, Expedia, Inc.  All rights reserved. 
// 
// File: TierType.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Possible values for Tier
    /// </summary>
    public enum TierType : long
    {
        /// <summary>
        /// None:
        ///     (2^25)
        /// </summary>
        None = 33554432,

        /// <summary>
        /// Tier0:
        ///     (2^20)
        /// </summary>
        Tier0 = 1048576,

        /// <summary>
        /// Tier1:
        ///     (2^21)
        /// </summary>
        Tier1 = 2097152,

        /// <summary>
        /// Tier2:
        ///     (2^22)
        /// </summary>
        Tier2 = 4194304,

        /// <summary>
        /// Tier3:
        ///     (2^23)
        /// </summary>
        Tier3 = 8388608,

        /// <summary>
        /// Tier4:
        ///     (2^24)
        /// </summary>
        Tier4 = 16777216,
    }
}
