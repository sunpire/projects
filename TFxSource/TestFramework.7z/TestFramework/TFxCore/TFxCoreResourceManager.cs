﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// manage the resource
    /// </summary>
    public class TFxCoreResourceManager
    {
        #region Fields
        private static string language = "EN";
        private static string defaultProjectName = "TFxCore";
        private static string resourceNamespace = "Expedia.Test.Framework.Resources.";
        private static string resourceType = ".resx";
        private static string idResourceFileNotExists = "TFxCore_Resource_FileNotExisted";
        private static string idResourceStringNotExists = "TFxCore_Resource_StringNotExisted";
        private static string idArgsCountNotExpected = "TFxCore_Arg_CountNotExpected";
        private static string idErrorNotExpected = "TFxCore_Error_NotExpected";
        private static bool isError = false;
        private static string errorMessage = string.Empty;
        #endregion

        #region Properties

        /// <summary>
        /// get and set Language
        /// </summary>
        public static string Language
        {
            get {return language;}
            set {language = value;}
        }

        /// <summary>
        /// get the last action status
        /// </summary>
        public static bool IsError
        {
            get {return isError;}
            private set {isError = value;}
        }

        /// <summary>
        /// get the last error message
        /// </summary>
        public static string ErrorMessage
        {
            get { return errorMessage; }
            private set { errorMessage = value; }
        }

        #endregion

        #region initialization

        #endregion

        #region Methods

        /// <summary>
        /// split the resourceid for getting resource name (project name)
        /// </summary>
        /// <param name="isFromResourceId">if ture , it will get resource name from resourceId . if false, it will get resource name from calling project which invoke this class.</param>
        /// <param name="resourceId"></param>
        /// <returns></returns>
        public static string GetResourceName(bool isFromResourceId, string resourceId)
        {
            string resourceName = string.Empty;
            string[] fullNameArray;
            if (isFromResourceId)
            {
                fullNameArray = resourceId.Split('_');
            }
            else
            {
                fullNameArray = System.Reflection.Assembly.GetCallingAssembly().FullName.Split(',');
            }
            if (fullNameArray != null && fullNameArray.Length > 0)
            {
                resourceName = fullNameArray[0];
            }
            return resourceName;
        }

        /// <summary>
        /// Get The Message From Resource
        /// </summary>
        /// <param name="resourceId"></param>
        /// <returns></returns>
        public static string GetMessageFromRes(string resourceId)
        {
            return GetMessageFromResCore(GetResourceName(true, resourceId), resourceId, "");            
        }

        /// <summary>
        /// Get The Message From Resource with parameters
        /// </summary>
        /// <param name="resourceId"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        public static string GetMessageFromRes(string resourceId, params object[] args)
        {
            return GetMessageFromResCore(GetResourceName(true, resourceId), resourceId, args);            
        }

        /// <summary>
        /// Get The Message From Resource with parameters
        /// </summary>
        /// <param name="useCallingProjectName">if true. it will use the project name which is calling this method as resource name. 
        /// if false. it will use resourceName as resource name.</param>
        /// <param name="resourceName">the resource name. you can input the project name which is calling this method. 
        /// or input other resource name which you expected.</param>
        /// <param name="resourceId"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        public static string GetMessageFromRes(bool useCallingProjectName, string resourceName, string resourceId, params object[] args)
        {
            string resName = string.Empty;
            if (useCallingProjectName)
            {
                resName = GetResourceName(false, resourceId);
            }
            else
            {
                resName = resourceName;
            }
            return GetMessageFromResCore(resName, resourceId, args);
        }
        /// <summary>
        /// the core method regarding to get message from resource . 
        /// </summary>
        /// <param name="currentProjectName"></param>
        /// <param name="resourceId"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        private static string GetMessageFromResCore(string resourceName, string resourceId, params object[] args)
        {
            string value = string.Empty;
            string pre = "[" + resourceId + "] ";
            isError = false;
            ErrorMessage = string.Empty;
            try
            {
                System.Resources.ResourceManager rm = new System.Resources.ResourceManager(resourceNamespace + resourceName, System.Reflection.Assembly.GetExecutingAssembly());
                value = rm.GetString(resourceId);
                if (value != null)
                {
                    value = string.Format(value, args);                    
                }
                else
                {
                    IsError = true;
                    System.Resources.ResourceManager errorRm = new System.Resources.ResourceManager(resourceNamespace + defaultProjectName, System.Reflection.Assembly.GetExecutingAssembly());
                    ErrorMessage = string.Format(errorRm.GetString(idResourceStringNotExists), resourceId);
                    value = string.Empty;
                }
            }
            catch (System.Resources.MissingManifestResourceException)
            {
                IsError = true;
                System.Resources.ResourceManager errorRm = new System.Resources.ResourceManager(resourceNamespace + defaultProjectName, System.Reflection.Assembly.GetExecutingAssembly());
                ErrorMessage = string.Format(errorRm.GetString(idResourceFileNotExists), resourceName);
                value = string.Empty;
            }
            catch (FormatException)
            {
                IsError = true;
                System.Resources.ResourceManager errorRm = new System.Resources.ResourceManager(resourceNamespace + defaultProjectName, System.Reflection.Assembly.GetExecutingAssembly());
                ErrorMessage = string.Format(errorRm.GetString(idArgsCountNotExpected));
                value = string.Empty;
            }
            catch(Exception rmEx)
            {
                IsError = true;
                System.Resources.ResourceManager errorRm = new System.Resources.ResourceManager(resourceNamespace + defaultProjectName, System.Reflection.Assembly.GetExecutingAssembly());
                ErrorMessage = string.Format(errorRm.GetString(idErrorNotExpected), rmEx.Message);
                value = string.Empty;
            }
            return pre + value;
        }
        #endregion
    }
}
