﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.Collections;

namespace Expedia.Test.Framework
{
    public static partial class Assert
    {
        #region IsNull

        /// <summary>
        /// Verifies that the specified object is null. The assertion fails if it is
        /// not null.
        /// </summary>
        /// <param name="value">The object to verify is null.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">value is not null.</exception>
        public static void IsNull(object value)
        {
            if (value != null)
            {
                Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_NotNull", value));
            }
        }

        /// <summary>
        /// Verifies that the specified object is null. The assertion fails if it is
        /// not null. Displays a message if the assertion fails, and applies the specified
        /// formatting to it.
        /// </summary>
        /// <param name="value">The object to verify is null.</param>
        /// <param name="message">A message to display if the assertion fails. This message can be seen in
        /// the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">value is not null.</exception>
        public static void IsNull(object value, string message, params object[] parameters)
        {
            if (value != null)
            {
                Assert.LogFailure(message, parameters);
            }
        }

        #endregion

        #region IsNotNull

        /// <summary>
        /// Verifies that the specified object is not null. The assertion fails if it
        /// is null.
        /// </summary>
        /// <param name="value">The object to verify is not null.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">value is null.</exception>
        public static void IsNotNull(object value)
        {
            if (value == null)
            {
                Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_Null"));
            }
        }

        /// <summary>
        /// Verifies that the specified object is not null. The assertion fails if it
        /// is null. Displays a message if the assertion fails, and applies the specified
        /// formatting to it.
        /// </summary>
        /// <param name="value">The object to verify is not null.</param>
        /// <param name="message">A message to display if the assertion fails. This message can be seen in
        /// the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">value is not null.</exception>
        public static void IsNotNull(object value, string message, params object[] parameters)
        {
            if (value == null)
            {
                Assert.LogFailure(message, parameters);
            }
        }

        #endregion
    }
}
