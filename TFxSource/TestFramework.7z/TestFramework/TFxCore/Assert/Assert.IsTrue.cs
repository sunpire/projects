﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.Collections;

namespace Expedia.Test.Framework
{
    public static partial class Assert
    {
        #region IsFalse/IsTrue

        /// <summary>
        /// Verifies that the specified condition is false. The assertion fails if the condition is true.
        /// </summary>
        /// <param name="condition">The condition to verify is false.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">condition evaluates to true.</exception>
        public static void IsFalse(bool condition)
        {
            if (condition)
            {
                Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_True"));
            }
        }

        /// <summary>
        /// Verifies that the specified condition is false. The assertion fails if the
        /// condition is true. Displays a message if the assertion fails, and applies
        /// the specified formatting to it.
        /// </summary>
        /// <param name="condition">The condition to verify is false.</param>
        /// <param name="message">A message to display if the assertion fails. This message can be seen in
        /// the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">condition evaluates to true.</exception>
        public static void IsFalse(bool condition, string message, params object[] parameters)
        {
            if (condition)
            {
                Assert.LogFailure(message, parameters);
            }
        }

        /// <summary>
        /// Verifies that the specified condition is true. The assertion fails if the
        /// condition is false.
        /// </summary>
        /// <param name="condition">The condition to verify is true.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">condition evaluates to false.</exception>
        public static void IsTrue(bool condition)
        {
            if (!condition)
            {
                Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_False"));
            }
        }

        /// <summary>
        /// Verifies that the specified condition is true. The assertion fails if the
        /// condition is false. Displays a message if the assertion fails, and applies
        /// the specified formatting to it.
        /// </summary>
        /// <param name="condition">The condition to verify is true.</param>
        /// <param name="message">A message to display if the assertion fails. This message can be seen in 
        /// the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">condition evaluates to false.</exception>
        public static void IsTrue(bool condition, string message, params object[] parameters)
        {
            if (!condition)
            {
                Assert.LogFailure(message, parameters);
            }
        }

        #endregion

    }
}
