﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.Collections;

namespace Expedia.Test.Framework
{
    public static partial class Assert
    {
        #region AreSame

        /// <summary>
        /// Verifies that two specified object variables refer to the same object. The
        /// assertion fails if they refer to different objects.
        /// </summary>
        /// <param name="expected">The first object to compare. This is the object the unit test expects.</param>
        /// <param name="actual">The second object to compare. This is the object the unit test produced.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">expected does not refer to the same object as actual.</exception>
        public static void AreSame(object expected, object actual)
        {
            if (!object.ReferenceEquals(expected, actual))
            {
                Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_NotSameRef", expected, actual));
            }
        }

        /// <summary>
        /// Verifies that two specified object variables refer to the same object. The
        /// assertion fails if they refer to different objects. Displays a message if
        /// the assertion fails, and applies the specified formatting to it.
        /// </summary>
        /// <param name="expected">The first object to compare. This is the object the unit test expects.</param>
        /// <param name="actual">The second object to compare. This is the object the unit test produced.</param>
        /// <param name="message">A message to display if the assertion fails. This message can be seen in
        /// the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">expected does not refer to the same object as actual.</exception>
        public static void AreSame(object expected, object actual, string message, params object[] parameters)
        {
            if (!object.ReferenceEquals(expected, actual))
            {
                Assert.LogFailure(message, parameters);
            }
        }

        #endregion
    }
}
