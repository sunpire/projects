﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.Collections;

namespace Expedia.Test.Framework
{
    public static partial class Assert
    {
        #region IsInstanceOfType/Not

        /// <summary>
        /// Verifies that the specified object is an instance of the specified type.
        /// The assertion fails if the type is not found in the inheritance hierarchy
        /// of the object.
        /// </summary>
        /// <param name="value">The object to verify is of expectedType.</param>
        /// <param name="expectedType">The type expected to be found in the inheritance hierarchy of value.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">value is not null and 
        /// expectedType is not found in the inheritance hierarchy of value.</exception>
        public static void IsInstanceOfType(object value, Type expectedType)
        {
            if (!expectedType.IsInstanceOfType(value))
            {
                Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_TypeNotFound", expectedType));
            }
        }

        /// <summary>
        /// Verifies that the specified object is an instance of the specified type.
        /// The assertion fails if the type is not found in the inheritance hierarchy
        /// of the object. Displays a message if the assertion fails, and applies the
        /// specified formatting to it.
        /// </summary>
        /// <param name="value">The object to verify is of expectedType.</param>
        /// <param name="expectedType">The type expected to be found in the inheritance hierarchy of value.</param>
        /// <param name="message">A message to display if the assertion fails. This message can be seen in
        /// the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">value is not null and 
        /// expectedType is not found in the inheritance hierarchy of value.</exception>
        public static void IsInstanceOfType(object value, Type expectedType, string message, params object[] parameters)
        {
            if (!expectedType.IsInstanceOfType(value))
            {
                Assert.LogFailure(message, parameters);
            }
        }

        /// <summary>
        /// Verifies that the specified object is not an instance of the specified type.
        /// The assertion fails if the type is found in the inheritance hierarchy of
        /// the object.
        /// </summary>
        /// <param name="value">The object to verify is not of wrongType.</param>
        /// <param name="wrongType">The type that should not be found in the inheritance hierarchy of value.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">value is not null and 
        /// wrongType is found in the inheritance hierarchy of value.</exception>
        public static void IsNotInstanceOfType(object value, Type wrongType)
        {
            if (wrongType.IsInstanceOfType(value))
            {
                Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_TypeFound", wrongType));
            }
        }

        /// <summary>
        /// Verifies that the specified object is not an instance of the specified type.
        /// The assertion fails if the type is found in the inheritance hierarchy of
        /// the object. Displays a message if the assertion fails, and applies the specified
        /// formatting to it.
        /// </summary>
        /// <param name="value">The object to verify is not of wrongType.</param>
        /// <param name="wrongType">The type that should not be found in the inheritance hierarchy of value.</param>
        /// <param name="message">A message to display if the assertion fails. This message can be seen in
        /// the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">value is not null and 
        /// wrongType is found in the inheritance hierarchy of value.</exception>
        public static void IsNotInstanceOfType(object value, Type wrongType, string message, params object[] parameters)
        {
            if (wrongType.IsInstanceOfType(value))
            {
                Assert.LogFailure(message, parameters);
            }
        }

        #endregion
    }
}
