﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.Collections;

namespace Expedia.Test.Framework
{
    public static partial class Assert
    {
        #region AreNotEqual

        /// <summary>
        /// Verifies that two specified generic type data are not equal. The assertion
        /// fails if they are equal.
        /// </summary>
        /// <typeparam name="T">Any type.</typeparam>
        /// <param name="notExpected">The first generic type data to compare. This is the generic type data the
        /// unit test expects not to match actual.</param>
        /// <param name="actual">The second generic type data to compare. This is the generic type data the
        /// unit test produced.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">notExpected is equal to actual.</exception>
        public static void AreNotEqual<T>(T notExpected, T actual)
        {
            if (areEqual<T>(notExpected, actual, new AssertComparer<T>()))
            {
                Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_Equal", notExpected, actual));
            }
        }

        /// <summary>
        /// Verifies that two specified generic type data are not equal. The assertion
        /// fails if they are equal.
        /// </summary>
        /// <typeparam name="T">Any type.</typeparam>
        /// <param name="notExpected">The first generic type data to compare. This is the generic type data the
        /// unit test expects not to match actual.</param>
        /// <param name="actual">The second generic type data to compare. This is the generic type data the
        /// unit test produced.</param>
        /// <param name="comparer">The comparer used to compare the two objects</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">notExpected is equal to actual.</exception>
        public static void AreNotEqual<T>(T notExpected, T actual, IComparer<T> comparer)
        {
            if (areEqual<T>(notExpected, actual, comparer))
            {
                Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_Equal", notExpected, actual));
            }
        }

        /// <summary>
        /// Verifies that two specified generic type data are not equal. The assertion
        /// fails if they are equal. Displays a message if the assertion fails, and applies
        /// the specified formatting to it.
        /// </summary>
        /// <typeparam name="T">Any type.</typeparam>
        /// <param name="notExpected">The first generic type data to compare. This is the generic type data the
        /// unit test expects not to match actual.</param>
        /// <param name="actual">The second generic type data to compare. This is the generic type data the
        /// unit test produced.</param>
        /// <param name="message">A message to display if the assertion fails. This message can be seen in
        /// the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">notExpected is equal to actual.</exception>
        public static void AreNotEqual<T>(T notExpected, T actual, string message, params object[] parameters)
        {
            if (areEqual<T>(notExpected, actual, new AssertComparer<T>()))
            {
                Assert.LogFailure(message, parameters);
            }
        }

        /// <summary>
        /// Verifies that two specified generic type data are not equal. The assertion
        /// fails if they are equal. Displays a message if the assertion fails, and applies
        /// the specified formatting to it.
        /// </summary>
        /// <typeparam name="T">Any type.</typeparam>
        /// <param name="notExpected">The first generic type data to compare. This is the generic type data the
        /// unit test expects not to match actual.</param>
        /// <param name="actual">The second generic type data to compare. This is the generic type data the
        /// unit test produced.</param>
        /// <param name="comparer">The comparer used to compare the two objects</param>
        /// <param name="message">A message to display if the assertion fails. This message can be seen in
        /// the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">notExpected is equal to actual.</exception>
        public static void AreNotEqual<T>(T notExpected, T actual, IComparer<T> comparer, string message, params object[] parameters)
        {
            if (areEqual<T>(notExpected, actual, comparer))
            {
                Assert.LogFailure(message, parameters);
            }
        }

        /// <summary>
        /// Verifies that two specified objects are not equal. The assertion fails if
        /// the objects are equal.
        /// </summary>
        /// <param name="notExpected">The first object to compare. This is the object the unit test expects not
        /// to match actual.</param>
        /// <param name="actual">The second object to compare. This is the object the unit test produced.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">notExpected is equal to actual.</exception>
        public static void AreNotEqual(object notExpected, object actual)
        {
            if (areEqual<object>(notExpected, actual, new AssertComparer<object>()))
            {
                Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_Equal", notExpected, actual));
            }
        }

        /// <summary>
        /// Verifies that two specified objects are not equal. The assertion fails if
        /// the objects are equal.
        /// </summary>
        /// <param name="notExpected">The first object to compare. This is the object the unit test expects not
        /// to match actual.</param>
        /// <param name="actual">The second object to compare. This is the object the unit test produced.</param>
        /// <param name="comparer">The comparer used to compare the two objects</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">notExpected is equal to actual.</exception>
        public static void AreNotEqual(object notExpected, object actual, IComparer<object> comparer)
        {
            if (areEqual<object>(notExpected, actual, comparer))
            {
                Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_Equal", notExpected, actual));
            }
        }

        /// <summary>
        /// Verifies that two specified objects are not equal. The assertion fails if
        /// the objects are equal. Displays a message if the assertion fails, and applies
        /// the specified formatting to it.
        /// </summary>
        /// <param name="notExpected">The first object to compare. This is the object the 
        /// unit test expects not to match actual.</param>
        /// <param name="actual">The second object to compare. This is the object the unit test produced.</param>
        /// <param name="message">A message to display if the assertion fails. This message can be seen in
        /// the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">notExpected is equal to actual.</exception>
        public static void AreNotEqual(object notExpected, object actual, string message, params object[] parameters)
        {
            if (areEqual<object>(notExpected, actual, new AssertComparer<object>()))
            {
                Assert.LogFailure(message, parameters);
            }
        }

        /// <summary>
        /// Verifies that two specified objects are not equal. The assertion fails if
        /// the objects are equal. Displays a message if the assertion fails, and applies
        /// the specified formatting to it.
        /// </summary>
        /// <param name="notExpected">The first object to compare. This is the object the 
        /// unit test expects not to match actual.</param>
        /// <param name="actual">The second object to compare. This is the object the unit test produced.</param>
        /// <param name="comparer">The comparer used to compare the two objects</param>
        /// <param name="message">A message to display if the assertion fails. This message can be seen in
        /// the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">notExpected is equal to actual.</exception>
        public static void AreNotEqual(object notExpected, object actual, IComparer<object> comparer, string message, params object[] parameters)
        {
            if (areEqual<object>(notExpected, actual, comparer))
            {
                Assert.LogFailure(message, parameters);
            }
        }

        /// <summary>
        /// Verifies that two specified doubles are not equal, and not within the specified
        /// accuracy of each other. The assertion fails if they are equal or within the
        /// specified accuracy of each other.
        /// </summary>
        /// <param name="notExpected">The first double to compare. This is the double the 
        /// unit test expects not to match actual.</param>
        /// <param name="actual">The second double to compare. This is the double the 
        /// unit test produced.</param>
        /// <param name="delta">The required inaccuracy. The assertion fails only if 
        /// notExpected is equal to actual or different from it by less than delta.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">notExpected is equal 
        /// to actual or different from it by less than delta.</exception>
        public static void AreNotEqual(double notExpected, double actual, double delta)
        {
            if (Math.Abs(notExpected - actual) <= delta)
            {
                Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_LessThanDelta", notExpected, actual, delta));
            }
        }

        /// <summary>
        /// Verifies that two specified doubles are not equal, and not within the specified
        /// accuracy of each other. The assertion fails if they are equal or within the
        /// specified accuracy of each other. Displays a message if the assertion fails,
        /// and applies the specified formatting to it.
        /// </summary>
        /// <param name="notExpected">The first double to compare. This is the double the unit test expects not
        /// to match actual.</param>
        /// <param name="actual">The second double to compare. This is the double the unit test produced.</param>
        /// <param name="delta">The required inaccuracy. The assertion will fail only if notExpected is equal
        /// to actual or different from it by less than delta.</param>
        /// <param name="message">A message to display if the assertion fails. This message can be seen in
        /// the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">notExpected is equal to actual or different from it by less than delta.</exception>
        public static void AreNotEqual(double notExpected, double actual, double delta, string message, params object[] parameters)
        {
            if (Math.Abs(notExpected - actual) <= delta)
            {
                Assert.LogFailure(message, parameters);
            }
        }

        /// <summary>
        /// Verifies that two specified singles are not equal, and not within the specified
        /// accuracy of each other. The assertion fails if they are equal or within the
        /// specified accuracy of each other.
        /// </summary>
        /// <param name="notExpected">The first single to compare. This is the single the unit test expects.</param>
        /// <param name="actual">The second single to compare. This is the single the unit test produced.</param>
        /// <param name="delta">The required inaccuracy. The assertion will fail only if notExpected is equal
        /// to actual or different from it by less than delta.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">notExpected is equal 
        /// to actual or different from it by less than delta.</exception>
        public static void AreNotEqual(float notExpected, float actual, float delta)
        {
            if (Math.Abs(notExpected - actual) <= delta)
            {
                Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_LessThanDelta", notExpected, actual, delta));
            }
        }


        /// <summary>
        /// Verifies that two specified singles are not equal, and not within the specified
        /// accuracy of each other. The assertion fails if they are equal or within the
        /// specified accuracy of each other. Displays a message if the assertion fails,
        /// and applies the specified formatting to it.
        /// </summary>
        /// <param name="notExpected">The first single to compare. This is the single the unit test expects not
        /// to match actual.</param>
        /// <param name="actual">The second single to compare. This is the single the unit test produced.</param>
        /// <param name="delta">The required inaccuracy. The assertion will fail only if notExpected is equal
        /// to actual or different from it by less than delta.</param>
        /// <param name="message">A message to display if the assertion fails. This message can be seen in
        /// the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">notExpected is equal to actual or different from it by less than delta.</exception>
        public static void AreNotEqual(float notExpected, float actual, float delta, string message, params object[] parameters)
        {
            if (Math.Abs(notExpected - actual) <= delta)
            {
                Assert.LogFailure(message, parameters);
            }
        }

        /// <summary>
        /// Verifies that two specified strings are not equal, ignoring case or not as
        /// specified. The assertion fails if they are equal.
        /// </summary>
        /// <param name="notExpected">The first string to compare. This is the string 
        /// the unit test expects not to match actual.</param>
        /// <param name="actual">The second string to compare. This is the string the unit test produced.</param>
        /// <param name="ignoreCase">A Boolean value that indicates a case-sensitive or insensitive comparison.
        /// true indicates a case-insensitive comparison.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">notExpected is equal to actual.</exception>
        public static void AreNotEqual(string notExpected, string actual, bool ignoreCase)
        {
            if (string.Compare(notExpected, actual, ignoreCase) == 0)
            {
                Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_Equal_IgnoreCase", notExpected, actual, ignoreCase,CultureInfo.CurrentCulture));
            }
        }

        /// <summary>
        /// Verifies that two specified strings are not equal, ignoring case or not as
        /// specified, and using the culture info specified. The assertion fails if they
        /// are equal.
        /// </summary>
        /// <param name="notExpected">The first string to compare. This is the string the unit test 
        /// expects not to match actual.</param>
        /// <param name="actual">The second string to compare. This is the string the unit test produced.</param>
        /// <param name="ignoreCase">A Boolean value that indicates a case-sensitive or insensitive comparison.
        /// true indicates a case-insensitive comparison.</param>
        /// <param name="culture">A System.Globalization.CultureInfo object that supplies culture-specific
        /// comparison information.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">notExpected is equal to actual.</exception>
        public static void AreNotEqual(string notExpected, string actual, bool ignoreCase, CultureInfo culture)
        {
            if (string.Compare(notExpected, actual, ignoreCase, culture) == 0)
            {
                Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_Equal_IgnoreCase", notExpected, actual, ignoreCase, culture));
            }
        }

        /// <summary>
        /// Verifies that two specified strings are not equal, ignoring case or not as
        /// specified. The assertion fails if they are equal. Displays a message if the
        /// assertion fails, and applies the specified formatting to it.
        /// </summary>
        /// <param name="notExpected">The first string to compare. This is the string the unit test expects not
        /// to match actual.</param>
        /// <param name="actual">The second string to compare. This is the string the unit test produced.</param>
        /// <param name="ignoreCase">A Boolean value that indicates a case-sensitive or insensitive comparison.
        /// true indicates a case-insensitive comparison.</param>
        /// <param name="message">A message to display if the assertion fails. This message can be seen in
        /// the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">notExpected is equal to actual.</exception>
        public static void AreNotEqual(string notExpected, string actual, bool ignoreCase, string message, params object[] parameters)
        {
            if (string.Compare(notExpected, actual, ignoreCase) == 0)
            {
                Assert.LogFailure(message, parameters);
            }
        }

        /// <summary>
        /// Verifies that two specified strings are not equal, ignoring case or not as
        /// specified, and using the culture info specified. The assertion fails if they
        /// are equal. Displays a message if the assertion fails, and applies the specified
        /// formatting to it.
        /// </summary>
        /// <param name="notExpected">The first string to compare. This is the string the unit test expects not
        /// to match actual.</param>
        /// <param name="actual">The second string to compare. This is the string the unit test produced.</param>
        /// <param name="ignoreCase">A Boolean value that indicates a case-sensitive or insensitive comparison.
        /// true indicates a case-insensitive comparison.</param>
        /// <param name="culture">A System.Globalization.CultureInfo object that supplies culture-specific
        /// comparison information.</param>
        /// <param name="message">A message to display if the assertion fails. This message can be seen in
        /// the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">notExpected is equal to actual.</exception>
        public static void AreNotEqual(string notExpected, string actual, bool ignoreCase, CultureInfo culture, string message, params object[] parameters)
        {
            if (string.Compare(notExpected, actual, ignoreCase, culture) == 0)
            {
                Assert.LogFailure(message, parameters);
            }
        }

        #endregion
    }
}
