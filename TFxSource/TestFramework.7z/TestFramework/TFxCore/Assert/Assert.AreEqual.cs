﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.Collections;

namespace Expedia.Test.Framework
{
    public static partial class Assert
    {
        #region AreEqual

        /// <summary>
        /// Compares two objects against each other and returns whether they are equal.
        /// </summary>
        /// <param name="expected">The expected object.</param>
        /// <param name="actual">The actual object.</param>
        /// <param name="comparer">Comparer</param>
        /// <returns>true if both expected and actual are equal, false otherwise.</returns>
        private static bool areEqual(object expected, object actual, IComparer comparer)
        {
            if (comparer.Compare(expected, actual) != 0)
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Compares two objects against each other and returns whether they are equal.
        /// </summary>
        /// <typeparam name="T">Any type.</typeparam>
        /// <param name="expected">The expected object.</param>
        /// <param name="actual">The actual object.</param>
        /// <param name="comparer">Comparer</param>
        /// <returns>true if both expected and actual are equal, false otherwise.</returns>
        private static bool areEqual<T>(T expected, T actual, IComparer<T> comparer)
        {
            if (comparer.Compare(expected, actual) != 0)
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Verifies that two specified generic type data are equal. The assertion fails
        /// if they are not equal.
        /// </summary>
        /// <typeparam name="T">Any type.</typeparam>
        /// <param name="expected">The first generic type data to compare. This is the generic type data the
        /// unit test expects.</param>
        /// <param name="actual">The second generic type data to compare. This is the generic type data the
        /// unit test produced.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">expected is not equal to actual.</exception>
        public static void AreEqual<T>(T expected, T actual)
        {
            if (!areEqual<T>(expected, actual, new AssertComparer<T>()))
            {
                Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_NotEqual", expected, actual));
            }
        }

        /// <summary>
        /// Verifies that two specified generic type data are equal. The assertion fails
        /// if they are not equal.
        /// </summary>
        /// <typeparam name="T">Any type.</typeparam>
        /// <param name="expected">The first generic type data to compare. This is the generic type data the
        /// unit test expects.</param>
        /// <param name="actual">The second generic type data to compare. This is the generic type data the
        /// unit test produced.</param>
        /// <param name="comparer">The comparer used to compare the two objects</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">expected is not equal to actual.</exception>
        public static void AreEqual<T>(T expected, T actual, IComparer<T> comparer)
        {
            if (!areEqual<T>(expected, actual, comparer))
            {
                Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_NotEqual", expected, actual));
            }
        }

        /// <summary>
        /// Verifies that two specified generic type data are equal. The assertion fails
        /// if they are not equal. Displays a message if the assertion fails, and applies
        /// the specified formatting to it.
        /// </summary>
        /// <typeparam name="T">Any type.</typeparam>
        /// <param name="expected">The first generic type data to compare. This is the generic type data the
        /// unit test expects.</param>
        /// <param name="actual">The second generic type data to compare. This is the generic type data the
        /// unit test produced.</param>
        /// <param name="message">A message to display if the assertion fails. This message can be seen in
        /// the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">expected is not equal to actual.</exception>
        public static void AreEqual<T>(T expected, T actual, string message, params object[] parameters)
        {
            if (!areEqual<T>(expected, actual, new AssertComparer<T>()))
            {
                Assert.LogFailure(message, parameters);
            }
        }

        /// <summary>
        /// Verifies that two specified generic type data are equal. The assertion fails
        /// if they are not equal. Displays a message if the assertion fails, and applies
        /// the specified formatting to it.
        /// </summary>
        /// <typeparam name="T">Any type.</typeparam>
        /// <param name="expected">The first generic type data to compare. This is the generic type data the
        /// unit test expects.</param>
        /// <param name="actual">The second generic type data to compare. This is the generic type data the
        /// unit test produced.</param>
        /// <param name="comparer">The comparer used to compare the two objects</param>
        /// <param name="message">A message to display if the assertion fails. This message can be seen in
        /// the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">expected is not equal to actual.</exception>
        public static void AreEqual<T>(T expected, T actual, IComparer<T> comparer, string message, params object[] parameters)
        {
            if (!areEqual<T>(expected, actual, comparer))
            {
                Assert.LogFailure(message, parameters);
            }
        }

        /// <summary>
        /// Verifies that two specified objects are equal. The assertion fails if the
        /// objects are not equal.
        /// </summary>
        /// <param name="expected">The first object to compare. This is the object the unit test expects.</param>
        /// <param name="actual">The second object to compare. This is the object the unit test produced.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">expected is not equal to actual.</exception>
        public static void AreEqual(object expected, object actual)
        {
            if ((new AssertComparer()).Compare(expected, actual) != 0)
            {
                Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_NotEqual", expected, actual));
            }
        }

        /// <summary>
        /// Verifies that two specified objects are equal. The assertion fails if the
        /// objects are not equal.
        /// </summary>
        /// <param name="expected">The first object to compare. This is the object the unit test expects.</param>
        /// <param name="actual">The second object to compare. This is the object the unit test produced.</param>
        /// <param name="comparer">The comparer used to compare the two objects</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">expected is not equal to actual.</exception>
        public static void AreEqual(object expected, object actual, IComparer comparer)
        {
            if (!areEqual(expected, actual, comparer))
            {
                Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_NotEqual", expected, actual));
            }
        }

        /// <summary>
        /// Verifies that two specified objects are equal. The assertion fails if the
        /// objects are not equal. Displays a message if the assertion fails, and applies
        /// the specified formatting to it.
        /// </summary>
        /// <param name="expected">The first object to compare. This is the object the unit test expects.</param>
        /// <param name="actual">The second object to compare. This is the object the unit test produced.</param>
        /// <param name="message">A message to display if the assertion fails. This message can be seen in
        /// the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">expected is not equal to actual.</exception>
        public static void AreEqual(object expected, object actual, string message, params object[] parameters)
        {
            if (!areEqual(expected, actual, new AssertComparer()))
            {
                Assert.LogFailure(message, parameters);
            }
        }

        /// <summary>
        /// Verifies that two specified objects are equal. The assertion fails if the
        /// objects are not equal. Displays a message if the assertion fails, and applies
        /// the specified formatting to it.
        /// </summary>
        /// <param name="expected">The first object to compare. This is the object the unit test expects.</param>
        /// <param name="actual">The second object to compare. This is the object the unit test produced.</param>
        /// <param name="comparer">The comparer used to compare the two objects</param>
        /// <param name="message">A message to display if the assertion fails. This message can be seen in
        /// the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">expected is not equal to actual.</exception>
        public static void AreEqual(object expected, object actual, IComparer comparer, string message, params object[] parameters)
        {
            if (!areEqual(expected, actual, comparer))
            {
                Assert.LogFailure(message, parameters);
            }
        }

        /// <summary>
        /// Verifies that two specified doubles are equal, or within the specified accuracy
        /// of each other. The assertion fails if they are not within the specified accuracy
        /// of each other.
        /// </summary>
        /// <param name="expected">The first double to compare. This is the double the unit test expects.</param>
        /// <param name="actual">The second double to compare. This is the double the unit test produced.</param>
        /// <param name="delta">The required accuracy. The assertion will fail only if expected is different
        /// from actual by more than delta.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">expected is different from actual by more than delta.</exception>
        public static void AreEqual(double expected, double actual, double delta)
        {
            if (Math.Abs(expected - actual) > delta)
            {
                Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_MoreThanDelta", expected, actual, delta));
            }
        }

        /// <summary>
        /// Verifies that two specified doubles are equal, or within the specified accuracy
        /// of each other. The assertion fails if they are not within the specified accuracy
        /// of each other. Displays a message if the assertion fails, and applies the
        /// specified formatting to it.
        /// </summary>
        /// <param name="expected">The first double to compare. This is the double the unit tests expects.</param>
        /// <param name="actual">The second double to compare. This is the double the unit test produced.</param>
        /// <param name="delta">The required accuracy. The assertion will fail only if expected is different
        /// from actual by more than delta.</param>
        /// <param name="message">A message to display if the assertion fails. This message can be seen in
        /// the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">expected is different from actual by more than delta.</exception>
        public static void AreEqual(double expected, double actual, double delta, string message, params object[] parameters)
        {
            if (Math.Abs(expected - actual) > delta)
            {
                Assert.LogFailure(message, parameters);
            }
        }

        /// <summary>
        /// Verifies that two specified singles are equal, or within the specified accuracy
        /// of each other. The assertion fails if they are not within the specified accuracy
        /// of each other.
        /// </summary>
        /// <param name="expected">The first single to compare. This is the single the unit test expects.</param>
        /// <param name="actual">The second single to compare. This is the single the unit test produced.</param>
        /// <param name="delta">The required accuracy. The assertion will fail only if expected is different
        /// from actual by more than delta.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">expected is different from actual by more than delta.</exception>
        public static void AreEqual(float expected, float actual, float delta)
        {
            if (Math.Abs(expected - actual) > delta)
            {
                Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_MoreThanDelta", expected, actual, delta));
            }
        }

        /// <summary>
        /// Verifies that two specified singles are equal, or within the specified accuracy
        /// of each other. The assertion fails if they are not within the specified accuracy
        /// of each other. Displays a message if the assertion fails, and applies the
        /// specified formatting to it.
        /// </summary>
        /// <param name="expected">The first single to compare. This is the single the unit test expects.</param>
        /// <param name="actual">The second single to compare. This is the single the unit test produced.</param>
        /// <param name="delta">The required accuracy. The assertion will fail only if expected is different
        /// from actual by more than delta.</param>
        /// <param name="message">A message to display if the assertion fails. This message can be seen in
        /// the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">expected is different from actual by more than delta.</exception>
        public static void AreEqual(float expected, float actual, float delta, string message, params object[] parameters)
        {
            if (Math.Abs(expected - actual) > delta)
            {
                Assert.LogFailure(message, parameters);
            }
        }

        /// <summary>
        /// Verifies that two specified strings are equal, ignoring case or not as specified.
        /// The assertion fails if they are not equal.
        /// </summary>
        /// <param name="expected">The first string to compare. This is the string the unit test expects.</param>
        /// <param name="actual">The second string to compare. This is the string the unit test produced.</param>
        /// <param name="ignoreCase">A Boolean value that indicates a case-sensitive or insensitive comparison.
        /// true indicates a case-insensitive comparison.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">expected is not equal to actual.</exception>
        public static void AreEqual(string expected, string actual, bool ignoreCase)
        {
            if (string.Compare(expected, actual, ignoreCase) != 0)
            {
                Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_NotEqual_IgnoreCase", expected, actual, ignoreCase, CultureInfo.CurrentCulture));
            }
        }

        /// <summary>
        /// Verifies that two specified strings are equal, ignoring case or not as specified,
        /// and using the culture info specified. The assertion fails if they are not
        /// equal.
        /// </summary>
        /// <param name="expected">The first string to compare. This is the string the unit test expects.</param>
        /// <param name="actual">The second string to compare. This is the string the unit test produced.</param>
        /// <param name="ignoreCase">A Boolean value that indicates a case-sensitive or insensitive comparison.
        /// true indicates a case-insensitive comparison.</param>
        /// <param name="culture">A System.Globalization.CultureInfo object that supplies culture-specific
        /// comparison information.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">expected is not equal to actual.</exception>
        public static void AreEqual(string expected, string actual, bool ignoreCase, CultureInfo culture)
        {
            if (string.Compare(expected, actual, ignoreCase, culture) != 0)
            {
                Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_NotEqual_IgnoreCase", expected, actual, ignoreCase, culture));
            }
        }

        /// <summary>
        /// Verifies that two specified strings are equal, ignoring case or not as specified.
        /// The assertion fails if they are not equal. Displays a message if the assertion
        /// fails, and applies the specified formatting to it.
        /// </summary>
        /// <param name="expected">The first string to compare. This is the string the unit test expects.</param>
        /// <param name="actual">The second string to compare. This is the string the unit test produced.</param>
        /// <param name="ignoreCase">A Boolean value that indicates a case-sensitive or insensitive comparison.
        /// true indicates a case-insensitive comparison.</param>
        /// <param name="message">A message to display if the assertion fails. This message can be seen in
        /// the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">expected is not equal to actual.</exception>
        public static void AreEqual(string expected, string actual, bool ignoreCase, string message, params object[] parameters)
        {
            if (string.Compare(expected, actual, ignoreCase) != 0)
            {
                Assert.LogFailure(message, parameters);
            }
        }

        /// <summary>
        /// Verifies that two specified strings are equal, ignoring case or not as specified,
        /// and using the culture info specified. The assertion fails if they are not
        /// equal. Displays a message if the assertion fails, and applies the specified
        /// formatting to it.
        /// </summary>
        /// <param name="expected">The first string to compare. This is the string the unit test expects.</param>
        /// <param name="actual">The second string to compare. This is the string the unit test produced.</param>
        /// <param name="ignoreCase">A Boolean value that indicates a case-sensitive or insensitive comparison.
        /// true indicates a case-insensitive comparison.</param>
        /// <param name="culture">A System.Globalization.CultureInfo object that supplies culture-specific
        /// comparison information.</param>
        /// <param name="message">A message to display if the assertion fails. This message can be seen in
        /// the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">expected is not equal to actual.</exception>
        public static void AreEqual(string expected, string actual, bool ignoreCase, CultureInfo culture, string message, params object[] parameters)
        {
            if (string.Compare(expected, actual, ignoreCase, culture) != 0)
            {
                Assert.LogFailure(message, parameters);
            }
        }

        #endregion
    }
}
