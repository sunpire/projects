﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.Collections;

namespace Expedia.Test.Framework
{
    public static partial class Assert
    {
        #region Log Helpers
        /// <summary>
        /// Reports an inconclusive failure and causes a test to fail.
        /// </summary>
        /// <param name="message">The failure message to log.</param>
        /// <param name="args">Any arguments used by the failure message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertInconclusiveException"></exception>
        private static void LogInconclusive(string message, params object[] args)
        {
            // Add assertion failed to the message.
            message = TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_Info", "Inconclusive", message);

            // Log the error.
            Logger.Instance.Write(new System.Diagnostics.StackFrame(1, true), SeverityType.Warning, LogLevelType.TestApi, message, args);

            // Throw an exception to completely fail the test.
            throw new AssertInconclusiveException(string.Format(message, args));
        }

        /// <summary>
        /// Reports a failure and causes a test to fail.
        /// </summary>
        /// <param name="message">The failure message to log.</param>
        /// <param name="args">Any arguments used by the failure message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException"></exception>
        private static void LogFailure(string message, params object[] args)
        {
            // Add assertion failed to the message.
            message = TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_Info", "Failed", message);

            // Log the error.
            Logger.Instance.Write(new System.Diagnostics.StackFrame(1, true), SeverityType.Error, LogLevelType.TestApi, message, args);

            // Throw an exception to completely fail the test.
            throw new AssertFailedException(string.Format(message, args));
        }
        #endregion
    }
}
