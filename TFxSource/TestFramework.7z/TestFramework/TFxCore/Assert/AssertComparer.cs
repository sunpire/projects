using System;
using System.Collections;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Default non-generic Comparer.  Does not support 
    /// IComparable&lt;T&gt; or IEquatable&lt;T&gt; types.
    /// </summary>
    public class AssertComparer : IComparer
    {
        #region IComparer Members

        /// <summary>
        /// Compare
        /// </summary>
        /// <param name="x">X</param>
        /// <param name="y">Y</param>
        /// <returns></returns>
        public int Compare(object x, object y)
        {
            // Get type
            Type type = typeof(object);
            if (x != null)
            {
                type = x.GetType();
            }
            else if (y != null)
            {
                type = y.GetType();
            }
            else
            {
                return 0;
            }

            // Null?            
            // Null (By definition, any object compares greater than null reference, and two null references compare equal to each other.)

            if (!type.IsValueType || (type.IsGenericType && type.GetGenericTypeDefinition().IsAssignableFrom(typeof(Nullable<>))))
            {
                if (object.Equals(x, default(object)))
                {
                    if (object.Equals(y, default(object)))
                    {
                        return 0;
                    }
                    return -1;
                }

                if (object.Equals(y, default(object)))
                {
                    return 1;
                }
            }

            // Arrays?
            if (type.IsArray)
            {
                Array xArray = x as Array;
                Array yArray = y as Array;

                if (xArray != null && yArray != null)
                {
                    if (xArray.Rank != 1)
                    {
                        throw new ArgumentException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_MultiDimArray"));
                    }

                    if (xArray.Length != yArray.Length)
                    {
                        return -1;
                    }

                    for (int index = 0; index < xArray.Length; index++)
                    {
                        if (!object.Equals(xArray.GetValue(index), yArray.GetValue(index)))
                        {
                            return -1;
                        }
                    }

                    return 0;
                }
            }

            // Implements IComparable?
            IComparable comparable2 = x as IComparable;

            if (comparable2 != null)
            {
                try
                {
                    return comparable2.CompareTo(y);
                }
                catch (ArgumentException)
                {
                }
            }

            // Last case, rely on Object.Equals
            return object.Equals(x, y) ? 0 : -1;
        }

        #endregion
    }
}
