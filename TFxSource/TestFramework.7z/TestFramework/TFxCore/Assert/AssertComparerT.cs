using System;
using System.Collections.Generic;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Default generic Comparer.  Supports both
    /// IComparable&lt;T&gt; and IEquatable&lt;T&gt; types.
    /// </summary>
    public class AssertComparer<T> : IComparer<T>
    {
        /// <summary>
        /// Compare
        /// </summary>
        /// <param name="x">X</param>
        /// <param name="y">Y</param>
        /// <returns></returns>
        public int Compare(T x, T y)
        {
            // Get type
            Type type = typeof(T);

            // Null?
            // Null (By definition, any object compares greater than null reference, and two null references compare equal to each other.)
            if (!type.IsValueType || (type.IsGenericType && type.GetGenericTypeDefinition().IsAssignableFrom(typeof(Nullable<>))))
            {
                if (object.Equals(x, default(T)))
                {
                    if (object.Equals(y, default(T)))
                    {
                        return 0;
                    }
                    return -1;
                }

                if (object.Equals(y, default(T)))
                {
                    return 1;
                }
            }

            // Arrays?
            if (type.IsArray || type.Equals(typeof(Array)))
            {
                Array xArray = x as Array;
                Array yArray = y as Array;

                if (xArray != null && yArray != null)
                {
                    if (xArray.Rank != 1)
                    {
                        throw new ArgumentException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_MultiDimArray"));
                    }

                    if (xArray.Length != yArray.Length)
                    {
                        return -1;
                    }

                    for (int index = 0; index < xArray.Length; index++)
                    {
                        if (!object.Equals(xArray.GetValue(index), yArray.GetValue(index)))
                        {
                            return -1;
                        }
                    }

                    return 0;
                }
            }

            // Implements IComparable<T>?
            IComparable<T> comparable1 = x as IComparable<T>;

            if (comparable1 != null)
            {
                return comparable1.CompareTo(y);
            }

            // Implements IComparable?
            IComparable comparable2 = x as IComparable;

            if (comparable2 != null)
            {
                try
                {
                    return comparable2.CompareTo(y);
                }
                catch (ArgumentException)
                {
                }
            }

            // Implements IEquatable<T>?
            IEquatable<T> equatable = x as IEquatable<T>;

            if (equatable != null)
            {
                return equatable.Equals(y) ? 0 : -1;
            }

            // Last case, rely on Object.Equals
            return object.Equals(x, y) ? 0 : -1;
        }
    }
}
