﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.Collections;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Provides a framework for verifying test state and data.  Various methods are available to evaluate and compare
    /// variables and expected responses, and fail the test in the case of unexpected results.  
    /// 
    /// Most methods have an overload for providing a custom error message if desired, otherwise a default one will be provided.
    /// </summary>
    /// <example>
    /// <code>
    /// [Test]
    /// public void WidgetTransmogrifierTest()
    /// {
    ///     Widget widget = new Widget();
    ///     string actual = widget.Transmogrifier("calvin")
    ///     string expected = "hobbes";
    ///     
    ///     Assert.AreEqual&lt;string&gt;(expected, actual, "Transmogrifier must be broken");
    ///     
    ///     // This line will not execute if Assert fails..
    ///     Logger.Instance.WriteInfo("Transmogrifier is working!");
    /// }
    /// </code>
    /// </example>
    public static partial class Assert
    {
        #region Misc

        /// <summary>
        /// Do not use this method.
        /// </summary>
        /// <exception cref="System.NotImplementedException">Do not use this method.</exception>
        [Obsolete("This is an override of Object.Equals(). Call Assert.Equal() instead.", true)]
        public static new bool Equals(object objA, object objB)
        {
            throw new InvalidOperationException(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_MethodNotBeUsed", "Assert.Equals"));
        }

        /// <summary>
        /// Fails the assertion without checking any conditions.
        /// </summary>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">Alwaus thrown.</exception>
        public static void Fail()
        {
            Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_MethodCalled", "Assert.Fail()"));
        }

        /// <summary>
        /// Fails the assertion without checking any conditions. Displays a message,
        /// and applies the specified formatting to it.
        /// </summary>
        /// <param name="message">A message to display. This message can be seen in the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertFailedException">Always thrown.</exception>
        public static void Fail(string message, params object[] parameters)
        {
            Assert.LogFailure(message, parameters);
        }

        /// <summary>
        /// Indicates that the assertion cannot be verified.
        /// </summary>
        /// <exception cref="Expedia.Test.Framework.AssertInconclusiveException">Always thrown.</exception>
        public static void Inconclusive()
        {
            Assert.LogInconclusive(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_MethodCalled", "Assert.Inconclusive()"));
        }

        /// <summary>
        /// Indicates that an assertion can not be verified. Displays a message, and
        /// applies the specified formatting to it.
        /// </summary>
        /// <param name="message">A message to display. This message can be seen in the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <exception cref="Expedia.Test.Framework.AssertInconclusiveException">Always thrown.</exception>
        public static void Inconclusive(string message, params object[] parameters)
        {
            Assert.LogInconclusive(message, parameters);
        }

        #endregion
    }
}
