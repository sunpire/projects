﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.Collections;

namespace Expedia.Test.Framework
{
    public static partial class Assert
    {
        #region Throws/DoesNotThrow

        /// <summary>
        /// Represents a method that takes no parameters and does not return anything. 
        /// This delegate is used by Assert.Throws and Assert.DoesNotThrow to test
        /// methods that throw exceptions.
        /// </summary>
        public delegate void ThrowsDelegate();
        
        /// <summary>
        /// Verifies that any exception is thrown.
        /// </summary>
        /// <param name="testCode">A delegate to the code to be tested</param>
        /// <returns>The expected exception that was caught.</returns>
        public static Exception Throws(ThrowsDelegate testCode)
        {
            Exception expectedException = null;

            try
            {
                testCode();
            }
            catch (Exception e)
            {
                // Code threw expected exception; success
                expectedException = e;
            }
            finally
            {
                if (expectedException == null)
                {
                    Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_NoException"));
                }
            }

            return expectedException;
        }

        /// <summary>
        /// Verifies that any exception is thrown.
        /// </summary>
        /// <param name="testCode">A delegate to the code to be tested</param>
        /// <param name="message">A message to display if the assertion fails. This message 
        /// can be seen in the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <returns>The expected exception that was caught.</returns>
        public static Exception Throws(ThrowsDelegate testCode, string message, params object[] parameters)
        {
            Exception expectedException = null;

            try
            {
                testCode();
            }
            catch (Exception e)
            {
                // Code threw expected exception; success
                expectedException = e;
            }
            finally
            {
                if (expectedException == null)
                {
                    Assert.LogFailure(message, parameters);
                }
            }

            return expectedException;
        }

        /// <summary>
        /// Verifies that the exact exception is thrown (and not a derived exception type).
        /// </summary>
        /// <typeparam name="T">The type of the exception expected to be thrown</typeparam>
        /// <param name="testCode">A delegate to the code to be tested</param>
        /// <returns>The expected exception that was caught.</returns>
        public static T Throws<T>(ThrowsDelegate testCode)
            where T : Exception
        {
            T expectedException = null;

            try
            {
                testCode();
            }
            catch (T e)
            {
                if (e.GetType().Equals(typeof(T)))
                {
                    // Code threw expected exception; success
                    expectedException = e;
                }
            }
            finally
            {
                if (expectedException == null)
                {
                    Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_ExceptionNotExpected", typeof(T).Name));
                }
            }
            return expectedException;
        }

        /// <summary>
        /// Verifies that the exact exception is thrown (and not a derived exception type).
        /// </summary>
        /// <typeparam name="T">The type of the exception expected to be thrown</typeparam>
        /// <param name="testCode">A delegate to the code to be tested</param>
        /// <param name="message">A message to display if the assertion fails. This message 
        /// can be seen in the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        /// <returns>The expected exception that was caught.</returns>
        public static T Throws<T>(ThrowsDelegate testCode, string message, params object[] parameters)
            where T : Exception
        {
            T expectedException = null;

            try
            {
                testCode();
            }
            catch (T e)
            {
                if (e.GetType().Equals(typeof(T)))
                {
                    // Code threw expected exception; success
                    expectedException = e;
                }
            }
            finally
            {
                if (expectedException == null)
                {
                    Assert.LogFailure(message, parameters);
                }
            }

            return expectedException;
        }

        /// <summary>
        /// Verifies that a block of code does not throw any exceptions.
        /// </summary>
        /// <param name="testCode">A delegate to the code to be tested</param>
        public static void DoesNotThrow(ThrowsDelegate testCode)
        {
            try
            {
                testCode();
            }
            catch (Exception e)
            {
                Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_Exception", e.GetType().Name));
            }
        }

        /// <summary>
        /// Verifies that a block of code does not throw any exceptions.
        /// </summary>
        /// <param name="testCode">A delegate to the code to be tested</param>
        /// <param name="message">A message to display if the assertion fails. This message 
        /// can be seen in the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        public static void DoesNotThrow(ThrowsDelegate testCode, string message, params object[] parameters)
        {
            try
            {
                testCode();
            }
            catch (Exception)
            {
                Assert.LogFailure(message, parameters);
            }
        }

        /// <summary>
        /// Verifies that a block of code does not throw an exact exception.
        /// Any other Exception types will be handled and not rethrown.
        /// </summary>
        /// <param name="testCode">A delegate to the code to be tested</param>
        public static void DoesNotThrow<T>(ThrowsDelegate testCode)
            where T : Exception
        {
            try
            {
                testCode();
            }
            catch (T e)
            {
                if (e.GetType().Equals(typeof(T)))
                {
                    Assert.LogFailure(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_Exception", e.GetType().Name));
                }
            }
            catch (Exception e)
            {
                Logger.Instance.WriteInfo(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_ExceptionNotExpected", e.GetType().Name));
            }
        }

        /// <summary>
        /// Verifies that a block of code does not throw an exact exception.
        /// Any other Exception types will be handled and not rethrown.
        /// </summary>
        /// <param name="testCode">A delegate to the code to be tested</param>
        /// <param name="message">A message to display if the assertion fails. This message 
        /// can be seen in the unit test results.</param>
        /// <param name="parameters">An array of parameters to use when formatting message.</param>
        public static void DoesNotThrow<T>(ThrowsDelegate testCode, string message, params object[] parameters)
            where T : Exception
        {
            try
            {
                testCode();
            }
            catch (T e)
            {
                if (e.GetType().Equals(typeof(T)))
                {
                    Assert.LogFailure(message, parameters);
                }
            }
            catch (Exception e)
            {
                Logger.Instance.WriteInfo(TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_ExceptionNotExpected", e.GetType().Name));
            }
        }

        #endregion
    }
}
