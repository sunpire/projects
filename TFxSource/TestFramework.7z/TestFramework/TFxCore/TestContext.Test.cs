using System;
using System.Diagnostics;
using System.Collections.Generic;

namespace Expedia.Test.Framework
{
    public class TestVerification
    {
        public bool Status { get; set; }
        public string Feature { get; set; }
        public string Product { get; set; }
        public string ProductVersion { get; set; }
        public string Tag { get; set; }
        public string Priority { get; set; }
        public string Risk { get; set; }
        public string TestType { get; set; }
        public string FailureMessage { get; set; }
        public string FailureDetails { get; set; }

        public override string ToString()
        {
            return string.Format(
                "Status={0},Product={1},Feature={2},ProductVersion={3},TestType={4},Tag={5},Priority={6},Risk={7},\r\nFailureMessage={8},\r\nFailureDetails={9}",
                Status,
                Product ?? string.Empty,
                Feature ?? string.Empty,
                ProductVersion ?? string.Empty,
                TestType ?? string.Empty,
                Tag ?? string.Empty,
                Priority ?? string.Empty,
                Risk ?? string.Empty,
                FailureMessage ?? string.Empty,
                FailureDetails ?? string.Empty
                );
        }
    }
    public class TestCounter
    {
        public string Feature { get; set; }
        public string Product { get; set; }
        public string ProductVersion { get; set; }
        public string Name { get; set; }
        public string Value { get; set; }
        public TestCounterValueType ValueType { get; set; }
        public string Priority { get; set; }
        public string Risk { get; set; }

        public override string ToString()
        {
            return string.Format(
                "Name={0},Value={1},ValueType={2},Product={3},Feature={4},ProductVersion={5},Priority={6},Risk={7}",
                Name,
                Value,
                ValueType,
                Product ?? string.Empty,
                Feature ?? string.Empty,
                ProductVersion ?? string.Empty,
                Priority ?? string.Empty,
                Risk ?? string.Empty
                );
        }
    }
    public enum TestCounterValueType
    {
        Text,
        Number,
        Date,
        Duration
    }
    public partial class TestContext
    {
        #region Verifications & Counters

        private List<TestVerification> _verifications = new List<TestVerification>();
        private List<TestCounter> _counters = new List<TestCounter>();

        public IEnumerable<TestVerification> Verifications
        {
            get { return _verifications; }
        }

        public IEnumerable<TestCounter> Counters
        {
            get { return _counters; }
        }

        public void ReportVerification(
            bool status,
            string feature,
            string product,
            string productVersion = null,
            string tags = null,
            string priority = null,
            string risk = null,
            string testType = null,
            string failureMessage = null,
            string failureDetails = null,
            bool enableLog=false)
        {
            var entry = new TestVerification
            {
                Status = status,
                Feature = feature,
                Product = product,
                ProductVersion = productVersion,
                Tag = tags,
                Priority = priority,
                Risk = risk,
                TestType = testType,
                FailureMessage = failureMessage,
                FailureDetails = failureDetails
            };
            _verifications.Add(entry);

            if (enableLog)
            {
                Logger.Instance.Write(LogLevelType.TestApi, TFxCoreResourceManager.GetMessageFromRes("TFxCore_ContextTest_Verification", entry));
            }
        }

        /// <summary>
        /// 
        /// ##Important##, do not delete this method since this method signature is being consumed
        /// by LIS team.
        /// 
        /// </summary>
        public void ReportCounter(
            string counterName,
            object counterValue,
            TestCounterValueType valueType,
            string feature,
            string product,
            string productVersion = null,
            string priority = null,
            string risk = null)
        {
            ReportCounter(
                counterName,
                counterValue,
                valueType,
                feature,
                product,
                false,
                productVersion,
                priority,
                risk);
        }

        public void ReportCounter(
            string counterName,
            object counterValue,
            TestCounterValueType valueType,
            string feature,
            string product,
            bool enableLog,
            string productVersion = null,
            string priority = null,
            string risk = null)
        {
            var entry = new TestCounter
            {
                Name = counterName,
                Value = counterValue.ToString(),
                ValueType = valueType,
                Feature = feature,
                Product = product,
                ProductVersion = productVersion,
                Priority = priority,
                Risk = risk
            };
            _counters.Add(entry);

            if (enableLog)
            {
                Logger.Instance.Write(LogLevelType.TestApi, TFxCoreResourceManager.GetMessageFromRes("TFxCore_ContextTest_Counter", entry));
            }
        }


        #endregion

        #region Test and Scenario Functions

        /// <summary>
        /// Gets access to the scenarios that have executed.
        /// </summary>
        public TestRunResult[] Scenarios
        {
            get
            {
                return this.scenarioResults.ToArray();
            }
        }

        /// <summary>
        /// Gets the current scenario.
        /// </summary>
        public TestRunResult CurrentScenario
        {
            get;
            private set;
        }

        /// <summary>
        /// Prepares the list of scenarios for assignment result 
        /// interpretation.
        /// </summary>
        private void PrepareScenarios()
        {
            // save any existing scenario to the scenario results collection
            this.ScenarioFinish();

            // check to see if there is a current scenario and create one if not
            if (this.scenarioResults.Count == 0)
            {
                // create the main result
                TestRunResult result = new TestRunResult();
                result.Outcome = TestOutcome.Pass;
                this.scenarioResults.Add(result);
            }
        }

        /// <summary>
        /// Ends the current scenario and starts a new scenario with the given description.
        /// </summary>
        /// <param name="description">The scenario description.</param>
        public void Scenario(string description)
        {
            // save the existing scenario to the scenario results collection
            this.ScenarioFinish();

            // create the scenario result
            TestRunResult tempResult = new TestRunResult();
            tempResult.Description = description;

            // add the scenario to the list
            this.CurrentScenario = tempResult;

            // write the log entry
            Logger.Instance.Write(LogLevelType.TestApi, TFxCoreResourceManager.GetMessageFromRes("TFxCore_ContextTest_Scenario", description));
        }

        /// <summary>
        /// Ends and saves the current scenario, if there is one.
        /// </summary>
        public void ScenarioFinish()
        {
            if (this.CurrentScenario != null)
            {
                if (this.CurrentScenario.Outcome == TestOutcome.None)
                {
                    this.CurrentScenario.Outcome = TestOutcome.Pass;
                }

                this.scenarioResults.Add(this.CurrentScenario);
                this.CurrentScenario = null;
            }
        }

        /// <summary>
        /// Reports the scenario failed with the following reason.
        /// </summary>
        /// <param name="failureReason">The reason the scenario failed.</param>
        public void ScenarioFail(string failureReason)
        {
            // create a stack trace to use as the error details
            StackTrace stackTrace = new StackTrace(1, true);

            // call the private scenario fail with this message.
            this.ScenarioFail(failureReason, stackTrace.ToString());
        }

        /// <summary>
        /// Reports the scenario failed with the following exception.
        /// </summary>
        /// <param name="exception">The exception that caused the failure.</param>
        public void ScenarioFail(Exception exception)
        {
            // call the private scenario fail with this exception.
            if (exception is TFxException)
                this.ScenarioFail(exception.Message, exception.ToString(), ((TFxException)exception).ErrorCategory, ((TFxException)exception).ErrorDetail);

            else
                this.ScenarioFail(exception.Message, exception.ToString());
        }

        /// <summary>
        /// Reports the scenario failed with the following reason.
        /// </summary>
        /// <param name="failureReason">The failure reason.</param>
        /// <param name="failureDetail">The failure detail.</param>
        private void ScenarioFail(string failureReason, string failureDetail)
        {
            ScenarioFail(failureReason, failureDetail, TestErrorCategory.Unresolved, null);
        }

        /// <summary>
        /// Reports the scenario failed with the failure reason and category to auto-resolve
        /// </summary>
        /// <param name="failureReason">The failure reason.</param>
        /// <param name="failureDetail">The failure detail.</param>
        /// <param name="errorCategory">the error category to auto-resolve</param>
        /// <param name="errorDetail">the error detail to auto-resolve</param>
        private void ScenarioFail(string failureReason, string failureDetail, TestErrorCategory errorCategory, string errorDetail)
        {
            // check to see if there is a current scenario
            if (this.CurrentScenario == null)
            {
                this.CurrentScenario = new TestRunResult();
            }

            // fail it
            this.CurrentScenario.Outcome = TestOutcome.Fail;
            this.CurrentScenario.FailureReason = failureReason;
            this.CurrentScenario.FailureDetail = failureDetail;
            this.CurrentScenario.ErrorCategory = errorCategory;
            this.CurrentScenario.ErrorDetail = errorDetail;

            this.scenarioResults.Add(this.CurrentScenario);
            this.CurrentScenario = null;

            // write the log entry
            StackFrame frame = new StackFrame(1, true);
            Logger.Instance.Write(frame, SeverityType.Error, LogLevelType.TestApi, failureReason);
            Logger.Instance.Write(frame, SeverityType.Warning, LogLevelType.TestApi, failureDetail);
        }

        /// <summary>
        /// Reports the test failed with the following reason.
        /// </summary>
        /// <param name="failureReason">The reason the test failed.</param>
        public void TestFail(string failureReason)
        {
            throw new TFxException(failureReason);
        }

        /// <summary>
        /// Fail the test with the specified failure reason, provides category and errorDetail to resolve automatically
        /// </summary>
        /// <param name="failureReason">Mark the test fail with this reason</param>
        /// <param name="errorCategory">Error category for the failed test case</param>
        /// <param name="errorDetail">error details to this automated resolve, will be displayed in each assignment column</param>
        public void TestFail(string failureReason, TestErrorCategory errorCategory, string errorDetail)
        {
            TFxException exception = new TFxException(failureReason)
            {
                ErrorCategory = errorCategory,
                ErrorDetail = "[ByCode] " + errorDetail
            };

            if (errorCategory != TestErrorCategory.Unresolved)
                Logger.Instance.WriteWarning(
                    string.Format("{0} \r[{1}]: {2}", TFxCoreResourceManager.GetMessageFromRes("TFxCore_Context_AutoResolve"), errorCategory.ToString(), errorDetail));
            throw exception;
        }

        #endregion

        #region Log Helpers

        /// <summary>
        /// Logs a comment for accessing a Config when it is being accessed the first time.
        /// </summary>
        /// <param name="name">Name of the Config.</param>
        /// <param name="message">The message to log.</param>
        /// <param name="args">Any other params for formatting the message.</param>
        private static void LogConfigMessage(string name, string message, params object[] args)
        {
            string lowerName = name.ToLower();

            if (!TestContext.Instance.accessedConfigs.Contains(lowerName))
            {
                TestContext.Instance.accessedConfigs.Add(lowerName);
                LogComment(message, args);
            }
        }

        /// <summary>
        /// Logs a comment to the logger.
        /// </summary>
        private static void LogComment(string comment, params object[] args)
        {
            Logger.Instance.Write(new StackFrame(1, true), SeverityType.Info, LogLevelType.TFxConfig, comment, args);
        }

        /// <summary>
        /// Logs a warning to the logger.
        /// </summary>
        private static void LogWarning(string warning, params object[] args)
        {
            Logger.Instance.Write(new StackFrame(1, true), SeverityType.Warning, LogLevelType.TFxConfig, warning, args);
        }

        /// <summary>
        /// Logs an error to the logger without throwing exceptions.
        /// </summary>
        private static void LogError(string error, params object[] args)
        {
            Logger.Instance.Write(new StackFrame(1, true), SeverityType.Error, LogLevelType.TFxConfig, error, args);
        }

        #endregion
    }
}
