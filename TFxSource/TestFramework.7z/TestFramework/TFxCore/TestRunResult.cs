using System;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Represents the results from a test execution.
    /// </summary>
    [Serializable]
    public sealed class TestRunResult
    {
        /// <summary>
        /// Defines the default test run result description.
        /// </summary>
        public static readonly string DefaultDescription = "main";

        /// <summary>
        /// Initializes the test run result.
        /// </summary>
        public TestRunResult()
        {
            this.Description = TestRunResult.DefaultDescription;
            this.Outcome = TestOutcome.None;
            this.FailureReason = string.Empty;
            this.FailureDetail = string.Empty;
        }

        /// <summary>
        /// Gets the description of this result.
        /// </summary>
        public string Description
        {
            get;
            internal set;
        }

        /// <summary>
        /// Gets the outcome of the given test.
        /// </summary>
        public TestOutcome Outcome
        {
            get;
            internal set;
        }

        /// <summary>
        /// Indicates whether the test has been executed.
        /// </summary>
        public bool Executed
        {
            get
            {
                return (this.Outcome != TestOutcome.None);
            }
        }

        /// <summary>
        /// Indicates whether the test has failed.
        /// </summary>
        public bool IsFailure
        {
            get
            {
                return (this.Outcome == TestOutcome.Fail || this.Outcome == TestOutcome.Timeout);
            }
        }

        /// <summary>
        /// Gets the failure reason of this result.
        /// </summary>
        public string FailureReason
        {
            get;
            internal set;
        }

        /// <summary>
        /// Gets the failure details of this result.
        /// </summary>
        public string FailureDetail
        {
            get;
            internal set;
        }

        private TestErrorCategory errorCategory;
        /// <summary>
        /// Error category of failed test case 
        /// </summary>
        public TestErrorCategory ErrorCategory
        {
            get
            {
                return errorCategory == 0 ? TestErrorCategory.Unresolved : errorCategory;
            }
            set
            {
                this.errorCategory = value;
            }
        }

        private string errorDetail;
        /// <summary>
        /// Detailed Infomation for describing the failed test case
        /// </summary>
        public string ErrorDetail
        {
            get
            {
                return errorDetail == null ? string.Empty : errorDetail;
            }
            set
            {
                this.errorDetail = value;
            }
        }
    }
}
