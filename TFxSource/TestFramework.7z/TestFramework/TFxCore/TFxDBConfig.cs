﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// TFxDBConfig
    /// </summary>
    public class TFxDBConfig
    {
        string m_serverName;
        string m_dbName;
        string m_serverMirrorName;

        /// <summary>
        /// Server Name
        /// </summary>
        public string ServerName
        {
            get
            {
                return m_serverName;
            }
            set
            {
                m_serverName = value;
            }
        }

        /// <summary>
        /// DB Name
        /// </summary>
        public string DBName
        {
            get
            {
                return m_dbName;
            }
            set
            {
                m_dbName = value;
            }
        }

        /// <summary>
        /// Server Mirror Name
        /// </summary>
        public string ServerMirrorName
        {
            get
            {
                return m_serverMirrorName;
            }
            set
            {
                m_serverMirrorName = value;
            }
        }

        /// <summary>
        /// Config File
        /// </summary>
        public static String ConfigFile = "TFxDB.config";

        /// <summary>
        /// TFx DB Config
        /// </summary>
        public TFxDBConfig()
        {
            if (System.IO.File.Exists(ConfigFile))
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(ConfigFile);
                XmlNodeList nodeList = doc.GetElementsByTagName("TFxConfig");

                // read nodes from TFxConfig
                if (nodeList.Count > 0)
                {
                    nodeList = nodeList[0].ChildNodes;
                    foreach (XmlNode node in nodeList)
                    {
                        if (node.Attributes["key"].Value == "TFxServerName")
                            m_serverName = node.Attributes["value"].Value;
                        else if (node.Attributes["key"].Value == "TFxDBName")
                            m_dbName = node.Attributes["value"].Value;
                        else if (node.Attributes["key"].Value == "TFxDBServerMirror")
                            m_serverMirrorName = node.Attributes["value"].Value;
                    }
                }
            }
            else
            {
                System.Diagnostics.EventLog.WriteEntry("Application",
                    TFxCoreResourceManager.GetMessageFromRes("TFxCore_DBConfig_FileNotExisted", System.IO.Path.GetFullPath(ConfigFile)));
            }

            if (string.IsNullOrEmpty(m_serverName) || string.IsNullOrEmpty(m_dbName))
            {
                m_serverName = "chsxsqltfx001.idx.expedmz.com,1433";
                m_dbName = "TFx2009";
                m_serverMirrorName = "chsxsqltfx003.idx.expedmz.com,1433";
            }
        }
    }
}
