﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Extend methods of existed classes
    /// </summary>
    public static class UtilityExtend
    {
        /// <summary>
        /// Contains the keys.
        /// </summary>
        /// <param name="dic">The specified dictionary.</param>
        /// <param name="key">The key value.</param>
        /// <param name="ignoreCase">if case sensitive set to true, case insensitive set to false</param>
        /// <param name="value">The value of key in dictionary.</param>
        /// <returns>whether contains or not</returns>
        public static bool ContainsKey(this Dictionary<string, string> dic, string key, bool ignoreCase, out string value)
        {
            value = string.Empty;
            if (dic == null || string.IsNullOrEmpty(key))
            {
                return false;
            }

            if (ignoreCase)
            {
                foreach (var item in dic)
                {
                    if (string.Compare(item.Key, key, true) == 0)
                    {
                        value = item.Value;
                        return true;
                    }
                }

                return false;
            }
            else
            {
                bool flag = dic.ContainsKey(key);
                if (flag)
                {
                    value = dic[key];
                }

                return flag;
            }
        }
    }
}
