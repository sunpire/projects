using System;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Used to attach a cleanup method to the TestContext
    /// so that the method can be invoked during the cleanup
    /// of TestContext.  This is useful for cleaning up 
    /// that initialize on first use. Use 
    /// TestContext.AttachCleaner(CleanupDelegate).
    /// </summary>
    public delegate void CleanupDelegate();
}
