﻿using System;
using System.Collections;
using System.IO;

namespace Expedia.Automation.Web.Registry
{
    public static class RegistryType
    {
        public enum MachineType
        {
            Native = 0,
            I386 = 0x014c,
            Itanium = 0x0200,
            x64 = 0x8664
        }

        private static readonly string[] msTravObPathstrings = new[] { @"\d$\travbind\server\", @"\d$\travbin\server\" };
        private const string msTravObExe = "mstravob.exe";

        private static Hashtable site64BitHash = new Hashtable();

        /// <summary>
        /// Checks if a site already exists in the hashtable and if not checks if mstravob.exe for that site is 64 bit 
        /// </summary>
        /// <param name="site">Remote machine</param>
        /// <returns>returns true if mstrabob.exe for a given site is 64 bit</returns>
        public static bool Read64BitRegistry(string site)
        {
            if (!site64BitHash.ContainsKey(site))
            {
                lock (site64BitHash)
                {
                    DirectoryInfo mstravObjdir = GetMsTravobjDir(site);
                    if (mstravObjdir == null)
                    {
                        site64BitHash[site] = false;
                        return (bool)site64BitHash[site];
                    }

                    string mstravObjFilePath = null;
                    try
                    {
                        mstravObjdir.GetFiles(); // Check for access
                        mstravObjFilePath = mstravObjdir.FullName + msTravObExe;
                        site64BitHash[site] = File.Exists(mstravObjFilePath) && Is64BitBinary(mstravObjFilePath);
                    }
                    catch (UnauthorizedAccessException e)
                    {
                        throw new UnauthorizedAccessException("Access to path is denied: \\" + mstravObjFilePath +
                            " ,Expedia Registry requires access to mstravob.exe to determine whether to call a 32 or 64 bit registry", e);
                    }
                }
            }

            return (bool)site64BitHash[site];
        }

        private static DirectoryInfo GetMsTravobjDir(string site)
        {
            DirectoryInfo mstravObjdir = null;
            foreach (string pathstring in msTravObPathstrings)
            {
                string path = @"\\" + site + pathstring;

                if (Directory.Exists(path))
                {
                    mstravObjdir = new DirectoryInfo(path);
                    break;
                }
            }
            return mstravObjdir;
        }

        /// <summary>
        /// Checks whether mstravob is a 32 or 64 binary
        /// </summary>
        /// <param name="path">path on the remote machine to mstravob.exe</param>
        /// <returns>returns true if mstrabob.exe is a 64 bit binary</returns>
        public static bool Is64BitBinary(string path)
        {
            return GetMachineType(path) == MachineType.x64;
        }

        /// <summary>
        /// Checks the machine type of a file by looking in the PE header for the bits corresponding to a particular
        /// machine type I386 = 0x014c, x64 = 0x8664
        /// http://stackoverflow.mobi/question197951_How-can-I-determine-for-which-platform-an-executable-is-compiled-.aspx
        /// </summary>
        /// <param name="fileName">the file on a remote machine to check</param>
        /// <returns>enum of the machinetype</returns>
        private static MachineType GetMachineType(string fileName)
        {
            const int PE_POINTER_OFFSET = 60;
            const int MACHINE_OFFSET = 4;
            byte[] data = new byte[4096];

            using (Stream s = new FileStream(fileName, FileMode.Open, FileAccess.Read))
            {
                s.Read(data, 0, 4096);
            }

            int peHheaderAddress = BitConverter.ToInt32(data, PE_POINTER_OFFSET);
            int machineTypeBytes = BitConverter.ToUInt16(data, peHheaderAddress + MACHINE_OFFSET);
            return (MachineType)machineTypeBytes;
        }
    }
}
