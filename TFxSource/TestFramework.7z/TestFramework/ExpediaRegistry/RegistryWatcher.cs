using System;
using System.IO;
using System.Threading;

using Microsoft.Win32;

namespace Expedia.Automation.Web.Registry
{
	public class RegistryWatcher : IDisposable
	{
        public delegate void RegistryChangedEventHandler(object sender, RegistryChangedEventArgs e);
        public event RegistryChangedEventHandler Changed;

        private Thread m_watcherThread = null;

        public RegistryWatcher() { }

        /// <summary>
        /// Wait for the registry value to change
        /// </summary>
        /// <param name="timeout">Timeout in miliseconds (0 for infinite)</param>
        /// <returns>Change results</returns>
        public WaitForChangedResult WaitForChange(int timeout)
        {
            WaitForChangedResult result = new WaitForChangedResult();
            result.ChangeType = WatcherChangeTypes.Changed;
            result.Name = m_subKey + "\\" + m_valueName;

            object initialValue = ExpediaRegistry.GetRegistryValue(m_machineName, m_Hive, m_subKey, m_valueName);
            object newValue = null;

            DateTime stop = DateTime.Now.AddMilliseconds(timeout);
            if (timeout == 0)
                stop = DateTime.Now.AddYears(1);
            while (DateTime.Now < stop)
            {
                newValue = ExpediaRegistry.GetRegistryValue(m_machineName, m_Hive, m_subKey, m_valueName);
                if (!newValue.Equals(initialValue))
                {
                    result.TimedOut = false;
                    return result;
                }
                Thread.Sleep(m_interval);
            }
            result.TimedOut = true;
            return result;
        }

        /// <summary>
        /// Notify listeners event was raised
        /// </summary>
        private void OnChanged(object initialValue, object newValue)
        {
            if(Changed != null)
            {
                Changed(this, new RegistryChangedEventArgs(initialValue, newValue));
            }
        }

        private bool m_enabled = false;
        /// <summary>
        /// Gets or sets flag indicating if the watcher will raise events
        /// This starts the watcher be sure to set SubKey and ValueName before enabling this
        /// </summary>
        public bool EnableRaisingEvents
        {
            get { return m_enabled; }
            set
            {
                if (m_subKey == null || m_valueName == null)
                    throw new Exception("Subkey or Valuename was not set");
                m_enabled = true;
                m_watcherThread = new Thread(StartWatching);
                m_watcherThread.Start();
            }
        }

        public void StartWatching()
        {
            object initialValue = ExpediaRegistry.GetRegistryValue(m_machineName, m_Hive, m_subKey, m_valueName);
            object newValue = null;
            while (m_enabled)
            {
                newValue = ExpediaRegistry.GetRegistryValue(m_machineName, m_Hive, m_subKey, m_valueName);
                if (!newValue.Equals(initialValue))
                {
                    OnChanged(initialValue, newValue);
                    initialValue = newValue;
                }
                Thread.Sleep(m_interval);
            }
        }

        private string m_machineName = ".";
        /// <summary>
        /// Gets or sets the machine name
        /// </summary>
        public string MachineName
        {
            get { return m_machineName; }
            set { m_machineName = value; }
        }

        private RegistryHive m_Hive = RegistryHive.LocalMachine;
        /// <summary>
        /// Gets or sets the registry hive
        /// </summary>
        public RegistryHive Hive
        {
            get { return m_Hive; }
            set { m_Hive = value; }
        }

        private int m_interval = 100;
        /// <summary>
        /// Gets or sets the poll interval in milliseconds
        /// </summary>
        public int Interval
        {
            get { return m_interval; }
            set { m_interval = value; }
        }

        private string m_subKey = null;
        /// <summary>
        /// Gets or sets the sub key
        /// Must be set before setting EnableRaisingEvents to true
        /// </summary>
        public string SubKey
        {
            get { return m_subKey; }
            set { m_subKey = value; }
        }

        private string m_valueName = null;
        /// <summary>
        /// Gets or sets the value name
        /// Must be set before setting EnableRaisingEvents to true
        /// </summary>
        public string ValueName
        {
            get { return m_valueName; }
            set { m_valueName = value; }
        }

        #region IDisposable Members

        public void Dispose()
        {
            if (m_enabled)
            {
                m_enabled = false;
                m_watcherThread.Join();
            }
        }

        #endregion
    }
}
