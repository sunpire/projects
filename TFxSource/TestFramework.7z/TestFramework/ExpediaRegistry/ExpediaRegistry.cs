﻿using System;
using Microsoft.Win32;
using System.IO;
using System.Net.NetworkInformation;
using System.Threading;
using ExpediaRegistryService.RegistryService;
using System.ServiceModel;

namespace Expedia.Automation.Web.Registry
{
    public static class ExpediaRegistry
    {
        public delegate void LogHandler(string comment, params object[] args);

        public static event LogHandler Log;

        public static Func<string, string> GetConfig;

        #region Properties
        public static string REGISTRY_TRAVELSERVER_MSTRAVOBJ = @"SOFTWARE\Expedia\TravelServer\MSTravelObject";
        public static string REGISTRY_TRAVELSERVER_LISP = @"SOFTWARE\Expedia\TravelServer\LISP";
        public static string REGISTRY_TRAVELSERVER = "SOFTWARE\\Expedia\\WebServer\\TravelServer\\Hot";
        public static string REGISTRY_TRAVELSERVER_VALUE = "Name";
        public static string REGISTRY_SPCONFIG = "SOFTWARE\\Expedia\\TravelServer\\spconfig";
    
       
        /// <summary>
        /// Gets or sets the timeout use for accessing registry
        /// </summary>
        public static int MaxTimeoutMilliSeconds { get; set; }
       
        #endregion
             
        #region Basic Methods
        /// <summary>
        /// Static constructor to set the default timeout value
        /// </summary>
        static ExpediaRegistry()
        {
            MaxTimeoutMilliSeconds = 60000;      
        }

        /// <summary>
        /// Makes the current thread sleep without eating up cpu time
        /// Accurate to 20 miliseconds not used as a timer
        /// </summary>
        /// <param name="miliSeconds">Number of miliseconds to sleep</param>
        private static void NonBusyWait(int miliSeconds)
        {
            DateTime stop = DateTime.Now.AddMilliseconds(miliSeconds);
            while (DateTime.Now < stop)
            {
                Thread.Sleep(20);
            }
        }

        private static RegistryServiceSoapClient registryServiceClient= null;


        public static RegistryServiceSoapClient RegistryServiceClient
        {
            get 
            {
                if (registryServiceClient == null)
                {
                    BasicHttpBinding basicHttpBinding = new BasicHttpBinding();
                    basicHttpBinding.SendTimeout = new TimeSpan(0, 10, 0);

                    // Default Endpoint; Load from TestData if possible
                    string endpoint = @"http://chelwebtfx01.idx.expedmz.com/RegistryService/RegistryService.asmx";
                    if (ExpediaRegistry.GetConfig != null)
                    {
                        endpoint = ExpediaRegistry.GetConfig("RegistryService_Endpoint");
                    }

                    EndpointAddress endPointAddress = null;
                    endPointAddress = new EndpointAddress(endpoint);

                    RegistryServiceSoapClient client = new RegistryServiceSoapClient(basicHttpBinding, endPointAddress);

                    return client;
                }
                return registryServiceClient;
            }
        }

        /// <summary>
        /// Convert Microsoft.Win32.RegistryHive to a serializable object
        /// </summary>
        /// <param name="hive">RegistryHive</param>
        /// <returns></returns>
        private static ExpediaRegistryService.RegistryService.RegistryHive ConvertRegistryHive(Microsoft.Win32.RegistryHive hive)
        {
            object obj = Enum.Parse(typeof(ExpediaRegistryService.RegistryService.RegistryHive), hive.ToString());
            return (ExpediaRegistryService.RegistryService.RegistryHive)obj;
        }

        /// <summary>
        /// Convert Microsoft.Win32.ConvertRegistryValueKind to a serializable object
        /// </summary>
        /// <param name="valueKind">valueKind</param>
        /// <returns></returns>
        private static ExpediaRegistryService.RegistryService.RegistryValueKind ConvertRegistryValueKind(Microsoft.Win32.RegistryValueKind valueKind)
        {
            object obj = Enum.Parse(typeof(ExpediaRegistryService.RegistryService.RegistryValueKind), valueKind.ToString());
            return (ExpediaRegistryService.RegistryService.RegistryValueKind)obj;
        }

        #endregion

        #region GetRegistryValue
        /// <summary>
        /// Gets the value from a registry key
        /// </summary>
        /// <param name="site">Remote machine</param>
        /// <param name="hive">Registry Hive</param>
        /// <param name="subKey">Sub key to look in</param>
        /// <param name="valueName">Name of the value in the key</param>
        /// <param name="TimeoutMilliSeconds">timeout millisecond the mehtod will try in</param>
        /// <returns>Value as an object</returns>
        /// <exception cref="Expedia.Automation.Web.Registry.RegistryTimeoutException">Throws RegistryTimeoutException</exception>
        /// <exception cref="System.ArgumentNullException">Throws ArgumentNullException</exception>
        public static object GetRegistryValue(string site, Microsoft.Win32.RegistryHive hive, string subKey, string valueName, bool isEmptyValid,  int timeoutMilliSeconds)
        {
            onLog("[Get Registry Value From Registry Service] -> Site = '{0}', Hive = '{1}', SubKey = '{2}', valueName = '{3}', emptyTrue = '{4}',timeoutMilliSeconds = '{5}'", site, hive, subKey, valueName, isEmptyValid, timeoutMilliSeconds);

            object value;

            if (RegistryType.Read64BitRegistry(site))
            {
                value = RegistryServiceClient.GetRegistryValue64Bit(site, ConvertRegistryHive(hive), subKey, valueName, isEmptyValid, timeoutMilliSeconds);
            }
            else
            {     
                value = RegistryServiceClient.GetRegistryValue(site, ConvertRegistryHive(hive), subKey, valueName, isEmptyValid, timeoutMilliSeconds);
            }

            onLog("[Get Registry Value From Registry Service Returned] -> Value = '{0}'", value);
            return value;
        }


        /// <summary>
        /// Gets the value from a 64 bit registry key
        /// </summary>
        /// <param name="site">Remote machine</param>
        /// <param name="hive">Registry Hive</param>
        /// <param name="subKey">Sub key to look in</param>
        /// <param name="valueName">Name of the value in the key</param>
        /// <param name="TimeoutMilliSeconds">timeout millisecond the mehtod will try in</param>
        /// <returns>Value as an object</returns>
        /// <exception cref="Expedia.Automation.Web.Registry.RegistryTimeoutException">Throws RegistryTimeoutException</exception>
        /// <exception cref="System.ArgumentNullException">Throws ArgumentNullException</exception>
        public static object GetRegistryValue64Bit(string site, Microsoft.Win32.RegistryHive hive, string subKey, string valueName, bool isEmptyValid, int timeoutMilliSeconds)
        {
            onLog("[Get 64 Bit Registry Value From Registry Service] -> Site = '{0}', Hive = '{1}', SubKey = '{2}', valueName = '{3}', emptyTrue = '{4}',timeoutMilliSeconds = '{5}'", site, hive, subKey, valueName, isEmptyValid, timeoutMilliSeconds);
            object value = RegistryServiceClient.GetRegistryValue64Bit(site, ConvertRegistryHive(hive), subKey, valueName, isEmptyValid, timeoutMilliSeconds);
            onLog("[Get 64 Bit Registry Value From Registry Service Returned] -> Value = '{0}'", value);
            return value;
        }

        /// <summary>
        /// Gets the value from a registry key
        /// </summary>
        /// <param name="site">Remote machine</param>
        /// <param name="hive">Registry Hive</param>
        /// <param name="subKey">Sub key to look in</param>
        /// <param name="valueName">Name of the value in the key</param>
        /// <returns>Value as an object</returns>
        /// <exception cref="Expedia.Automation.Web.Registry.RegistryTimeoutException">Throws RegistryTimeoutException</exception>
        /// <exception cref="System.ArgumentNullException">Throws ArgumentNullException</exception>
        public static object GetRegistryValue(string site, Microsoft.Win32.RegistryHive hive, string subKey, string valueName)
        {
            return GetRegistryValue(site, hive, subKey, valueName, false, MaxTimeoutMilliSeconds);
        }


        /// <summary>
        /// Gets the value from a 64 bit registry key
        /// </summary>
        /// <param name="site">Remote machine</param>
        /// <param name="hive">Registry Hive</param>
        /// <param name="subKey">Sub key to look in</param>
        /// <param name="valueName">Name of the value in the key</param>
        /// <returns>Value as an object</returns>
        /// <exception cref="Expedia.Automation.Web.Registry.RegistryTimeoutException">Throws RegistryTimeoutException</exception>
        /// <exception cref="System.ArgumentNullException">Throws ArgumentNullException</exception>
        public static object GetRegistryValue64Bit(string site, Microsoft.Win32.RegistryHive hive, string subKey, string valueName)
        {
            return GetRegistryValue64Bit(site, hive, subKey, valueName, false, MaxTimeoutMilliSeconds);
        }


        /// <summary>
        /// Gets the value from a registry key
        /// </summary>
        /// <param name="site">Remote machine</param>
        /// <param name="hive">Registry Hive</param>
        /// <param name="subKey">Sub key to look in</param>
        /// <param name="valueName">Name of the value in the key</param>
        /// <param name="emptyTrue">If empty string is a valid response</param>
        /// <param name="timeoutMilliSeconds">Override the default time out</param>
        /// <param name="retryMilliSeconds">Override the default re try</param>
        /// <returns>Value as an object</returns>
        /// <exception cref="Expedia.Automation.Web.Registry.RegistryTimeoutException">Throws RegistryTimeoutException</exception>
        /// <exception cref="System.ArgumentNullException">Throws ArgumentNullException</exception>
        public static object GetRegistryValue(string site, Microsoft.Win32.RegistryHive hive, string subKey, string valueName, bool emptyTrue, int timeoutMilliSeconds, int retryMilliSeconds)
        {
            return GetRegistryValue(site, hive, subKey, valueName, emptyTrue, timeoutMilliSeconds);
        }


        /// <summary>
        /// Gets the value from a 64 bit registry key
        /// </summary>
        /// <param name="site">Remote machine</param>
        /// <param name="hive">Registry Hive</param>
        /// <param name="subKey">Sub key to look in</param>
        /// <param name="valueName">Name of the value in the key</param>
        /// <param name="emptyTrue">If empty string is a valid response</param>
        /// <param name="timeoutMilliSeconds">Override the default time out</param>
        /// <param name="retryMilliSeconds">Override the default re try</param>
        /// <returns>Value as an object</returns>
        /// <exception cref="Expedia.Automation.Web.Registry.RegistryTimeoutException">Throws RegistryTimeoutException</exception>
        /// <exception cref="System.ArgumentNullException">Throws ArgumentNullException</exception>
        public static object GetRegistryValue64Bit(string site, Microsoft.Win32.RegistryHive hive, string subKey, string valueName, bool emptyTrue, int timeoutMilliSeconds, int retryMilliSeconds)
        {
            return GetRegistryValue64Bit(site, hive, subKey, valueName, emptyTrue, timeoutMilliSeconds);
        }

        /// <summary>
        /// Gets the value from a registry key
        /// </summary>
        /// <param name="site">Remote machine</param>
        /// <param name="hive">Registry Hive</param>
        /// <param name="subKey">Sub key to look in</param>
        /// <param name="valueName">Name of the value in the key</param>
        /// <param name="emptyTrue">If empty string is a valid response</param>
        /// <returns>Value as an object</returns>
        /// <exception cref="Expedia.Automation.Web.Registry.RegistryTimeoutException">Throws RegistryTimeoutException</exception>
        /// <exception cref="System.ArgumentNullException">Throws ArgumentNullException</exception>
        public static object GetRegistryValue(string site, Microsoft.Win32.RegistryHive hive, string subKey, string valueName, bool isEmptyValid)
        {
            return GetRegistryValue(site, hive, subKey, valueName, isEmptyValid, MaxTimeoutMilliSeconds);
        }

        /// <summary>
        /// Gets the value from a 64 bit registry key
        /// </summary>
        /// <param name="site">Remote machine</param>
        /// <param name="hive">Registry Hive</param>
        /// <param name="subKey">Sub key to look in</param>
        /// <param name="valueName">Name of the value in the key</param>
        /// <param name="emptyTrue">If empty string is a valid response</param>
        /// <returns>Value as an object</returns>
        /// <exception cref="Expedia.Automation.Web.Registry.RegistryTimeoutException">Throws RegistryTimeoutException</exception>
        /// <exception cref="System.ArgumentNullException">Throws ArgumentNullException</exception>
        public static object GetRegistryValue64Bit(string site, Microsoft.Win32.RegistryHive hive, string subKey, string valueName, bool isEmptyValid)
        {
            return GetRegistryValue64Bit(site, hive, subKey, valueName, isEmptyValid, MaxTimeoutMilliSeconds);
        }

        #endregion

        #region GetSubKeyNames
        /// <summary>
        /// Opens up a registry key on a remote machine
        /// </summary>
        /// <param name="site">Server to get the registry key from</param>
        /// <param name="hive">Registry hive</param>
        /// <param name="subKey">Sub key name</param>
        /// <param name="timeout">timeout millisecond the mehtod will try in</param>
        /// <returns>RegistryKey object</returns>
        /// <exception cref="Expedia.Automation.Web.Registry.RegistryTimeoutException">Throws RegistryTimeoutException</exception>
        /// <exception cref="System.ArgumentNullException">Throws ArgumentNullException</exception>
        public static string[] GetSubKeyNames(string site, Microsoft.Win32.RegistryHive hive, string subKey, int timeout)
        {
            onLog("[Get Sub Key Names From Registry Service] -> Site = '{0}', Hive = '{1}', SubKey = '{2}', timeout = '{3}'", site, hive, subKey, timeout);

            if (RegistryType.Read64BitRegistry(site))
            {
                return RegistryServiceClient.GetSubKeyNames64Bit(site, ConvertRegistryHive(hive), subKey, timeout).ToArray();
            }
            else
            {
                return RegistryServiceClient.GetSubKeyNames(site, ConvertRegistryHive(hive), subKey, timeout).ToArray();
            }
        }

        /// <summary>
        /// Opens up a 64 bit registry key on a remote machine
        /// </summary>
        /// <param name="site">Server to get the registry key from</param>
        /// <param name="hive">Registry hive</param>
        /// <param name="subKey">Sub key name</param>
        /// <param name="timeout">timeout millisecond the mehtod will try in</param>
        /// <returns>RegistryKey object</returns>
        /// <exception cref="Expedia.Automation.Web.Registry.RegistryTimeoutException">Throws RegistryTimeoutException</exception>
        /// <exception cref="System.ArgumentNullException">Throws ArgumentNullException</exception>
        public static string[] GetSubKeyNames64Bit(string site, Microsoft.Win32.RegistryHive hive, string subKey, int timeout)
        {
            onLog("[Get Sub Key Names From Registry Service] -> Site = '{0}', Hive = '{1}', SubKey = '{2}', timeout = '{3}'", site, hive, subKey, timeout);
            return RegistryServiceClient.GetSubKeyNames64Bit(site, ConvertRegistryHive(hive), subKey, timeout).ToArray();
        }

        /// <summary>
        /// Opens up a registry key on a remote machine
        /// </summary>
        /// <param name="site">Server to get the registry key from</param>
        /// <param name="hive">Registry hive</param>
        /// <param name="subKey">Sub key name</param>
        /// <returns>RegistryKey object</returns>
        /// <exception cref="Expedia.Automation.Web.Registry.RegistryTimeoutException">Throws RegistryTimeoutException</exception>
        /// <exception cref="System.ArgumentNullException">Throws ArgumentNullException</exception>
        public static string[] GetSubKeyNames(string site, Microsoft.Win32.RegistryHive hive, string subKey)
        {
            return GetSubKeyNames(site, hive, subKey, MaxTimeoutMilliSeconds);
        }

        /// <summary>
        /// Opens up a 64 bit registry key on a remote machine
        /// </summary>
        /// <param name="site">Server to get the registry key from</param>
        /// <param name="hive">Registry hive</param>
        /// <param name="subKey">Sub key name</param>
        /// <returns>RegistryKey object</returns>
        /// <exception cref="Expedia.Automation.Web.Registry.RegistryTimeoutException">Throws RegistryTimeoutException</exception>
        /// <exception cref="System.ArgumentNullException">Throws ArgumentNullException</exception>
        public static string[] GetSubKeyNames64Bit(string site, Microsoft.Win32.RegistryHive hive, string subKey)
        {
            return GetSubKeyNames64Bit(site, hive, subKey, MaxTimeoutMilliSeconds);
        }

        #endregion

        #region SetRegistryKeyWithApply

        /// <summary>
        /// Most expedia reg keys have an associated ApplyNow key, this function sets the reg key then sets the
        /// associated apply now key and waits for the value to become zero again.
        /// </summary>
        /// <param name="site">Server</param>
        /// <param name="hive">Registry hive</param>
        /// <param name="subKey">Sub key</param>
        /// <param name="valueName">Name of value</param>
        /// <param name="valueType">Value type</param>
        /// <param name="value">Value to set</param>
        /// <exception cref="System.ArgumentNullException">Throws ArgumentNullException</exception>
        public static void SetRegistryKeyWithApply(string site, Microsoft.Win32.RegistryHive hive, string subKey, string valueName, Microsoft.Win32.RegistryValueKind valueType, object value)
        {
           SetRegistryKeyWithApply(site,hive,subKey,valueName,valueType,value, MaxTimeoutMilliSeconds);
        }

        /// <summary>
        /// Most expedia reg keys have an associated ApplyNow key, this function sets the 64 bit reg key then sets the
        /// associated apply now key and waits for the value to become zero again.
        /// </summary>
        /// <param name="site">Server</param>
        /// <param name="hive">Registry hive</param>
        /// <param name="subKey">Sub key</param>
        /// <param name="valueName">Name of value</param>
        /// <param name="valueType">Value type</param>
        /// <param name="value">Value to set</param>
        /// <exception cref="System.ArgumentNullException">Throws ArgumentNullException</exception>
        public static void SetRegistryKeyWithApply64Bit(string site, Microsoft.Win32.RegistryHive hive, string subKey, string valueName, Microsoft.Win32.RegistryValueKind valueType, object value)
        {
            SetRegistryKeyWithApply64Bit(site, hive, subKey, valueName, valueType, value, MaxTimeoutMilliSeconds);
        }

        /// <summary>
        /// Most expedia reg keys have an associated ApplyNow key, this function sets the reg key then sets the
        /// associated apply now key and waits for the value to become zero again.
        /// </summary>
        /// <param name="site">Server</param>
        /// <param name="hive">Registry hive</param>
        /// <param name="subKey">Sub key</param>
        /// <param name="valueName">Name of value</param>
        /// <param name="valueType">Value type</param>
        /// <param name="value">Value to set</param>
        /// <param name="timeout">timeout millisecond the mehtod will try in</param>
        /// <exception cref="System.ArgumentNullException">Throws ArgumentNullException</exception>
        public static void SetRegistryKeyWithApply(string site, Microsoft.Win32.RegistryHive hive, string subKey, string valueName, Microsoft.Win32.RegistryValueKind valueType, object value, int timeout)
        {
            onLog("[Set Registry Key With Apply Using Registry Service] -> Site = '{0}', Hive = '{1}', SubKey = '{2}', valueName = '{3}', valueType = '{4}',value = '{5}', timeout = '{6}'", site, hive, subKey, valueName, valueType, value, timeout);

            if (RegistryType.Read64BitRegistry(site))
            {
                RegistryServiceClient.SetRegistryKeyWithApply64Bit(site, ConvertRegistryHive(hive), subKey, valueName, ConvertRegistryValueKind(valueType), value, timeout);
            }
            else
            {
                RegistryServiceClient.SetRegistryKeyWithApply(site, ConvertRegistryHive(hive), subKey, valueName, ConvertRegistryValueKind(valueType), value, timeout);
            }
        }

        /// <summary>
        /// Most expedia reg keys have an associated ApplyNow key, this function sets the 64 bit reg key then sets the
        /// associated apply now key and waits for the value to become zero again.
        /// </summary>
        /// <param name="site">Server</param>
        /// <param name="hive">Registry hive</param>
        /// <param name="subKey">Sub key</param>
        /// <param name="valueName">Name of value</param>
        /// <param name="valueType">Value type</param>
        /// <param name="value">Value to set</param>
        /// <param name="timeout">timeout millisecond the mehtod will try in</param>
        /// <exception cref="System.ArgumentNullException">Throws ArgumentNullException</exception>
        public static void SetRegistryKeyWithApply64Bit(string site, Microsoft.Win32.RegistryHive hive, string subKey, string valueName, Microsoft.Win32.RegistryValueKind valueType, object value, int timeout)
        {
            onLog("[Set 64 Bit Registry Key With Apply Using Registry Service] -> Site = '{0}', Hive = '{1}', SubKey = '{2}', valueName = '{3}', valueType = '{4}',value = '{5}', timeout = '{6}'", site, hive, subKey, valueName, valueType, value, timeout);
            RegistryServiceClient.SetRegistryKeyWithApply64Bit(site, ConvertRegistryHive(hive), subKey, valueName, ConvertRegistryValueKind(valueType), value, timeout);
        }

        #endregion

        #region SetRegistryValue

        /// <summary>
        /// Sets the value in a registry key on a remote machine
        /// </summary>
        /// <param name="site">Server to set the registry value on</param>
        /// <param name="hive">Registry hive</param>
        /// <param name="subKey">Sub key name</param>
        /// <param name="valueName">Value name</param>
        /// <param name="valueType">Value type</param>
        /// <param name="value">Value to set</param>
        /// <exception cref="Expedia.Automation.Web.Registry.RegistryTimeoutException">Throws RegistryTimeoutException</exception>
        /// <exception cref="System.ArgumentNullException">Throws ArgumentNullException</exception>
        public static void SetRegistryValue(string site, Microsoft.Win32.RegistryHive hive, string subKey, string valueName, Microsoft.Win32.RegistryValueKind valueType, object value)
        {
            SetRegistryValue(site, hive, subKey, valueName, valueType, value, MaxTimeoutMilliSeconds);
        }

        /// <summary>
        /// Sets the value in a 64 bit registry key on a remote machine
        /// </summary>
        /// <param name="site">Server to set the registry value on</param>
        /// <param name="hive">Registry hive</param>
        /// <param name="subKey">Sub key name</param>
        /// <param name="valueName">Value name</param>
        /// <param name="valueType">Value type</param>
        /// <param name="value">Value to set</param>
        /// <exception cref="Expedia.Automation.Web.Registry.RegistryTimeoutException">Throws RegistryTimeoutException</exception>
        /// <exception cref="System.ArgumentNullException">Throws ArgumentNullException</exception>
        public static void SetRegistryValue64Bit(string site, Microsoft.Win32.RegistryHive hive, string subKey, string valueName, Microsoft.Win32.RegistryValueKind valueType, object value)
        {
            SetRegistryValue64Bit(site, hive, subKey, valueName, valueType, value, MaxTimeoutMilliSeconds);
        }

        /// <summary>
        /// Sets the value in a registry key on a remote machine
        /// </summary>
        /// <param name="site">Server to set the registry value on</param>
        /// <param name="hive">Registry hive</param>
        /// <param name="subKey">Sub key name</param>
        /// <param name="valueName">Value name</param>
        /// <param name="valueType">Value type</param>
        /// <param name="value">Value to set</param>
        /// <param name="timeout">timeout millisecond the mehtod will try in</param>
        /// <exception cref="Expedia.Automation.Web.Registry.RegistryTimeoutException">Throws RegistryTimeoutException</exception>
        /// <exception cref="System.ArgumentNullException">Throws ArgumentNullException</exception>
        public static void SetRegistryValue(string site, Microsoft.Win32.RegistryHive hive, string subKey, string valueName, Microsoft.Win32.RegistryValueKind valueType, object value, int timeout)
        {
            onLog("[Set Registry Key Using Registry Service] -> Site = '{0}', Hive = '{1}', SubKey = '{2}', valueName = '{3}', valueType = '{4}',value = '{5}'", site, hive, subKey, valueName, valueType, value);

            if (RegistryType.Read64BitRegistry(site))
            {
                RegistryServiceClient.SetRegistryValue64Bit(site, ConvertRegistryHive(hive), subKey, valueName, ConvertRegistryValueKind(valueType), value, timeout);
            }
            else
            {
                RegistryServiceClient.SetRegistryValue(site, ConvertRegistryHive(hive), subKey, valueName, ConvertRegistryValueKind(valueType), value, timeout);
            }
        }

        /// <summary>
        /// Sets the value in a 64 bit registry key on a remote machine
        /// </summary>
        /// <param name="site">Server to set the registry value on</param>
        /// <param name="hive">Registry hive</param>
        /// <param name="subKey">Sub key name</param>
        /// <param name="valueName">Value name</param>
        /// <param name="valueType">Value type</param>
        /// <param name="value">Value to set</param>
        /// <param name="timeout">timeout millisecond the mehtod will try in</param>
        /// <exception cref="Expedia.Automation.Web.Registry.RegistryTimeoutException">Throws RegistryTimeoutException</exception>
        /// <exception cref="System.ArgumentNullException">Throws ArgumentNullException</exception>
        public static void SetRegistryValue64Bit(string site, Microsoft.Win32.RegistryHive hive, string subKey, string valueName, Microsoft.Win32.RegistryValueKind valueType, object value, int timeout)
        {
            onLog("[Set 64 Bit Registry Key Using Registry Service] -> Site = '{0}', Hive = '{1}', SubKey = '{2}', valueName = '{3}', valueType = '{4}',value = '{5}'", site, hive, subKey, valueName, valueType, value);
            RegistryServiceClient.SetRegistryValue64Bit(site, ConvertRegistryHive(hive), subKey, valueName, ConvertRegistryValueKind(valueType), value, timeout);
        }

        #endregion

        #region GetValueNames
        /// <summary>
        /// Get value names list from the specified subKey
        /// </summary>
        /// <param name="site">site</param>
        /// <param name="hive">hive</param>
        /// <param name="subKey">subKey</param>
        /// <returns>value names list</returns>
        public static string[] GetValueNames(string site, Microsoft.Win32.RegistryHive hive, string subKey)
        {
            return GetValueNames(site, hive, subKey, MaxTimeoutMilliSeconds); 
        }

        /// <summary>
        /// Get value names list from the specified 64 bit subKey
        /// </summary>
        /// <param name="site">site</param>
        /// <param name="hive">hive</param>
        /// <param name="subKey">subKey</param>
        /// <returns>value names list</returns>
        public static string[] GetValueNames64Bit(string site, Microsoft.Win32.RegistryHive hive, string subKey)
        {
            return GetValueNames64Bit(site, hive, subKey, MaxTimeoutMilliSeconds);
        }

        /// <summary>
        /// Get value names list from the specified subKey
        /// </summary>
        /// <param name="site">site</param>
        /// <param name="hive">hive</param>
        /// <param name="subKey">subKey</param>
        /// <param name="timeout">timeout millisecond the mehtod will try in</param>
        /// <returns>value names list</returns>
        public static string[] GetValueNames(string site, Microsoft.Win32.RegistryHive hive, string subKey, int timeout)
        {
            string[] value;

            if (RegistryType.Read64BitRegistry(site))
            {
                value = RegistryServiceClient.GetValueNames64Bit(site, ConvertRegistryHive(hive), subKey, timeout).ToArray();
            }
            else
            {
                value = RegistryServiceClient.GetValueNames(site, ConvertRegistryHive(hive), subKey, timeout).ToArray();
            }

            return value;
        }

        /// <summary>
        /// Get value names list from the specified 64 bit subKey
        /// </summary>
        /// <param name="site">site</param>
        /// <param name="hive">hive</param>
        /// <param name="subKey">subKey</param>
        /// <param name="timeout">timeout millisecond the mehtod will try in</param>
        /// <returns>value names list</returns>
        public static string[] GetValueNames64Bit(string site, Microsoft.Win32.RegistryHive hive, string subKey, int timeout)
        {
            return RegistryServiceClient.GetValueNames64Bit(site, ConvertRegistryHive(hive), subKey, timeout).ToArray();
        }

        #endregion

        #region Logging
        public static void onLog(string comment, params object[] args)
        {
            if (Log != null)
            {
                Log(comment, args);
            }
        }
        #endregion
    }
}
