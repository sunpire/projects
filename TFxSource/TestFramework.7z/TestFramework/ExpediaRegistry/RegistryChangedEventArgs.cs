namespace Expedia.Automation.Web.Registry
{
	public class RegistryChangedEventArgs
	{
        private object m_initial;
        private object m_new;

        public RegistryChangedEventArgs(object initial, object newValue)
        {
            m_initial = initial;
            m_new = newValue;
        }

        /// <summary>
        /// Gets the initial value;
        /// </summary>
        public object InitialValue
        {
            get { return m_initial; }
        }

        /// <summary>
        /// Gets the new value
        /// </summary>
        public object NewValue
        {
            get { return m_new; }
        }
	}
}
