//***************************************
//Designed by:Linc li
//Datetime:Aug 25 2008
//Description:Travel Server IP transfer
//***************************************
using System;
using System.Collections.Generic;
using System.Text;

using System.Text.RegularExpressions;
using System.Net;
using System.Management;
using System.Collections;
using System.DirectoryServices;
using System.DirectoryServices.ActiveDirectory;

namespace Expedia.Automation.Web.Registry
{
    internal class WebServerTransfer
    {
        #region private parameter
        private const string QUERY_STRING = "select name from win32_computersystem";
        private const string SCOPE_PATH_FORMAT = @"\\{0}\root\cimv2";

        /// <summary>
        /// WebServerTransfer object collection cashe in
        /// </summary>
        private static Dictionary<string, WebServerTransfer> WebServerCollection = new Dictionary<string, WebServerTransfer>();

        #endregion

        /// <summary>
        /// Transfer IP to Hostname
        /// </summary>
        /// <param name="iporname"></param>
        public WebServerTransfer(string iporname)
        {
            if (string.IsNullOrEmpty(iporname))
                throw new ArgumentNullException("IP or Name is empty!");

            Domain domain = Domain.GetCurrentDomain();
            string domainName = domain.ToString();

            if (domainName.ToLower().Contains("sea"))//if it is on SEA Domain
            {
                SetValue(iporname, iporname, iporname);
                return;
            }

            if (IsExistInCache(iporname))
            {
                SetValue(WebServerCollection[iporname].IP, WebServerCollection[iporname].MachineName, WebServerCollection[iporname].FQDN);
            }
            else
            {
                if (IsIPType(iporname))
                {
                    //input a IP
                    IPHostEntry m_entry = null;

                    m_entry = GetEntryByDNS(iporname);

                    if (m_entry.HostName == iporname)//if it is virtual IP
                    {
                        m_entry = GetEntryByWMI(iporname);
                    }

                    if (m_entry == null)
                        throw new Exception("invalid IP!");

                    SetValue(iporname, m_entry.HostName.Split('.')[0], m_entry.HostName);                    
                }
                else
                {
                    //input a machinename
                    IPHostEntry m_entry = Dns.GetHostEntry(iporname);

                    if (m_entry == null)
                        throw new Exception("Invalid Name!");

                    if (m_entry.AddressList.Length > 0)
                    {
                        SetValue(m_entry.AddressList[0].ToString(), m_entry.HostName.Split('.')[0], m_entry.HostName);
                    }
                    else
                    {
                        throw new ArgumentOutOfRangeException("AddressList is out of range");
                    }
                }
                WebServerCollection.Add(iporname, this);
            }
        }

        /// <summary>
        /// Set IP,MachinaName,FQDN
        /// </summary>
        /// <param name="ip">IP</param>
        /// <param name="machinename">MachineName</param>
        /// <param name="fqdn">FQDN</param>
        private void SetValue(string ip, string machinename, string fqdn)
        {
            this.IP = ip;
            this.MachineName = machinename;
            this.FQDN = fqdn;
        }

        /// <summary>
        /// check whether ip or name is exists in cache 
        /// </summary>
        /// <param name="iporname"></param>
        /// <returns></returns>
        private bool IsExistInCache(string iporname)
        {
            if (WebServerCollection.Count == 0)
                return false;

            return WebServerCollection.ContainsKey(iporname);
        }

        /// <summary>
        /// return the Entry by DNS
        /// </summary>
        /// <param name="ip">ip address</param>
        /// <returns></returns>
        private IPHostEntry GetEntryByDNS(string ip)
        {
            IPHostEntry m_entry = Dns.GetHostEntry(ip);
            return m_entry;
        }

        /// <summary>
        /// return the Entry by WMI
        /// </summary>
        /// <param name="ip">ip address</param>
        /// <returns></returns>
        private IPHostEntry GetEntryByWMI(string ip)
        {
            string physicalMachineName = null;

            ConnectionOptions options = new ConnectionOptions();
            options.Impersonation = ImpersonationLevel.Impersonate;

            options.EnablePrivileges = true;
            options.Username = String.Format(@"{0}\{1}", Environment.UserDomainName, Environment.UserName);

            ManagementScope scope = new ManagementScope(String.Empty, options);
            ObjectQuery query = new ObjectQuery(QUERY_STRING);

            scope.Path.Path = String.Format(SCOPE_PATH_FORMAT, ip);

            using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(scope, query))
            {
                IEnumerator enumerator = searcher.Get().GetEnumerator();

                if (!enumerator.MoveNext())
                    throw new Exception("No results found");
                ManagementObject result = enumerator.Current as ManagementObject;
                physicalMachineName = result["Name"].ToString();

            }

            return Dns.GetHostEntry(physicalMachineName);
        }

        /// <summary>
        /// check whether the parameter input is the type of IP
        /// </summary>
        /// <param name="iporname">the input(IP or Machine Name)</param>
        /// <returns>true when it is IP, while false when not</returns>
        private bool IsIPType(string iporname)
        {
            try
            {
                IPAddress temp_IPAddress = IPAddress.Parse(iporname);
                return true;
            }
            catch
            {
                return false;
            }

        }

        #region public properties
        /// <summary>
        /// Machine name
        /// </summary>
        public string MachineName { get; set; }
        /// <summary>
        /// Machine IP
        /// </summary>
        public string IP { get; set; }
        
        /// <summary>
        /// Machine name and domain
        /// </summary>
        public string FQDN{ get; set; }
        
        #endregion
    }
}
