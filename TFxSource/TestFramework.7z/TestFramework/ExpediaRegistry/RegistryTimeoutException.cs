﻿using System;

namespace Expedia.Automation.Web.Registry
{
    public class RegistryTimeoutException : Exception
    {
        private static string ERROR_REGISTRY_TIMEOUT = "Unable to get registry value timeout exceeded";

        public RegistryTimeoutException() : base(ERROR_REGISTRY_TIMEOUT) { }
        public RegistryTimeoutException(Exception innerException) : base(ERROR_REGISTRY_TIMEOUT, innerException) { }
    }
}
