using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
//using TFxCore;


namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for DBRepository.
    /// </summary>
    /// 
    [Serializable]
    internal class TFxArea : TestArea
    {
        private int m_areaId;

        public int AreaId
        {
            get
            {
                return m_areaId;
            }
            set
            {
                m_areaId = value;
            }
        }

        public TFxArea(string pathName, string testName, string owner)
            : base(pathName, testName, owner)
        {
        }

        public TFxArea(int areaId, TestInfo parent, string pathName, string testName, string owner)
            : base(parent, pathName, testName, owner)
        {
            m_areaId = areaId;
        }
    }

    [Serializable]
    public class TFxCase : TestCase
    {

        Guid m_testgid;

        public Guid TestGid
        {
            get
            {
                return m_testgid;
            }
            set
            {
                m_testgid = value;
            }
        }


        public TFxCase(Guid testgid, string pathName, string testName)
            : base(pathName, testName)
        {
            this.m_testgid = testgid;
        }
        public TFxCase(Guid testgid, TestArea parent, string pathName, string testName, string owner, long testCategory)
            : base(parent, pathName, testName, owner, testCategory)
        {
            this.m_testgid = testgid;
        }

        public TFxCase() { }

    }

    [Serializable]
    //Comments:	Changed UserId from Int to GUID
    internal class TFxDBUser : TFxUser
    {
        private Guid m_usergid;

        public override Guid usergid
        {
            get
            {
                return m_usergid;

            }
            set
            {
                m_usergid = value;
            }
        }

    }

    public class TFxDBRepository : Repository
    {
        public class InitRepositoryRequest : RepositoryRequest
        {
            public string ServerName;
            public string DBName;
            public InitRepositoryRequest(string serverName, string dbName)
                : base(RepositoryRequestType.Get)
            {
                this.ServerName = serverName;
                this.DBName = dbName;
            }
        }

        public string ServerName;
        public string DBName;
        public string LogServerName;
        public string LogDBName;
        public SqlConnection ConnectionString;

        public TFxDBRepository()
        {
        }


        public class DBInfoRequest : RepositoryRequest
        {
            public string ServerName;
            public string DBName;
            public string LogServerName;
            public string LogDBName;
            public string ConnectionString;

            public DBInfoRequest(RepositoryRequestType requestType)
                : base(requestType)
            {
            }
        }

        public void ProcessRequest(InitRepositoryRequest request)
        {
            this.ServerName = request.ServerName;
            this.DBName = request.DBName;
        }

        public void ProcessRequest(DBInfoRequest request)
        {

            switch (request.RequestType)
            {
                case RepositoryRequestType.Get:
                    //Load from your db info 
                    request.ServerName = this.ServerName;
                    request.DBName = this.DBName;
                    request.LogServerName = this.LogServerName;
                    request.LogDBName = this.LogDBName;

                    using (TFxDB tfxdb = new TFxDB(ServerName, DBName))
                    {
                        request.ConnectionString = TFxDB.ConnectionString();
                    }
                    break;

                case RepositoryRequestType.Update:
                    this.ServerName = request.ServerName;
                    this.DBName = request.DBName;
                    this.LogServerName = request.LogServerName;
                    this.LogDBName = request.LogDBName;
                    break;
            }
        }


        public void ProcessRequest(ReleaseListRequest request)
        {
            using (TFxDB tfxdb = new TFxDB(ServerName, DBName))
            {
                request.Objects = tfxdb.GetReleaseList();
            }
        }

        /// <summary>
        /// Removed check for request.ReleaseName, because the method that called doesn't 
        ///         currently work, and I can't find any code that sets the ReleaseName
        ///         of this request.  (dmb 23.04.2008)
        /// Comments: 	Changed the related test id from int to GUID
        /// </summary>
        /// <param name="request"></param>
        public void ProcessRequest(TestCaseListRequest request)
        {
            TestInfoCollection testCasesCollection = null;
            using (TFxDB tfxdb = new TFxDB(ServerName, DBName))
            {
                if (request.RelatedTestGid != Guid.Empty)
                {
                    testCasesCollection = tfxdb.GetTestCasesRelated(request.RelatedTestGid);
                }
                else if (request.ModuleName == null)
                {
                    testCasesCollection = tfxdb.GetTestCasesBuildCollection(request.BuildName);
                }
                else
                {
                    testCasesCollection = tfxdb.GetTestCasesModuleCollection(request.BuildName, request.ModuleName);
                }
            }

            ArrayList areas = new ArrayList();
            if (testCasesCollection != null && testCasesCollection.Count > 0)
            {
                foreach (TestCase testCase in testCasesCollection)
                {
                    TestArea rootArea = FindTestArea(areas, testCase.Path);
                    if (rootArea != null)
                    {
                        TestArea area = rootArea.CreateFindTestSuite(testCase.Path);
                        if (!area.Tests.ContainsKey(testCase.Name))
                            area.Tests.Add(testCase.Name, testCase);

                    }

                }
            }

            request.TestAreaRoots = (TestArea[])areas.ToArray(typeof(TestArea));

        }

        public void ProcessRequest(ManagerRequest request)
        {
            switch (request.RequestType)
            {
                case RepositoryRequestType.Get:
                    request.ManagersList = GetManagersList();
                    break;
            }
        }

        public void ProcessRequest(BuildListRequest request)
        {
            switch (request.RequestType)
            {
                case RepositoryRequestType.Get:
                    request.Objects = GetTestBuilds(request.Release);
                    break;
            }
        }

        public void ProcessRequest(AssignmentAssignedToRequest request)
        {
            switch (request.RequestType)
            {
                case RepositoryRequestType.Update:
                    UpdateAssignmentOwner(request.Assignment, request.User);
                    break;
            }
        }

        public void ProcessRequest(AssignmentStatusRequest request)
        {
            switch (request.RequestType)
            {
                case RepositoryRequestType.Get:
                    if (request.Assignment != null)
                    {
                        GetAssignmentStatus(request.Assignment);
                    }
                    break;
                case RepositoryRequestType.Update:
                    if (request.Assignment != null)
                    {
                        UpdateAssignmentStatus(request.Assignment);
                    }
                    break;
            }
        }

        public void ProcessRequest(TemplateLabRunRequest request)
        {
            switch (request.RequestType)
            {
                case RepositoryRequestType.Create:
                    if (request.TestRun != null)
                    {
                        CreateTemplate(request.TestRun, request.UserName, request.BuildType);
                        request.Message = String.Format("{0} has been saved sucessfully", request.TestRun.LabRunName);
                    }
                    break;
                case RepositoryRequestType.Update:
                    if (request.TestRun != null)
                    {
                        UpdateTemplate(request.TestRun, request.UserName, request.isAssignmentCollectionChanged, request.BuildType);
                        request.Message = String.Format("{0} has been updated sucessfully", request.TestRun.LabRunName);
                    }
                    break;

            }
        }

        /// <summary>
        /// Comments:	Changed UserId from Int to GUID
        /// </summary>
        /// <param name="request"></param>
        public void ProcessRequest(LabRunRequest request)
        {
            switch (request.RequestType)
            {
                case RepositoryRequestType.Create:
                    if (request.TestRun != null)
                    {
                        CreateTestRun(request.TestRun, request.UserName);
                        request.Message = String.Format("Lab Run {0} has been saved successfully", request.TestRun.LabRunName);
                    }
                    break;

                case RepositoryRequestType.Update:
                    if (request.TestRun != null)
                    {
                        UpdateTestRun(request.TestRun, request.UserName, request.isAssignmentCollectionChanged);
                        request.Message = String.Format("Lab Run {0} has been updated  successfully", request.TestRun.LabRunName);
                    }
                    break;


                case RepositoryRequestType.Get:
                    request.TestRun = GetTestRun(request.TestRunGid, request.TestRunName, request.BuildGid, request.ManagerGid, request.Status, request.GetResult);
                    break;
            }
        }

        public void ProcessRequest(TestRunTemplateListRequest request)
        {
            switch (request.RequestType)
            {
                case RepositoryRequestType.Get:
                    using (TFxDB tfx = new TFxDB(this.ServerName, this.DBName))
                    {
                        request.list = tfx.GetTestRunTemplateList(request.GetNamesOnly);
                    }
                    break;
            }
        }


        public void ProcessRequest(TestRunTemplateRequest request)
        {

            switch (request.RequestType)
            {
                case RepositoryRequestType.Get:
                    // Getting Template by Name or ID
                    if (request.TemplateGid == Guid.Empty)
                    {
                        if (request.TemplateID == -1)
                            request.Template = GetTestRunTemplate(request.TemplateName, request.Release);
                        else
                            request.Template = GetTestRunTemplate(request.TemplateID, request.Release);
                    }
                    // Getting Template by GID
                    else
                    {
                        using (TFxDB tfx = new TFxDB(this.ServerName, this.DBName))
                        {
                            request.Template = tfx.GetTestRunTemplate(request.TemplateGid, request.Release);
                        }
                    }
                    break;

            }

        }

        public void ProcessRequest(TestBuildRequest request)
        {
            switch (request.RequestType)
            {
                case RepositoryRequestType.Get:
                    request.Build = GetTestBuild(request.BuildName, request.Release, request.BuildType, request.BitAvailable);
                    break;
                case RepositoryRequestType.Update:
                    if (request.Build != null)
                    {
                        UpdateTestBuild(request.Build);
                    }
                    break;
                case RepositoryRequestType.Create:
                    if (request.Build != null)
                    {
                        CreateTestBuild(request.Build);
                    }
                    break;

            }
        }

        public void ProcessRequest(TestBuildModuleRequest request)
        {
            switch (request.RequestType)
            {
                case RepositoryRequestType.Get:
                    request.Module = GetTestBuildModule(request.BuildName, request.ReleaseName, request.BuildType, request.ModuleName);
                    break;
                case RepositoryRequestType.Create:
                    CreateTestBuildModule(request.ModuleName);
                    break;
            }
        }

        public void ProcessRequest(BuildPublishRequest request)
        {
            if (request.PublishBuild != null)
            {
                PublishTestCases(request.PublishBuild, request.ChangeList);
            }
        }

        //private TestRunTemplate GetTestRunTemplate(string templatename, string release)
        //{
        //    using (TFxDB tfxdb = new TFxDB(ServerName, DBName))
        //    {
        //        return tfxdb.GetTestRunTemplate(templatename, release);
        //    }
        //}

        //private TestRunTemplate GetTestRunTemplate(int templateID, string release)
        //{
        //    using (TFxDB tfxdb = new TFxDB(ServerName, DBName))
        //    {
        //        return tfxdb.GetTestRunTemplate(templateID, release);
        //    }
        //}

        private TestBuild GetTestBuild(string buildname, string release, BuildType buildtype, int bitAvailable)
        {
            using (TFxDB tfxdb = new TFxDB(ServerName, DBName))
            {
                if (buildtype == BuildType.Specific)
                {
                    return tfxdb.GetTestBuild(buildname, buildtype, bitAvailable);
                }
                else
                {
                    return tfxdb.GetTestBuild(release, buildtype, bitAvailable);
                }
            }
        }

        private void CreateTestBuild(TestBuild testBuild)
        {
            using (TFxDB tfxdb = new TFxDB(ServerName, DBName))
            {
                tfxdb.CreateTestBuild(testBuild);
            }
        }

        private void UpdateTestBuild(TestBuild testBuild)
        {
            using (TFxDB tfxdb = new TFxDB(ServerName, DBName))
            {
                tfxdb.UpdateTestBuild(testBuild);
            }

        }

        private TestBuildModule GetTestBuildModule(string buildname, string release, BuildType buildtype, string moduleName)
        {
            using (TFxDB tfxdb = new TFxDB(ServerName, DBName))
            {
                return tfxdb.GetTestBuildModule(buildname, release, buildtype, moduleName);
            }
        }

        private void CreateTestBuildModule(string moduleName)
        {
            using (TFxDB tfxdb = new TFxDB(ServerName, DBName))
            {
                tfxdb.CreateTestBuildModule(moduleName);
            }
        }

        private void PublishTestCases(TestBuild testBuild, RepositoryChangelist list)
        {

            using (TFxDB tfxdb = new TFxDB(ServerName, DBName))
            {
                tfxdb.PublishTestCases(testBuild, list);
            }
        }

        /// <summary>
        /// Comments:Changed buildid to buildgid type GUID
        /// changed labrunid to GUID labrungid 
        /// </summary>
        /// <param name="request"></param>
        private TestRun GetTestRun(Guid labrungid, string labrunname, Guid buildgid, Guid managerGid, LabRunStatusType status, bool getResult)
        {
            using (TFxDB tfxdb = new TFxDB(ServerName, DBName))
            {
                return tfxdb.GetTestRun(labrungid, labrunname, buildgid, managerGid, status, getResult);
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="run"></param>
        private void GetTeam(TFxTeam team, bool activeTeam)
        {
            using (TFxDB tfxdb = new TFxDB(ServerName, DBName))
            {
                tfxdb.GetTeam(team, activeTeam, this);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="assignment"></param>
        private void GetAssignmentStatus(Assignment assignment)
        {
            using (TFxDB tfxdb = new TFxDB(ServerName, DBName))
            {
                tfxdb.GetAssignmentStatus(assignment);
            }
        }


        /// <summary>
        /// Comments: changed labrunid to GUID labrungid 
        /// </summary>
        /// <param name="assignment"></param>
        private void UpdateAssignmentStatus(Assignment assignment)
        {
            using (TFxDB tfxdb = new TFxDB(ServerName, DBName))
            {
                tfxdb.UpdateAssignment(assignment.LabRun.LabRunGid, assignment, 0, null);
            }
        }


        /// <summary>
        /// Comments:	Changed UserId from Int to GUID
        /// Comments: changed labrunid to GUID labrungid
        /// </summary>
        /// <param name="assignment"></param>
        /// <param name="user"></param>
        private void UpdateAssignmentOwner(Assignment assignment, TFxUser user)
        {
            using (TFxDB tfxdb = new TFxDB(ServerName, DBName))
            {
                tfxdb.UpdateAssignmentOwner(assignment.AssignmentId, assignment.LabRun.LabRunGid, user.usergid);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private TFxUser[] GetManagersList()
        {
            using (TFxDB tfxdb = new TFxDB(ServerName, DBName))
            {


                TFxUser[] managers = tfxdb.GetManagers();
                return managers;
            }

        }


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private String[] GetTestBuilds(TestRelease release)
        {
            using (TFxDB tfxdb = new TFxDB(ServerName, DBName))
            {

                string releaseName = null;

                if (release != null)
                {
                    releaseName = release.ReleaseName;
                }

                String[] builds = tfxdb.GetTestBuilds(releaseName);
                return builds;
            }
        }


        /// <summary>
        /// Comments:	Changed UserId from Int to GUID
        /// Comments: changed labrunid to GUID labrungid
        /// </summary>
        /// <param name="testRun"></param>
        private void CreateTestRun(TestRun testRun, string userName)
        {
            //TODO: Why we need the LabRun in the Assignment			

            using (TFxDB tfxdb = new TFxDB(ServerName, DBName))
            {

                //int labrunid = -1;
                AssignmentCollection assignList = new AssignmentCollection();

                if ((testRun != null) && (testRun.Assignments != null))
                {
                    try
                    {
                        //Create the labrun									
                        testRun.LabRunGid = tfxdb.CreateNewLabRun(testRun.LabRunName, testRun.Manager.Name, testRun.TestBuild.Name, testRun.Template, testRun.TestRunGid, testRun.Status, userName);

                        //Should we do like this or pass in the labrunid along with the testRun
                        tfxdb.AddAssignmentInfo(testRun);
                        tfxdb.UpdateLabRunStatus(testRun);
                    }
                    catch (SqlException ex)
                    {
                        if (ex.Number == 1205)
                        {
                            throw (new Exception("Deadlock has occured.  Please try create again."));
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Comments:	Changed UserId from Int to GUID
        /// Comments: changed labrunid to GUID labrungid
        /// Comments: changed testrunid to testrungid
        /// </summary>
        /// <param name="testRun"></param>
        /// <param name="userName"></param>
        private void CreateTemplate(TestRun testRun, string userName, BuildType buildType)
        {
            Guid testrungid;
            using (TFxDB tfxdb = new TFxDB(ServerName, DBName))
            {
                if ((testRun != null) && (testRun.Assignments != null))
                {
                    //Create the labrun							
                    testRun.LabRunGid = tfxdb.CreateNewLabRun(testRun.LabRunName, testRun.Manager.Name, testRun.TestBuild.Name, testRun.Template, testRun.TestRunGid, testRun.Status, userName);
                    tfxdb.AddAssignmentInfo(testRun);
                    testrungid = tfxdb.CreateNewLabRunTemplate(testRun.LabRunName, null, buildType.ToString(), testRun.TestBuild.Name, testRun.LabRunGid, userName);
                    tfxdb.UpdateLabRun(testRun.LabRunGid, testRun.LabRunName, testRun.Manager.Name, testRun.TestBuild.Name, testRun.Status, testRun.LabRunName, userName);
                    tfxdb.UpdateLabRunStatusTemplate(testRun);
                }
            }
        }

        /// <summary>
        /// Comments:	Changed UserId from Int to GUID
        /// Comments: changed labrunid to GUID labrungid
        /// </summary>
        /// <param name="testRun"></param>
        /// <param name="userName"></param>
        /// <param name="isAssignmentCollectionChanged"></param>
        private void UpdateTemplate(TestRun testRun, string userName, bool isAssignmentCollectionChanged, BuildType buildType)
        {
            using (TFxDB tfxdb = new TFxDB(ServerName, DBName))
            {
                if ((testRun != null) && (testRun.Assignments != null))
                {
                    tfxdb.UpdateLabRun(testRun.LabRunGid, testRun.LabRunName, testRun.Manager.Name, testRun.TestBuild.Name, testRun.Status, testRun.Template, userName);
                    if (isAssignmentCollectionChanged)
                    {
                        tfxdb.UpdateAssignmentCollection(testRun);
                    }
                    tfxdb.UpdateLabRunStatusTemplate(testRun);
                    tfxdb.UpdateTemplate(testRun.LabRunName, null, buildType.ToString(), testRun.TestBuild.Name, testRun.LabRunGid, userName);
                }
            }
        }

        /// <summary>
        /// Comments:	Changed UserId from Int to GUID
        /// Comments: changed labrunid to GUID labrungid
        /// </summary>
        /// <param name="testRun"></param>
        /// <param name="userName"></param>
        /// <param name="isAssignmentCollectionChanged"></param>
        private void UpdateTestRun(TestRun testRun, string userName, bool isAssignmentCollectionChanged)
        {
            using (TFxDB tfxdb = new TFxDB(ServerName, DBName))
            {
                AssignmentCollection assignList = new AssignmentCollection();

                if ((testRun != null) && (testRun.Assignments != null))
                {
                    try
                    {
                        if (testRun.Template == null)
                        {
                            tfxdb.UpdateLabRun(testRun.LabRunGid, testRun.LabRunName, testRun.Manager.Name, testRun.TestBuild.Name, testRun.Status, testRun.TestRunGid, userName);
                        }
                        else
                        {
                            tfxdb.UpdateLabRun(testRun.LabRunGid, testRun.LabRunName, testRun.Manager.Name, testRun.TestBuild.Name, testRun.Status, testRun.Template, userName);
                        }

                        if (isAssignmentCollectionChanged)
                        {
                            tfxdb.UpdateAssignmentCollection(testRun);
                        }
                    }
                    catch (SqlException ex)
                    {
                        if (ex.Number == 1205)
                        {
                            throw (new Exception("Deadlock has occured.  Please try update again."));
                        }
                    }
                }
            }

        }

        TestArea FindTestArea(ArrayList areas, string path)
        {
            string[] pathparts = path.Split('.');

            if (areas != null && pathparts != null && pathparts.Length > 0)
            {
                foreach (TestArea area in areas)
                {
                    if (area.Name == pathparts[0])
                    {
                        return area;
                    }
                }
                TestArea newArea = new TestArea(pathparts[0]);
                areas.Add(newArea);
                return newArea;
            }

            return null;
        }
    }
}
	

