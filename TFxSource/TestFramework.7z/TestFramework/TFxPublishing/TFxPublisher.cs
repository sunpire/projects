using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Expedia.Test.Framework
{
    public class TFxPublisher
    {
        static string DBServer_default = "blsqltfx01.idx.expedmz.com";
        static string DBName_default = "TFx2008";
        static string BuildFolder_default = "\\\\blsqltfx03.idx.expedmz.com\\builds";
        static string Email_default = "tfxbuild@expedia.com";
        
        string localTempFolder = Path.GetTempPath();

        string release;
        string buildName;
        string buildFolder;

        public string DBServer = DBServer_default;
        public string DBName = DBName_default;
        public string Email = Email_default;
        public string BuildFolder = BuildFolder_default;

        public TFxPublisher(string pathToPublish)
        {
            buildFolder = pathToPublish;
        }

        public static string ValidateBuildFolder(string path)
        {
            if (!Directory.Exists(path))
                return string.Format("Build folder {0} does not exist", path);

            if (Path.GetPathRoot(path.ToLower()) != BuildFolder_default)
                return string.Format("Build must be placed in the folder: {0}\\[Release]\\[Build]", BuildFolder_default);

            DirectoryInfo dir = new DirectoryInfo(path);
            if (dir.Parent == null || dir.Parent.Parent == null || 
                !dir.Parent.Parent.FullName.ToLower().Equals(BuildFolder_default))
                return string.Format("Build must be placed in the folder: {0}\\[Release]\\[Build]", BuildFolder_default);

            return string.Empty;
        }
        
        /// <summary>
        /// Publish the tests in the build folder
        /// </summary>
        /// <returns>publish errors</returns>
        public PublishResult Publish()
        {
            string existsMessage = "";
            string error = ValidateBuildFolder(buildFolder);
            if (!string.IsNullOrEmpty(error))
                return new PublishResult(error);

            DirectoryInfo dir = new DirectoryInfo(buildFolder);
            buildName = dir.Name;
            release = dir.Parent.Name;

            CopyBuildToLocalDrive();

            TestBuildRequest buildRequest = new TestBuildRequest(RepositoryRequestType.Get);
            LabRunManagerRepository dbRep = new LabRunManagerRepository();
            dbRep.InitDBRepository(DBServer, DBName);

            buildRequest.BuildName = buildName;
            buildRequest.BuildType = BuildType.Specific;
            dbRep.ExecuteRequest(buildRequest);

            TestBuild build;

            //if build does not exist, create new build
            if (buildRequest.Build == null)
            {
                buildRequest = new TestBuildRequest(RepositoryRequestType.Create);
                build = buildRequest.Build = new TestBuild();
                SetupBuildInfo(build);
                dbRep.ExecuteRequest(buildRequest);

                //Get the build again to get the build gid
                buildRequest = new TestBuildRequest(RepositoryRequestType.Get);
                buildRequest.BuildName = buildName;
                buildRequest.BuildType = BuildType.Specific;
                dbRep.ExecuteRequest(buildRequest);
                build.BuildGid = buildRequest.Build.BuildGid;
            }
            else
            {
                existsMessage = String.Format("The Build {0} already exists in the DB", buildRequest.BuildName);
                return new PublishResult(existsMessage);
            }

            try
            {
                return PublishTests(dbRep, build);
            }
            catch (Exception e)
            {
                return new PublishResult(e.ToString());
            }
           
        }

        void CleanupTempBuildFolder()
        {
            if (System.IO.Directory.Exists(localTempFolder))
                System.IO.Directory.Delete(localTempFolder, true);
        }

        void CopyBuildToLocalDrive()
        {
            localTempFolder = Path.Combine(localTempFolder, this.buildName);

            Logger.Instance.WriteInfo("Local Temp Folder", localTempFolder);

            //Create clean local build folder
            if (Directory.Exists(localTempFolder))
            {
                Directory.Delete(localTempFolder, true);
            }
            Directory.CreateDirectory(localTempFolder);

            foreach(string file in Directory.GetFiles(buildFolder))
            {
                string localFileName = Path.Combine(localTempFolder, new FileInfo(file).Name);
                File.Copy(file, localFileName);
            }
        }

        void SetupBuildInfo(TestBuild build)
        {
            build.Name = buildName;
            build.RootFolder = buildFolder;
            build.AlternateRootFolder = buildFolder;
            build.Modules = GetBuildModules(localTempFolder);
            build.TestRelease = new TestRelease();
            build.TestRelease.ReleaseName = release;
            build.BitAvailable = 0;
        }

        TestBuildModule[] GetBuildModules(string primary)
        {
            ArrayList modules = new ArrayList();

            foreach (string file in System.IO.Directory.GetFiles(primary, "*.dll"))
            {
                LoadModule(modules, file);
            }

            foreach (string file in System.IO.Directory.GetFiles(primary, "*.jar"))
            {
                LoadModule(modules, file);
            }

            return (TestBuildModule[])modules.ToArray(typeof(TestBuildModule));
        }

        private void LoadModule(ArrayList modules, string file)
        {
            ExecuteTestModule module = new ExecuteTestModule(file);
            try
            {
                Driver.List(module.DllFullName);
                modules.Add(module);
            }
            catch
            {
                Console.WriteLine("Cannot load {0}", module.DllFullName);
            }
        }

        PublishResult PublishTests(LabRunManagerRepository labRep, TestBuild build)
        {

            ReleasePublisher publisher = new ReleasePublisher(labRep);
            PublishResult result = publisher.Evaluate(build);


            publisher.Publish();

            TestBuildRequest updateRequest = new TestBuildRequest(RepositoryRequestType.Update);
            build.BitAvailable = 1;
            updateRequest.Build = build;
            labRep.ExecuteRequest(updateRequest);

            return result;
        }

        public void SendEmail(PublishResult result)
        {
            using (TFxMail mail = new TFxMail())
            {
                StringBuilder mailMessage = new StringBuilder("<HTML><font size=2>");
                mailMessage.Append("<B><U>Publish Build</U></B><BR>");
                mailMessage.AppendFormat("Release Folder:    {0}<BR>", release);
                mailMessage.AppendFormat("Primary Folder:    {0}<BR>", buildFolder);
                mailMessage.AppendFormat("Secondary Folder:    {0}<BR>", "");
                mailMessage.AppendFormat("Server Name:    {0}<BR>", DBServer);

                if (!string.IsNullOrEmpty(result.FailureReason))
                    mailMessage.AppendFormat("<font color=Red><B>Status:    Fail: {0}</B></font><BR><BR>", result.FailureReason);

                mailMessage.Append("<TABLE><TR><TD><B><font size=2>ModuleName</font></B></TD><TD width=50></TD><TD><B><font size=2>Status</font></B></TD></TR>");

                foreach (PublishModuleResult moduleResult in result.PublishedModuleResult)
                {
                    if (moduleResult.Result)
                    {
                        mailMessage.AppendFormat("<TR><TD><font size=2>{0}</font></TD><TD width=50></TD><TD><font size=2 color=green>Published</font></TD></TR>", moduleResult.ModuleName);
                    }
                    else
                    {
                        mailMessage.AppendFormat("<TR><TD><font size=2>{0}</font></TD><TD width=50></TD><TD><font size=2 color=red>{1}</font></TD></TR>", moduleResult.ModuleName, moduleResult.FailureReason);
                    }
                }

                mailMessage.Append("</TABLE><BR>");
                mailMessage.Append("</font></HTML>");

                mail.Send("TFxReport@expedia.com", Email, string.Format("TFxPublish {0} publish summmary", buildName), mailMessage.ToString());
            }
        }

        public void WriteStatusLog(PublishResult result)
        {
            string writingResultFile = Path.Combine(buildFolder, "_WritingResult.txt");
            string completeResultFile = Path.Combine(buildFolder, "_PublishResult.txt");

            if (File.Exists(writingResultFile))
                File.Delete(writingResultFile);
            if (File.Exists(completeResultFile))
                File.Delete(completeResultFile);

            FileStream fs = File.Create(writingResultFile);
            StreamWriter sw = new StreamWriter(fs);
            sw.Write(string.Format("Build {0} publish result\r\n\r\nDBServer: {1}\r\nDBName: {2}\r\n\r\n{3}", buildName, DBServer, DBName, result.ToString()));
            sw.Close();
            fs.Close();

            FileInfo fi = new FileInfo(writingResultFile);
            fi.MoveTo(completeResultFile);
        }

    }
}
