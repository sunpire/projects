using System;
using System.Collections;
using System.Data;
using System.Reflection;
using System.Data.SqlClient;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for BuildCollection.
	/// </summary>
	public class ObjectQuery : SimpleSQLQuery
	{
		
		public ObjectQuery()
		{

		}

		public static object GetObject(SqlConnection connection, string source, Type objectType)
		{
			DataTable dt = SimpleSQLQuery.Query(connection, source);
			return DBDeserializer.GetObject(dt, objectType);
		}

		public static object GetCollection(SqlConnection connection, string source, Type collectionType,Type objectType)
		{
			DataTable dt = SimpleSQLQuery.Query(connection, source);
			return DBDeserializer.GetCollection(dt, collectionType, objectType);
		}


		public static object GetObject(SqlConnection connection, string source, ArrayList paramsList,Type objectType)
		{
			DataTable dt = SimpleSQLQuery.Query(connection, source, paramsList);
			return DBDeserializer.GetObject(dt,objectType);
		}

		public static object GetCollection(SqlConnection connection, string source, ArrayList paramsList,Type collectionType,Type objectType)
		{
			DataTable dt = SimpleSQLQuery.Query(connection, source, paramsList);
			return DBDeserializer.GetCollection(dt, collectionType, objectType);
		}

		public static object GetObject(SqlConnection connection, string source, string paramName, object paramValue, Type objectType)
		{
			DataTable dt = SimpleSQLQuery.Query(connection, source, paramName, paramValue);
			return DBDeserializer.GetObject(dt,objectType);
		}

		public static object GetCollection(SqlConnection connection, string source, string paramName, object paramValue, Type collectionType,Type objectType)
		{
			DataTable dt = SimpleSQLQuery.Query(connection, source, paramName, paramValue);
			return DBDeserializer.GetCollection(dt,collectionType,objectType);
		}

		public static object GetObject(SqlConnection connection, string source, string paramName, object paramValue, string secondParamName, object secondParamValue, Type objectType)
		{
			DataTable dt = SimpleSQLQuery.Query(connection,source,paramName, paramValue,secondParamName, secondParamValue);
			return DBDeserializer.GetObject(dt,objectType);

		}

		public static object GetCollection(SqlConnection connection, string source, string paramName, object paramValue, string secondParamName, object secondParamValue, Type collectionType,Type objectType)
		{
			DataTable dt = SimpleSQLQuery.Query(connection,source,paramName, paramValue,secondParamName, secondParamValue);
			return DBDeserializer.GetCollection(dt,collectionType,objectType);

		}

		public static object GetObject(SqlConnection connection, string source, string paramName, object paramValue, QueryOperator betweenOperator, string secondParamName, object secondParamValue, Type objectType)
		{
			DataTable dt = SimpleSQLQuery.Query(connection, source, paramName, paramValue, betweenOperator, secondParamName, secondParamValue);
			return DBDeserializer.GetObject(dt, objectType);
		}

		public static object GetCollection(SqlConnection connection, string source, string paramName, object paramValue, QueryOperator betweenOperator, string secondParamName, object secondParamValue, Type collectionType,Type objectType)
		{
			DataTable dt = SimpleSQLQuery.Query(connection, source, paramName, paramValue, betweenOperator, secondParamName, secondParamValue);
			return DBDeserializer.GetCollection(dt, collectionType, objectType);
		}

	}
}
