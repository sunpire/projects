using System;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Data;
using System.Collections;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for SimpleSQLQuery.
	/// </summary>
	/// 

	public enum QueryOperator
	{
		And,
		Or
	}

	public enum ParamOperator
	{
		Equals,
		NotEqual,
		LessThan,
		LessThanEquals,
		GreaterThan,
		GreaterThanEquals
	}

	public class SimpleSQLQuery
	{

		public class SQLParam
		{
			public string m_paramName=null;
			public string ParamName
			{
				get
				{
					if(m_paramName == null)
					{
						return '@'+ColName+"Param";
					}
					else
					{
						return m_paramName;
					}
				}
			}
			public string ColName;
			public object ParamValue;
			public QueryOperator Operator = QueryOperator.And;
			public ParamOperator RelationalOperator = ParamOperator.Equals;

			public SQLParam(string colName, object val) 
			{
				this.ColName = colName;
				this.ParamValue = val;
			}

			
			public SQLParam(string colName, object val, QueryOperator operatorValue) 
			{
				this.ColName = colName;
				this.ParamValue = val;
				this.Operator = operatorValue;
			}


			public SQLParam(string colName, object val, ParamOperator opeartorValue) 
			{
				this.ColName = colName;
				this.ParamValue = val;
				this.RelationalOperator = opeartorValue;
			}

			public SQLParam(string colName, object val, QueryOperator operatorValue, ParamOperator relationalValue) 
			{
				this.ColName = colName;
				this.ParamValue = val;
				this.Operator = operatorValue;
				this.RelationalOperator = relationalValue;
			}
	
			public string GetUniqueParamName(SqlCommand cmd)
			{
				string param = this.ParamName;
				int i=0;
				while(cmd.Parameters.Contains(param))
				{
					i++;
					param = this.ParamName + i.ToString();
				}
				return param;
			}

			public string GetRelationalOperator()
			{
				string relationalValue = "";

				switch(this.RelationalOperator)
				{
					case ParamOperator.Equals:
						relationalValue = "=";
						break;
					case ParamOperator.NotEqual:
						relationalValue = "!=";
						break;						
					case ParamOperator.LessThan:
						relationalValue = "<";
						break;						
					case ParamOperator.LessThanEquals:
						relationalValue = "<=";
						break;						
					case ParamOperator.GreaterThan:
						relationalValue = ">";
						break;						
					case ParamOperator.GreaterThanEquals:
						relationalValue = ">=";
						break;							
				}

				return relationalValue;

			}			
		}



		string m_sourceName = null;
		SqlCommand m_sqlCommand = null;
		ArrayList m_paramsList = new ArrayList();

		public SqlCommand SqlCommand
		{
			get
			{
				return this.m_sqlCommand;
			}
			set
			{
				this.m_sqlCommand = value;
			}
		}

		public SimpleSQLQuery()
		{
			
		}

		public SimpleSQLQuery(string sourceName)
		{
			m_sourceName = sourceName;
			
		}

		public void AddParam(string paramName, object paramValue, QueryOperator operatorValue) 
		{
			SQLParam param = new SQLParam(paramName,paramValue,operatorValue);
			if(this.m_paramsList == null)
			{
				m_paramsList = new ArrayList();
			}
			m_paramsList.Add(param);			
		}	

		public void AddParam(string paramName, object paramValue) 
		{
			this.AddParam(paramName, paramValue,QueryOperator.And);		
		}	

		public void AddParam(string paramName, object paramValue, ParamOperator paramOperator) 
		{
			SQLParam param = new SQLParam(paramName,paramValue, paramOperator);
			if(this.m_paramsList == null)
			{
				m_paramsList = new ArrayList();
			}
			m_paramsList.Add(param);			
		}	

		
		private SqlCommand CreateCmd(string sourceName, System.Collections.ArrayList param)
		{
			SqlCommand cmd = new SqlCommand();
			System.Text.StringBuilder sb = new System.Text.StringBuilder();
			sb.AppendFormat("select * from {0} ", sourceName);
			if(param != null && param.Count > 0)
			{
				sb.Append("Where ");
				foreach(SQLParam p in param)
				{
					string paramName = p.GetUniqueParamName(cmd);
					if(cmd.Parameters.Count > 0)
					{
						sb.AppendFormat(" {0} ", p.Operator.ToString());
					}
					sb.AppendFormat(" {0} {1} {2} ", p.ColName, p.GetRelationalOperator(), paramName);
					cmd.Parameters.AddWithValue(paramName, p.ParamValue);
				}	
			}
			cmd.CommandText = sb.ToString();
			return cmd;
		}

		DataTable ExecuteQuery(string sourceName, System.Collections.ArrayList param, SqlConnection connection)
		{
			using(SqlCommand cmd = CreateCmd(sourceName, param))
			{
				return this.ExecuteQuery(cmd,connection);				
			}
		}


		public DataTable Execute(SqlConnection connection)
		{
			return this.ExecuteQuery(this.m_sourceName, this.m_paramsList, connection);			
		}

		
		private DataTable ExecuteQuery(string sql, SqlConnection conn)
		{

            Exception exp = null;
            int tries = 0;
            do
            {
                try
                {
                    if (conn.State == System.Data.ConnectionState.Closed)
                    {
                        conn.Open();
                    }
                    using (SqlDataAdapter da = new SqlDataAdapter(sql, conn))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }

                }
                catch (Exception e)
                {
                    tries++;
                    string message = String.Format("Error occurred while executing query\n query = {1}\n number of attempts {2}\n exception details:\n {0}", e, sql, tries.ToString());
                    exp = e;
                    EventLog.WriteEntry("Application", message, EventLogEntryType.Warning);
                    System.Threading.Thread.Sleep(15000);
                }
            }
            while (TFxDB.Retry && tries < 100);

            EventLog.WriteEntry("Application", "Error occurred while executing query, gave up at last, number of attempts:" + tries.ToString(), EventLogEntryType.Error);
            throw exp;		
		    
		}

		
		public DataTable ExecuteQuery(SqlCommand cmd, SqlConnection conn)
		{

            Exception exp = null;
            int tries = 0;
            do
            {
                try
                {
                    if (conn.State == System.Data.ConnectionState.Closed)
                    {
                        conn.Open();
                    }
                    cmd.Connection = conn;
                    cmd.CommandTimeout = 3600;

                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
                catch (Exception e)
                {
                    tries++;
                    string message = String.Format("Error occurred while executing query\n query = {1}\n number of attempts {2}\n exception details:\n {0}", e, TFxDB.GetSqlString(cmd), tries.ToString());
                    exp = e;
                    EventLog.WriteEntry("Application", message, EventLogEntryType.Warning);
                    System.Threading.Thread.Sleep(15000);
                }
            }
            while (TFxDB.Retry && tries < 100);

            EventLog.WriteEntry("Application", "Error occurred while executing query, gave up at last, number of attempts:" + tries.ToString(), EventLogEntryType.Error);
            throw exp;			
			
		}


		public static DataTable Query(SqlConnection connection, string source)
		{
			if(source == null || source == "")
			{
				throw new ArgumentException("Cannot be null or empty string", "source");
			}	
	
			SimpleSQLQuery ssq = new SimpleSQLQuery(source);
			return ssq.Execute(connection);
			
		}

		public static DataTable Query(SqlConnection connection, string source, ArrayList paramsList)
		{
			if(source == null || source == "")
			{
				throw new ArgumentException("Cannot be null or empty string", "source");
			}
	
			SimpleSQLQuery ssq = new SimpleSQLQuery(source);

			if(paramsList != null)
			{
				ssq.m_paramsList.AddRange(paramsList);
			}
			
			return ssq.Execute(connection);
			
		}

		public static DataTable Query(SqlConnection connection, string source, string paramName, object paramValue)
		{
			if(source == null || source == "")
			{
				throw new ArgumentException("Cannot be null or empty string", "source");
			}
	
			if(paramName == null && paramName == "")
			{
				throw new ArgumentException("Cannot be null or empty string", "paramName");
			}

			if(paramValue == null && paramValue.ToString() == "")
			{
				throw new ArgumentException("Cannot be null or empty string", "paramValue");
			}

			SimpleSQLQuery ssq = new SimpleSQLQuery(source);
			ssq.AddParam(paramName, paramValue.ToString(), QueryOperator.And);
			return ssq.Execute(connection);			
			
		}


		public static DataTable Query(SqlConnection connection, string source, string paramName, object paramValue, ParamOperator paramOperator)
		{
			if(source == null || source == "")
			{
				throw new ArgumentException("Cannot be null or empty string", "source");
			}
	
			if(paramName == null && paramName == "")
			{
				throw new ArgumentException("Cannot be null or empty string", "paramName");
			}

			if(paramValue == null && paramValue.ToString() == "")
			{
				throw new ArgumentException("Cannot be null or empty string", "paramValue");
			}

			SimpleSQLQuery ssq = new SimpleSQLQuery(source);
			ssq.AddParam(paramName, paramValue.ToString(), paramOperator);
			return ssq.Execute(connection);			
			
		}

		public static DataTable Query(SqlConnection connection, string source, string paramName, object paramValue, string secondParamName, object secondParamValue)
		{
			
			if(source == null || source == "")
			{
				throw new ArgumentException("Cannot be null or empty string", "source");
			}
	
			if(paramName == null && paramName == "")
			{
				throw new ArgumentException("Cannot be null or empty string", "paramName");
			}

			if(paramValue == null && paramValue.ToString() == "")
			{
				throw new ArgumentException("Cannot be null or empty string", "paramValue");
			}

			if(secondParamName == null && secondParamName == "")
			{
				throw new ArgumentException("Cannot be null or empty string", "secondParamName");
			}

			if(secondParamValue == null && secondParamValue.ToString() == "")
			{
				throw new ArgumentException("Cannot be null or empty string", "secondParamValue");
			}

			SimpleSQLQuery ssq = new SimpleSQLQuery(source);
			ssq.AddParam(paramName, paramValue.ToString());
			ssq.AddParam(secondParamName, secondParamValue.ToString());
			return ssq.Execute(connection);
		}		


		public static DataTable Query(SqlConnection connection, string source, string paramName, object paramValue, QueryOperator betweenOperator, string secondParamName, object secondParamValue)
		{

			if(source == null || source == "")
			{
				throw new ArgumentException("Cannot be null or empty string", "source");
			}
	
			if(paramName == null && paramName == "")
			{
				throw new ArgumentException("Cannot be null or empty string", "paramName");
			}

			if(paramValue == null && paramValue.ToString() == "")
			{
				throw new ArgumentException("Cannot be null or empty string", "paramValue");
			}

			if(secondParamName == null && secondParamName == "")
			{
				throw new ArgumentException("Cannot be null or empty string", "secondParamName");
			}

			if(secondParamValue == null && secondParamName == "")
			{
				throw new ArgumentException("Cannot be null or empty string", "secondParamValue");
			}

			SimpleSQLQuery ssq = new SimpleSQLQuery(source);
			ssq.AddParam(paramName, paramValue.ToString());
			ssq.AddParam(secondParamName, secondParamName.ToString(), betweenOperator);
			return ssq.Execute(connection);
		}
		
		
	}
}
