using System;
using System.Collections;
using System.Data;
using System.Reflection;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for DBDeserializer.
	/// </summary>
	public class DBDeserializer
	{
		public DBDeserializer()
		{
			
		}


		public static object GetCollection(DataTable sourceTable, Type collectionType, Type objectType)
		{
			if(sourceTable == null || collectionType == null || objectType == null)
            {
				throw new ArgumentException("Cannot be null or empty string");
            }
			IList objects = (IList) Activator.CreateInstance(collectionType);

			foreach(DataRow row in sourceTable.Rows)
			{
				objects.Add(GetObject(row, objectType));
			}

			return objects;		
			
		}

		public static string FindMatchingColumn(string propertyName, DataRow row)
		{
			if(row.Table.Columns.Contains(propertyName))
			{
				return propertyName;
			}
			return null;
		}

		/// <summary>
		/// Considers row 0 only
		/// </summary>
		/// <param name="row"></param>
		/// <param name="objectType"></param>
		/// <returns></returns>
		public static object GetObject(DataTable table, Type objectType)
		{
			if(table.Rows.Count > 0)
			{
				return GetObject(table.Rows[0], objectType);
			}
			return null;
		}

		static bool  IsTerminalType(Type type)
		{
			if(type.IsClass)
			{
				if(type == typeof(System.String))
				{
					return true;
				}
				return false;
			}
			return true;
		}
		
		public static object GetObject(DataRow row, Type objectType)
		{
			Object obj = null;
			Type memberType = null;
			object val = null;		
			MemberInfo[] memberInfo = null;	
		
			if(row == null || objectType == null)
			{
				return null;
			}

			obj = Activator.CreateInstance(objectType);

			if(obj == null)
			{
				return null;
			}
				
			memberInfo = objectType.GetMembers(BindingFlags.Instance|BindingFlags.Public|BindingFlags.GetProperty|BindingFlags.GetField); //BindingFlags.GetProperty|BindingFlags.GetField|

			foreach(MemberInfo member in memberInfo)
			{
				val = null;
				memberType = GetMemberType(member);

				if(memberType != null)
				{
					if(IsTerminalType(memberType))
					{
						string colName = FindMatchingColumn(member.Name, row);
						if(colName != null)
						{
							val = row[colName];							
						}
					}
					else
					{
						val = GetObjectProperty(row, member.Name,memberType);
					}

					if(val != null && val != DBNull.Value)
					{
						UpdateMemberValue(member,obj, val);
					}

					
				}
				
			}

			return obj;
		}


			
		public static object GetObjectProperty(DataRow row, string propertyName, Type objectType)
		{
			object obj = null;
			Type memberType = null;
			object val = null;				
			MemberInfo[] memberInfo = null;	
			string memberName = null;
		
			if(row == null || propertyName == null ||objectType == null)
			{
				return null;
			}		
			
			obj = Activator.CreateInstance(objectType);

			if(obj == null)
			{
				return null;
			}

			memberInfo = objectType.GetMembers(BindingFlags.Instance|BindingFlags.Public|BindingFlags.GetProperty|BindingFlags.GetField); //BindingFlags.GetProperty|BindingFlags.GetField|

			foreach(MemberInfo member in memberInfo)
			{
				val = null;
				memberType = GetMemberType(member);

				if(memberType != null)
				{
					if(IsTerminalType(memberType))
					{
						memberName = propertyName + member.Name;
						string colName = FindMatchingColumn(memberName, row);
						if(colName != null)
						{
							val = row[colName];
							if(val != null && val != DBNull.Value)
							{
								UpdateMemberValue(member,obj, val);
							}
						}
					}
				}
			}

			return obj;
		}	


		
		static void UpdateMemberValue(MemberInfo member, object obj, object memberValue)
		{
			FieldInfo fi = null;
			PropertyInfo pi = null;
			object objectValue = null;

			if(member == null || obj == null || memberValue == null)
			{
				return;
			}
		
			switch(member.MemberType)
			{
				case MemberTypes.Field:
				{
					fi = member as FieldInfo;
					objectValue = GetObjectValue(fi,memberValue);
					fi.SetValue(obj, objectValue);
				}
					break;
				case MemberTypes.Property:
				{
					pi = member as PropertyInfo;
					objectValue = GetObjectValue(pi,memberValue);
					pi.SetValue(obj,objectValue, null);					
				}
					break;
			}

		}

		
		public static object GetObjectValue(PropertyInfo pi, object memberValue)
		{
			object objValue = null;

			if(pi.PropertyType.IsEnum)
			{
				objValue = System.Enum.Parse(pi.PropertyType, memberValue.ToString(), true);
				return objValue;
			}

			if(pi.PropertyType == typeof(System.Boolean))
			{
				objValue = Convert.ToBoolean(memberValue.ToString());
				return objValue;

			}

			return memberValue;
		}


		public static object GetObjectValue(FieldInfo fi, object memberValue)
		{
			object objValue = null;

			if(fi.FieldType.IsEnum)
			{
				objValue = System.Enum.Parse(fi.FieldType, memberValue.ToString(), true);
				return objValue;
			}

			if(fi.FieldType == typeof(System.Boolean))
			{
				objValue = Convert.ToBoolean(memberValue.ToString());
				return objValue;

			}

			return memberValue;
		}

		public static Type GetMemberType(MemberInfo member)
		{
			FieldInfo fi = null;
			PropertyInfo pi = null;
			Type memberType = null;

			fi = member as FieldInfo;
			pi = member as PropertyInfo;
			
			
			switch(member.MemberType)
			{
				case MemberTypes.Field:
				{
					memberType = fi.FieldType;
				}
					break;
				case MemberTypes.Property:
				{
					memberType = pi.PropertyType;
				}
					break;
			}

			return memberType;

		}		

	}
}
