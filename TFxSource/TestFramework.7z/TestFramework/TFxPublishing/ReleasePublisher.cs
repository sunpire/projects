using System;
using System.Collections;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ReleasePublisher.
	/// </summary>
	public class ReleasePublisher
	{
		Repository m_repository;
		RepositoryChangelist m_list;
		TestBuild m_build;


		public ReleasePublisher(Repository repository)
		{
			//
			// TODO: Add constructor logic here
			//
			this.m_repository = repository;
		}

		public PublishResult  Evaluate(TestBuild currentBuild)
		{

			PublishResult result = new PublishResult();
			m_list = new RepositoryChangelist();
			m_build = currentBuild;

			if (currentBuild !=null)
			{
				foreach (TestBuildModule module in currentBuild.Modules)
				{
                    PublishModuleResult moduleResult = Evaluate(currentBuild, module, m_list);
                    if (string.IsNullOrEmpty(moduleResult.FailureReason) ||
                        !moduleResult.FailureReason.Equals("No tests found in module"))
                    {
                        result.PublishedModuleResult.Add(moduleResult);
                    }
				}	
			}
			 return result;
		}

		public void Publish()
		{
            Logger.Instance.WriteInfo("Start -> Publish to DB");
			if (m_list !=null)
			{
				BuildPublishRequest publishRequest = new BuildPublishRequest(RepositoryRequestType.Create);
				publishRequest.ChangeList = m_list;
				publishRequest.PublishBuild = m_build;
				this.m_repository.ExecuteRequest(publishRequest);	
			}
            Logger.Instance.WriteInfo("End -> Publish to DB");
		}	


		private PublishModuleResult Evaluate(TestBuild build, TestBuildModule module, RepositoryChangelist list)
		{

			// TODO:  pull email from db
            PublishModuleResult moduleResult = new PublishModuleResult(module.Name);
            ArrayList newTestAreas = new ArrayList();

			// Find Module in the database
			try
			{
			
				TestBuildModuleRequest request = new TestBuildModuleRequest(RepositoryRequestType.Get);
				request.ReleaseName = build.TestRelease.ReleaseName;
				request.BuildType = BuildType.Latest;
				request.ModuleName = module.Name;
				m_repository.ExecuteRequest(request);
			
				TestArea dbTests = null;	
				TestArea currentTest = null;

             
				// Get all the test cases from driver
				// Current Module
                newTestAreas.Add(Driver.List(module.DllFullName));

				TestArea [] areas = (TestArea[])newTestAreas.ToArray(typeof(TestArea));

				if (areas !=null && areas.Length > 0)
				{
					currentTest = areas[0];
				}

                if (currentTest != null)
                {
                    if (request.Module != null)
                    {
                        // Get all the test cases in DB module
                        TestCaseListRequest testCaseRequest = new TestCaseListRequest(RepositoryRequestType.Get);
                        testCaseRequest.ModuleName = request.Module.Name;
                        testCaseRequest.BuildName = request.Module.BuildName;
                        this.m_repository.ExecuteRequest(testCaseRequest);


                        // Get all the test cases in this DB module
                        if (testCaseRequest.TestAreaRoots != null && testCaseRequest.TestAreaRoots.Length > 0)
                        {
                            dbTests = testCaseRequest.TestAreaRoots[0];
                        }
                    }
                    else
                    {
                        // this is a new module
                        TestBuildModuleRequest createModuleRequest = new TestBuildModuleRequest(RepositoryRequestType.Create);
                        createModuleRequest.ModuleName = module.Name;
                        m_repository.ExecuteRequest(createModuleRequest);
                    }


                    RepositoryChangelist currentList = CreateChangeList(dbTests, currentTest, moduleResult);

                    if (moduleResult.Result && currentList != null)
                    {
                        foreach (TestCaseChange change in currentList)
                        {
                            list.Add(change);
                        }
                    }
                }
                else
                    throw new Exception("No tests found in module");
			}
			catch (Exception e)
			{
				// publishing fails
				moduleResult.Result = false;
				moduleResult.FailureReason = e.Message;
			}

			return moduleResult;
		}

        /// <summary>
        /// Comments: 	Changed the related test id from int to GUID
        /// </summary>
        /// <param name="dbTest"></param>
        /// <param name="currentTest"></param>
        /// <param name="moduleResult"></param>
        /// <returns></returns>
		private RepositoryChangelist CreateChangeList(TestArea dbTest, TestArea currentTest, PublishModuleResult moduleResult)
		{

			RepositoryChangelist list = new RepositoryChangelist();

			TestDiff diff = currentTest.Diff(dbTest);
										
			foreach (TestCaseDifference difference in diff.Differences)
			{
				if (difference.DifferenceType == TestCaseDifferenceType.NoMatchFound
					&& difference.TestCase2 == null)
				{
					// new test case
					moduleResult.Added.Add(difference.TestCase1.FullName);
					list.Add(new TestCaseChange(RepositoryRequestType.Create, difference.TestCase1));
				}
				else if (difference.DifferenceType == TestCaseDifferenceType.NoMatchFound
					&& difference.TestCase1 == null)
				{
					// deleted test cases
					// don't have to do anything
					moduleResult.Deleted.Add(difference.TestCase2.FullName);
				}
				else if (difference.TestCase2 !=null && difference.TestCase1 !=null)
				{
					// change related test id
					difference.TestCase1.RelatedTestGid = difference.TestCase2.RelatedTestGid;
					moduleResult.Related.Add(difference.TestCase1.FullName);
					list.Add(new TestCaseChange(RepositoryRequestType.Create, difference.TestCase1));
				}
			
			}

			moduleResult.Result = true;

			if (((moduleResult.Added.Count > 0) && (moduleResult.Deleted.Count > 0)))
			{
				moduleResult.Result = false;
				moduleResult.FailureReason = "Publish Conflict";
			}
										
			return list;
		}

	}
}
