using System;
using System.Collections;
using System.Text;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for PublishResut.
	/// </summary>
	public class PublishResult
	{
		public PublishResult()
		{
			PublishedModuleResult = new ArrayList();
		}

        public PublishResult(string failureReason)
        {
            PublishedModuleResult = new ArrayList();
            FailureReason = failureReason;
        }

		public ArrayList PublishedModuleResult;
        public string FailureReason;

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            if (!string.IsNullOrEmpty(FailureReason))
            {
                sb.AppendLine(string.Format("Publish error: {0}", FailureReason));
            }

            sb.AppendLine(string.Format("{0} of published modules", PublishedModuleResult.Count));
            sb.AppendLine();

            foreach (PublishModuleResult moduleResult in PublishedModuleResult)
            {
                if (moduleResult.Result)
                {
                    sb.AppendLine(string.Format("{0} module is published sucessfully", moduleResult.ModuleName));
                    sb.AppendLine(string.Format("{0} of Test Cases are Added", moduleResult.Added.Count));
                    sb.AppendLine(string.Format("{0} of Test Cases are Deleted", moduleResult.Deleted.Count));
                    sb.AppendLine(string.Format("{0} of Test Cases are Related", moduleResult.Related.Count));
                }
                else
                {
                    sb.AppendLine(string.Format("{0} module is not published because {1}", moduleResult.ModuleName, moduleResult.FailureReason));
                }
            }

            return sb.ToString();
        }
	}


	/// <summary>
	/// Summary description for PublishModuleResult
	/// </summary>
	public class PublishModuleResult
	{
		public PublishModuleResult(string moduleName)
		{
			//
			// TODO: Add constructor logic here
			//

			ModuleName = moduleName;
			Added = new ArrayList();
			Deleted = new ArrayList();
			Related = new ArrayList();
			Result  = false;
		}
		
		public string ModuleName;
		public ArrayList Added;
		public ArrayList Deleted;
		public ArrayList Related;
		public bool Result;
		public string FailureReason;

	}
}
