using System;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Data.SqlClient;
using System.Collections;
using System.Diagnostics;
using System.Text;
using System.Collections.Generic;

namespace Expedia.Test.Framework
{
    public class TFxDB : IDisposable
    {
        /// <summary>
        /// Summary description for DBConnectionType.
        /// </summary>
        public enum ConnectionType
        {
            AutoCloseConnection = 0,
            CacheConnection
        }

        SqlConnection m_connection;
        ConnectionType m_connectType;

        private static String c_ServerName = String.Empty;

        public static String ServerName
        {
            get { return c_ServerName; }
            set { c_ServerName = value; }
        }

        private static String c_DatabaseName = String.Empty;

        public static String DatabaseName
        {
            get { return c_DatabaseName; }
            set { c_DatabaseName = value; }
        }


        public static bool Retry = true;

        public SqlConnection Connection
        {
            get
            {
                Exception exp = null;
                int tries = 0;
                do
                {
                    try
                    {
                        if (m_connection == null)
                        {
                            m_connection = GetConnection();
                            if (m_connectType == ConnectionType.AutoCloseConnection)
                            {
                                m_connection.Open();
                            }
                        }
                        return m_connection;

                    }
                    catch (Exception e)
                    {
                        tries++;
                        string message = String.Format("Error occurred while trying to open connection,\n Connection String:{2}\n number of attempts {1}\n exception details:\n {0}", e, tries.ToString(), m_connection.ConnectionString);
                        exp = e;
                        EventLog.WriteEntry("Application", message, EventLogEntryType.Warning);
                        System.Threading.Thread.Sleep(15000);
                    }
                }
                while (Retry && tries < 100);

                EventLog.WriteEntry("Application", "Error occurred while opening a connection, gave up at last, number of attempts " + tries.ToString(), EventLogEntryType.Error);
                throw exp;

            }

        }


        public TFxDB(string serverName, string dbName)
            : this(ConnectionType.AutoCloseConnection, serverName, dbName)
        {
            // default connection type is AutoCloseConnection

        }

        public TFxDB(ConnectionType type, string serverName, string dbName)
        {
            ServerName = serverName;
            DatabaseName = dbName;
            m_connectType = type;
        }

        public void Dispose()
        {
            if (m_connection != null)
            {
                m_connection.Dispose();
            }
            GC.SuppressFinalize(this);
        }

        public static string ConnectionString()
        {
            if (string.IsNullOrEmpty(ServerName) || string.IsNullOrEmpty(DatabaseName))
            {
                TFxApplicationConfig TFxConfig = new TFxApplicationConfig();

                ServerName = TFxConfig.ServerName;
                DatabaseName = TFxConfig.DBName;
            }

            return string.Format("Data Source={0};Initial Catalog={1};Integrated Security=SSPI", ServerName, DatabaseName);
        }

        internal SqlConnection GetConnection()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = ConnectionString();
            return con;
        }

        public DataTable ExecuteQuery(string sql, SqlConnection conn)
        {
            Exception exp = null;
            int tries = 0;
            do
            {
                try
                {

                    if (conn.State == System.Data.ConnectionState.Closed)
                    {
                        conn.Open();
                    }
                    using (SqlDataAdapter da = new SqlDataAdapter(sql, conn))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        if (m_connectType == ConnectionType.AutoCloseConnection)
                        {
                            conn.Close();
                        }
                        return dt;
                    }

                }
                catch (Exception e)
                {
                    tries++;
                    string message = String.Format("Error occurred while executing query\n query={0}\n number of attempts {1}\n exception details:\n{2}", sql, tries.ToString(), e);
                    exp = e;
                    EventLog.WriteEntry("Application", message, EventLogEntryType.Warning);
                    System.Threading.Thread.Sleep(15000);
                }
            }
            while (Retry && tries < 100);

            EventLog.WriteEntry("Application", "Error occurred while executing query, gave up at last, number of attempts: " + tries.ToString(), EventLogEntryType.Error);
            throw exp;

        }

        /// <summary>
        /// Convert SqlCommand to string, including the parameter names and values
        /// </summary>
        public static string GetSqlString(SqlCommand cmd)
        {
            StringBuilder sqlcmd = new StringBuilder(cmd.CommandText);
            foreach (SqlParameter param in cmd.Parameters)
            {
                sqlcmd.AppendFormat(", {0}={1}", param.ParameterName, param.Value);
            }
            return sqlcmd.ToString();
        }

        public DataTable ExecuteQuery(SqlCommand cmd, SqlConnection conn)
        {

            Exception exp = null;
            int tries = 0;
            do
            {
                try
                {
                    if (conn.State == System.Data.ConnectionState.Closed)
                    {
                        conn.Open();
                    }
                    cmd.CommandTimeout = 3600;
                    cmd.Connection = conn;

                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        if (m_connectType == ConnectionType.AutoCloseConnection)
                        {
                            conn.Close();
                        }
                        return dt;
                    }

                }
                catch (Exception e)
                {
                    tries++;
                    string message = String.Format("Error occurred while executing query\n query={2}\n number of attempts {1}\n exception details:\n{0}", e, tries.ToString(), GetSqlString(cmd));
                    exp = e;
                    EventLog.WriteEntry("Application", message, EventLogEntryType.Warning);
                    System.Threading.Thread.Sleep(15000);
                }
            }
            while (Retry && tries < 100);

            EventLog.WriteEntry("Application", "Error occurred while executing query, gave up at last, number of attempts:" + tries.ToString(), EventLogEntryType.Error);
            throw exp;
        }

        internal void ExecuteNonQuery(SqlCommand cmd, SqlConnection conn)
        {
            Exception exp = null;
            int tries = 0;
            do
            {
                try
                {
                    if (conn.State == System.Data.ConnectionState.Closed)
                    {
                        conn.Open();
                    }
                    cmd.CommandTimeout = 3600;
                    cmd.Connection = conn;
                    cmd.ExecuteNonQuery();

                    if (m_connectType == ConnectionType.AutoCloseConnection)
                    {
                        conn.Close();
                    }

                    return;

                }

                catch (Exception e)
                {
                    tries++;
                    string message = String.Format("Error occurred while executing query\n query={2}\n number of attempts {1}\n exception details:\n{0}", e, tries.ToString(), GetSqlString(cmd));
                    exp = e;
                    EventLog.WriteEntry("Application", message, EventLogEntryType.Warning);
                    System.Threading.Thread.Sleep(15000);
                }
            }
            while (Retry && tries < 100);

            EventLog.WriteEntry("Application", "Error occurred while executing query, gave up at last, number of attempts:" + tries.ToString(), EventLogEntryType.Error);

            if (m_connectType == ConnectionType.AutoCloseConnection)
            {
                conn.Close();
            }

            throw exp;
        }


        internal object ExecuteScalar(SqlCommand cmd, SqlConnection conn)
        {

            Exception exp = null;
            int tries = 0;
            do
            {
                try
                {
                    //if(m_connectType==ConnectionType.CacheConnection && conn.State == System.Data.ConnectionState.Closed)
                    if (conn.State == System.Data.ConnectionState.Closed)
                    {
                        conn.Open();
                    }
                    cmd.Connection = conn;
                    cmd.CommandTimeout = 3600;
                    object obj = cmd.ExecuteScalar();

                    if (m_connectType == ConnectionType.AutoCloseConnection)
                    {
                        conn.Close();
                    }

                    return obj;

                }
                catch (Exception e)
                {
                    tries++;
                    string message = String.Format("Error occurred while executing query\n query={2}\n number of attempts {1}\n exception details:\n{0}", e, tries.ToString(), GetSqlString(cmd));
                    exp = e;
                    EventLog.WriteEntry("Application", message, EventLogEntryType.Warning);
                    System.Threading.Thread.Sleep(15000);
                }
            }
            while (Retry && tries < 100);

            EventLog.WriteEntry("Application", "Error occurred while executing query, gave up at last, number of attempts:" + tries.ToString(), EventLogEntryType.Error);

            if (m_connectType == ConnectionType.AutoCloseConnection)
            {
                conn.Close();
            }

            throw exp;

        }


        /// <summary>
        /// Comments:	Changed testid to testgid
        /// Comments: 	Changed the related test id from int to GUID
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>

        private TestInfoCollection GetTestCasesCollection(DataTable dt)
        {

            TestInfoCollection testCaseCollection = new TestInfoCollection();

            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow testRow in dt.Rows)
                {
                    if (testRow["FullPath"] != DBNull.Value)
                    {
                        // The Full Path Name includes the PathName + testName
                        //Get the PathName and the testName separetely

                        string pathName = testRow["FullPath"].ToString();
                        pathName = pathName.Replace("\\", ".");

                        int index = pathName.LastIndexOf(".");
                        string testName = null;

                        if (index > 0)
                        {
                            testName = pathName.Substring(index + 1, pathName.Length - index - 1);
                            pathName = pathName.TrimEnd(testName.ToCharArray());
                            pathName = pathName.TrimEnd('.');

                        }
                        else
                        {
                            testName = pathName;
                            pathName = null;
                        }

                        TFxCase testCase = new TFxCase(new Guid((testRow["testgid"]).ToString()), pathName, testName);
                        if (dt.Columns.Contains("relatedtestgid"))
                        {
                            testCase.RelatedTestGid = new Guid(testRow["relatedtestgid"].ToString());
                        }

                        if (testRow["description"] != DBNull.Value)
                        {
                            testCase.Description = testRow["description"].ToString();
                        }


                        testCase.Owner = testRow["owner"].ToString();
                        if (testRow["testCategory"] != DBNull.Value && testRow["testCategory"] != null)
                        {
                            testCase.TestCategory = (Convert.ToInt64(testRow["testCategory"].ToString()));
                        }
                        testCase.Module = new TestBuildModule();
                        testCase.Module.ModuleName = testRow["modulename"].ToString();
                        testCaseCollection.Add(testCase);
                    }
                }
            }
            return testCaseCollection;
        }



        public TestInfoCollection GetTestCasesModuleCollection(string buildname, string modulename)
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select * from TFx16_TestCases where modulename=@module and buildname=@build";
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@module", modulename);
                cmd.Parameters.AddWithValue("@build", buildname);
                cmd.Connection = Connection;

                DataTable dt = ExecuteQuery(cmd, Connection);

                return GetTestCasesCollection(dt);
            }

        }

        /// <summary>
        /// Comments: 	Changed the related test id from int to GUID
        /// </summary>
        /// <param name="relatedtestid"></param>
        /// <returns></returns>
        public TestInfoCollection GetTestCasesRelated(Guid relatedtestgid)
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select * from TFx16_TestCases where relatedtestgid = @relatedtestgid order by createddate DESC";
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@relatedtestgid", relatedtestgid);
                cmd.Connection = Connection;

                DataTable dt = ExecuteQuery(cmd, Connection);

                return GetTestCasesCollection(dt);
            }

        }

        public TestInfoCollection GetTestCasesBuildCollection(string buildname)
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select * from TFx16_TestCases where buildname=@build";
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@build", buildname);
                cmd.Connection = Connection;

                DataTable dt = ExecuteQuery(cmd, Connection);

                return GetTestCasesCollection(dt);
            }
        }

        /// <summary>
        ///  Comments:	Changed UserId from Int to GUID
        /// </summary>
        /// <param name="team"></param>
        /// <param name="repository"></param>
        // TODO:  Reconsider passing repository to RemoteClient
        public void GetTeam(TFxTeam team, bool activeTeam, Repository repository)
        {
            //using (SqlCommand cmd = new SqlCommand())
            //{
            //    cmd.CommandText = "select * from TFx16_Users where (managerusergid=@managergid or usergid=@managergid)";
            //    if (activeTeam)
            //    {
            //        cmd.CommandText += " and lasttalktime != ''";
            //    }
            //    cmd.CommandType = CommandType.Text;
            //    (cmd.Parameters.AddWithValue("@managergid", SqlDbType.UniqueIdentifier)).Value = team.Manager.usergid;
            //    cmd.Connection = Connection;

            //    DataTable dt = ExecuteQuery(cmd, Connection);

            //    team.Clients = new ClientCollection();

            //    if (dt != null && dt.Rows.Count > 0)
            //    {
            //        foreach (DataRow row in dt.Rows)
            //        {
            //            if (new Guid(row["usergid"].ToString()) == team.Manager.usergid)
            //            {
            //                team.Manager = (TFxManager)DBDeserializer.GetObject(row, typeof(TFxManager));
            //            }
            //            else
            //            {
            //                // TODO:  Pass in maximum concurrency instead of hard code to 15
            //                Client client = new RemoteClient(1, repository);
            //                client.Name = (string)row["name"];
            //                if (row["concurrencysize"] != DBNull.Value)
            //                {
            //                    client.AssignmentQSize = Convert.ToInt32(row["concurrencysize"]);
            //                }
            //                client.Tester = (TFxUser)DBDeserializer.GetObject(row, typeof(TFxUser));
            //                team.Clients.Add(client);
            //            }
            //        }
            //    }
            //}
        }

        public TFxUserCollection GetAllUsers()
        {
            return (TFxUserCollection)ObjectQuery.GetCollection(
                this.Connection, "TFx16_Users", typeof(TFxUserCollection), typeof(TFxUser));
        }

        /// <summary>
        ///Comments:  Changed the TestBuild Id to buildgid
        /// Comments: changed labrunid to GUID labrungid
        /// </summary>
        /// <param name="labrungid"></param>
        /// <param name="labrunname"></param>
        /// <param name="buildgid"></param>
        /// <param name="managerid"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        public TestRun GetTestRun(Guid labrungid, string labrunname, Guid buildgid, Guid managerGid, LabRunStatusType status)
        {
            return GetTestRun(labrungid, labrunname, buildgid, managerGid, status, false);
        }

        /// <summary>
        /// Comments:   Changed the releaseid to releasegid(spusapati(08/07/2006)
        ///             Changed the TestBuild Id to buildgid, in the select statement and the testRun.TestBuild.BuildGid
        ///             Changed UserId from Int to GUID
        /// Comments: changed labrunid to GUID labrungid
        /// </summary>
        /// <param name="labrungid"></param>
        /// <param name="labrunname"></param>
        /// <param name="buildid"></param>
        /// <param name="managerid"></param>
        /// <param name="status"></param>
        /// <param name="getResult"></param>
        /// <returns></returns>
        public TestRun GetTestRun(Guid labrungid, string labrunname, Guid buildgid, Guid managerGid, LabRunStatusType status, bool getResult)
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select * from TFx16_LabRuns where (@labrunname is null or labrunname=@labrunname) and (@labrungid is null or labrungid=@labrungid) and (@managerGid is null or managerGid=@managerGid) and (@buildgid is null or buildgid=@buildgid) and (@statusid=-1 or labrunstatusid=@statusid) order by labrunid desc";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = Connection;

                (cmd.Parameters.AddWithValue("@labrungid", SqlDbType.UniqueIdentifier)).Value = DBNull.Value;
                (cmd.Parameters.AddWithValue("@managerGid", SqlDbType.UniqueIdentifier)).Value = DBNull.Value;
                (cmd.Parameters.AddWithValue("@buildgid", SqlDbType.UniqueIdentifier)).Value = DBNull.Value;
                (cmd.Parameters.AddWithValue("@labrunname", SqlDbType.VarChar)).Value = DBNull.Value;
                (cmd.Parameters.AddWithValue("@statusid", SqlDbType.Int)).Value = -1;

                if (labrunname != null && labrunname != string.Empty)
                {
                    cmd.Parameters["@labrunname"].Value = labrunname;
                }

                if (labrungid != Guid.Empty)
                {
                    cmd.Parameters["@labrungid"].Value = labrungid;
                }

                if (buildgid != Guid.Empty)
                {
                    cmd.Parameters["@buildgid"].Value = buildgid;
                }

                if (managerGid != Guid.Empty)
                {
                    cmd.Parameters["managerGid"].Value = managerGid;
                }

                if (status != LabRunStatusType.Created)
                {
                    cmd.Parameters["@statusid"].Value = status;
                }


                DataTable dt = ExecuteQuery(cmd, Connection);

                if (dt != null && dt.Rows.Count > 0)
                {
                    DataRow row = dt.Rows[0];

                    TestRun testRun = new TestRun();
                    testRun.LabRunName = (string)row["labrunname"];
                    testRun.LabRunId = (int)row["LabRunId"];
                    testRun.LabRunGid = (Guid)row["labrungid"];
                    testRun.Manager = new TFxUser();
                    testRun.Manager.IsManager = true;
                    testRun.Manager.Name = (string)row["username"];
                    testRun.Manager.usergid = new Guid(row["managergid"].ToString());
                    testRun.Status = (LabRunStatusType)Enum.Parse(typeof(LabRunStatusType), row["labrunstatusid"].ToString());
                    testRun.TestBuild = new TestBuild();
                    testRun.TestBuild.BuildGid = new Guid(row["buildgid"].ToString());
                    testRun.TestBuild.Name = (string)row["buildname"];
                    testRun.TestBuild.RootFolder = (string)row["rootfolder"];
                    testRun.TestBuild.TestRelease = new TestRelease();
                    testRun.TestBuild.TestRelease.ReleaseGid = new Guid(row["releasegid"].ToString());
                    testRun.TestBuild.TestRelease.ReleaseName = (string)row["releasename"];

                    if (row["alternaterootfolder"] != DBNull.Value)
                    {
                        testRun.TestBuild.AlternateRootFolder = (string)row["alternaterootfolder"];
                    }

                    testRun.Assignments = GetAssignments(testRun, 0, getResult);
                    testRun.SystemTasks = GetAssignments(testRun, 1, getResult);

                    return testRun;

                }



            }

            return null;
        }

        /// <summary>
        /// Comments: Changed the TestBuild id to buildgid
        /// Comments:	Changed UserId from Int to GUID
        /// Comments: changed labrunid to GUID labrungid
        /// Comments: changed templateid to GUID templategid
        /// </summary>
        /// <param name="templatename"></param>
        /// <returns></returns>
        //public TestRunTemplate GetTestRunTemplate(string templatename, string release)
        //{
        //    using (SqlCommand cmd = new SqlCommand())
        //    {
        //        cmd.CommandText = "select * from TFx16_TestRuns where labrunname=@templatename";
        //        cmd.CommandType = CommandType.Text;
        //        (cmd.Parameters.AddWithValue("@templatename", SqlDbType.VarChar)).Value = templatename;
        //        cmd.Connection = Connection;

        //        DataTable dt = ExecuteQuery(cmd, Connection);

        //        if (dt != null && dt.Rows.Count == 1)
        //        {
        //            DataRow row = dt.Rows[0];
        //            return GenerateTemplateFromDataRow(row, release);
        //        }

        //    }
        //    return null;
        //}

        /// <summary>
        /// Comments: Changed the buildid to buildgid
        /// Comments:	Changed UserId from Int to GUID
        /// Comments: Changed the templateid to templategid
        /// Comments: changed labrunid to GUID labrungid
        /// </summary>
        /// <param name="templateid"></param>
        /// <returns></returns>
        //public TestRunTemplate GetTestRunTemplate(Guid templategid, string release)
        //{

        //    using (SqlCommand cmd = new SqlCommand())
        //    {
        //        cmd.CommandText = "select * from TFx16_TestRuns where templategid=@templategid";
        //        cmd.CommandType = CommandType.Text;
        //        (cmd.Parameters.AddWithValue("@templategid", SqlDbType.UniqueIdentifier)).Value = templategid;
        //        cmd.Connection = Connection;

        //        DataTable dt = ExecuteQuery(cmd, Connection);

        //        if (dt != null && dt.Rows.Count == 1)
        //        {
        //            DataRow row = dt.Rows[0];
        //            return GenerateTemplateFromDataRow(row, release);
        //        }

        //        return null;

        //    }
        //}

        //private TestRunTemplate GenerateTemplateFromDataRow(DataRow row, string release)
        //{
        //    TestRunTemplate template = new TestRunTemplate();
        //    template.BuildName = row["buildname"] as string;
        //    template.BuildType = (BuildType)Enum.Parse(typeof(BuildType), row["buildtype"] as string, true);
        //    template.TemplateName = row["labrunname"] as string;

        //    template.testRun = new TestRun();
        //    template.testRun.TestRunGid = (Guid)row["templategid"];
        //    template.testRun.LabRunName = row["labrunname"] as string;
        //    template.testRun.LabRunGid = (Guid)row["labrungid"];
        //    template.testRun.Manager = new TFxUser();
        //    template.testRun.Manager.IsManager = true;
        //    template.testRun.Manager.Name = (string)row["mangername"];
        //    template.testRun.Manager.usergid = new Guid(row["managerGid"].ToString());
        //    template.testRun.Status = (LabRunStatusType)Enum.Parse(typeof(LabRunStatusType), row["labrunstatusid"].ToString());

        //    if (template.BuildType == BuildType.Latest)
        //    {
        //        //Get the Latest build first
        //        if (string.IsNullOrEmpty(release))
        //            template.testRun.TestBuild = this.GetTestBuild(row["ReleaseName"].ToString(), BuildType.Latest, 1);
        //        else
        //            template.testRun.TestBuild = this.GetTestBuild(release, BuildType.Latest, 1);
        //    }
        //    else
        //    {
        //        template.testRun.TestBuild = new TestBuild();
        //        template.testRun.TestBuild.BuildGid = new Guid(row["buildgid"].ToString());
        //        template.testRun.TestBuild.Name = (string)row["buildname"];

        //        if (row["rootfolder"] != DBNull.Value)
        //        {
        //            template.testRun.TestBuild.RootFolder = (string)row["rootfolder"];
        //        }

        //        template.testRun.TestBuild.TestRelease = new TestRelease();
        //        template.testRun.TestBuild.TestRelease.ReleaseName = (string)row["ReleaseName"];
        //        template.testRun.TestBuild.TestRelease.ReleaseGid = new Guid(row["releasegid"].ToString());
        //    }

        //    template.testRun.AssignmentsGroup = GetAssignmentGroup(template.testRun);

        //    return template;
        //}

        //public TestRunTemplate GetTestRunTemplate(int templateID, string release)
        //{
        //    using (SqlCommand cmd = new SqlCommand())
        //    {
        //        cmd.CommandText = "Select templategid from TestRunTemplate where id=@templateID";
        //        cmd.CommandType = CommandType.Text;
        //        (cmd.Parameters.AddWithValue("@templateID", SqlDbType.Int)).Value = templateID;
        //        cmd.Connection = Connection;

        //        DataTable dt = ExecuteQuery(cmd, Connection);

        //        if (dt != null && dt.Rows.Count == 1)
        //        {
        //            DataRow row = dt.Rows[0];
        //            Guid templateGid = (Guid)row[0];
        //            return GetTestRunTemplate(templateGid, release);
        //        }
        //        return null;
        //    }
        //}

        /// <summary>
        /// Comments:Changed moduleid to modulegid(spusapati)
        /// </summary>
        /// <param name="buildname"></param>
        /// <param name="release"></param>
        /// <param name="buildtype"></param>
        /// <param name="moduleName"></param>
        /// <returns></returns>
        public TestBuildModule GetTestBuildModule(string buildname, string release, BuildType buildtype, string moduleName)
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                if (buildtype == BuildType.Specific)
                {
                    cmd.CommandText = "select TOP 1 * from PUB_V_TestBuildModule where (buildname=@buildname and modulename=@modulename)";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@buildname", buildname);
                    cmd.Parameters.AddWithValue("@modulename", moduleName);
                }
                else if (buildtype == BuildType.Latest)
                {
                    cmd.CommandText = "select TOP 1 * from PUB_V_TestBuildModule where (releasename=@release and modulename=@modulename) order by buildid desc";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@release", release);
                    cmd.Parameters.AddWithValue("@modulename", moduleName);
                }

                cmd.Connection = Connection;

                DataTable dt = ExecuteQuery(cmd, Connection);

                if (dt != null && dt.Rows.Count == 1)
                {
                    DataRow row = dt.Rows[0];

                    TestBuildModule module = new TestBuildModule();
                    module.BuildName = row["buildname"] as string;
                    module.ModuleName = moduleName;
                    module.ModuleGid = new Guid(row["modulegid"].ToString());

                    return module;
                }

            }
            return null;
        }
        /// <summary>
        /// Comments: Added a new output parameter @modulegid
        /// </summary>
        /// <param name="modulename"></param>
        public void CreateTestBuildModule(string modulename)
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "PUB_sp_CreateNewModule";
                cmd.CommandType = CommandType.StoredProcedure;
                (cmd.Parameters.AddWithValue("@moduleName", SqlDbType.VarChar)).Value = modulename;
                cmd.Parameters.AddWithValue("@exists", SqlDbType.Int);
                cmd.Parameters.AddWithValue("@modulegid", Guid.Empty);
                cmd.Parameters["@exists"].Direction = ParameterDirection.Output;
                cmd.Parameters["@modulegid"].Direction = ParameterDirection.Output;


                cmd.Connection = Connection;
                ExecuteScalar(cmd, Connection);

                //if (Convert.ToInt32(cmd.Parameters["@exists"].Value) == 1)
                //{
                //    throw new Exception(String.Format("Module Name {0} already exixts", modulename));
                //}


            }

        }

        /// <summary>
        /// Comments:   Changed the module.ModuleId to module.modulegid
        ///             Changed the TestBuild Id to buildgid
        /// </summary>
        /// <param name="name">if build type is latest then name should contain release name otherwise it should contain build name</param>
        /// <param name="buildtype"></param>
        /// <returns></returns>
        public TestBuild GetTestBuild(string name, BuildType buildtype, int bitAvailable)
        {

            using (SqlCommand cmd = new SqlCommand())
            {
                if (buildtype == BuildType.Specific)
                {
                    cmd.CommandText = "select TOP 1 * from TFx16_TestBuilds where (buildname=@testbuildname)";
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@testbuildname", name);
                }
                else
                {

                    cmd.CommandText = string.Format("select TOP 1 * from TFx16_TestBuilds where (ReleaseName=@releaseName) and (BitAvailable={0}) ORDER BY buildid DESC", bitAvailable);
                    cmd.CommandType = CommandType.Text;
                    if (name == null)
                    {
                        (cmd.Parameters.AddWithValue("@releaseName", SqlDbType.VarChar)).Value = DBNull.Value;
                    }
                    else
                    {
                        (cmd.Parameters.AddWithValue("@releaseName", SqlDbType.VarChar)).Value = name;
                    }
                }

                cmd.Connection = Connection;

                DataTable dt = ExecuteQuery(cmd, Connection);

                if (dt != null && dt.Rows.Count == 1)
                {
                    TestBuild rbuild = new TestBuild();
                    rbuild.Name = dt.Rows[0]["buildname"].ToString();
                    if (dt.Rows[0]["rootfolder"] != DBNull.Value)
                    {
                        rbuild.RootFolder = (string)dt.Rows[0]["rootfolder"];
                    }
                    if (dt.Rows[0]["alternaterootfolder"] != DBNull.Value)
                    {
                        rbuild.AlternateRootFolder = (string)dt.Rows[0]["alternaterootfolder"];
                    }
                    rbuild.BuildGid = new Guid(dt.Rows[0]["buildgid"].ToString());
                    rbuild.TestRelease = new TestRelease();
                    rbuild.TestRelease.ReleaseName = (string)dt.Rows[0]["ReleaseName"];
                    rbuild.TestRelease.ReleaseGid = new Guid(dt.Rows[0]["releasegid"].ToString());

                    // Get Test Build Module

                    cmd.CommandText = "SELECT modulename, modulegid FROM dbo.Modules";
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = Connection;
                    DataTable modules = ExecuteQuery(cmd, Connection);

                    if (modules != null && modules.Rows.Count > 0)
                    {
                        rbuild.Modules = new TestBuildModule[modules.Rows.Count];

                        for (int i = 0; i < modules.Rows.Count; i++)
                        {
                            TestBuildModule module = new TestBuildModule();
                            module.ModuleGid = new Guid(modules.Rows[i]["modulegid"].ToString());
                            module.ModuleName = (string)modules.Rows[i]["modulename"];
                            rbuild.Modules[i] = module;
                        }
                    }

                    return rbuild;
                }

                return null;
            }
        }


        public void UpdateTestBuild(TestBuild testBuild)
        {
            if (testBuild == null)
            {
                return;
            }

            using (SqlCommand cmd = new SqlCommand())
            {

                cmd.CommandText = "PUB_sp_UpdateTestBuild";
                cmd.CommandType = CommandType.StoredProcedure;
                (cmd.Parameters.AddWithValue("@buildname", SqlDbType.VarChar)).Value = testBuild.Name;
                (cmd.Parameters.AddWithValue("@rootfolder", SqlDbType.VarChar)).Value = testBuild.RootFolder;
                (cmd.Parameters.AddWithValue("@alternatefolder", SqlDbType.VarChar)).Value = testBuild.AlternateRootFolder;
                (cmd.Parameters.AddWithValue("@bitavailable", SqlDbType.Bit)).Value = testBuild.BitAvailable;

                cmd.Connection = Connection;
                int ret = Convert.ToInt32(ExecuteScalar(cmd, Connection));

                if (ret == -1)
                {
                    throw new Exception(String.Format("Cannot update TestBuild {0}", testBuild.Name));
                }
            }
        }


        //TODO: need to have update espcially for goodbuild flag, and isbitsavailable
        /// <summary>
        /// Comments: Changed the return type to return 0 or -1
        /// </summary>
        /// <param name="testBuild"></param>
        public void CreateTestBuild(TestBuild testBuild)
        {

            if (testBuild == null)
            {
                return;
            }

            if (testBuild.RootFolder == null)
            {
                throw new Exception(String.Format("Build {0} Root Folder cannot be null", testBuild.Name));
            }

            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "TFx16_CreateTestBuildWithRelease";
                cmd.CommandType = CommandType.StoredProcedure;
                (cmd.Parameters.AddWithValue("@buildname", SqlDbType.VarChar)).Value = testBuild.Name;
                (cmd.Parameters.AddWithValue("@rootfolder", SqlDbType.VarChar)).Value = testBuild.RootFolder;
                (cmd.Parameters.AddWithValue("@alternatefolder", SqlDbType.VarChar)).Value = DBNull.Value;
                (cmd.Parameters.AddWithValue("@bitavailable", SqlDbType.Bit)).Value = testBuild.BitAvailable;
                (cmd.Parameters.AddWithValue("@releasename", SqlDbType.VarChar)).Value = testBuild.TestRelease.ReleaseName;


                if (testBuild.AlternateRootFolder != null)
                {
                    cmd.Parameters["@alternatefolder"].Value = testBuild.AlternateRootFolder;

                }

                cmd.Connection = Connection;
                int returnType = Convert.ToInt32(ExecuteScalar(cmd, Connection));

                if (returnType == -1)
                {
                    throw new Exception(String.Format("Build Name {0} already exixts", testBuild.Name));
                }
            }
        }



        /// <summary>
        /// Comments:	Changed UserId from Int to GUID
        /// </summary>
        /// <returns></returns>
        public TFxUser[] GetManagers()
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select * from TFx16_Users where ismanager=1 order by name";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = Connection;

                DataTable dt = ExecuteQuery(cmd, Connection);

                if (dt != null && dt.Rows.Count >= 1)
                {
                    TFxUser[] managers = new TFxUser[dt.Rows.Count];

                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        DataRow dr = dt.Rows[i];
                        TFxDBUser manager = new TFxDBUser();
                        manager.usergid = new Guid(dr["usergid"].ToString());
                        manager.userid = int.Parse(dr["userid"].ToString());
                        manager.Name = dr["name"] as string;
                        managers[i] = manager as TFxUser;

                    }

                    return managers;
                }


                return null;
            }
        }

        /// <summary>
        /// Comments:	Changed testid to testgid
        /// Comments:	Changed UserId from Int to GUID
        /// Comments: changed labrunid to GUID labrungid
        /// </summary>
        /// <param name="testRun"></param>
        /// <returns></returns>

        public ArrayList GetAssignmentGroup(TestRun testRun)
        {

            ArrayList list = new ArrayList();

            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select * from TFx16_Assignments where labrungid=@labrungid order by assignmentgroup";
                cmd.CommandType = CommandType.Text;
                (cmd.Parameters.AddWithValue("@labrungid", SqlDbType.UniqueIdentifier)).Value = testRun.LabRunGid;
                cmd.Connection = Connection;

                DataTable dt = ExecuteQuery(cmd, Connection);

                if (dt != null && dt.Rows.Count >= 1)
                {

                    AssignmentCollection col = new AssignmentCollection();
                    int assignmentgroup = Convert.ToInt32(dt.Rows[0]["assignmentgroup"]);
                    list.Add(col);

                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        DataRow row = dt.Rows[i];
                        int cur = Convert.ToInt32(row["assignmentgroup"]);

                        if (cur != assignmentgroup)
                        {
                            col = new AssignmentCollection();
                            list.Add(col);
                            assignmentgroup = cur;
                        }

                        Assignment assignment = new Assignment();
                        assignment.AssignmentId = Convert.ToInt32(row["assignmentid"]);
                        assignment.RunStatus = (AssignmentStatusType)Enum.Parse(typeof(AssignmentStatusType), row["assignmentstatusid"].ToString());
                        if (assignment.RunStatus == AssignmentStatusType.Completed)
                        {
                            assignment.AssignedTo = new TFxUser();
                            assignment.AssignedTo.Name = (string)row["username"];
                            assignment.AssignedTo.usergid = new Guid(row["usergid"].ToString());
                        }
                        else
                        {
                            // all the assignments should be assigned to manager
                            assignment.AssignedTo = testRun.Manager;
                            assignment.RunStatus = AssignmentStatusType.Assigned;
                        }
                        string testName = (string)row["testname"];
                        string fullPath = ((string)row["FullPath"]).Replace('\\', '.').Replace("." + testName, "");
                        assignment.TestCase = new TFxCase(new Guid(row["testgid"].ToString()), fullPath, testName);

                        assignment.TestCase.Module = new TestBuildModule();
                        assignment.TestCase.Module.ModuleName = (string)row["modulename"];

                        if (row["testcategory"] != DBNull.Value)
                        {
                            assignment.TestCase.TestCategory = (long)Convert.ToInt32(row["testcategory"]);
                        }

                        if (row["Owner"] != DBNull.Value)
                        {
                            assignment.TestCase.Owner = (string)row["Owner"];
                        }

                        assignment.LabRun = new LabRun();
                        assignment.LabRun.LabRunGid = (Guid)row["labrungid"];

                        GetAssignmentConfigData(assignment);

                        // set assignment timeout
                        string timeout = assignment.ConfigData.GetValue(TFxConst.c_AssignmentTimeout);

                        if (timeout != null)
                        {
                            try
                            {
                                assignment.AssignmentTimeout = TimeSpan.Parse(timeout);
                            }
                            catch
                            {
                                assignment.AssignmentTimeout = TimeSpan.Zero;
                            }
                        }

                        col.Add(assignment);

                    }

                }


            }

            return list;


        }


        public string GetRelease(string buildName)
        {
            SimpleSQLQuery query = new SimpleSQLQuery("TFx16_TestBuilds");
            query.AddParam("buildName", buildName);

            DataTable dt = query.Execute(this.Connection);

            if (dt != null && dt.Rows.Count == 1)
            {
                return dt.Rows[0]["releaseName"].ToString();
            }

            return null;

        }

        /// <summary>
        /// Comments:	Changed testid to testgid, int to GUID
        /// Comments:	Changed UserId from Int to GUID
        /// Comments: changed labrunid to GUID labrungid
        /// </summary>
        /// <param name="testRun"></param>
        /// <param name="assignmentGroup"></param>
        /// <param name="getResult"></param>
        /// <returns></returns>
        public AssignmentCollection GetAssignments(TestRun testRun, int assignmentGroup, bool getResult)
        {
            AssignmentCollection col = new AssignmentCollection();

            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select * from TFx16_Assignments where labrungid=@labrungid";
                cmd.CommandType = CommandType.Text;
                (cmd.Parameters.AddWithValue("@labrungid", SqlDbType.UniqueIdentifier)).Value = testRun.LabRunGid;
                cmd.Connection = Connection;

                DataTable dt = ExecuteQuery(cmd, Connection);

                if (dt != null && dt.Rows.Count >= 1)
                {

                    DataRow[] rows = dt.Select("assignmentgroup=" + assignmentGroup.ToString());

                    for (int i = 0; rows != null && i < rows.Length; i++)
                    {
                        DataRow row = rows[i];
                        Assignment assignment = new Assignment();
                        assignment.AssignmentId = Convert.ToInt32(row["assignmentid"]);

                        assignment.AssignedTo = new TFxUser();
                        assignment.AssignedTo.Name = (string)row["username"];
                        assignment.AssignedTo.usergid = new Guid(row["usergid"].ToString());

                        string testName = (string)row["testname"];
                        string fullPath = ((string)row["FullPath"]).Replace('\\', '.').Replace("." + testName, "");
                        assignment.TestCase = new TFxCase(new Guid(row["testgid"].ToString()), fullPath, testName);

                        if (row["testcategory"] != DBNull.Value)
                        {
                            assignment.TestCase.TestCategory = (long)Convert.ToInt32(row["testcategory"]);
                        }

                        if (row["Owner"] != DBNull.Value)
                        {
                            assignment.TestCase.Owner = (string)row["Owner"];
                        }

                        assignment.TestCase.Module = new TestBuildModule();
                        assignment.TestCase.Module.ModuleName = (string)row["modulename"];
                        assignment.LabRun = new LabRun();
                        assignment.LabRun.LabRunGid = (Guid)row["labrungid"];

                        GetAssignmentConfigData(assignment);

                        // set assignment timeout
                        string timeout = assignment.ConfigData.GetValue(TFxConst.c_AssignmentTimeout);

                        if (timeout != null)
                        {
                            try
                            {
                                assignment.AssignmentTimeout = TimeSpan.Parse(timeout);
                            }
                            catch
                            {
                                assignment.AssignmentTimeout = TimeSpan.Zero;
                            }
                        }

                        // set assignment results
                        if (getResult)
                        {
                            SetAssignmentResult(row, assignment);
                        }

                        assignment.RunStatus = (AssignmentStatusType)row["assignmentstatusid"];

                        col.Add(assignment);

                    }



                }


            }

            return col;
        }

        /// Comments: changed labrunid to GUID labrungid
        protected void GetAssignmentConfigData(Assignment assignment)
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                if (assignment != null)
                {
                    assignment.ConfigData = new ConfigData();

                    cmd.CommandText = "select * from [dbo].[AssignmentConfigData] where labrungid=@labrungid and assignmentid=@assignmentid";
                    cmd.CommandType = CommandType.Text;
                    (cmd.Parameters.AddWithValue("@labrungid", SqlDbType.UniqueIdentifier)).Value = assignment.LabRun.LabRunGid;
                    (cmd.Parameters.AddWithValue("@assignmentid", SqlDbType.Int)).Value = assignment.AssignmentId;
                    cmd.Connection = Connection;

                    DataTable dt = ExecuteQuery(cmd, Connection);

                    if (dt != null)
                    {
                        StringConfig config = new StringConfig();

                        foreach (DataRow r in dt.Rows)
                        {
                            config.Add(r["configname"], r["configvalue"]);
                        }

                        assignment.ConfigData.Append(config);
                    }

                }
            }

        }

        /// Comments: changed labrunid to GUID labrungid
        public void GetAssignmentStatus(Assignment assignment)
        {


            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select * from TFx16_Assignments where labrungid=@labrungid and assignmentid=@assignmentid";
                (cmd.Parameters.AddWithValue("@labrungid", SqlDbType.UniqueIdentifier)).Value = assignment.LabRun.LabRunGid;
                (cmd.Parameters.AddWithValue("@assignmentid", SqlDbType.Int)).Value = assignment.AssignmentId;
                cmd.CommandType = CommandType.Text;
                cmd.Connection = Connection;

                DataTable dt = ExecuteQuery(cmd, Connection);


                if (dt != null && dt.Rows.Count == 1)
                {
                    DataRow row = dt.Rows[0];
                    SetAssignmentResult(row, assignment);

                    if (row["startdate"] != DBNull.Value)
                    {
                        assignment.StartDate = (DateTime)row["startdate"];
                    }
                }


            }

        }

        private void SetAssignmentResult(DataRow row, Assignment assignment)
        {
            assignment.Result = new AssignmentResult();
            assignment.RunStatus = (AssignmentStatusType)row["assignmentstatusid"];
            assignment.Result.RunStatus = assignment.RunStatus;
            if (row["assignmentrunresultid"] != DBNull.Value)
            {
                assignment.Result.Status = (AssignmentRunResultType)row["assignmentrunresultid"];
            }
            if (row["failurereason"] != null)
            {
                assignment.Result.FailureReason = row["failurereason"] as string;
            }
        }

        /// <summary>
        /// Depending upon the bool, either the entire testruntemplate class is build or not
        /// </summary>
        /// <param name="getNamesOnly"></param>
        /// <returns></returns>
        //public TestRunTemplate[] GetTestRunTemplateList(bool getNamesOnly)
        //{
        //    using (SqlCommand cmd = new SqlCommand())
        //    {
        //        cmd.CommandText = "select * from TFx16_LabRunTemplate";
        //        cmd.CommandType = CommandType.Text;
        //        DataTable dt = ExecuteQuery(cmd, Connection);

        //        ArrayList list = new ArrayList();
        //        foreach (DataRow tRow in dt.Rows)
        //        {
        //            if (!getNamesOnly)
        //            {
        //                list.Add(GetTestRunTemplate((Guid)tRow["templategid"], null));
        //            }
        //            else
        //            {
        //                list.Add(new TestRunTemplate(tRow["labrunname"] as string));
        //            }

        //        }
        //        return (TestRunTemplate[])list.ToArray(typeof(TestRunTemplate));
        //    }

        //}

        public string[] GetReleaseList()
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = @"SELECT      r.ReleaseName
                                    FROM        [dbo].[Release] AS r
                                    WHERE		(
                                                    SELECT  COUNT(*)
                                                    FROM    [dbo].[TestBuild]
                                                    WHERE   releasegid = r.releasegid
                                                        AND bitavailable = 1
                                                ) > 0
                                    ORDER BY    ReleaseDate DESC";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = Connection;

                DataTable dataTable = ExecuteQuery(cmd, Connection);

                if (dataTable != null && dataTable.Rows.Count >= 1)
                {
                    List<string> releases = new List<string>();

                    foreach (DataRow row in dataTable.Rows)
                    {
                        releases.Add(row["ReleaseName"].ToString());
                    }

                    return releases.ToArray();
                }

                return null;
            }
        }

        public object GetObject(string source, Type objectType, ArrayList paramsList)
        {
            return ObjectQuery.GetObject(this.Connection, source, paramsList, objectType);
        }

        public String[] GetTestBuilds(string releaseName)
        {

            using (SqlCommand cmd = new SqlCommand())
            {
                if (releaseName != null)
                {
                    cmd.CommandText = "select * from TFx16_TestBuilds where (ReleaseName=null or ReleaseName=@releaseName) and BitAvailable=1 order by buildname";
                    (cmd.Parameters.AddWithValue("@releaseName", SqlDbType.VarChar)).Value = releaseName;
                }
                else
                {
                    cmd.CommandText = "select * from TFx16_TestBuilds where BitAvailable=1 order by buildname";
                }
                cmd.CommandType = CommandType.Text;
                cmd.Connection = Connection;

                DataTable dt = ExecuteQuery(cmd, Connection);

                if (dt != null && dt.Rows.Count >= 1)
                {
                    String[] builds = new String[dt.Rows.Count];

                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        DataRow dr = dt.Rows[i];

                        builds[i] = dr["buildname"].ToString();

                    }

                    return builds;
                }


                return null;
            }
        }

        /// <summary>
        /// Comments:	Changed UserId from Int to GUID
        /// </summary>
        /// <param name="name"></param>
        /// <param name="trans"></param>
        /// <returns></returns>
        public Guid GetUserId(string name)
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select * from TFx16_Users where name=@name";
                cmd.Parameters.AddWithValue("@name", name.ToLower());
                cmd.CommandType = CommandType.Text;
                cmd.Connection = Connection;

                DataTable dt = ExecuteQuery(cmd, Connection);

                if (dt != null && dt.Rows.Count == 1)
                {
                    return new Guid(dt.Rows[0]["usergid"].ToString());
                }
            }
            return Guid.Empty;
        }

        /// <summary>
        /// Comments:	Changed UserId from Int to GUID
        /// Comments: changed labrunid to GUID labrungid
        /// Comments: Changed testrunid to testrungid
        /// </summary>
        /// <param name="labrunname"></param>
        /// <param name="managergid"></param>
        /// <param name="buildName"></param>
        /// <param name="templatename"></param>
        /// <param name="testRunId"></param>
        /// <param name="labRunStatus"></param>
        /// <param name="userName"></param>
        /// <returns></returns>
        public Guid CreateNewLabRun(string labrunname, string managerName, string buildName, string templatename, Guid testRunGid, LabRunStatusType labRunStatus, string userName)
        {
            Guid labrungid;


            Guid managergid = this.GetUserId(managerName);




            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "TFx16_CreateNewLabrun";
                cmd.CommandType = CommandType.StoredProcedure;
                (cmd.Parameters.AddWithValue("@Name", SqlDbType.VarChar)).Value = labrunname;
                (cmd.Parameters.AddWithValue("@managergid", SqlDbType.UniqueIdentifier)).Value = managergid;
                (cmd.Parameters.AddWithValue("@buildName", SqlDbType.VarChar)).Value = buildName;
                (cmd.Parameters.AddWithValue("@template", SqlDbType.VarChar)).Value = DBNull.Value;
                (cmd.Parameters.AddWithValue("@templategid", SqlDbType.UniqueIdentifier)).Value = testRunGid;
                (cmd.Parameters.AddWithValue("@labrunstatus", SqlDbType.Int)).Value = labRunStatus;
                (cmd.Parameters.AddWithValue("@userName", SqlDbType.VarChar)).Value = userName;

                if (templatename != null)
                {
                    cmd.Parameters["@template"].Value = templatename;
                }

                labrungid = new Guid(Convert.ToString(ExecuteScalar(cmd, Connection)));
            }
            return labrungid;
        }

        /// Comments: changed labrunid to GUID labrungid
        /// Comments: changed templateid to templategid
        public Guid CreateNewLabRunTemplate(string labRunName, string param, string buildType, string buildName, Guid labrungid, string userName)
        {
            Guid templategid = Guid.Empty;
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "TFx16_CreateNewTemplate";
                cmd.CommandType = CommandType.StoredProcedure;
                (cmd.Parameters.AddWithValue("@labrunname", SqlDbType.VarChar)).Value = labRunName;
                (cmd.Parameters.AddWithValue("@buildtype", SqlDbType.VarChar)).Value = buildType;
                (cmd.Parameters.AddWithValue("@buildname", SqlDbType.VarChar)).Value = buildName;
                (cmd.Parameters.AddWithValue("@labrungid", SqlDbType.UniqueIdentifier)).Value = labrungid;
                (cmd.Parameters.AddWithValue("@userName", SqlDbType.VarChar)).Value = userName;

                templategid = new Guid(Convert.ToString(ExecuteScalar(cmd, Connection)));
            }
            return templategid;
        }

        /// Comments: changed labrunid to GUID labrungid
        public void UpdateTemplate(string labRunName, string param, string buildType, string buildName, Guid labRunGid, string userName)
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "TFx16_UpdateTemplate";
                cmd.CommandType = CommandType.StoredProcedure;
                (cmd.Parameters.AddWithValue("@labrunname", SqlDbType.VarChar)).Value = labRunName;
                (cmd.Parameters.AddWithValue("@buildtype", SqlDbType.VarChar)).Value = buildType;
                (cmd.Parameters.AddWithValue("@buildname", SqlDbType.VarChar)).Value = buildName;
                (cmd.Parameters.AddWithValue("@labrungid", SqlDbType.UniqueIdentifier)).Value = labRunGid;
                (cmd.Parameters.AddWithValue("@userName", SqlDbType.VarChar)).Value = userName;
                object ret = ExecuteScalar(cmd, Connection);
            }
        }


        /// <summary>
        /// This is the one that is used when u wnat to update the template
        /// you send the template name
        /// Comments:	Changed managerId from Int to GUID
        /// Comments: changed labrunid to GUID labrungid
        /// </summary>
        /// <param name="labrungid"></param>
        /// <param name="labrunname"></param>
        /// <param name="managerid"></param>
        /// <param name="buildName"></param>
        /// <param name="runStatus"></param>
        /// <param name="templatename"></param>
        /// <param name="userName"></param>
        public void UpdateLabRun(Guid labrungid, string labrunname, string managerName, string buildName, LabRunStatusType runStatus, string templatename, string userName)
        {
            Guid managerGid = this.GetUserId(managerName);

            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "TFx16_UpdateLabrun";
                cmd.CommandType = CommandType.StoredProcedure;
                (cmd.Parameters.AddWithValue("@labrungid", SqlDbType.UniqueIdentifier)).Value = labrungid;
                (cmd.Parameters.AddWithValue("@Name", SqlDbType.VarChar)).Value = labrunname;
                (cmd.Parameters.AddWithValue("@managergid", SqlDbType.UniqueIdentifier)).Value = managerGid;
                (cmd.Parameters.AddWithValue("@buildName", SqlDbType.VarChar)).Value = buildName;
                (cmd.Parameters.AddWithValue("@labRunStatus", SqlDbType.Int)).Value = (int)runStatus;
                (cmd.Parameters.AddWithValue("@template", SqlDbType.VarChar)).Value = DBNull.Value;
                (cmd.Parameters.AddWithValue("@userName", SqlDbType.VarChar)).Value = userName;

                if (templatename != null)
                {
                    cmd.Parameters["@template"].Value = templatename;
                }

                object ret = ExecuteScalar(cmd, Connection);

            }

        }

        /// <summary>
        /// This is the actually one that updates the labrun, when creating a labrun
        /// Comments:	Changed managerId from Int to GUID
        /// Comments: changed labrunid to GUID labrungid
        /// Comments: changed testrunid to GUID testrungid, @testrunid to @templategid
        /// </summary>
        /// <param name="labrungid"></param>
        /// <param name="labrunname"></param>
        /// <param name="managerid"></param>
        /// <param name="buildName"></param>
        /// <param name="runStatus"></param>
        /// <param name="testrunid"></param>
        /// <param name="userName"></param>

        public void UpdateLabRun(Guid labrungid, string labrunname, string managerName, string buildName, LabRunStatusType runStatus, Guid testrungid, string userName)
        {
            Guid managerGid = this.GetUserId(managerName);

            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "TFx16_UpdateLabrun2";
                cmd.CommandType = CommandType.StoredProcedure;
                (cmd.Parameters.AddWithValue("@labrungid", SqlDbType.UniqueIdentifier)).Value = labrungid;
                (cmd.Parameters.AddWithValue("@Name", SqlDbType.VarChar)).Value = labrunname;
                (cmd.Parameters.AddWithValue("@managergid", SqlDbType.UniqueIdentifier)).Value = managerGid;
                (cmd.Parameters.AddWithValue("@buildName", SqlDbType.VarChar)).Value = buildName;
                (cmd.Parameters.AddWithValue("@labRunStatus", SqlDbType.Int)).Value = (int)runStatus;
                (cmd.Parameters.AddWithValue("@templategid", SqlDbType.UniqueIdentifier)).Value = testrungid;
                (cmd.Parameters.AddWithValue("@userName", SqlDbType.VarChar)).Value = userName;

                object ret = ExecuteScalar(cmd, Connection);

            }

        }

        /// Comments: changed labrunid to GUID labrungid
        /// Used by things like Build task (dmb 24.04.2008)
        public void UpdateLabRunStatus(TestRun run)
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "TFx16_SetLabRunStatus";
                cmd.CommandType = CommandType.StoredProcedure;
                (cmd.Parameters.AddWithValue("@labrungid", SqlDbType.UniqueIdentifier)).Value = run.LabRunGid;
                (cmd.Parameters.AddWithValue("@LabRunStatus", SqlDbType.Int)).Value = (int)run.Status;
                cmd.Connection = Connection;

                object ret = ExecuteScalar(cmd, Connection);
            }
        }

        /// Comments: changed labrunid to GUID labrungid
        public void UpdateLabRunStatusTemplate(TestRun run)
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "TFx16_SetLabRunStatus";
                cmd.CommandType = CommandType.StoredProcedure;
                (cmd.Parameters.AddWithValue("@labrungid", SqlDbType.UniqueIdentifier)).Value = run.LabRunGid;
                (cmd.Parameters.AddWithValue("@LabRunStatus", SqlDbType.Int)).Value = 10;
                cmd.Connection = Connection;

                object ret = ExecuteScalar(cmd, Connection);
            }
        }

        /// <summary>
        /// Comments:	Changed UserId from Int to GUID
        /// Comments: Changed labrunid to GUID labrungid
        /// </summary>
        /// <param name="assignmentid"></param>
        /// <param name="labrunid"></param>
        /// <param name="userid"></param>
        public void UpdateAssignmentOwner(int assignmentid, Guid labrungid, Guid usergid)
        {

            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "TFx16_AssignAssignment";
                cmd.CommandType = CommandType.StoredProcedure;
                (cmd.Parameters.AddWithValue("@assignmentid", SqlDbType.Int)).Value = assignmentid;
                (cmd.Parameters.AddWithValue("@labrungid", SqlDbType.UniqueIdentifier)).Value = labrungid;
                (cmd.Parameters.AddWithValue("@usergid", SqlDbType.UniqueIdentifier)).Value = usergid;
                cmd.Connection = Connection;

                object ret = ExecuteScalar(cmd, Connection);

            }

        }

        /// <summary>
        /// Comments: TestRun function to take the GUID value
        /// Comments: changed labrunid to GUID labrungid
        /// </summary>
        /// <param name="currentTestRun"></param>
        public void UpdateAssignmentCollection(TestRun currentTestRun)
        {
            TestRun goldenTestRun = null;
            Guid defaultValue = Guid.Empty;

            //Get the Golden Copy Test Run from the DB
            if (currentTestRun != null)
            {
                goldenTestRun = this.GetTestRun(currentTestRun.LabRunGid, currentTestRun.LabRunName, Guid.Empty, defaultValue, LabRunStatusType.Created);
            }

            UpdateAssignmentCollection(currentTestRun, goldenTestRun);

        }

        /// <summary>
        /// Comments:	Changed testid to testgid
        /// Comments:	Changed UserId from Int to GUID
        /// Comments: changed labrunid to GUID labrungid
        /// </summary>
        /// <param name="currentTestRun"></param>
        /// <param name="goldenTestRun"></param>

        public void UpdateAssignmentCollection(TestRun currentTestRun, TestRun goldenTestRun)
        {
            AssignmentCollection goldenAssignments = null;
            AssignmentCollection currentAssignments = null;
            AssignmentCollection localAssignments = null;
            int index = -1;
            Assignment assignment = null;
            IConfig[] configs = null;
            Guid labrungid;
            Guid usergid = Guid.Empty;

            labrungid = goldenTestRun.LabRunGid;
            usergid = currentTestRun.Manager.usergid;

            if (currentTestRun != null && goldenTestRun != null)
            {
                // For transactions to work, we cannot close the connection after each command
                if (this.m_connectType == ConnectionType.AutoCloseConnection)
                {
                    this.m_connectType = ConnectionType.CacheConnection;
                }

                // Open the connection if neccessary
                if (Connection.State == System.Data.ConnectionState.Closed)
                {
                    Connection.Open();
                }

                ArrayList addList = new ArrayList();
                ArrayList deleteList = new ArrayList();
                ArrayList updateList = new ArrayList();


                using (SqlCommandCollection col = new SqlCommandCollection())
                {

                    for (int i = 0; i < Math.Max(currentTestRun.AssignmentsGroup.Count, goldenTestRun.AssignmentsGroup.Count); i++)
                    {

                        goldenAssignments = null;
                        currentAssignments = null;
                        addList.Clear();
                        deleteList.Clear();
                        updateList.Clear();

                        if (goldenTestRun.AssignmentsGroup.Count > i)
                        {
                            goldenAssignments = goldenTestRun.AssignmentsGroup[i] as AssignmentCollection;
                        }

                        if (currentTestRun.AssignmentsGroup.Count > i)
                        {
                            currentAssignments = currentTestRun.AssignmentsGroup[i] as AssignmentCollection;
                        }


                        if (goldenAssignments != null && currentAssignments != null)
                        {

                            localAssignments = currentAssignments.Clone();

                            //Get the delta of the golden copy(DB) and the currentCopy
                            foreach (Assignment assign in goldenAssignments)
                            {
                                if (currentAssignments.Contains(assign))
                                {
                                    index = currentAssignments.IndexOf(assign);
                                    if (index != -1)
                                    {
                                        assignment = currentAssignments[index];
                                        if (assignment != null && assignment.Changed)
                                        {
                                            updateList.Add(assignment);

                                        }

                                        localAssignments.Remove(assign);
                                    }
                                }
                                else
                                {
                                    deleteList.Add(assign);
                                    localAssignments.Remove(assign);
                                }
                            }


                            //Remaining assignments would be a create
                            foreach (Assignment assign in localAssignments)
                            {
                                //Get the TestCase ID
                                TFxCase testCase = assign.TestCase as TFxCase;

                                if (testCase != null)
                                {
                                    addList.Add(assign);

                                }
                            }
                        }
                        else if (goldenAssignments != null)
                        {
                            foreach (Assignment assign in goldenAssignments)
                            {
                                deleteList.Add(assign);
                            }
                        }
                        else if (currentAssignments != null)
                        {
                            foreach (Assignment assign in currentAssignments)
                            {
                                addList.Add(assign);
                            }
                        }



                        foreach (Assignment assign in addList)
                        {

                            TFxCase testCase = assign.TestCase as TFxCase;

                            //Create New Test Assignment
                            col.Add(CreateNewTestAssignment(labrungid, i, assign.AssignmentId, testCase.TestGid, usergid));

                            //Add the config to the Test Assignment
                            configs = assign.ConfigData.GetAllConfigs();

                            AddReleaseInfoToAssignmentConfig(configs, currentTestRun.TestBuild.TestRelease.ReleaseName);

                            AddAssignmentConfig(labrungid, assign.AssignmentId, configs, col);
                        }

                        foreach (Assignment assign in updateList)
                        {
                            configs = assign.ConfigData.GetAllConfigs();
                            AddReleaseInfoToAssignmentConfig(configs, currentTestRun.TestBuild.TestRelease.ReleaseName);
                            UpdateAssignment(labrungid, assign, i, configs, col);
                        }

                        foreach (Assignment assign in deleteList)
                        {
                            col.Add(DeleteAssignment(labrungid, assign.AssignmentId));
                        }

                    }


                    SqlCommand complexCommand = col.GetSqlComplexCommand();

                    if (complexCommand.CommandText != "")
                    {
                        complexCommand.Connection = Connection;
                        object result = ExecuteScalar(complexCommand, Connection);
                    }
                    else
                    {
                        Connection.Close();
                    }

                }


            }

        }

        /// <summary>
        /// This function will update the assignment Test Case Id
        /// This is used by the TFxBackUp tool for now
        /// </summary>
        /// <param name="testRun"></param>
        public void UpdateAssignmentTestCaseIds(TestRun testRun, string buildName)
        {
            if (testRun == null)
            {
                return;
            }

            Hashtable testCaseFullPaths = new Hashtable();

            foreach (Assignment assign in testRun.Assignments)
            {
                if (assign.TestCase != null)
                {
                    if (!testCaseFullPaths.Contains(assign.TestCase.FullName))
                    {
                        SimpleSQLQuery query = new SimpleSQLQuery("TFx16_TestCases");
                        query.AddParam("buildname", buildName);
                        query.AddParam("fullpath", assign.TestCase.FullName);
                        DataTable dt = query.Execute(this.Connection);

                        if (dt != null && dt.Rows.Count != 0)
                        {
                            testCaseFullPaths.Add(assign.TestCase.FullName, dt.Rows[0]["testid"]);
                        }
                        else
                        {
                            continue;
                        }

                    }


                    TFxCase testCase = assign.TestCase as TFxCase;
                    testCase.TestGid = new Guid(testCaseFullPaths[assign.TestCase.FullName].ToString());
                }
            }


            foreach (Assignment assign in testRun.Assignments)
            {
                if (assign.TestCase != null)
                {
                    if (!testCaseFullPaths.Contains(assign.TestCase.FullName))
                    {
                        SimpleSQLQuery query = new SimpleSQLQuery("TFx16_TestCases");
                        query.AddParam("buildname", buildName);
                        query.AddParam("fullpath", assign.TestCase.FullName);
                        DataTable dt = query.Execute(this.Connection);

                        if (dt != null && dt.Rows.Count != 0)
                        {
                            testCaseFullPaths.Add(assign.TestCase.FullName, dt.Rows[0]["testgid"]);
                        }
                        else
                        {
                            continue;
                        }

                    }

                    TFxCase testCase = assign.TestCase as TFxCase;
                    testCase.TestGid = new Guid(testCaseFullPaths[assign.TestCase.FullName].ToString());
                }
            }
        }
        /// <summary>
        /// Comments:	Changed testid to testgid
        /// Comments:	Changed UserId from Int to GUID
        /// </summary>
        /// <param name="testRun"></param>
        public void AddAssignmentInfo(TestRun testRun)
        {
            //			int labrunid;
            //
            //Used to get the asssignmentId for each Assignment
            int assignmentId = 0;

            // For transactions to work, we cannot close the connection after each command
            if (this.m_connectType == ConnectionType.AutoCloseConnection)
            {
                this.m_connectType = ConnectionType.CacheConnection;
            }

            // Open the connection if neccessary
            if (Connection.State == System.Data.ConnectionState.Closed)
            {
                Connection.Open();
            }


            using (SqlCommandCollection col = new SqlCommandCollection())
            {
                for (int i = 0; i < testRun.AssignmentsGroup.Count; i++)
                {
                    AssignmentCollection assignments = testRun.AssignmentsGroup[i] as AssignmentCollection;

                    foreach (Assignment assign in assignments)
                    {

                        //Save the assignmentId
                        assign.AssignmentId = assignmentId;

                        //Get the TestCase ID
                        TFxCase testCase = assign.TestCase as TFxCase;

                        if (testCase != null)
                        {

                            SqlCommand assignmentCommand = this.CreateNewTestAssignment(testRun.LabRunGid, i, assignmentId, testCase.TestGid, testRun.Manager.usergid);
                            col.Add(assignmentCommand);

                            //Increment the AssignmentId
                            IConfig[] configs = assign.ConfigData.GetAllConfigs();

                            AddReleaseInfoToAssignmentConfig(configs, testRun.TestBuild.TestRelease.ReleaseName);

                            AddAssignmentConfig(testRun.LabRunGid, assignmentId, configs, col);
                        }


                        assignmentId++;
                    }

                    if (col.Count > 0)
                    {
                        SqlCommand complexCommand = col.GetSqlComplexCommand();
                        complexCommand.Connection = Connection;
                        object result = ExecuteScalar(complexCommand, Connection);
                        col.Clear();
                    }


                }
            }


        }

        private void AddReleaseInfoToAssignmentConfig(IConfig[] configs, string releaseName)
        {
            StringConfig strconfig = configs[0] as StringConfig;
            strconfig[TFxConst.c_ReleaseInfo] = releaseName;
        }


        /// <summary>
        /// Comments:	Changed testid to testgid, int to GUID
        /// Comments:	Changed UserId from Int to GUID
        /// Comments: changed labrunid to GUID labrungid
        /// </summary>
        /// <param name="labrungid"></param>
        /// <param name="assignmentgroup"></param>
        /// <param name="assignmentId"></param>
        /// <param name="testgid"></param>
        /// <param name="assignedtoid"></param>
        /// <returns></returns>

        public SqlCommand CreateNewTestAssignment(Guid labrungid, int assignmentgroup, int assignmentId, Guid testgid, Guid assignedtogid)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "TFx16_CreateNewTestAssignment";
            cmd.CommandType = CommandType.StoredProcedure;
            (cmd.Parameters.AddWithValue("@testgid", SqlDbType.UniqueIdentifier)).Value = testgid;
            (cmd.Parameters.AddWithValue("@labrungid", SqlDbType.UniqueIdentifier)).Value = labrungid;
            (cmd.Parameters.AddWithValue("@assignmentid", SqlDbType.Int)).Value = assignmentId;
            (cmd.Parameters.AddWithValue("@assignmentgroup", SqlDbType.Int)).Value = assignmentgroup;
            (cmd.Parameters.AddWithValue("@assignedtogid", SqlDbType.UniqueIdentifier)).Value = assignedtogid;
            cmd.Connection = Connection;


            return cmd;
        }

        /* changed labrunid to GUID labrungid */
        public void UpdateAssignment(Guid labrunGid, Assignment assignment, int assignmentGroup, IConfig[] configs)
        {
            using (SqlCommandCollection col = new SqlCommandCollection())
            {
                UpdateAssignment(labrunGid, assignment, assignmentGroup, configs, col);

                SqlCommand cmd = col.GetSqlComplexCommand();
                cmd.Connection = Connection;
                object result = ExecuteScalar(cmd, Connection);

            }
        }

        /// <summary>
        /// Comments:	Changed AssignedToId from Int to GUID
        /// changed labrunid to GUID labrungid 
        /// </summary>
        /// <param name="labrunId"></param>
        /// <param name="assignment"></param>
        /// <param name="assignmentGroup"></param>
        /// <param name="configs"></param>
        /// <param name="col"></param>
        public void UpdateAssignment(Guid labrunGid, Assignment assignment, int assignmentGroup, IConfig[] configs, SqlCommandCollection col)
        {
            if (assignment != null && labrunGid != Guid.Empty)
            {
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = "TFx16_UpdateAssignment";
                cmd.CommandType = CommandType.StoredProcedure;
                (cmd.Parameters.AddWithValue("@labrungid", SqlDbType.UniqueIdentifier)).Value = labrunGid;
                (cmd.Parameters.AddWithValue("@assignmentId", SqlDbType.Int)).Value = assignment.AssignmentId;
                (cmd.Parameters.AddWithValue("@assignmentGroup", SqlDbType.Int)).Value = assignmentGroup;
                (cmd.Parameters.AddWithValue("@assignmentStatusId", SqlDbType.Int)).Value = (int)Enum.Parse(typeof(AssignmentStatusType), assignment.RunStatus.ToString());
                (cmd.Parameters.AddWithValue("@failureReason", SqlDbType.NVarChar)).Value = DBNull.Value;
                (cmd.Parameters.AddWithValue("@errorTypeName", SqlDbType.VarChar)).Value = DBNull.Value;
                (cmd.Parameters.AddWithValue("@assignedtogid", SqlDbType.UniqueIdentifier)).Value = DBNull.Value;
                if (assignment.Result != null)
                {
                    cmd.Parameters["@failureReason"].Value = assignment.Result.FailureReason;
                    cmd.Parameters["@errorTypeName"].Value = assignment.Result.ErrorTypeName;
                }
                if (assignment.AssignedTo != null)
                {
                    cmd.Parameters["@assignedtogid"].Value = assignment.AssignedTo.usergid;
                }

                col.Add(cmd);

                if (configs != null)
                {
                    col.Add(DeleteAssignmentConfig(labrunGid, assignment.AssignmentId));
                    AddAssignmentConfig(labrunGid, assignment.AssignmentId, configs, col);
                }
            }

        }

        /* changed labrunid to GUID labrungid */
        public SqlCommand DeleteAssignment(Guid labrungid, int assignmentId)
        {
            //Cascading delete will delete the data from the assignment config and assignment config data
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "TFx16_DeleteAssignment";
            cmd.CommandType = CommandType.StoredProcedure;
            (cmd.Parameters.AddWithValue("@labrungid", SqlDbType.UniqueIdentifier)).Value = labrungid;
            (cmd.Parameters.AddWithValue("@assignmentid", SqlDbType.Int)).Value = assignmentId;
            return cmd;
        }

        /* changed labrunid to GUID labrungid */
        public SqlCommand DeleteAssignmentConfig(Guid labrungid, int assignmentId)
        {
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "TFx16_DeleteAssignmentConfigData";
            cmd.CommandType = CommandType.StoredProcedure;
            (cmd.Parameters.AddWithValue("@labrungid", SqlDbType.UniqueIdentifier)).Value = labrungid;
            (cmd.Parameters.AddWithValue("@assignmentid", SqlDbType.Int)).Value = assignmentId;

            return cmd;

        }

        /* changed labrunid to GUID labrungid */
        public void AddAssignmentConfig(Guid labrungid, int assignmentId, IConfig[] configs, SqlCommandCollection col)
        {
            string configname = "";
            string configvalue = "";

            if ((assignmentId != -1) && (configs != null) && (configs.Length > 0))
            {

                StringConfig strconfig = configs[0] as StringConfig;

                foreach (object keys in strconfig.Config.Keys)
                {
                    configname = keys.ToString();
                    configvalue = strconfig.Config[keys].ToString();

                    SqlCommand cmd = new SqlCommand();

                    cmd.CommandText = "TFx16_AddAssignmentConfigData";
                    cmd.CommandType = CommandType.StoredProcedure;
                    (cmd.Parameters.AddWithValue("@labrungid", SqlDbType.UniqueIdentifier)).Value = labrungid;
                    (cmd.Parameters.AddWithValue("@assignmentid", SqlDbType.Int)).Value = assignmentId;
                    (cmd.Parameters.AddWithValue("@configname", SqlDbType.VarChar)).Value = configname;
                    (cmd.Parameters.AddWithValue("@configvalue", SqlDbType.NVarChar)).Value = configvalue;


                    col.Add(cmd);
                }
            }
        }

        #region Publishing

        public bool CreateTestCase(string testName, string fullpath, string moduleName, string user, long testCategory, Guid relatedtestgid, Guid buildgid)
        {

            fullpath = fullpath.Replace("\\", ".");
            fullpath = fullpath.TrimEnd('.');

            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "PUB_CreateTestCase";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@fullpath", fullpath);
                cmd.Parameters.AddWithValue("@owner", user);
                cmd.Parameters.AddWithValue("@testname", testName);
                cmd.Parameters.AddWithValue("@description", "");
                cmd.Parameters.AddWithValue("@testcategory", testCategory);
                cmd.Parameters.AddWithValue("@modulename", moduleName);
                cmd.Parameters.AddWithValue("@buildgid", buildgid);
                if (relatedtestgid != Guid.Empty)
                {
                    cmd.Parameters.AddWithValue("@relatedtestgid", relatedtestgid);
                }
                else
                {
                    cmd.Parameters.AddWithValue("@relatedtestgid", DBNull.Value);
                }
                cmd.Parameters.AddWithValue("@testgid", Guid.Empty);
                cmd.Parameters["@testgid"].Direction = ParameterDirection.Output;
                cmd.Connection = Connection;

                ExecuteScalar(cmd, Connection);


                if (cmd.Parameters["@testgid"].Value != null)
                {
                    Guid testId = new Guid(cmd.Parameters["@testgid"].Value.ToString());
                    return true;
                }
            }

            return false;
        }

        public int MoveTestCase(string testName1, string testArea1, long testCategory1, string testName2, string testArea2, long testCategory2, string user)
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "PUB_MoveTestCase";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@testName1", testName1);
                cmd.Parameters.AddWithValue("@testArea1", testArea1);
                cmd.Parameters.AddWithValue("@testCategory1", testCategory1);
                cmd.Parameters.AddWithValue("@testName2", testName2);
                cmd.Parameters.AddWithValue("@testArea2", testArea2);
                cmd.Parameters.AddWithValue("@testCategory2", testCategory2);
                cmd.Parameters.AddWithValue("@owner", user);
                cmd.Connection = Connection;

                object ret = ExecuteScalar(cmd, Connection);
                if (ret != null)
                {
                    return 1;
                }
                else
                {
                    throw new Exception(String.Format("Error moving test case: '{0}.{1}' to '{2}.{3}'", testArea1, testName1, testArea2, testName2));
                }
            }
        }

        public void DeleteTestCase(string fullname)
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "PUB_DeleteTestCase";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@fullname", fullname);
                cmd.Connection = Connection;
                object result = ExecuteScalar(cmd, Connection);
            }
        }

        /// <summary>
        /// Comments: Changed the TestBuild id to buildgid
        /// Comments: Changed testid to testgid, int to GUID
        /// Comments: 	Changed the related test id from int to GUID
        /// Comments:	Changed UserId from Int to GUID
        /// 
        /// </summary>
        /// <param name="testBuild"></param>
        /// <param name="changes"></param>
        public void PublishTestCases(TestBuild testBuild, RepositoryChangelist changes)
        {
            if (this.m_connectType == ConnectionType.AutoCloseConnection)
            {
                this.m_connectType = ConnectionType.CacheConnection;
            }

            // Open the connection if neccessary
            if (Connection.State == System.Data.ConnectionState.Closed)
            {
                Connection.Open();
            }

            try
            {

                foreach (TestCaseChange change in changes)
                {

                    if (change.RequestType == RepositoryRequestType.Create)
                    {
                        // we are hardcoding to publishing to Latest build

                        // If TestCase Owener is empty we are using who ever is logged into TFx Builder
                        // This seems wrong and probablly needs to be fixed
                        if (String.IsNullOrEmpty(change.NewTestCase.Owner))
                        {
                            change.NewTestCase.Owner = System.Security.Principal.WindowsIdentity.GetCurrent().Name.ToString();
                        }

                        // Add the test case to the database
                        CreateTestCase(
                            change.NewTestCase.Name,
                            change.NewTestCase.Path,
                            change.NewTestCase.ModuleName,
                            change.NewTestCase.Owner,
                            change.NewTestCase.TestCategory,
                            change.NewTestCase.RelatedTestGid,
                            testBuild.BuildGid);

                    }
                    else if (change.RequestType == RepositoryRequestType.Delete)
                    {
                        DeleteTestCase(change.OldTestCase.FullName);
                    }
                    else if (change.RequestType == RepositoryRequestType.Update)
                    {
                        // If TestCase Owener is empty we are using who ever is logged into TFx Builder
                        // This seems wrong and probablly needs to be fixed
                        if (String.IsNullOrEmpty(change.NewTestCase.Owner))
                        {
                            change.NewTestCase.Owner = System.Security.Principal.WindowsIdentity.GetCurrent().Name.ToString();
                        }

                        MoveTestCase(
                            change.OldTestCase.Name, change.OldTestCase.Path, change.OldTestCase.TestCategory,
                            change.NewTestCase.Name, change.NewTestCase.Path, change.NewTestCase.TestCategory,
                            change.NewTestCase.Owner);
                    }
                }

                Connection.Close();
                this.m_connectType = ConnectionType.AutoCloseConnection;
            }
            catch (Exception e)
            {
                // Error occurred, so discard changes and close connection
                Connection.Close();
                this.m_connectType = ConnectionType.AutoCloseConnection;

                // Rethrow exception to be caught by calling function
                throw e;
            }
        }

        #endregion

    }
}
