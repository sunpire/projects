using System;
using System.Net.Mail;
using System.Collections.Generic;


namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TFxMail.
	/// </summary>
	public class TFxMail : IDisposable
	{
		//TODO:  might think of reading this information from a config
        private string[] m_smtpServer = { "10.95.0.30", "172.30.31.21", "10.1.1.161", "10.1.1.162"};

		public TFxMail()
		{
		}

		const string c_defaultEmailFrom = "TFxReport@expedia.com";
		const string c_defaultEmailSubject = "Lab Run Report";

        List<Attachment> attachments = new List<Attachment>();

        public void AddAttachment(string path)
        {
            if (System.IO.File.Exists(path))
            {
                /*
                System.IO.FileStream fileStream = new System.IO.FileStream(path, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                System.IO.MemoryStream memoryStream = new System.IO.MemoryStream((int)fileStream.Length);
                fileStream.Read(memoryStream.GetBuffer(), 0, (int)fileStream.Length);
                */

                this.attachments.Add(new Attachment(path));
            } // if
        }

        public void AddAttachment(string name, string str)
        {
            byte[] intoBytes = System.Text.Encoding.Unicode.GetBytes(str);
            System.IO.MemoryStream ms = new System.IO.MemoryStream(intoBytes);           
            this.attachments.Add(new Attachment(ms, name));            
        }

		public void Send(string emailTo, string message)
		{
			Send(c_defaultEmailFrom, emailTo, "TFx LabRunReport - " + message, "Result");
		}

		public void Send(string emailFrom, string emailTo, string emailSubject, string message)
		{
			Send(emailFrom, emailTo, emailSubject, message, this.attachments);
		}

		public void Send(string emailFrom, string emailTo, string emailSubject, string message, List<Attachment> attachments)
		{
            // MailMessage supports comma address delimiters--we'll support semi-colons AND commas
            emailTo = emailTo.Replace(';', ',');

            using (MailMessage mailMsg = new MailMessage())
            {
                mailMsg.From = new MailAddress(emailFrom);
                mailMsg.Subject = emailSubject;
                mailMsg.Body = message;
                mailMsg.To.Add(emailTo);
                mailMsg.IsBodyHtml = true;

                if (this.attachments != null)
                {
                    this.attachments.ForEach(
                        delegate(Attachment attachment)
                        {
                            mailMsg.Attachments.Add(attachment);
                        }
                    );
                }

                for (int i = 0; i < m_smtpServer.Length; i++)
                {
                    try
                    {
                        SmtpClient smtp = new SmtpClient();
                        smtp.Host = m_smtpServer[i];
                        smtp.Send(mailMsg);

                        Console.WriteLine("Email has been sent to {0}\n", emailTo);
                        return;
                    }
                    catch (SmtpFailedRecipientsException)
                    {
                        throw; // One or more addresses was invalid--don't bother retrying
                    }
                    catch (SmtpException)
                    {
                        Console.WriteLine("SMTP server: {0} failed.", m_smtpServer[i]);
                    }
                }
            }

            throw new Exception("SMTP servers all failed. Cannot send mail to " + emailTo);
		}

        #region IDisposable Members

        public void Dispose()
        {
            // Dispose any attachments
            attachments.ForEach(
                delegate(Attachment attachment)
                {
                    attachment.Dispose();
                }
            );

            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
