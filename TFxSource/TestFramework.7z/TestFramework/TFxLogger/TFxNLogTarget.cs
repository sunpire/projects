﻿
using System;
using System.Collections;
using System.Collections.Generic;
using Expedia.Test.Framework.Log;
using NLog;
using NLog.Targets;
namespace Expedia.Test.Framework
{
    /// <summary>
    /// TFx NLog Target
    /// </summary>
    [Target("TFxNLogTarget")]
    public class TFxNLogTarget : TargetWithLayout
    {
        IList<IDirectLog> directLogs = null;

        /// <summary>
        /// Initialize Target
        /// </summary>
        protected override void InitializeTarget()
        {
            try
            {
                directLogs = InitializeTFxLogger();
            }
            catch (Exception e)
            {
                // Eat up any exceptions thrown by initializing the log.
                // TODO: Write log to the right place.
                Console.WriteLine("Failed to initialize logger: {0}", e);
            }

            base.InitializeTarget();
        }

        /// <summary>
        /// Close Target
        /// </summary>
        protected override void CloseTarget()
        {
            try
            {
                // cleanup the loggers.
                if (directLogs != null && directLogs.Count > 0)
                {
                    foreach (var directLog in directLogs)
                    {
                        CleanupLogger(directLog);
                    }
                }
            }
            catch (Exception e)
            {
                // Eat up any exceptions thrown by cleaning up the log.
                // TODO: Write log to the right place.
                Console.WriteLine("Failed to cleanup logger: {0}", e);
            }

            base.CloseTarget();
        }

        /// <summary>
        /// Write log
        /// </summary>
        protected override void Write(LogEventInfo logEvent)
        {
            var logMessage = this.Layout.Render(logEvent).Split(new char[] { '|' });

            switch (logEvent.Level.ToString().ToLower())
            {
                case "trace":
                case "debug":
                case "info":
                    Logger.Instance.WriteInfo(logMessage[logMessage.Length - 1]);
                    break;
                case "warn":
                    Logger.Instance.WriteWarning(logMessage[logMessage.Length - 1]);
                    break;
                case "error":
                case "fatal":
                    Logger.Instance.WriteError(logMessage[logMessage.Length - 1]);
                    break;
            }
            //Logger.Instance.Write(LogLevelType.TFx, logMessage[logMessage.Length - 1]);
        }

        /// <summary>
        /// Initialize TFxLogger
        /// </summary>
        private static IList<IDirectLog> InitializeTFxLogger()
        {
            // make sure logger is not already initialized.
            if (Logger.IsInitialized)
            {
                throw new InvalidOperationException("Logger has already been initialized.");
            }

            // initialize useful variables
            IList<IDirectLog> directLogs = new List<IDirectLog>();
            string logType = Environment.GetEnvironmentVariable("lrm.__LogType");
            logType = string.IsNullOrWhiteSpace(logType) ? "FileLog" : logType;

            string logInfo = Environment.GetEnvironmentVariable("lrm.__LogInfo");
            logInfo = string.IsNullOrWhiteSpace(logInfo) ? "Log" : logInfo;

            string labrunName = Environment.GetEnvironmentVariable("lrm.__labrunname");
            labrunName = string.IsNullOrWhiteSpace(labrunName) ? "DefaultLabRun" : labrunName;

            string labrunId = Environment.GetEnvironmentVariable("lrm.__labrunid");
            labrunId = string.IsNullOrWhiteSpace(labrunId) ? "-1" : labrunId;

            string assignmentId = Environment.GetEnvironmentVariable("lrm.__assignmentid");
            assignmentId = string.IsNullOrWhiteSpace(assignmentId) ? "0" : assignmentId;

            string logSystem = Environment.GetEnvironmentVariable("lrm.__LogSystem");
            logSystem = string.IsNullOrWhiteSpace(logSystem) ? string.Empty : logSystem;

            var logLevelString = Environment.GetEnvironmentVariable("lrm.__loglevel");
            logLevelString = string.IsNullOrWhiteSpace(logLevelString) ? "Default" : logLevelString;

            LogLevelType logLevel = (LogLevelType)Enum.Parse(typeof(LogLevelType), logLevelString, true);

            if (logSystem.Contains("DBLog"))
            {
                // try to parse the assignment id (defaults to 0)
                int numericAssignmentId;
                int.TryParse(assignmentId, out numericAssignmentId);

                // create the database log
                DirectDBLog databaseLog = new DirectDBLog();
                databaseLog.AssignmentId = numericAssignmentId;
                databaseLog.LabrunId = int.Parse(labrunId);
                databaseLog.ConnectString = logInfo;
                IDirectLog directLog = new AsyncLog(databaseLog);
                directLog.Start();
                directLogs.Add(directLog);
                Logger.Instance.AttachLogListener(logLevel, directLog);
            }
            else
            {
                // default log type is file log unless otherwise specified
                DirectFileLog fileLog = new DirectFileLog(string.Format("{0}\\{1}.{2}.xml", logInfo, labrunName, assignmentId));
                IDirectLog directLog = new AsyncLog(fileLog);
                directLog.Start();
                directLogs.Add(directLog);
                Logger.Instance.AttachLogListener(logLevel, directLog);
            }

            var realtimelog = Environment.GetEnvironmentVariable("lrm.realtimelog");
            realtimelog = string.IsNullOrWhiteSpace(realtimelog) ? bool.FalseString : realtimelog;

            bool enableRealTimeLogger = false;
            bool.TryParse(realtimelog, out enableRealTimeLogger);

            if (enableRealTimeLogger)
            {
                Logger.Instance.AttachLogListener(
                    LogLevelType.TestApi | LogLevelType.Test | LogLevelType.ExpWeb | LogLevelType.TFx,
                    RealTimeLogger.Instance);
            }

            // return the directlog object
            return directLogs;
        }

        /// <summary>
        /// Cleanup Logger
        /// </summary>
        private static void CleanupLogger(IDirectLog directLog)
        {
            // make sure direct log exists before detaching it.
            if (directLog != null)
            {
                // end the direct log.
                directLog.End();

                // detach it from the logger.
                Logger.Instance.DetachLogListener(directLog);
            }

            if (RealTimeLogger.IsInitialized)
            {
                Logger.Instance.DetachLogListener(RealTimeLogger.Instance);
                RealTimeLogger.Instance.Dispose();
            }
        }
    }
}
