
namespace Expedia.Test.Framework
{
    /// <summary>
    /// Specifies the level of logging that a particular entry is being made at.
    /// </summary>
    public enum LogLevelType : long
    {
        /// <summary>
        /// None
        /// </summary>
        None = 0,

        /// <summary>
        /// Web browser log
        /// Browser Events
        /// </summary>
        Browser = 1 + 2 + 4,

        /// <summary>
        /// Web browser log
        /// Browser Events
        /// </summary>
        BrowserHtml = 2,

        /// <summary>
        /// Web browser log
        /// Page as picture on each page complete
        /// </summary>
        BrowserPicture = 4,

        /// <summary>
        /// Web browser log
        /// Raw Html on page not as requested.
        /// </summary>
        ErrorHtml = 8,

        /// <summary>
        /// Web browser log
        /// Page as picture on error page.
        /// </summary>
        ErrorPicture = 16,

        /// <summary>
        /// Raw HTML
        /// </summary>
        Html = 128,

        /// <summary>
        /// Picture of HTML
        /// </summary>
        Picture = 256,

        /// <summary>
        ///  Default log settings - Html, Picture, ExpWeb, Test, TestApi, TFxConfig
        /// </summary>
        Default = 128 + 1024 + 2048 + 4096 + 64 + 32768 + 16384,

        /// <summary>
        /// TFx genral log
        /// </summary>
        TFx = 64 + 32,

        /// <summary>
        /// TFx Client Logs
        /// </summary>
        TFxClient = 32,
        /// <summary>
        /// All config related logs
        /// </summary>
        TFxConfig = 64,


        //external to TFX and automation starts here

        /// <summary>
        ///Level 0: Page IDs for all pages apearing in the browser
        /// </summary>
        ExpWeb = 1024,

        /// <summary>
        /// Log from api functions
        /// </summary>
        TestApi = 2048,

        /// <summary>
        /// Test module log
        /// </summary>
        Test = 4096,

        /// <summary>
        /// Template Based Automation
        /// </summary>
        TBA = 8192,

        /// <summary>
        /// Log for WebService XML Calls
        /// </summary>
        WebService = 5120,

        /// <summary>
        /// SOA Message
        /// </summary>
        SOAMessage = 16384,

        /// <summary>
        /// SOA log
        /// </summary>
        SOA = 32768 + 16384,

        /// <summary>
        /// SOA RawMessage log
        /// </summary>
        SOARawMessage = 65536,

        /// <summary>
        /// All
        /// </summary>
        All = 0x7fffffffffffffff
    }
}
