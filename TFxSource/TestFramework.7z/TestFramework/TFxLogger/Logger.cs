using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Allows tests to log messages during execution.
    /// </summary>
    [Serializable]
    public sealed class Logger
    {
        #region Constructor
        /// <summary>
        /// Initializes the logger one and only logger.
        /// </summary>
        private Logger()
        {
            // initialize the listeners
            listeners = new List<LogListener>();
            // initialize the auto entry id
            autoEntryID = 0;
            isInitialized = true;
        }
        #endregion

        #region Properties

        /// <summary>
        /// Gets the Logger singleton instance.
        /// </summary>
        public static Logger Instance
        {
            get
            {
                lock (padlock)
                {
                    if (instance == null)
                    {
                        instance = new Logger();
                    }
                    else if (!isInitialized)
                    {
                        throw new InvalidOperationException("Logger has not been initialized.");
                    }
                    return instance;
                }
            }
        }

        public String logFilePath = null;

        #endregion

        /// <summary>
        /// Write this entry to log.
        /// </summary>
        /// <param name="entry">The log entry to write.</param>
        private void Write(LogEntry entry)
        {
            // add the auto incrementing entry id
            entry.EntryId = autoEntryID;
            autoEntryID++;

            // notify all listeners
            foreach (LogListener log in this.listeners)
            {
                log.Add(entry);
            }
        }

        /// <summary>
        /// Creates a log entry based on the given parameters.
        /// </summary>
        /// <param name="frame">A reference to a stack frame to log from.</param>
        /// <param name="severity">The severity type of the log (info, error, warning).</param>
        /// <param name="level">The level of the log.</param>
        /// <param name="type">The type of log (plain text, html, picture).</param>
        /// <param name="array">The array of bytes.</param>
        /// <param name="message">The log message text.</param>
        /// <param name="args">Any formatting argument for the message text.</param>
        /// <returns>A LogEntry object.</returns>
        private LogEntry CreateEntry(StackFrame frame, SeverityType severity, LogLevelType level, LogViewType logType, EntryType type, byte[] array, string message, params object[] args)
        {
            // gather useful information
            System.Reflection.MethodBase method = frame.GetMethod();
            string fullFunctionName = string.Concat(method.DeclaringType.FullName, '.', method.Name);
            string moduleName = method.DeclaringType.Assembly.Location;

            LogEntry entry;

            if (args.Length == 0)
            {
                entry = new LogEntry(severity, level, logType, message, moduleName, fullFunctionName, type, array);
            }
            else
            {
                entry = new LogEntry(severity, level, logType, string.Format(message, args), moduleName, fullFunctionName, type, array);
            }
            return entry;
        }


        /// <summary>
        /// Gets whether the logger is initialized.
        /// </summary>
        public static bool IsInitialized
        {
            get
            {
                return isInitialized;
            }
        }

        #region Public Logging Methods

        /// <summary>
        /// Writes an information long log entry to the log handle associated with this test.
        /// </summary>
        /// <param name="description">The text description to write to the log.</param>
        /// <param name="args">The arguments passed to the description.</param>
        public void WriteInfo(string description, params object[] args)
        {
            WriteInfo(description, LogViewType.LongLogOnly, args);
        }

        /// <summary>
        /// Writes an information log entry to the log handle associated with this test.
        /// </summary>
        /// <param name="description">The text description to write to the log.</param>
        /// <param name="logViewType">The arguments passed to the log type, LongAndShortLog or LongLogOnly.</param>
        /// <param name="args">The arguments passed to the description.</param>
        public void WriteInfo(string description, LogViewType logViewType, params object[] args)
        {
            StackFrame frame = new StackFrame(1, true);
            this.Write(frame, SeverityType.Info, LogLevelType.Test, logViewType, description, args);
        }

        /// <summary>
        /// Writes an error log entry to the log handle associated with this test.
        /// </summary>
        /// <param name="description">The text description to write to the log.</param>
        /// <param name="args">The arguments passed to the description.</param>
        public void WriteError(string description, params object[] args)
        {
            WriteError(description, LogViewType.LongLogOnly, args);
        }

        /// <summary>
        /// Writes an error log entry to the log handle associated with this test.
        /// </summary>
        /// <param name="description">The text description to write to the log.</param>
        /// <param name="logViewType">The arguments passed to the log type, LongAndShortLog or LongLogOnly.</param>
        /// <param name="args">The arguments passed to the description.</param>
        public void WriteError(string description, LogViewType logViewType, params object[] args)
        {
            StackFrame frame = new StackFrame(1, true);
            this.Write(frame, SeverityType.Error, LogLevelType.Test, logViewType, description, args);
        }

        /// <summary>
        /// Writes a warning long log entry to the log handle associated with this test.
        /// </summary>
        /// <param name="description">The text description to write to the log.</param>
        /// <param name="args">The arguments passed to the description.</param>
        public void WriteWarning(string description, params object[] args)
        {
            WriteWarning(description, LogViewType.LongLogOnly, args);
        }

        /// <summary>
        /// Writes a warning log entry to the log handle associated with this test.
        /// </summary>
        /// <param name="description">The text description to write to the log.</param>
        /// <param name="logViewType">The arguments passed to the log type, LongAndShortLog or LongLogOnly.</param>
        /// <param name="args">The arguments passed to the description.</param>
        public void WriteWarning(string description, LogViewType logViewType, params object[] args)
        {
            StackFrame frame = new StackFrame(1, true);
            this.Write(frame, SeverityType.Warning, LogLevelType.Test, logViewType, description, args);
        }

        /// <summary>
        /// Writes a binary array to the log.
        /// </summary>
        /// <param name="severity">The severity type of the log (info, error, warning).</param>
        /// <param name="level">The level of the log.</param>
        /// <param name="logViewType">The arguments passed to the log type, LongAndShortLog or LongLogOnly.</param>
        /// <param name="array">The array of bytes.</param>
        /// <param name="type">The type of log (plain text, html, picture).</param>
        public void WriteBinary(SeverityType severity, LogLevelType level, byte[] array, EntryType type, ImageInfo info)
        {
            WriteBinary(severity, level, LogViewType.LongLogOnly, array, type, info);
        }

        /// <summary>
        /// Writes a binary array to the log.
        /// </summary>
        /// <param name="severity">The severity type of the log (info, error, warning).</param>ok
        /// <param name="level">The level of the log.</param>
        /// <param name="logViewType">The arguments passed to the log type, LongAndShortLog or LongLogOnly.</param>
        /// <param name="array">The array of bytes.</param>
        /// <param name="type">The type of log (plain text, html, picture).</param>
        public void WriteBinary(SeverityType severity, LogLevelType level, LogViewType logViewType, byte[] array, EntryType type, ImageInfo info)
        {
            // generate a stack frame
            StackFrame frame = new StackFrame(1, true);
            LogEntry entry = this.CreateEntry(frame, severity, level, logViewType, type, array, string.Empty);
            entry.ImageInfo = info;
            // write to the log
            this.Write(entry);
        }

        /// <summary>
        /// Writes a HTML log entry with the specified html string.
        /// </summary>
        /// <param name="html">The html text to write.</param>
        public void WriteHtml(string html)
        {
            WriteHtml(html, LogViewType.LongLogOnly);
        }

        /// <summary>
        /// Writes a HTML log entry with the specified html string.
        /// </summary>
        /// <param name="html">The html text to write.</param>
        /// <param name="logViewType">The arguments passed to the log type, LongAndShortLog or LongLogOnly.</param>
        public void WriteHtml(string html, LogViewType logViewType)
        {
            // generate a stack frame
            StackFrame frame = new StackFrame(1, true);

            // write to the log
            this.Write(this.CreateEntry(frame, SeverityType.Info, LogLevelType.Html, logViewType, EntryType.Html, null, html));
        }

        /// <summary>
        /// Write the fastinfoset msg to log 
        /// </summary>
        /// <param name="messageTypeName"></param>
        /// <param name="encoding"></param>
        /// <param name="isRequest"></param>
        /// <param name="content"></param>
        public void WriteFastInfoSet(string messageTypeName, bool isRequest, Encoding encoding, string content)
        {
            // Convert the string content to byte
            byte[] contentBytes = encoding.GetBytes(content);

            WriteFastInfoSet(messageTypeName, isRequest, contentBytes);
        }

        /// <summary>
        /// Write the fastinfoset msg to log
        /// </summary>
        /// <param name="messageTypeName"></param>
        /// <param name="isRequest"></param>
        /// <param name="contentBytes"></param>
        public void WriteFastInfoSet(string messageTypeName, bool isRequest, byte[] contentBytes)
        {
            String fileName = String.Empty;

            // get the message name
            int lastDotIndex = messageTypeName.LastIndexOf(".");
            if (lastDotIndex > 0)
                messageTypeName = messageTypeName.Substring(lastDotIndex + 1);

            fileName = messageTypeName;

            // check if it is request
            if (isRequest == true)
                fileName = fileName + "RQ";
            else
                fileName = fileName + "RS";

            WriteFile(fileName, contentBytes, EntryType.FastInfoSet, SeverityType.Info, LogLevelType.SOA, LogViewType.LongAndShortLog, true, true);
        }

        public void WriteFile(string fileName, Encoding encoding, string content)
        {
            // Convert the string content to byte
            byte[] contentBytes = encoding.GetBytes(content);

            WriteFile(fileName, contentBytes);
        }

        public void WriteFile(string fileName, byte[] contentBytes)
        {
            WriteFile(fileName, contentBytes, EntryType.File, SeverityType.Info, LogLevelType.SOA, LogViewType.LongAndShortLog, true, true);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="encoding"></param>
        /// <param name="content"></param>
        /// <param name="contentBytes"></param>
        /// <param name="entryType"></param>
        /// <param name="logSeverity"></param>
        /// <param name="logLevelType"></param>
        /// <param name="logViewType"></param>
        /// <param name="gZip"></param>
        /// <param name="appendGuidToFileName"></param>
        private void WriteFile(string fileName, byte[] contentBytes, EntryType entryType, SeverityType logSeverity, LogLevelType logLevelType, LogViewType logViewType, bool gZip, bool appendGuidToFileName)
        {
            // generate a stack frame
            StackFrame frame = new StackFrame(1, true);

            LogEntry entry = null;

            this.CreateEntry(frame, logSeverity, logLevelType, logViewType, entryType, contentBytes, null);


            entry.OtherInfo.Add("filename", fileName);
            entry.OtherInfo.Add("gzip", gZip);
            entry.OtherInfo.Add("appendGuidToFileName", appendGuidToFileName);
            //entry.OtherInfo.Add("Encoding", encoding);

            // write to the log
            this.Write(entry);
        }

        /// <summary>
        /// Writhes a XML log entry with the specified xml string.
        /// </summary>
        /// <param name="xml">The xml text to write</param>
        /// <param name="isRequest">isRequest</param>
        /// <param name="logLevelType">logLevelType</param>
        /// <param name="messageTypeName">messageTypeName</param>
        public void WriteXML(string messageTypeName, bool isRequest, string xml, LogLevelType logLevelType)
        {
            WriteXML(messageTypeName, isRequest, xml, logLevelType, LogViewType.LongLogOnly);
        }

        /// <summary>
        /// Writhes a XML log entry with the specified xml string.
        /// </summary>
        /// <param name="xml">The xml text to write</param>
        /// <param name="isRequest">isRequest</param>
        /// <param name="messageTypeName">messageTypeName</param>
        /// <param name="logViewType">The arguments passed to the log type, LongAndShortLog or LongLogOnly.</param>
        public void WriteXML(string messageTypeName, bool isRequest, string xml, LogLevelType logLevelType, LogViewType logViewType)
        {
            // generate a stack frame
            StackFrame frame = new StackFrame(1, true);

            LogEntry entry = this.CreateEntry(frame, SeverityType.Info, logLevelType, logViewType, EntryType.XmlFile, null, xml);

            // get the message name
            int lastDotIndex = messageTypeName.LastIndexOf(".");
            if (lastDotIndex > 0)
                messageTypeName = messageTypeName.Substring(lastDotIndex + 1);

            entry.AdditionalInfo.Add(messageTypeName);
            entry.OtherInfo.Add("messageTypeName", messageTypeName);

            String fileName = messageTypeName;

            // check if it is request
            if (isRequest == true)
            {
                entry.AdditionalInfo.Add("RQ");
                entry.OtherInfo.Add("messageType", "RQ");

                fileName = fileName + "RQ";
            }
            else
            {
                entry.AdditionalInfo.Add("RS");
                entry.OtherInfo.Add("messageType", "RS");

                fileName = fileName + "RS";
            }

            entry.AdditionalInfo.Add("text");
            entry.OtherInfo.Add("gzip", "true");
            entry.OtherInfo.Add("text", "true");
            entry.OtherInfo.Add("filename", fileName);
            entry.OtherInfo.Add("appendGuidToFileName", true);

            // write to the log
            this.Write(entry);
        }


        /// <summary>
        /// Writhes a XML log entry with the specified xml string.
        /// </summary>
        /// <param name="bytes">Bytes</param>
        /// <param name="isRequest">IsRequest</param>
        /// <param name="logLevelType">Log Level Type</param>
        /// <param name="messageTypeName">Message Type Name</param>
        public void WriteXML(string messageTypeName, bool isRequest, byte[] bytes, LogLevelType logLevelType)
        {
            WriteXML(messageTypeName, isRequest, bytes, logLevelType, LogViewType.LongLogOnly);
        }
        /// <summary>
        /// Writhes a XML log entry with the specified xml string.
        /// </summary>
        /// <param name="bytes">Bytes</param>
        /// <param name="isRequest">IsRequest</param>
        /// <param name="logLevelType">Log Level Type</param>
        /// <param name="messageTypeName">Message Type Name</param>
        /// <param name="logViewType">The arguments passed to the log type, LongAndShortLog or LongLogOnly.</param>
        public void WriteXML(string messageTypeName, bool isRequest, byte[] bytes, LogLevelType logLevelType, LogViewType logViewType)
        {
            // generate a stack frame
            StackFrame frame = new StackFrame(1, true);

            LogEntry entry = this.CreateEntry(frame, SeverityType.Info, logLevelType, logViewType, EntryType.XmlFile, null, Encoding.UTF8.GetString(bytes));

            // get the message name
            int lastDotIndex = messageTypeName.LastIndexOf(".");
            if (lastDotIndex > 0)
                messageTypeName = messageTypeName.Substring(lastDotIndex + 1);

            entry.AdditionalInfo.Add(messageTypeName);
            entry.OtherInfo.Add("messageTypeName", messageTypeName);

            String fileName = messageTypeName;

            // check if it is request
            if (isRequest == true)
            {
                entry.AdditionalInfo.Add("RQ");
                entry.OtherInfo.Add("messageType", "RQ");

                fileName = fileName + "RQ";
            }
            else
            {
                entry.AdditionalInfo.Add("RS");
                entry.OtherInfo.Add("messageType", "RS");

                fileName = fileName + "RS";
            }

            // check if it is binary
            entry.AdditionalInfo.Add("binary");
            entry.OtherInfo.Add("binary", "true");
            entry.OtherInfo.Add("gzip", "true");
            entry.OtherInfo.Add("filename", fileName);
            entry.OtherInfo.Add("appendGuidToFileName", true);
            entry.Array = bytes;

            // write to the log
            this.Write(entry);
        }

        #endregion

        /// <summary>
        /// Writes the specified array of objects to the log output output stream using the specified format information.
        /// </summary>
        /// <param name="level">Log level assigned for current log</param>
        /// <param name="message">The log message.</param>
        /// <param name="args">An array of objects to write using format.</param>
        public void Write(LogLevelType level, string message, params object[] args)
        {
            // generate a stack frame
            StackFrame frame = new StackFrame(1, true);
            this.Write(this.CreateEntry(frame, SeverityType.Info, level, LogViewType.LongLogOnly, EntryType.PlainText, null, message, args));
        }

        /// <summary>
        /// Writes the specified array of objects to the log output output stream using the specified format information.
        /// </summary>
        /// <param name="level">Log level assigned for current log</param>
        /// <param name="logViewType">The arguments passed to the log type, LongAndShortLog or LongLogOnly.</param>
        /// <param name="message">The log message.</param>
        /// <param name="args">An array of objects to write using format.</param>
        public void Write(LogLevelType level, LogViewType logViewType, string message, params object[] args)
        {
            // generate a stack frame
            StackFrame frame = new StackFrame(1, true);

            this.Write(this.CreateEntry(frame, SeverityType.Info, level, logViewType, EntryType.PlainText, null, message, args));
        }

        /// <summary>
        /// Writes the specified array of objects to the log output output stream using the specified format information.
        /// </summary>
        /// <param name="severity">The severity of the log entry.</param>
        /// <param name="level">The Log level assigned for the log entry.</param>
        /// <param name="message">The log message.</param>
        /// <param name="args">An array of objects to write using format.</param>
        public void Write(SeverityType severity, LogLevelType level, string message, params object[] args)
        {
            // generate a stack frame
            StackFrame frame = new StackFrame(1, true);

            this.Write(this.CreateEntry(frame, severity, level, LogViewType.LongLogOnly, EntryType.PlainText, null, message, args));
        }

        /// <summary>
        /// Writes the specified array of objects to the log output output stream using the specified format information.
        /// </summary>
        /// <param name="severity">The severity of the log entry.</param>
        /// <param name="level">The Log level assigned for the log entry.</param>
        /// <param name="logViewType">The arguments passed to the log type, LongAndShortLog or LongLogOnly.</param>
        /// <param name="message">The log message.</param>
        /// <param name="args">An array of objects to write using format.</param>
        public void Write(SeverityType severity, LogLevelType level, LogViewType logViewType, string message, params object[] args)
        {
            // generate a stack frame
            StackFrame frame = new StackFrame(1, true);

            this.Write(this.CreateEntry(frame, severity, level, logViewType, EntryType.PlainText, null, message, args));
        }

        /// <summary>
        /// Writes the specified array of objects to the log output output stream using the specified format information.
        /// </summary>
        /// <param name="frame">A Stack frame pointing to the origin of the log entry.</param>
        /// <param name="severity">The severity of the log entry.</param>
        /// <param name="level">The Log level assigned for the log entry.</param>
        /// <param name="message">The log message.</param>
        /// <param name="args">Args</param>
        public void Write(StackFrame frame, SeverityType severity, LogLevelType level, string message, params object[] args)
        {
            this.Write(this.CreateEntry(frame, severity, level, LogViewType.LongLogOnly, EntryType.PlainText, null, message, args));
        }

        /// <summary>
        /// Writes the specified array of objects to the log output output stream using the specified format information.
        /// </summary>
        /// <param name="frame">A Stack frame pointing to the origin of the log entry.</param>
        /// <param name="severity">The severity of the log entry.</param>
        /// <param name="level">The Log level assigned for the log entry.</param>
        /// <param name="logViewType">The arguments passed to the log type, LongAndShortLog or LongLogOnly.</param>
        /// <param name="message">The log message.</param>
        /// <param name="args">Args</param>
        public void Write(StackFrame frame, SeverityType severity, LogLevelType level, LogViewType logViewType, string message, params object[] args)
        {
            this.Write(this.CreateEntry(frame, severity, level, logViewType, EntryType.PlainText, null, message, args));
        }

        /// <summary>
        /// Writes the specified array of objects to the log output output stream using the specified format information.
        /// </summary>
        /// <param name="frame">A Stack frame pointing to the origin of the log entry.</param>
        /// <param name="level">The Log level assigned for the log entry.</param>
        /// <param name="message">The log message.</param>
        /// <param name="args">Args</param>
        public void Write(StackFrame frame, LogLevelType level, string message, params object[] args)
        {
            // write to the log
            this.Write(this.CreateEntry(frame, SeverityType.Info, level, LogViewType.LongLogOnly, EntryType.PlainText, null, message, args));
        }

        /// <summary>
        /// Writes the specified array of objects to the log output output stream using the specified format information.
        /// </summary>
        /// <param name="frame">A Stack frame pointing to the origin of the log entry.</param>
        /// <param name="level">The Log level assigned for the log entry.</param>
        /// <param name="logViewType">The arguments passed to the log type, LongAndShortLog or LongLogOnly.</param>
        /// <param name="message">The log message.</param>
        /// <param name="args">Args</param>
        public void Write(StackFrame frame, LogLevelType level, LogViewType logViewType, string message, params object[] args)
        {
            // write to the log
            this.Write(this.CreateEntry(frame, SeverityType.Info, level, logViewType, EntryType.PlainText, null, message, args));
        }

        /// <summary>
        /// Writes the specified array of objects to the log output output stream using the specified format information.
        /// </summary>
        /// <param name="level">The Log level assigned for the log entry.</param>
        /// <param name="message">The log message.</param>
        public void Write(LogLevelType level, string message)
        {
            // generate a stack frame
            StackFrame frame = new StackFrame(1, true);

            // write to the log
            this.Write(this.CreateEntry(frame, SeverityType.Info, level, LogViewType.LongLogOnly, EntryType.PlainText, null, message));
        }

        /// <summary>
        /// Writes the specified array of objects to the log output output stream using the specified format information.
        /// </summary>
        /// <param name="level">The Log level assigned for the log entry.</param>
        /// <param name="logViewType">The arguments passed to the log type, LongAndShortLog or LongLogOnly.</param>
        /// <param name="message">The log message.</param>
        public void Write(LogLevelType level, LogViewType logViewType, string message)
        {
            // generate a stack frame
            StackFrame frame = new StackFrame(1, true);

            // write to the log
            this.Write(this.CreateEntry(frame, SeverityType.Info, level, logViewType, EntryType.PlainText, null, message));
        }

        #region Log Listener Methods

        /// <summary>
        /// Attach a log listener to listen to specific types of logs.
        /// </summary>
        /// <param name="logLevelType">Specifies the log level which can be one of <typeparamref name="Expedia.Test.Framework.LogLevelType"/>.</param>
        /// <param name="log">A reference to the log object to attach.</param>
        public void AttachLogListener(LogLevelType logLevelType, ILog log)
        {
            if (log != null)
            {
                if (log is AsyncLog)
                {
                    ((AsyncLog)log).LogFilePath = this.logFilePath;
                }

                this.listeners.Add(new LogListener(logLevelType, log));
            }
        }

        public void SetLogFileShare(string share)
        {
            this.logFilePath = share;

            if ((listeners == null) || (String.IsNullOrWhiteSpace(share)))
            {
                return;
            }

            for (int i = 0; i < this.listeners.Count; i++)
            {
                if (this.listeners[i].Log is AsyncLog)
                {
                    ((AsyncLog)this.listeners[i].Log).LogFilePath = this.logFilePath;
                }
            }
        }

        /// <summary>
        /// Detach a log listener.
        /// </summary>
        /// <param name="log">A reference to the log object to detach.</param>
        public void DetachLogListener(ILog log)
        {
            for (int i = 0; i < this.listeners.Count; i++)
            {
                if (this.listeners[i].Log == log)
                {
                    this.listeners.RemoveAt(i);
                    break;
                }
            }
        }

        /// <summary>
        /// Indicates whether there are any listeners listening for a specified type.
        /// </summary>
        /// <param name="logLevelType">Specifies the log level to check which can be one of <typeparamref name="Expedia.Test.Framework.LogLevelType"/>.</param>
        /// <returns>True if we have a listener that is listening for the specified type, false otherwise.</returns>
        public bool IsListenerType(LogLevelType logLevelType)
        {
            foreach (LogListener log in this.listeners)
            {
                if ((log.Level & logLevelType) != 0)
                {
                    return true;
                }
            }
            return false;
        }

        #endregion

        /// <summary>
        /// Represents an auto-incrementing entry id.
        /// </summary>
        private int autoEntryID = 0;

        /// <summary>
        /// Represents a list of listeners.
        /// </summary>
        private List<LogListener> listeners;

        /// <summary>
        /// The only instance of this class.
        /// </summary>
        private static Logger instance;

        /// <summary>
        /// Used to lock the creation of an instance.
        /// </summary>
        private static readonly object padlock = new object();

        /// <summary>
        /// Used to indicate whether the logger has been initialized.
        /// </summary>
        private static bool isInitialized;

    }
}
