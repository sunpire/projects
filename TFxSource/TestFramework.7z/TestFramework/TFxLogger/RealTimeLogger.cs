using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using System.ComponentModel;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Outputs the logging info in real time to either a stream that is provided or
    /// to the default console window
    /// </summary>
    [Serializable]
    public sealed class RealTimeLogger : ILog, IDisposable
    {
        private static readonly object m_padlock = new object();
        private static RealTimeLogger m_instance;

        private RichTextBox m_txtBox;

        private Queue<LogEntry> m_currentRead;
        private Queue<LogEntry> m_currentWrite;

        private Mutex m_writeLock;

        private EventWaitHandle m_waitHandle;
        private EventWaitHandle m_formLoaded;

        private delegate void InsertTextDelegate();
        private InsertTextDelegate m_insertText;

        private bool m_running;
        private Thread m_queueThread;
        private Thread m_uiThread;

        /// <summary>
        /// Instance
        /// </summary>
        public static RealTimeLogger Instance
        {
            get
            {
                lock (m_padlock)
                {
                    if (m_instance == null)
                    {
                        m_instance = new RealTimeLogger();
                    }
                    return m_instance;
                }
            }
        }

        /// <summary>
        /// Is Initialized
        /// </summary>
        public static bool IsInitialized
        {
            get { return m_instance != null; }
        }

        /// <summary>
        /// Real Time Logger
        /// </summary>
        private RealTimeLogger()
        {
            m_running = IsTestStudioRunning();
            if (m_running)
            {
                m_currentRead = new Queue<LogEntry>();
                m_currentWrite = new Queue<LogEntry>();

                m_writeLock = new Mutex(false);

                m_waitHandle = new EventWaitHandle(false, EventResetMode.ManualReset);
                m_formLoaded = new EventWaitHandle(false, EventResetMode.ManualReset);
                m_insertText = InsertText;

                m_uiThread = new Thread(FormSetUp);
                m_uiThread.Name = "RealTimeLogger";
                m_uiThread.Start();

                m_queueThread = new Thread(WorkQueueStart);
                m_queueThread.Name = "QueueWatcher";
                m_queueThread.Start();
            }
        }

        /// <summary>
        /// Check to see if we are running in test studio
        /// </summary>
        /// <returns></returns>
        private bool IsTestStudioRunning()
        {
            return Process.GetCurrentProcess().ProcessName.Equals("TestStudio",
                StringComparison.CurrentCultureIgnoreCase);
        }

        /// <summary>
        /// Work Queue Start
        /// </summary>
        private void WorkQueueStart()
        {
            m_formLoaded.WaitOne();

            while (m_running)
            {
                try
                {
                    m_txtBox.Invoke(m_insertText);
                }
                catch (InvalidAsynchronousStateException) { }

                m_waitHandle.WaitOne();

                m_writeLock.WaitOne();
                Queue<LogEntry> temp = m_currentRead;
                m_currentRead = m_currentWrite;
                m_currentWrite = temp;
                m_writeLock.ReleaseMutex();
            }
        }

        /// <summary>
        /// Insert Text
        /// </summary>
        private void InsertText()
        {
            LogEntry entry;
            while (m_currentRead.Count > 0)
            {
                entry = m_currentRead.Dequeue();
                if (Path.GetFileName(entry.Module).Equals("webautomation.dll", StringComparison.CurrentCultureIgnoreCase))
                {
                    m_txtBox.SelectionColor = Color.Gray;
                }
                else
                {
                    Color foreColor = m_txtBox.ForeColor;
                    switch (entry.Severity)
                    {
                        case SeverityType.Error:
                            foreColor = Color.Red;
                            break;
                        case SeverityType.Warning:
                            foreColor = Color.Yellow;
                            break;
                        case SeverityType.Info:
                            foreColor = Color.White;
                            break;
                    }
                    m_txtBox.SelectionColor = foreColor;
                }
                m_txtBox.AppendText(entry.Text + Environment.NewLine);
            }
        }

        /// <summary>
        /// Form Set Up
        /// </summary>
        private void FormSetUp()
        {
            //set up form
            using (Form form = new Form())
            {
                form.Text = "Real time log viewer";
                form.Size = new Size(600, 800);

                form.Closing += form_Closing;
                m_txtBox = new RichTextBox();
                m_txtBox.Dock = DockStyle.Fill;
                m_txtBox.ReadOnly = true;
                m_txtBox.Multiline = true;
                m_txtBox.WordWrap = false;
                m_txtBox.ScrollBars = RichTextBoxScrollBars.Both;
                m_txtBox.BackColor = Color.Black;                
                m_txtBox.DetectUrls = false;

                form.Controls.Add(m_txtBox);
                form.Show();

                // indicate that the form is setup
                m_formLoaded.Set();

                while (m_running)
                {
                    //this keeps my ui thread alive and takes up minimal cpu time
                    Application.DoEvents();
                    Thread.Sleep(100);
                }
            }
        }

        /// <summary>
        /// Form Closing
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Cancel Event Args</param>
        private void form_Closing(object sender, CancelEventArgs e)
        {
            //if someone clicks close on the logging form set running to false so that we no longer try
            //to send messages to the form
            m_running = false;
        }

        #region ILog Members

        /// <summary>
        /// Add
        /// </summary>
        /// <param name="entry">Entry</param>
        public void Add(LogEntry entry)
        {
            //make sure the form is still open and running before we send messages
            if (m_running)
            {
                m_writeLock.WaitOne();
                m_currentWrite.Enqueue(entry);
                m_writeLock.ReleaseMutex();
                m_waitHandle.Set();
            }
        }

        #endregion

        #region IDisposable Members

        /// <summary>
        /// Dispose
        /// </summary>
        public void Dispose()
        {
            //set running to false and wait for queue and ui threads to close
            if (m_running)
            {
                // stop all the threads
                m_running = false;

                // re-join the threads to make sure they abort
                m_queueThread.Join();
                m_uiThread.Join();
            }
        }

        #endregion
    }
}