using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Container for discrete unit of information to be logged.
    /// </summary>
    [Serializable]
    public class LogEntry : IComparable, IComparable<LogEntry>
    {
        #region Constructors

        /// <summary>
        /// Log Entry
        /// </summary>
        public LogEntry()
        {
            AdditionalInfo = new List<string>();
            OtherInfo = new SerializableDictionary<string, Object>();
        }

        /// <summary>
        /// Log Entry
        /// </summary>
        /// <param name="severity">severity</param>
        /// <param name="level">level</param>
        /// <param name="text">text</param>
        /// <param name="module">module</param>
        /// <param name="function">function</param>
        /// <param name="type">type</param>
        public LogEntry(SeverityType severity, LogLevelType level, string text, string module, string function, EntryType type)
        {
            this.Severity = severity;
            this.Level = level;
            this.LogViewType = LogViewType.LongLogOnly;
            this.Text = text;
            this.EntryTime = DateTime.Now;
            this.Module = module;
            this.Function = function;
            this.Type = type;
            this.Array = null;

            AdditionalInfo = new List<string>();
            OtherInfo = new SerializableDictionary<string, Object>();
        }

        /// <summary>
        /// Log Entry
        /// </summary>
        /// <param name="severity">severity</param>
        /// <param name="level">level</param>
        /// <param name="logViewType">logViewType</param>
        /// <param name="text">text</param>
        /// <param name="module">module</param>
        /// <param name="function">function</param>
        /// <param name="type">type</param>
        public LogEntry(SeverityType severity, LogLevelType level, LogViewType logViewType, string text, string module, string function, EntryType type)
        {
            this.Severity = severity;
            this.Level = level;
            this.LogViewType = logViewType;
            this.Text = text;
            this.EntryTime = DateTime.Now;
            this.Module = module;
            this.Function = function;
            this.Type = type;
            this.Array = null;

            AdditionalInfo = new List<string>();
            OtherInfo = new SerializableDictionary<string, Object>();
        }

        /// <summary>
        /// Log Entry
        /// </summary>
        /// <param name="severity">severity</param>
        /// <param name="level">level</param>
        /// <param name="array">array</param>
        /// <param name="module">module</param>
        /// <param name="function">function</param>
        /// <param name="type">type</param>
        public LogEntry(SeverityType severity, LogLevelType level, byte[] array, string module, string function, EntryType type)
        {
            this.Severity = severity;
            this.Level = level;
            this.LogViewType = LogViewType.LongLogOnly;
            this.Array = array;
            this.EntryTime = DateTime.Now;
            this.Module = module;
            this.Function = function;
            this.Type = type;
            this.Text = String.Empty;

            AdditionalInfo = new List<string>();
            OtherInfo = new SerializableDictionary<string, Object>();
        }

        /// <summary>
        /// Log Entry
        /// </summary>
        /// <param name="severity">severity</param>
        /// <param name="level">level</param>
        /// <param name="logViewType">logViewType</param>
        /// <param name="array">array</param>
        /// <param name="module">module</param>
        /// <param name="function">function</param>
        /// <param name="type">type</param>
        public LogEntry(SeverityType severity, LogLevelType level, LogViewType logViewType, byte[] array, string module, string function, EntryType type)
        {
            this.Severity = severity;
            this.Level = level;
            this.LogViewType = logViewType;
            this.Array = array;
            this.EntryTime = DateTime.Now;
            this.Module = module;
            this.Function = function;
            this.Type = type;
            this.Text = String.Empty;

            AdditionalInfo = new List<string>();
            OtherInfo = new SerializableDictionary<string, Object>();
        }

        /// <summary>
        /// Log Entry
        /// </summary>
        /// <param name="severity">severity</param>
        /// <param name="level">level</param>
        /// <param name="text">text</param>
        /// <param name="module">module</param>
        /// <param name="function">function</param>
        /// <param name="type">type</param>
        /// <param name="array">array</param>
        public LogEntry(SeverityType severity, LogLevelType level, string text, string module, string function, EntryType type, byte[] array)
        {
            this.Severity = severity;
            this.Level = level;
            this.LogViewType = LogViewType.LongLogOnly;
            this.Array = array;
            this.EntryTime = DateTime.Now;
            this.Module = module;
            this.Function = function;
            this.Type = type;
            this.Text = text;

            AdditionalInfo = new List<string>();
            OtherInfo = new SerializableDictionary<string, Object>();
        }

        /// <summary>
        /// Log Entry
        /// </summary>
        /// <param name="severity">severity</param>
        /// <param name="level">level</param>
        /// <param name="logViewType">logViewType</param>
        /// <param name="text">text</param>
        /// <param name="module">module</param>
        /// <param name="function">function</param>
        /// <param name="type">type</param>
        /// <param name="array">array</param>
        public LogEntry(SeverityType severity, LogLevelType level, LogViewType logViewType, string text, string module, string function, EntryType type, byte[] array)
        {
            this.Severity = severity;
            this.Level = level;
            this.LogViewType = logViewType;
            this.Array = array;
            this.EntryTime = DateTime.Now;
            this.Module = module;
            this.Function = function;
            this.Type = type;
            this.Text = text;

            AdditionalInfo = new List<string>();
            OtherInfo = new SerializableDictionary<string, Object>();
        }

        #endregion

        #region Properties

        /// <summary>
        /// LogEntry ID.
        /// </summary>
        [XmlAttribute("Id")]
        public int EntryId { get; set; }

        /// <summary>
        /// Time of LogEntry.
        /// </summary>
        [XmlAttribute("Time")]
        public DateTime EntryTime { get; set; }

        /// <summary>
        /// Level of LogEntry.
        /// </summary>
        [XmlAttribute]
        public LogLevelType Level { get; set; }

        /// <summary>
        /// Severity of LogEntry.
        /// </summary>
        [XmlAttribute]
        public SeverityType Severity { get; set; }

        /// <summary>
        /// Type of Log.
        /// </summary>
        [XmlAttribute]
        public LogViewType LogViewType { get; set; }

        /// <summary>
        /// The relevant module name.
        /// </summary>
        [XmlAttribute]
        public string Module { get; set; }

        /// <summary>
        /// The relevant method name.
        /// </summary>
        [XmlAttribute]
        public string Function { get; set; }

        /// <summary>
        /// The type of LogEntry
        /// </summary>
        [XmlAttribute]
        public EntryType Type { get; set; }

        /// <summary>
        /// The log entry message
        /// </summary>
        [XmlText(typeof(string))]
        public string Text { get; set; }

        /// <summary>
        /// A byte array of relevent data
        /// </summary>
        [XmlAttribute]
        public byte[] Array { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [XmlAttribute]
        public List<string> AdditionalInfo { get; set; }

        /// <summary>
        /// image metadata for image log
        /// </summary>
        public ImageInfo ImageInfo { get; set; }

        public SerializableDictionary<String, Object> OtherInfo { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// To String
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            string text = string.Format("{0} :", Level.ToString());
            text += this.Text;
            return text;
        }

        #endregion

        #region IComparable Members

        /// <summary>
        /// Compare To 
        /// </summary>
        /// <param name="obj">Object</param>
        /// <returns></returns>
        public int CompareTo(object obj)
        {
            LogEntry other = obj as LogEntry;
            if (other != null)
            {
                return this.EntryId.CompareTo(other.EntryId);
            }

            throw new ArgumentException("object is not a LogEntry", "obj");
        }

        #endregion

        #region IComparable<LogEntry> Members

        /// <summary>
        /// Compare to
        /// </summary>
        /// <param name="other">Other</param>
        /// <returns></returns>
        public int CompareTo(LogEntry other)
        {
            if (other == null)
            {
                return 1;  // this is not null, obviously
            }

            return this.EntryId.CompareTo(other.EntryId);
        }

        #endregion
    }
}
