﻿using System;
using System.IO;
using System.IO.Compression;
using System.Security;
using System.Security.Permissions;
using System.Text;

namespace Expedia.Test.Framework
{
    public class LogHelper
    {
        private static LogHelper logHelper = null;

        public static LogHelper Instance
        {
            get
            {
                if (logHelper == null)
                {
                    logHelper = new LogHelper();
                }
                return logHelper;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="filename"></param>
        /// <param name="content"></param>
        public void CompressAndWriteToFile(string filename, Encoding encoding, string content)
        {
            // Convert the string content to byte
            byte[] contentBytes = encoding.GetBytes(content);

            CompressAndWriteToFile(filename, contentBytes);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="filename"></param>
        /// <param name="contentBytes"></param>
        public void CompressAndWriteToFile(string filename, byte[] contentBytes)
        {
            var permissionSet = new PermissionSet(PermissionState.None);
            var writePermission = new FileIOPermission(FileIOPermissionAccess.Write, filename);
            permissionSet.AddPermission(writePermission);

            if (permissionSet.IsSubsetOf(AppDomain.CurrentDomain.PermissionSet))
            {
                // write the compressed content
                using (FileStream fileStream = new FileStream(filename, FileMode.Create))
                {
                    using (GZipStream gZip = new GZipStream(fileStream, CompressionMode.Compress, false))
                    {
                        gZip.Write(contentBytes, 0, contentBytes.Length);
                    }
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="filename"></param>
        /// <param name="contentBytes"></param>
        public void WriteToFile(string filename, byte[] contentBytes)
        {
            var permissionSet = new PermissionSet(PermissionState.None);
            var writePermission = new FileIOPermission(FileIOPermissionAccess.Write, filename);
            permissionSet.AddPermission(writePermission);

            if (permissionSet.IsSubsetOf(AppDomain.CurrentDomain.PermissionSet))
            {
                using (FileStream fstream = new FileStream(filename, FileMode.Create))
                {
                    using (BinaryWriter writer = new BinaryWriter(fstream))
                    {
                        writer.Write(contentBytes);
                    }
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="filename"></param>
        /// <param name="content"></param>
        public void WriteToFile(string filename, Encoding encoding, string content)
        {
            var permissionSet = new PermissionSet(PermissionState.None);
            var writePermission = new FileIOPermission(FileIOPermissionAccess.Write, filename);
            permissionSet.AddPermission(writePermission);

            if (permissionSet.IsSubsetOf(AppDomain.CurrentDomain.PermissionSet))
            {
                using (FileStream fstream = new FileStream(filename, FileMode.Create))
                {
                    using (TextWriter writer = new StreamWriter(fstream, encoding))
                    {
                        try
                        {
                            writer.WriteLine(content);
                        }
                        catch { }
                    }
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="entry"></param>
        /// <param name="directoryPath"></param>
        /// <returns></returns>
        public String WriteContentToUniqueFile(LogEntry entry, String directoryPath)
        {
            string suffix = entry.EntryTime.ToString("yyyyMMddHHmmss-fffffff");//Guid.NewGuid().ToString()
            //
            // generate a unique file name
            //
            String filePath = String.Empty;

            if (entry.OtherInfo.ContainsKey("filename"))
            {
                filePath = Convert.ToString(entry.OtherInfo["filename"]);
            }

            //
            // check whether to append guid to file name or not
            //
            if (entry.OtherInfo.ContainsKey("appendGuidToFileName"))
            {
                bool appendGuidToFileName = false;

                Boolean.TryParse(Convert.ToString(entry.OtherInfo["appendGuidToFileName"]), out appendGuidToFileName);

                if (appendGuidToFileName == true)
                {
                    if (!String.IsNullOrWhiteSpace(filePath))
                    {
                        filePath = filePath + "_";
                    }

                    filePath = filePath + suffix + "_" + Guid.NewGuid().ToString();
                }
            }

            // if file name is empty right now, need to assign it to a GUID
            if (String.IsNullOrWhiteSpace(filePath))
            {
                filePath = suffix;
            }

            filePath = System.IO.Path.Combine(directoryPath, filePath);

            //
            // check whether to gzip or not
            //
            bool gzip = false;

            if (entry.OtherInfo.ContainsKey("gzip"))
            {
                Boolean.TryParse(Convert.ToString(entry.OtherInfo["gzip"]), out gzip);
            }

            bool text = false;
            if (entry.OtherInfo.ContainsKey("text"))
            {
                Boolean.TryParse(Convert.ToString(entry.OtherInfo["text"]), out text);
            }

            if (gzip == true)
            {
                string ext = ".xml.gz";
                filePath = filePath + ext;

                if (System.IO.File.Exists(filePath) == true)
                {
                    filePath = filePath.Replace(ext, "-" + suffix + ext);
                }

                if (!text && entry.Array != null)
                {
                    this.CompressAndWriteToFile(filePath, entry.Array);
                }
                else if (text && !string.IsNullOrEmpty(entry.Text))
                {
                    this.CompressAndWriteToFile(filePath, Encoding.UTF8, entry.Text);
                }
            }
            else
            {
                filePath = filePath + ".xml";

                if (System.IO.File.Exists(filePath) == true)
                {
                    filePath = filePath.Replace(".xml", "-" + suffix + ".xml");
                }

                if (!text && entry.Array != null)
                {
                    this.WriteToFile(filePath, entry.Array);
                }
                else if (text && !string.IsNullOrEmpty(entry.Text))
                {
                    this.WriteToFile(filePath, Encoding.UTF8, entry.Text);
                }
            }

            return filePath;
        }
    }
}
