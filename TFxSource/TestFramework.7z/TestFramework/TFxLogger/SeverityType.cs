
namespace Expedia.Test.Framework
{
    /// <summary>
    /// Specifies the severity of an entry being made in the log.
    /// </summary>
    public enum SeverityType
    {
        /// <summary>
        /// Info
        /// </summary>
        Info = 0,
        /// <summary>
        /// Warning
        /// </summary>
        Warning = 1,
        /// <summary>
        /// Error
        /// </summary>
        Error = 2
    }
}
