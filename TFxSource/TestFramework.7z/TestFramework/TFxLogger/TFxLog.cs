using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// TFxLog.
    /// </summary>
    [Serializable]
    [XmlInclude(typeof(LogEntry))]
    [XmlRoot("Log")]
    public class TFxLog : IPersistableLog
    {
        #region Constructor

        /// <summary>
        /// TFx Log
        /// </summary>
        public TFxLog()
        {
        }

        #endregion

        #region Properties

        /// <summary>
        /// Publicly-accessible log entryQueue.
        /// </summary>
        [XmlArrayItem(ElementName = "Entry", Type = typeof(LogEntry))]
        public List<LogEntry> LogEntries
        {
            get
            {
                if (this.logEntries == null)
                {
                    this.logEntries = new List<LogEntry>();
                }
                return this.logEntries;
            }
            set
            {
                this.logEntries = value;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Add a new entry to the log.
        /// </summary>
        /// <param name="entry">Entry to add.</param>
        public virtual void Add(LogEntry entry)
        {
            this.LogEntries.Add(entry);
        }

        /// <summary>
        /// Returns all log entryQueue in a newline-delimited string.
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            StringBuilder text = new StringBuilder();
            foreach (LogEntry entry in this.LogEntries)
            {
                text.Append(entry.ToString());
                text.Append(System.Environment.NewLine);
            }

            return text.ToString();
        }
        
        /// <summary>
        /// Deserializes a string of XML into a TFxLog.
        /// </summary>
        /// <param name="tw">The XML string to deserialize.</param>
        /// <returns>The TFxLog object created.</returns>
        public static TFxLog FromXML(string tw)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(TFxLog));
            TFxLog log;

            using (XmlTextReader reader = new XmlTextReader(tw, XmlNodeType.Element, null))
            {
                log = (TFxLog)serializer.Deserialize(reader);
            }

            return log;
        }

        /// <summary>
        /// Outputs the current LogEntries in serialized XML.
        /// </summary>
        /// <returns>The serialized LogEntries.</returns>
        public string ToXml()
        {
            XmlSerializer serializer = new XmlSerializer(this.GetType());

            using (StringWriter stringWriter = new StringWriter())
            {
                using (XmlTextWriter doc = new XmlTextWriter(stringWriter))
                {
                    serializer.Serialize(doc, this);
                }
                return stringWriter.ToString();
            }
        }

        #endregion

        #region Fields

        /// <summary>
        /// Persists the LogEntries.
        /// </summary>
        private List<LogEntry> logEntries;

        #endregion
    }
}