using System.Collections.Generic;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// A log interface which persists the LogEntries added to it.
	/// </summary>
    public interface IPersistableLog : ILog
    {
        /// <summary>
        /// List of previously-Added LogEntry items.
        /// </summary>
        List<LogEntry> LogEntries { get; }

        /// <summary>
        /// Serializes the current Log into XML
        /// </summary>
        /// <returns>Serialized XML.</returns>
        string ToXml();
    }
}
