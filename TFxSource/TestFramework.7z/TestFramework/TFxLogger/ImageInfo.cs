using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows.Media.Imaging;

namespace Expedia.Test.Framework
{
    public class ImageInfo
    {
        public string Title { get; set; }
        public string Subject { get; set; }
        public string Comment { get; set; }
        public string[] Author { get; set; }
    }

    static class ImageInfoWriter
    {
        public static void WriteJpeg(string fileName, byte[] content, ImageInfo info)
        {
            MemoryStream ms = new MemoryStream(content);
            BitmapFrame bitmapFrame = BitmapFrame.Create(ms);
            BitmapMetadata metadata = bitmapFrame.CreateInPlaceBitmapMetadataWriter();

            //DO NOT remove this line, add an exif tag first by setquery
            metadata.SetQuery("/app1/ifd/exif:{uint=40092}", "comments");
            metadata.Author = new ReadOnlyCollection<string>(info.Author);
            metadata.Title = info.Title ?? string.Empty;
            metadata.Subject = info.Subject ?? string.Empty;
            metadata.Comment = info.Comment ?? string.Empty;

            var encoder = new JpegBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(bitmapFrame, bitmapFrame.Thumbnail, metadata, bitmapFrame.ColorContexts));

            using (Stream stream = File.Open(fileName, FileMode.Create))
                encoder.Save(stream);
        }
    }
}
