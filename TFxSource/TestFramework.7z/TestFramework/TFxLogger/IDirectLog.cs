
namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for IDirectLog.
    /// </summary>
    public interface IDirectLog : ILog
    {
        /// <summary>
        /// Start
        /// </summary>
        void Start();
        /// <summary>
        /// End
        /// </summary>
        void End();
    }
}
