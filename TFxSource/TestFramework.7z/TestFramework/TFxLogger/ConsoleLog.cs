using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// A log that writes to the Console.
	/// </summary>
    [Serializable]
    public class ConsoleLog : ILog
    {
        /// <summary>
        /// Add
        /// </summary>
        /// <param name="entry">Log Entry</param>
        public void Add(LogEntry entry)
        {
            Console.WriteLine("[{0}] ( {1} )", entry.Text, entry.EntryTime.ToString());
        }
    }
}
