using System.Collections.Generic;
using System.Threading;
using Expedia.Test.Framework.Log;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// AsyncLog.
    /// </summary>
    public class AsyncLog : IDirectLog
    {
        #region Constructors

        /// <summary>
        /// Creates a new async log that does not refer to an ILog instance.
        /// </summary>
        public AsyncLog()
        {
        }

        /// <summary>
        /// Creates a new async log refering to the given ILog instance.
        /// </summary>
        /// <param name="log">An instance of a class that defines the ILog interface.</param>
        public AsyncLog(ILog log)
        {
            this.log = log;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Add a new entry to the log.
        /// </summary>
        /// <param name="entry">Entry to add.</param>
        public void Add(LogEntry entry)
        {
            if (entry == null) return;
            lock (padlock)
            {
                this.entryQueue.Enqueue(entry);
            }
            this.keepWriting.Set();
        }

        private void WriterWorker()
        {
            try
            {
                bool checkMore = true;
                bool continueLoop = true;
                do
                {
                    lock (padlock)
                    {
                        if (this.entryQueue.Count > 0)
                        {
                            this.log.Add(this.entryQueue.Dequeue());
                            checkMore = true;
                        }
                        else
                        {
                            checkMore = false;
                        }
                    }

                    if (!checkMore)
                    {
                        if (this.keepWriting != null)
                        {
                            this.keepWriting.WaitOne(1000, true);
                        }
                    }

                    lock (padlock)
                    {
                        continueLoop = this.entryQueue.Count > 0 || this.continueWorking;
                    }
                }
                while (continueLoop);
            }
            catch (ThreadAbortException)
            {
                this.End();
            }
        }

        #endregion

        #region IDirectLog Members

        /// <summary>
        /// Start
        /// </summary>
        public void Start()
        {
            if (this.persistanceThread == null)
            {
                this.entryQueue = new Queue<LogEntry>();

                this.persistanceThread = new Thread(new ThreadStart(WriterWorker));
                this.persistanceThread.SetApartmentState(ApartmentState.STA);
                this.persistanceThread.Priority = ThreadPriority.Normal;
                this.persistanceThread.Start();
                this.keepWriting = new AutoResetEvent(false);
            }
        }

        /// <summary>
        /// End
        /// </summary>
        public void End()
        {
            lock (padlock)
            {
                while (this.entryQueue.Count > 0)
                {
                    this.log.Add(this.entryQueue.Dequeue());
                }

                IDirectLog directLog = this.log as IDirectLog;
                if (directLog != null)
                {
                    directLog.End();
                }
            }

            this.continueWorking = false;
        }

        #endregion

        #region Fields

        /// <summary>
        /// Used for locking this instance of the async log.
        /// </summary>
        private readonly object padlock = new object();

        private ILog log;
        private Queue<LogEntry> entryQueue;
        private Thread persistanceThread;
        private AutoResetEvent keepWriting;
        private bool continueWorking = true;

        #endregion

        private string logFilePath = string.Empty;

        public string LogFilePath
        {
            get
            {
                return this.logFilePath;
            }
            set
            {
                this.logFilePath = value;

                if ((this.log != null) && (this.log is DirectDBLog))
                {
                    ((DirectDBLog)this.log).LogFilePath = value;
                }

                if ((this.log != null) && (this.log is CassandraLog))
                {
                    ((CassandraLog)this.log).LogFilePath = value;
                }
            }
        }
    }
}
