
namespace Expedia.Test.Framework
{
    /// <summary>
    /// Generic Interface for logging messages
    /// </summary>
    public interface ILog
    {
        /// <summary>
        /// Logs a new entry.
        /// </summary>
        /// <param name="entry">The entry to log.</param>
        void Add(LogEntry entry);
    }
}
