﻿using System;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Listens for certain types of log events and dispatches them.
    /// </summary>
    [Serializable]
    internal class LogListener
    {
        /// <summary>
        /// Initializes a log listener.
        /// </summary>
        public LogListener()
        {
        }

        /// <summary>
        /// Initializes a log listener that listens for certain types of log events.
        /// </summary>
        /// <param name="level">The log level to listen for.</param>
        /// <param name="log">The log to dispatch.</param>
        public LogListener(LogLevelType level, ILog log)
        {
            this.log = log;
            this.level = level;
        }

        /// <summary>
        /// Gets or sets the log instance.
        /// </summary>
        public ILog Log
        {
            get
            {
                return this.log;
            }
            set
            {
                this.log = value;
            }
        }

        /// <summary>
        /// Gets or sets the log level.
        /// </summary>
        public LogLevelType Level
        {
            get
            {
                return this.level;
            }
            set
            {
                this.level = value;
            }
        }

        /// <summary>
        /// Write this entry to log
        /// </summary>
        /// <param name="entry"></param>
        public void Add(LogEntry entry)
        {
            if ((this.level & entry.Level) != 0)
            {
                this.log.Add(entry);
            }
        }

        private ILog log;
        private LogLevelType level;
    }
}
