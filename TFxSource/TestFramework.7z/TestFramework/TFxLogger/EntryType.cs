
namespace Expedia.Test.Framework
{
    /// <summary>
    /// Specifies the type of an entry being made in the log.
    /// </summary>
    public enum EntryType
    {
        /// <summary>
        /// Plain Text
        /// </summary>
        PlainText = 0,
        /// <summary>
        /// Html
        /// </summary>
        Html = 1,
        /// <summary>
        /// Pricture
        /// </summary>
        Picture = 2,
        /// <summary>
        /// XML
        /// </summary>
        XML = 3,
        /// <summary>
        /// Generic file type
        /// </summary>
        File = 4,
        /// <summary>
        /// FI binary, gzipped and saved on a share
        /// </summary>
        FastInfoSet = 5,
        /// <summary>
        /// XML, gzipped into a file and saved on a share
        /// </summary>
        XmlFile = 6
    }
}
