﻿using System;
using System.Diagnostics;
using Expedia.Test.Framework.LogJamServiceReference;

namespace Expedia.Test.Framework
{
    public class CassandraLog : IDirectLog
    {
        #region Constructor

        /// <summary>
        /// Direct DB Log
        /// </summary>
        public CassandraLog(string serviceUrl, string logId, string ttl)
        {
            this.ServiceUrl = serviceUrl;
            this.LogId = logId;
            int _ttl;
            if (!int.TryParse(ttl, out _ttl))
            {
                _ttl = 2592000; //30 days 3600*24*30
            }
            LogTTL = _ttl;
        }

        #endregion

        #region Properties

        /// <summary>
        /// LogJamService Url
        /// </summary>
        public string ServiceUrl { get; set; }

        /// <summary>
        /// logid - 'LRM' + executionId
        /// </summary> 
        public string LogId { get; set; }

        /// <summary>
        /// cassandra log ttl
        /// </summary> 
        public int LogTTL { get; set; }

        /// <summary>
        /// Path to write log files
        /// </summary>
        public String LogFilePath
        {
            get;
            set;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Add a new entry to the logjam service.
        /// </summary>
        /// <param name="entry">Entry to add.</param>
        public void Add(LogEntry entry)
        {
            if (entry == null)
            {
                EventLog.WriteEntry("Application", "The LogEntry is null.", EventLogEntryType.Error);
                return;
            }

            try
            {
                var service = ServiceFactory.CreateLogJamService(ServiceUrl);
                var entryText = string.Empty;
                switch (entry.Type)
                {
                    case EntryType.Picture:
                        entryText = entry.Array == null ? string.Empty : Convert.ToBase64String(entry.Array);
                        break;
                    case EntryType.XmlFile:
                    case EntryType.File:
                    case EntryType.FastInfoSet:
                        String filePath = LogHelper.Instance.WriteContentToUniqueFile(entry, this.LogFilePath);
                        entryText = filePath;
                        break;
                    default:
                        entryText = entry.Text;
                        break;
                }
                var request = new WriteEntryRequest()
                {
                    Entry = new LogEntryType()
                    {
                        EntryTime = entry.EntryTime,
                        EntryType = ConvertEntryType(entry.Type),
                        LogId = LogId,
                        Severity = ConvertEntrySeverity(entry.Severity),
                        Text = entryText,
                        Ttl = LogTTL
                    }
                };

                var additionalInfo = new ArrayOfKeyValuePairType();
                if (!string.IsNullOrWhiteSpace(entry.Module))
                {
                    additionalInfo.Add(new LogJamServiceReference.KeyValuePairType { Key = "Module", Value = entry.Module });
                }

                if (!string.IsNullOrWhiteSpace(entry.Function))
                {
                    additionalInfo.Add(new LogJamServiceReference.KeyValuePairType { Key = "Function", Value = entry.Function });
                }

                request.Entry.AdditionalInfo = additionalInfo;
                service.WriteEntry(request);
            }
            catch (Exception e)
            {
                string message = String.Format("Error {0} occurred while adding entryQueue to the log jam service.", e);
                EventLog.WriteEntry("Application", message, EventLogEntryType.Error);
            }
        }

        /// <summary>
        /// Converts the entry severity.
        /// </summary>
        /// <param name="severity">The severity.</param>
        /// <returns></returns>
        private LogJamServiceReference.SeverityType ConvertEntrySeverity(Expedia.Test.Framework.SeverityType severity)
        {
            switch (severity)
            {
                case SeverityType.Info:
                    return LogJamServiceReference.SeverityType.Info;
                case SeverityType.Error:
                    return LogJamServiceReference.SeverityType.Error;
                case SeverityType.Warning:
                    return LogJamServiceReference.SeverityType.Warn;
                default:
                    return LogJamServiceReference.SeverityType.Info;
            }
        }

        /// <summary>
        /// Converts the type of the entry.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns></returns>
        private LogJamServiceReference.EntryType ConvertEntryType(Expedia.Test.Framework.EntryType type)
        {
            switch (type)
            {
                case EntryType.FastInfoSet:
                    return LogJamServiceReference.EntryType.BinaryFastInfoset;
                //case EntryType.File:
                case EntryType.Html:
                    return LogJamServiceReference.EntryType.Html;
                case EntryType.Picture:
                    //webautomation write jpg image
                    return LogJamServiceReference.EntryType.ImageJPG;
                case EntryType.PlainText:
                    return LogJamServiceReference.EntryType.Text;
                case EntryType.XML:
                    return LogJamServiceReference.EntryType.XML;
                //case EntryType.XmlFile:
                default:
                    return LogJamServiceReference.EntryType.Text;
            }
        }

        #endregion

        #region IDirectLog Members

        /// <summary>
        /// Start
        /// </summary>
        public void Start()
        {
        }

        /// <summary>
        /// End
        /// </summary>
        public void End()
        {
        }

        #endregion
    }
}
