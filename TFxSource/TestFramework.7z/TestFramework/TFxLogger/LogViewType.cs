﻿
namespace Expedia.Test.Framework
{
    /// <summary>
    /// Long log only shows in long log view
    /// </summary>
    public enum LogViewType
    {
        /// <summary>
        /// LongLogOnly
        /// </summary>
        LongLogOnly,
        /// <summary>
        /// LongAndShortLog
        /// </summary>
        LongAndShortLog,
        
    }
}

