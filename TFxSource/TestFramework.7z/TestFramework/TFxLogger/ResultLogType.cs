
namespace Expedia.Test.Framework
{
	/// <summary>
	/// Specifies the type of log being displayed.
	/// </summary>
	public enum ResultLogType
	{
        /// <summary>
        /// Full Log
        /// </summary>
		FullLog = 0,
        /// <summary>
        /// Short Log
        /// </summary>
		ShortLog = 1,
	}
}
