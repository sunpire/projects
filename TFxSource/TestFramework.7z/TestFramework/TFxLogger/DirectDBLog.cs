using System;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;

namespace Expedia.Test.Framework.Log
{
    /// <summary>
    /// DirectDBLog.
    /// </summary>
    public class DirectDBLog : IDirectLog
    {
        #region Constructor

        /// <summary>
        /// Direct DB Log
        /// </summary>
        public DirectDBLog()
        {
        }

        #endregion

        #region Properties

        /// <summary>
        /// Connection String
        /// </summary>
        public string ConnectString { get; set; }

        /// <summary>
        /// Lab Run Id
        /// </summary>
        public int LabrunId { get; set; }

        /// <summary>
        /// Assignment Id
        /// </summary>
        public int AssignmentId { get; set; }

        /// <summary>
        /// Path to write log files
        /// </summary>
        public String LogFilePath
        {
            get;
            set;
        }

        #endregion

        /// <summary>
        /// This is the number of retry the logger will try to write to the log database.
        /// 
        /// Right now, the value is 3, means that in total, the logger will try 3 times if
        /// fail to connect to the db
        /// </summary>
        protected const int MAX_RETRY = 3;

        /// <summary>
        /// Retry Count
        /// </summary>
        protected int retryCount = MAX_RETRY;

        #region Methods



        /// <summary>
        /// Add a new entry to the log.
        /// </summary>
        /// <param name="entry">Entry to add.</param>
        public void Add(LogEntry entry)
        {
            //TODO: we can buffer these and write in bulk
            if (entry == null)
            {
                EventLog.WriteEntry("Application", "The LogEntry is null.", EventLogEntryType.Error);
                return;
            }

            Exception exp = null;

            // Do not attempt to write any more log if retry count has exceeded the max
            if (retryCount <= 0)
            {
                return;
            }

            do
            {
                try
                {
                    using (SqlConnection con = new SqlConnection())
                    {
                        con.ConnectionString = this.ConnectString;
                        con.Open();

                        switch (entry.Type)
                        {
                            case EntryType.Picture:
                                using (SqlCommand cmd = new SqlCommand())
                                {
                                    cmd.CommandText = "[dbo].[TFx_AddLogEntry]";
                                    cmd.CommandType = CommandType.StoredProcedure;
                                    (cmd.Parameters.Add("@labrunId", SqlDbType.Int)).Value = this.LabrunId;
                                    (cmd.Parameters.Add("@assignmentId", SqlDbType.Int)).Value = this.AssignmentId;
                                    (cmd.Parameters.Add("@entryId", SqlDbType.Int)).Value = entry.EntryId;
                                    (cmd.Parameters.Add("@entryTime", SqlDbType.DateTime)).Value = entry.EntryTime;
                                    (cmd.Parameters.Add("@entryType", SqlDbType.SmallInt)).Value = entry.Type;
                                    (cmd.Parameters.Add("@function", SqlDbType.VarChar)).Value = entry.Function;
                                    (cmd.Parameters.Add("@level", SqlDbType.BigInt)).Value = entry.Level;
                                    (cmd.Parameters.Add("@viewType", SqlDbType.Bit)).Value = entry.LogViewType;
                                    (cmd.Parameters.Add("@module", SqlDbType.VarChar)).Value = entry.Module;
                                    (cmd.Parameters.Add("@severity", SqlDbType.SmallInt)).Value = entry.Severity;
                                    cmd.Parameters.Add(new SqlParameter("@text", Convert.ToBase64String(entry.Array)));
                                    cmd.Connection = con;
                                    cmd.ExecuteNonQuery();
                                }
                                break;

                            case EntryType.XmlFile:
                            case EntryType.File:
                            case EntryType.FastInfoSet:

                                String filePath = LogHelper.Instance.WriteContentToUniqueFile(entry, this.LogFilePath);

                                // update the entry.Text to be the file path to the saved file
                                entry.Text = filePath;

                                using (SqlCommand cmd = new SqlCommand())
                                {
                                    cmd.CommandText = "[dbo].[TFx_AddLogEntry]";
                                    cmd.CommandType = CommandType.StoredProcedure;
                                    (cmd.Parameters.Add("@labrunId", SqlDbType.Int)).Value = this.LabrunId;
                                    (cmd.Parameters.Add("@assignmentId", SqlDbType.Int)).Value = this.AssignmentId;
                                    (cmd.Parameters.Add("@entryId", SqlDbType.Int)).Value = entry.EntryId;
                                    (cmd.Parameters.Add("@entryTime", SqlDbType.DateTime)).Value = entry.EntryTime;
                                    (cmd.Parameters.Add("@entryType", SqlDbType.SmallInt)).Value = entry.Type;
                                    (cmd.Parameters.Add("@function", SqlDbType.VarChar)).Value = entry.Function;
                                    (cmd.Parameters.Add("@level", SqlDbType.BigInt)).Value = entry.Level;
                                    (cmd.Parameters.Add("@viewType", SqlDbType.Bit)).Value = entry.LogViewType;
                                    (cmd.Parameters.Add("@module", SqlDbType.VarChar)).Value = entry.Module;
                                    (cmd.Parameters.Add("@severity", SqlDbType.SmallInt)).Value = entry.Severity;
                                    (cmd.Parameters.Add("@text", SqlDbType.NVarChar, -1)).Value = entry.Text;

                                    // TBD - need to store the text as binary if entry.AdditionalInfo[2] is binary

                                    cmd.Connection = con;
                                    cmd.ExecuteNonQuery();
                                }
                                break;

                            case EntryType.Html:
                            case EntryType.PlainText:
                            case EntryType.XML:

                                using (SqlCommand cmd = new SqlCommand())
                                {
                                    cmd.CommandText = "[dbo].[TFx_AddLogEntry]";
                                    cmd.CommandType = CommandType.StoredProcedure;
                                    (cmd.Parameters.Add("@labrunId", SqlDbType.Int)).Value = this.LabrunId;
                                    (cmd.Parameters.Add("@assignmentId", SqlDbType.Int)).Value = this.AssignmentId;
                                    (cmd.Parameters.Add("@entryId", SqlDbType.Int)).Value = entry.EntryId;
                                    (cmd.Parameters.Add("@entryTime", SqlDbType.DateTime)).Value = entry.EntryTime;
                                    (cmd.Parameters.Add("@entryType", SqlDbType.SmallInt)).Value = entry.Type;
                                    (cmd.Parameters.Add("@function", SqlDbType.VarChar)).Value = entry.Function;
                                    (cmd.Parameters.Add("@level", SqlDbType.BigInt)).Value = entry.Level;
                                    (cmd.Parameters.Add("@viewType", SqlDbType.Bit)).Value = entry.LogViewType;
                                    (cmd.Parameters.Add("@module", SqlDbType.VarChar)).Value = entry.Module;
                                    (cmd.Parameters.Add("@severity", SqlDbType.SmallInt)).Value = entry.Severity;
                                    (cmd.Parameters.Add("@text", SqlDbType.NVarChar, -1)).Value = entry.Text;

                                    // TBD - need to store the text as binary if entry.AdditionalInfo[2] is binary

                                    cmd.Connection = con;
                                    cmd.ExecuteNonQuery();
                                }
                                break;
                        }
                    }

                    return;
                }
                catch (Exception e)
                {
                    retryCount = retryCount - 1;
                    string message = String.Format("Error {0} occurred while adding entryQueue to the log server, number of attempts {1}", e, (MAX_RETRY - retryCount).ToString());
                    exp = e;
                    EventLog.WriteEntry("Application", message, EventLogEntryType.Warning);
                    System.Threading.Thread.Sleep(30000);
                }
            }
            while (retryCount > 0);

            // Report the problem in eventlog and also to the LRM availability database (TBD)
            if ((retryCount <= 0) && (exp != null))
            {
                // Write the error to the event log
                EventLog.WriteEntry("Application", "Error occurred while adding entryQueue to the log server after trying " + MAX_RETRY.ToString() + " times, logging disabled.", EventLogEntryType.Error);

                // Write the error to the LRM availability database
                // #TBD
            }
        }

        #endregion

        #region IDirectLog Members

        /// <summary>
        /// Start
        /// </summary>
        public void Start()
        {
        }

        /// <summary>
        /// End
        /// </summary>
        public void End()
        {
        }

        #endregion
    }
}
