using System;
using System.IO;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for FileLog.
    /// </summary>
    [Serializable]
    public class FileLog : ILog, IDisposable
    {
        private const string defaultfileName = "Log.txt";

        #region Constructors

        /// <summary>
        /// File Log
        /// </summary>
        public FileLog()
        {
            this.SetupFile(defaultfileName);
        }

        /// <summary>
        /// File Log
        /// </summary>
        /// <param name="fileName">File Name</param>
        public FileLog(string fileName)
        {
            this.SetupFile(fileName);
        }

        #endregion

        #region Properties

        /// <summary>
        /// The file to log to.
        /// </summary>
        public string FileName { get; protected set; }

        #endregion

        #region Methods

        /// <summary>
        /// Sets up the streamwriter to write the log.
        /// </summary>
        /// <param name="fileName">The file to log to.</param>
        private void SetupFile(string fileName)
        {
            int i = 0;
            string newFileName = fileName;

            while (File.Exists(newFileName))
            {
                newFileName = fileName + "." + i++;
            }

            this.FileName = newFileName;
            this.streamWriter = File.AppendText(newFileName);
            this.streamWriter.AutoFlush = true;
        }

        /// <summary>
        /// Logs a new entry.
        /// </summary>
        /// <param name="entry">The entry to log.</param>
        public void Add(LogEntry entry)
        {
            this.streamWriter.Write("[{0}] ( {1} ) \r\n",
                entry.Text,
                entry.EntryTime.ToString());
        }

        #endregion

        #region IDisposable Members

        /// <summary>
        /// Dispose
        /// </summary>
        public void Dispose()
        {
            if (this.streamWriter != null)
            {
                this.streamWriter.Dispose();
                this.streamWriter = null;
            }
        }

        #endregion

        #region Fields

        /// <summary>
        /// The streamwriter open to the log file.
        /// </summary>
        private StreamWriter streamWriter;

        #endregion
    }
}
