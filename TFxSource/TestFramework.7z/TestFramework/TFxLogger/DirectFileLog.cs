using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Xml;
using System.Xml.Serialization;

namespace Expedia.Test.Framework.Log
{
    /// <summary>
    /// Summary description for DirectFileLog.
    /// </summary>
    public class DirectFileLog : IDirectLog, IDisposable
    {
        /// <summary>
        /// Direct File Log
        /// </summary>
        /// <param name="fileName">File Name</param>
        public DirectFileLog(string fileName)
        {
            if (string.IsNullOrEmpty(fileName))
            {
                throw new ArgumentNullException("fileName");
            }

            // Remove all bad characters from the filename.
            string justRootPath = Path.GetDirectoryName(fileName);
            string justFileName = string.Join(string.Empty, Path.GetFileName(fileName).Split(Path.GetInvalidFileNameChars()));
            this.FileName = Path.Combine(justRootPath, justFileName);
        }

        #region Properties

        /// <summary>
        /// The file to log to.
        /// </summary>
        public string FileName { get; protected set; }

        #endregion

        #region IDirectLog Members

        /// <summary>
        /// Opens the DirectFileLog.
        /// </summary>
        public void Start()
        {
            this.currentHtmlDoc = 0;
            this.currentPicDoc = 0;
            this.currentXmlDoc = 0;
            if (!Directory.Exists(Path.GetDirectoryName(this.FileName)))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(this.FileName));
            }
            this.streamWriter = new StreamWriter(this.FileName, false);
            this.xmlWriter = new XmlTextWriter(this.streamWriter);
            this.xmlWriter.WriteStartElement("Log");
            this.xmlWriter.WriteStartElement("LogEntries");
            this.serializer = new XmlSerializer(typeof(LogEntry));

            if (!Directory.Exists(this.logDirectory))
            {
                Directory.CreateDirectory(this.logDirectory);
            }
        }

        /// <summary>
        /// Closes the DirectFileLog.
        /// </summary>
        public void End()
        {
            if (this.xmlWriter != null)
            {
                this.xmlWriter.Close();
                this.xmlWriter = null;
            }

            if (this.streamWriter != null)
            {
                this.streamWriter.Dispose();
                this.streamWriter = null;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Logs a new entry.
        /// </summary>
        /// <param name="entry">The entry to log.</param>
        public void Add(LogEntry entry)
        {
            if (entry == null)
            {
                //this means we are closing and still trying to handle entries
                return;
            }

            //TODO: we can buffer these and write in bulk

            if (this.streamWriter == null)
            {
                this.Start();
            }

            // save the file name for later
            string entryFile = Path.Combine(this.logDirectory,
                    string.Concat(Path.GetFileNameWithoutExtension(this.FileName), ".",
                        this.currentHtmlDoc, ".", entry.EntryTime.ToString("hhmmss")));

            switch (entry.Type)
            {
                case EntryType.PlainText:
                    if (this.serializer != null)  // HACK: Why would serializer be null?..who knows
                    {
                        this.serializer.Serialize(this.xmlWriter, entry);
                    }
                    break;

                case EntryType.Html:
                    using (StreamWriter writer = File.CreateText(string.Concat(entryFile, ".htm")))
                    {
                        entry.Text.Replace("\r\n", "<BR>");
                        writer.Write(entry.Text);
                        this.currentHtmlDoc++;
                    }
                    break;

                case EntryType.Picture:
                    entryFile = Path.Combine(this.logDirectory,
                            string.Concat(Path.GetFileNameWithoutExtension(this.FileName), ".",
                            this.currentPicDoc, ".", entry.EntryTime.ToString("hhmmss")));

                    string filename = string.Concat(entryFile, ".jpg");

                    ImageInfoWriter.WriteJpeg(filename, entry.Array, entry.ImageInfo);

                    this.currentPicDoc++;

                    break;

                case EntryType.XmlFile:
                case EntryType.XML:
                    if (this.serializer != null)
                    {
                        this.serializer.Serialize(this.xmlWriter, entry);
                    }

                    // make sure the SOA subdirectory exist
                    if (!Directory.Exists(Path.Combine(this.logDirectory, "SOA")))
                        Directory.CreateDirectory(Path.Combine(this.logDirectory, "SOA"));

                    // Construct the file name
                    string fileName = Path.GetFileNameWithoutExtension(this.FileName);

                    if (entry.AdditionalInfo.Count > 2)
                    {
                        fileName = entry.AdditionalInfo[0] + entry.AdditionalInfo[1];
                    }

                    entryFile = Path.Combine(Path.Combine(this.logDirectory, "SOA"),
                            string.Concat(fileName, ".",
                            this.currentXmlDoc, ".", entry.EntryTime.ToString("MM-dd-yyyy_HH-mm-ss-fff", CultureInfo.InvariantCulture)));

                    // Check whether we want to write as binary or not
                    if (entry.AdditionalInfo[2].Equals("binary", StringComparison.InvariantCultureIgnoreCase))
                    {
                        using (FileStream fs = File.Create(string.Concat(entryFile, ".binary")))
                        {
                            BinaryWriter bw = new BinaryWriter(fs);
                            bw.Write(entry.Array);
                            this.currentXmlDoc++;
                            bw.Close();
                        }
                    }
                    else
                    {
                        this.currentXmlDoc++;

                        //
                        // Make sure the xml text is formatted
                        //
                        try
                        {
                            using (StringWriter stringWriter = new StringWriter())
                            {
                                // Load the string into xml document
                                XmlDocument doc = new XmlDocument();
                                //keep white spaces
                                doc.PreserveWhitespace = true;

                                doc.LoadXml(entry.Text);

                                // output the xml to a string thru xmlwriter
                                XmlWriterSettings settings = new XmlWriterSettings();
                                settings.Indent = true;
                                settings.IndentChars = "  ";
                                settings.NewLineChars = Environment.NewLine;

                                using (XmlWriter xmlWriter = XmlWriter.Create(stringWriter, settings))
                                {
                                    doc.WriteTo(xmlWriter);
                                    xmlWriter.Flush();
                                    using (StreamWriter writer = File.CreateText(string.Concat(entryFile, "-Formatted.xml")))
                                    {
                                        writer.Write(stringWriter.ToString());
                                    }
                                }

                                doc = null;
                            }
                        }
                        catch (Exception ex)
                        {
                            EventLog.WriteEntry("Application", "Fail to write the SOA xml file. Exception : " + ex.Message, EventLogEntryType.Error);
                        }
                    }

                    break;

                case EntryType.FastInfoSet:
                case EntryType.File:

                    if (this.serializer != null)
                    {
                        this.serializer.Serialize(this.xmlWriter, entry);
                    }

                    // make sure the SOA subdirectory exist
                    if (!Directory.Exists(Path.Combine(this.logDirectory, "Files")))
                        Directory.CreateDirectory(Path.Combine(this.logDirectory, "Files"));

                    LogHelper.Instance.WriteContentToUniqueFile(entry, Path.Combine(this.logDirectory, "Files"));

                    this.currentXmlDoc++;

                    break;
            }
        }

        /// <summary>
        /// Deserializes a DirectFileLog into an ILog.
        /// </summary>
        /// <param name="fileName">The file to load.</param>
        /// <returns>The object version of the file.</returns>
        public static ILog GetLog(string fileName)
        {
            TFxLog log = new TFxLog();

            if (File.Exists(fileName))
            {
                XmlTextReader reader = null;

                try
                {
                    XmlDocument xmlDocument = new XmlDocument();
                    xmlDocument.Load(fileName);
                    XmlNodeList nodeList = xmlDocument.SelectNodes("Log//LogEntries//LogEntry");
                    XmlSerializer serializer = new XmlSerializer(typeof(LogEntry));

                    foreach (XmlNode node in nodeList)
                    {
                        try
                        {
                            LogEntry entry = (LogEntry)serializer.Deserialize(new XmlTextReader(node.OuterXml, XmlNodeType.Element, null));
                            log.Add(entry);
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                        }
                    }
                }
                catch (Exception e)
                {
                    // Write exeption and return empty log.
                    Console.WriteLine(e);
                }
                finally
                {
                    if (reader != null)
                    {
                        reader.Close();
                    }
                }
            }

            return log;
        }

        #endregion

        #region IDisposable Members

        /// <summary>
        /// Dispose
        /// </summary>
        public void Dispose()
        {
            this.End();
        }

        #endregion

        #region Fields

        private int currentHtmlDoc;
        private int currentPicDoc;
        private int currentXmlDoc;

        private string logDirectory = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + "\\Log";

        /// <summary>
        /// The StreamWriter open to the log file.
        /// </summary>
        private StreamWriter streamWriter;

        /// <summary>
        /// The XmlTextWriter on top of the StreamWriter
        /// </summary>
        private XmlTextWriter xmlWriter;

        /// <summary>
        /// Serializer which serializes objects and outputs them to the XmlTextWriter
        /// </summary>
        private XmlSerializer serializer;

        #endregion
    }
}
