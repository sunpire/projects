using System;
using System.IO;
using System.Net;
using System.Text;

namespace TFxPublishCmd
{
    /// <summary>
    /// Command line publisher sending web request to LabRunManager Publish Build page
    /// </summary>
    class TFxPublishCmd
    {
        static string m_TFxBuildFolder = "\\\\chelsqltfx01.idx.expedmz.com\\Builds\\";

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            if (args.Length < 4)
            {
                Console.Write("Usage: TFxPublishCmd [Release] [BuildName] [LocalBuildFolder] [LabRunManager URL (e.g. http://tfx/LabRunManager/)] [email(optional)] -wait(optional)");
                return;
            }

            string release = args[0];
            string build = args[1];
            string localPath = args[2];

            if (!Directory.Exists(localPath))
            {
                Console.Write("Path does not exist: " + localPath);
                return;
            }

            string buildFolder = m_TFxBuildFolder + release + "\\" + build;
            if (Directory.Exists(buildFolder))
            {
                Console.Write("Build folder already exists: " + buildFolder + ". Do you want to overwrite existing folder? (y/n) ");
                if (!(Console.ReadLine().ToLower().StartsWith("y")))
                    return;
            }

            if (localPath.ToLower().Equals(buildFolder.ToLower()))
            {
                Console.Write("Error: Please provide a local folder to the build.");
                return;
            }

            //Copy build from local folder to TFx build folder
            CopyDirectory(new DirectoryInfo(localPath), new DirectoryInfo(buildFolder), true);

            //Send WebRequest to LRM Publish Page to create publish request
            string url = args[3];
            if (!url.EndsWith("\\") && !url.EndsWith("/"))
                url += "/";
            url += "build/publishbuild.aspx?execute=1&buildFolder=" + buildFolder;

            if (args.Length > 4 && args[4] != "-wait")
                url += "&email=" + args[4];

            WebRequest myRequest = WebRequest.Create(url);
            myRequest.Credentials = System.Net.CredentialCache.DefaultCredentials;
            // Return the response. 
            WebResponse myWebResponse = myRequest.GetResponse();

            // Obtain a 'Stream' object associated with the response object.
            Stream ReceiveStream = myWebResponse.GetResponseStream();

            Encoding encode = System.Text.Encoding.GetEncoding("utf-8");

            // Pipe the stream to a higher level stream reader with the required encoding format. 
            StreamReader readStream = new StreamReader(ReceiveStream, encode);
            string response = readStream.ReadToEnd();
            int start = -1;
            int end = -1;
            start = response.IndexOf("LabelMessage\"");
            if (start >= 0)
            {
                end = response.IndexOf("</span>", start);

                if (end >= 0)
                {
                    Console.WriteLine("{0}", response.Substring(start + 14, end - start - 14));
                }

            }
            else
            {
                Console.WriteLine("{0}", response);
            }

            // Close the response to free resources.
            myWebResponse.Close();

            // write publish status to console
            if ((args.Length > 4 && args[4] == "-wait") ||
                (args.Length > 5 && args[5] == "-wait"))
            {
                Console.Write("Waiting for publish result");
                while (!File.Exists(buildFolder + "\\_PublishResult.txt"))
                {
                    System.Threading.Thread.Sleep(2000);
                    Console.Write('.');
                }
                
                Console.WriteLine();

                StreamReader sr = File.OpenText(buildFolder + "\\_PublishResult.txt");
                string s = sr.ReadLine();
                while (s != null)
                {
                    Console.WriteLine(s);
                    s=sr.ReadLine();
                }
                sr.Close();
            }
        }

        /// <summary>
        /// Copy all files and sub directories from srcPath to destPath.
        /// If destPath exists, it will be removed and replaced with files and directories from srcPath.
        /// </summary>
        static void CopyDirectory(DirectoryInfo srcPath, DirectoryInfo destPath, bool recursive)
        {
            if (destPath.Exists)
                destPath.Delete(true);

            destPath.Create();

            // copy files 
            foreach (FileInfo fi in srcPath.GetFiles())
            {
                fi.CopyTo(Path.Combine(destPath.FullName, fi.Name), true);
            }

            // copy directories 
            if (recursive)
            {
                foreach (DirectoryInfo di in srcPath.GetDirectories())
                {
                    CopyDirectory(di, new DirectoryInfo(Path.Combine(destPath.FullName, di.Name)), recursive);
                }
            }
        } 
    }
}
