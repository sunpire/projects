using System;
using System.Collections;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace Expedia.Test.Framework
{
    class TestRunCmd
    {
        private FileRepository repository = new FileRepository();
        private string configPath;
        private string modulePath;
        private ArrayList testFullNames;
        private TestBuild localBuild;
        private ArrayList modules;

        private XmlDocument xmldoc = null;
        private string resultXmlFilePath = null;
        private ArrayList resultList = new ArrayList();
        private int assignmentCount = 0;

        public TestRunCmd(string module, string testCollectionPath, string config, string resultXmlFile)
        {
            resultXmlFilePath = resultXmlFile;

            // Generate the xml instance to store the results
            if (!String.IsNullOrEmpty(resultXmlFilePath))
            {
                xmldoc = new XmlDocument();
                //add the XML declaration section
                XmlNode xmlnode = xmldoc.CreateNode(XmlNodeType.XmlDeclaration, "", "");
                xmldoc.AppendChild(xmlnode);
            } // if

            this.modulePath = module;

            this.testFullNames = new ArrayList();
            TextReader tr = new StreamReader(testCollectionPath);
            string testName = tr.ReadLine();
            while (testName != null)
            {
                this.testFullNames.Add(testName);
                testName = tr.ReadLine();
            }
            tr.Close();

            this.configPath = config;

            this.localBuild = new TestBuild();
            this.modules = new ArrayList();
        }

        public void Run()
        {
            this.loadModules();

            AssignmentCollection col = this.createAssignments();
            TFxTeam team = GetTeam();
            LabRun run = CreateLabRun(team, col);
            assignmentCount = run.Assignments.Count;

            if (run != null && run.Assignments != null && run.Assignments.Count > 0 && team != null)
            {
                (new ExecutionManager()).Execute(team, run);
            }
        }

        /// <summary>
        /// Writ the results to an xml file
        /// </summary>
        public void writeResultToXML()
        {
            if (xmldoc != null)
            {
                XmlElement xmlelem = xmldoc.CreateElement("Results");
                xmldoc.AppendChild(xmlelem);

                for (int i = 0; i < resultList.Count; i++)
                {
                    XmlElement element = (XmlElement)resultList[i];
                    xmlelem.AppendChild(element);
                }

                xmldoc.Save(resultXmlFilePath);
            } // if
        }

        private TFxTeam GetTeam()
        {
            TFxTeam team1 = new TFxTeam();
            team1.Manager = new TFxUser();
            team1.Manager.IsManager = true;
            team1.Manager.Name = "TP_Manager";

            team1.Clients = new ClientCollection();
            LocalClient client = new LocalClient(1, null);

            client.Tester = new TFxUser();
            client.Tester.IsManager = false;
            client.Tester.Name = "TP_Client";

            client.Name = "TP_Client";
            client.ClientAssignmentCompleted += new ClientAssignmentEventHandler(this.AssignmentCompleted);
            team1.Clients.Add(client);

            return team1;
        }

        private void AssignmentCompleted(Client client, Assignment assignment, AssignmentResult result)
        {
            //
            // Output the result to command line
            //
            string output = "Assignment ID: " + assignment.AssignmentId.ToString() +
                            "\nTest Case Name: " + assignment.TestCase.FullName.ToString() +
                            "\nTest Result: " + result.Status.ToString();
            if (!result.Status.ToString().Equals("Pass"))
            {
                output += "\nFailure Reason: " + result.FailureReason;
            }

            output += "\n";

            Console.WriteLine(output);

            //
            // Store the result as XML format 
            //
            if (xmldoc != null)
            {
                XmlElement resultElement = xmldoc.CreateElement("Result");
                XmlElement nameElement = xmldoc.CreateElement("name");
                nameElement.InnerText = assignment.TestCase.FullName;
                XmlElement statusElement = xmldoc.CreateElement("Status");
                statusElement.InnerText = result.Status.ToString();
                XmlElement reasonElement = xmldoc.CreateElement("Reason");
                resultElement.InnerText = result.FailureReason;

                resultElement.AppendChild(nameElement);
                resultElement.AppendChild(statusElement);
                resultElement.AppendChild(reasonElement);

                resultList.Add(resultElement);

                assignmentCount -= 1;

                if (assignmentCount == 0)
                {
                    writeResultToXML();
                } // if
            } // if
        }

        private ConfigData getConfigData()
        {
            ConfigRequest configRequest = new ConfigRequest(RepositoryRequestType.Get);
            configRequest.ConfigExpression = (ConfigExpressionData)this.GetObject(typeof(ConfigExpressionData), "Config.xml");
            return configRequest.Data();
        }

        private object GetObject(Type type, string extention)
        {
            if (File.Exists(this.configPath))
            {
                XmlTextReader reader = null;
                try
                {
                    XmlSerializer serializer = new XmlSerializer(type);
                    reader = new System.Xml.XmlTextReader(this.configPath);
                    return serializer.Deserialize(reader);
                }
                finally
                {
                    if (reader != null)
                    {
                        reader.Close();
                    }
                }
            }
            return null;
        }

        private void loadModules()
        {
            ExecuteTestModule module = new ExecuteTestModule(this.modulePath);
            module.BuildName = "local";
            this.modules.Add(module);

            //add modules to local build
            localBuild.Modules = (TestBuildModule[])this.modules.ToArray(typeof(TestBuildModule));
        }

        private AssignmentCollection createAssignments()
        {

            int assignmentCount = 1;
            TestInfoCollection validTestCases = new TestInfoCollection();

            foreach (string testFullName in this.testFullNames)
            {
                validTestCases.Add(new TestCase(testFullName));
            }

            AssignmentCollection assignList = new AssignmentCollection();
            IConfig[] Data = this.getConfigData().GetAllConfigs();

            if (Data != null && Data.Length > 0)
            {
                //Loop througth the entire selected config data
                for (int index = 0; index < Data.Length; index++)
                {
                    //Loop through the entire selected test cases
                    if (validTestCases != null && validTestCases.Count > 0)
                    {
                        foreach (TestCase testCase in validTestCases)
                        {
                            Assignment assignment = new Assignment();
                            assignment.TestCase = testCase as TestCase;
                            assignment.TestCase.Module = this.localBuild.GetModule(this.modulePath);
                            //assignment.TestCase.Module.DllFullName = this.modulePath;
                            ConfigData dd = new ConfigData();
                            dd.Append(Data[index]);

                            assignment.AssignmentId = assignmentCount;
                            assignList.Add(assignment);
                            assignment.LabRun = new LabRun();
                            assignment.LabRun.Name = "TestStudioCMD";
                            assignment.LabRun.LabRunGid = Guid.Empty/*1*/; //Not sure what this means
                            assignment.LabRun.Build = this.localBuild;

                            assignment.ConfigData = dd;

                            string timeout = assignment.ConfigData.GetValue(TFxConst.c_AssignmentTimeout);
                            if (timeout != null)
                            {
                                try
                                {
                                    assignment.AssignmentTimeout = TimeSpan.Parse(timeout);
                                }
                                catch
                                {
                                    // this is not a value timeout
                                    assignment.AssignmentTimeout = TimeSpan.Zero;
                                }
                            }
                            assignmentCount++;
                        }
                    }
                }
            }
            return assignList;
        }

        private LabRun CreateLabRun(TFxTeam team, AssignmentCollection col)
        {
            LabRun run = new LabRun();
            run.Assignments = col;
            run.Name = System.DateTime.Now.ToString();

            run.Build = this.localBuild;
            run.Manager = team.Manager;

            foreach (Assignment assignment in run.Assignments)
            {
                assignment.AssignedTo = run.Manager;
                assignment.LabRun = new LabRun();
                assignment.LabRun.Name = run.Name;
                assignment.LabRun.AssignedTo = run.Manager;
                assignment.Result = null;
                assignment.RunStatus = AssignmentStatusType.None;
            }

            return run;
        }
    }
}
