using System;
using System.Collections.Generic;
using System.Text;
using Expedia.Test.Framework;

namespace TestStudioCmd
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.GetLength(0) == 3)
            {
                TestRunCmd testRun = new TestRunCmd(args[0], args[1], args[2], "false");
                testRun.Run();
            }
            else if (args.GetLength(0) == 4)
            {
                TestRunCmd testRun = new TestRunCmd(args[0], args[1], args[2], args[3]);
                testRun.Run();
            }
            else
            {
                Console.WriteLine("Expecting 3 Args: <modulepath> <testcollectionpath> <configfilepath>");
            }
        }
    }
}
