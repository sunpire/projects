﻿
namespace TFxRunner
{
    public enum TestRunResultType
    {
        Pass = 0,
        ModuleNotFound = 1,
        FailToFindTest = 2,
        BuildNotInstalled = 3,
        ExecutionError = 4,
        UnknownError = 5,
        FailToLoad = 6,
        NoResults = 7,
        Timeout = 8
    }
}
