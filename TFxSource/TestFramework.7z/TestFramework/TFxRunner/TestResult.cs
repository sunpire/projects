﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TFxRunner
{
    /// <summary>
    /// TestResult.
    /// </summary>
    public sealed class TestResult
    {
        public TestResult()
        {
        }

        public TestResult(string testName, Exception e)
        {
            this.TestName = testName;
            this.RunResult = TestRunResultType.UnknownError;
            this.FailureReason = e.ToString();
            this.Scenarios = new List<ScenarioResult>();
        }

        public TestResult(string testName, string runResult, string failureReason, string[,] scenarios)
        {
            this.TestName = testName;
            this.RunResult = (TestRunResultType)Enum.Parse(typeof(TestRunResultType), runResult);
            this.FailureReason = failureReason;
            this.Scenarios = new List<ScenarioResult>();

            if (scenarios != null)
            {
                int scenariosLength = scenarios.GetLength(0);
                for (int i = 0; i < scenariosLength; i++)
                {
                    ScenarioResult scenarioResult = new ScenarioResult
                    {
                        ScenarioName = scenarios[i, 0],
                        Status = scenarios[i, 1],
                        FailureReason = scenarios[i, 2],
                        FailureDetail = scenarios[i, 3]
                    };

                    this.Scenarios.Add(scenarioResult);
                }
            }
        }
        public string TestName { get; set; }

        public string FailureReason { get; set; }

        public TestRunResultType RunResult { get; set; }

        public List<ScenarioResult> Scenarios { get; set; }

        public override string ToString()
        {
            return this.ToString(false);
        }

        public string ToString(bool verbose)
        {
            StringBuilder builder = new StringBuilder();

            if (verbose)
            {
                builder.AppendLine(string.Format("Result: {0}", this.RunResult.ToString()));

                if (this.RunResult != TestRunResultType.Pass)
                {
                    builder.AppendLine(string.Format("Failure Reason: {0}", this.FailureReason));
                }

                if (this.Scenarios != null && this.Scenarios.Count > 0)
                {
                    builder.AppendLine("Scenarios:");
                    foreach (ScenarioResult scenarioResult in this.Scenarios)
                    {
                        builder.AppendLine(scenarioResult.ToString());
                    }
                }
            }
            else
            {
                if (this.RunResult != TestRunResultType.Pass)
                {
                    builder.Append(this.FailureReason);
                }
            }

            return builder.ToString();
        }
    }
}