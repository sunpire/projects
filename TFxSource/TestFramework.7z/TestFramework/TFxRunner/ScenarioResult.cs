﻿using System;
using System.Text;

namespace TFxRunner
{
    /// <summary>
    /// ScenarioResult.
    /// </summary>
    public sealed class ScenarioResult
    {
        public string ScenarioName { get; set; }

        public bool IsFailure { get { return !this.Status.Equals("Pass", StringComparison.InvariantCultureIgnoreCase); } }

        public string FailureDetail { get; set; }

        public string FailureReason { get; set; }

        public string Status { get; set; }

        public override string ToString()
        {
            return this.ToString(false);
        }

        public string ToString(bool verbose)
        {
            StringBuilder builder = new StringBuilder();

            builder.AppendLine(string.Format("\t{0}: {1}", this.ScenarioName, this.Status));
            if (this.IsFailure && verbose)
            {
                builder.AppendLine(string.Format("\t\tFailure Reason: {0}", this.FailureReason));
                builder.AppendLine(string.Format("\t\tDetail: {0}", this.FailureDetail));
            }

            return builder.ToString();
        }
    }
}