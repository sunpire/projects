﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;
using System.Diagnostics;
using System.Reflection;

namespace TFxRunner
{
    internal class Executioner
    {
        private static TestResult result;
        private static AutoResetEvent autoEvent = new AutoResetEvent(false);
        private string testName;

        internal TestResult ExecuteTest(string dllPath, string testName, Dictionary<string, string> assignmentConfigs, Dictionary<string, string> testConfigs, Dictionary<string, string> testParameters, TimeSpan timeOut, bool verbose)
        {

            Thread timerThread = null;
            Executioner.result = null;

            this.testName = testName;
            if (verbose)
            {
                Console.WriteLine("Executing test:");
                Console.WriteLine("{0}:{1}", dllPath, testName);
                Console.WriteLine("--------------------------------");
            }

            if (!File.Exists(dllPath))
            {
                Executioner.result = new TestResult
                {
                    TestName = testName,
                    RunResult = TestRunResultType.ModuleNotFound,
                    FailureReason = string.Format("Test DLL not found: {0}", dllPath),
                    Scenarios = null
                };
            }
            else
            {
                try
                {
                    timerThread = timerThread = new Thread(new ParameterizedThreadStart(Timer));
                    timerThread.Name = "TestRunnerTimeout";
                    timerThread.Start(timeOut);

                    // Begin execution
                    string buildPath = Path.GetDirectoryName(dllPath);
                    string driverPath = Path.Combine(buildPath, "ExpTestDriver.dll");

                    Assembly a = Assembly.LoadFrom(driverPath);
                    Assembly.LoadFrom(Path.Combine(buildPath, "TFxCore.dll"));
                    Assembly.LoadFrom(Path.Combine(buildPath, "TFxAppCore.dll"));
                    Assembly.LoadFrom(Path.Combine(buildPath, "TFxLogger.dll"));

                    Type driver = a.GetType("Expedia.Test.Framework.Driver", true, true);

                    MethodInfo method = driver.GetMethod("Execute",
                       new Type[] { 
                        typeof(string), 
                        typeof(string), 
                        typeof(Dictionary<string, string>), 
                        typeof(Dictionary<string, string>), 
                        typeof(string[,]).MakeByRefType(), 
                        typeof(string).MakeByRefType(), 
                        typeof(string).MakeByRefType(),
                        typeof(string).MakeByRefType(),
                        typeof(string).MakeByRefType()
                       });
           
                    if (method == null)
                    {
                        StringBuilder builder = new StringBuilder("Unable to find Execute method in the Driver");
                        builder.AppendLine();
                        MethodInfo[] methods = driver.GetMethods(BindingFlags.Public | BindingFlags.Static);
                        Array.ForEach<MethodInfo>(methods, m => builder.AppendLine(m.Name));

                        throw new Exception(builder.ToString());
                    }

                    //Set parameters for Driver.Execute function - 4 inputs, 5 out
                    object[] arrParms = new object[9];
                    arrParms.SetValue(testName, 0);
                    arrParms.SetValue(dllPath, 1);
                    arrParms.SetValue(assignmentConfigs, 2);
                    arrParms.SetValue(testParameters, 3);

                    ParameterInfo[] infoss = method.GetParameters();

                    object obj = method.Invoke(null, arrParms);

                    

                    result = new TestResult(
                                        testName,
                                        (string)arrParms[6],
                                        (string)arrParms[5],
                                        (string[,])arrParms[4]);
                }
                catch (Exception e)
                {
                    Executioner.result = new TestResult(testName, e);
                }
                finally
                {
                    //signal timer thread that test execution is completed
                    autoEvent.Set();
                    if (timerThread != null)
                    {
                        timerThread.Join();
                    }
                }
            }

            return Executioner.result;
        }

        /// <summary>
        /// Timer thread to keep test execution time
        /// Save Timeout result and kill process if timeout happens
        /// </summary>
        /// <param name="timeout"></param>
        void Timer(object timeout)
        {
            // assignment has timed out
            if (!Executioner.autoEvent.WaitOne((TimeSpan)timeout, false))
            {
                Executioner.result = new TestResult
                {
                    TestName = this.testName,
                    RunResult = TestRunResultType.Timeout,
                    FailureReason = "",
                    Scenarios = null
                };

            }
        }
    }
}
