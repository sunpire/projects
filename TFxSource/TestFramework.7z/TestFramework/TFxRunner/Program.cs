﻿using System;
using System.Collections.Generic;

namespace TFxRunner
{
    class Program
    {
        [STAThread()]
        static int Main(string[] args)
        {
            if (args.Length >= 2)
            {
                if (args[0].Equals("-x", StringComparison.CurrentCultureIgnoreCase))
                {
                    Program.ExecuteXml(args[1]);
                    return 2;
                }
                else
                {
                    string dllPath = args[0];
                    string testName = args[1];
                    bool verbose = false;
                    TimeSpan timeOut = TimeSpan.FromMinutes(10);
                    Dictionary<string, string> configs = new Dictionary<string, string>();
                    Dictionary<string, string> testParameters = new Dictionary<string, string>();


                    for (int i = 2; i < args.Length; i++)
                    {
                        if (args[i].Equals("-t", StringComparison.CurrentCultureIgnoreCase))
                        {
                            TimeSpan.TryParse(args[++i], out timeOut);
                        }

                        if (args[i].Equals("-v", StringComparison.CurrentCultureIgnoreCase))
                        {
                            verbose = true;
                        }

                        if (args[i].Equals("-c", StringComparison.CurrentCultureIgnoreCase))
                        {
                            for (++i; i < args.Length; i += 2)
                            {
                                if (args[i].StartsWith("-"))
                                {
                                    i--;
                                    break;
                                }

                                if ((i + 1) >= args.Length)
                                {
                                    Console.WriteLine("Error: configs are not paired correctly");
                                    return 2;
                                }

                                if (args[i + 1].StartsWith("-"))
                                {
                                    Console.WriteLine("Error: configs are not paired correctly");
                                    return 2;
                                }

                                configs.Add(args[i], args[i + 1]);
                            }
                        }
                        if (i < args.Length)
                        {
                            if (args[i].Equals("-p", StringComparison.CurrentCultureIgnoreCase))
                            {
                                for (++i; i < args.Length; i += 2)
                                {
                                    if (args[i].StartsWith("-"))
                                    {
                                        i--;
                                        break;
                                    }

                                    if ((i + 1) >= args.Length)
                                    {
                                        Console.WriteLine("Error: test parameters are not paired correctly");
                                        return 2;
                                    }

                                    if (args[i + 1].StartsWith("-"))
                                    {
                                        Console.WriteLine("Error: test parameters are not paired correctly");
                                        return 2;
                                    }

                                    testParameters.Add(args[i], args[i + 1]);
                                }
                                break;
                            }
                        }
                    }

                    Executioner executioner = new Executioner();
                    TestResult result = executioner.ExecuteTest(dllPath, testName, configs, null, testParameters, timeOut, verbose);

                    Console.WriteLine("--------------------------------");
                    Console.Write(result.ToString(verbose));
                    return (result.RunResult == TestRunResultType.Pass) ? 0 : 1;
                }
            }

            Console.WriteLine();
            Console.WriteLine("Usage: tfxrunner [[dll_path test_name [-t timeout] [-v] [-c config_name config_value [...]] [-p parameter_name parameter_value [...]]] | [-x xml_path]]");
            Console.WriteLine();
            Console.WriteLine("\tdll_path\tA TFx DLL name or path, e.g. CommonTest.dll");
            Console.WriteLine("\ttest_name\tThe TFx full test name, which is the C# namespace and the method name (the class name is excluded)");
            Console.WriteLine();
            Console.WriteLine("\t-t\tSpecifies a test timeout in format hh:mm:ss.");
            Console.WriteLine("\t-v\tEnables verbose output.");
            Console.WriteLine("\t-c\tSpecifies configs for test.  Configs follow in pairs of names and values.");
            Console.WriteLine("\t-p\tSpecifies parameters (arguments) for the test method.  Parameters follow in pairs of names and values.");
            Console.WriteLine("\t-x\tSpecifies an LRM/TestStudio export file to execute. (Not implemented)");

            return 0;
        }


        internal static void ExecuteXml(string xmlPath)
        {
            Console.WriteLine("ExecuteXml: " + xmlPath);
            Console.WriteLine();
            Console.WriteLine(@"This functionality is not yet implemented.  Please contact Engineering Tools with your requirements if you think we should implement this feature.");
        }
    }
}