﻿using System;
using System.Collections.Generic;
using System.Data.Linq;
using System.Linq;
using System.Reflection;

namespace Expedia.Test.Framework
{
    public static class Extensions
    {
        public static EntitySet<T> ToEntitySet<T>(this IEnumerable<T> source) where T : class
        {
            var es = new EntitySet<T>();
            es.AddRange(source);
            return es;
        }

        public static IEnumerable<T> Except<T, T1>(this IEnumerable<T> source, IEnumerable<T1> toBeRemoved, Func<T, T1, bool> filter)
        {
            var el = from e in source
                     where (
                            from t in toBeRemoved
                            where filter(e, t)
                            select t
                     ).Count() <= 0
                     select e;

            return el.ToList();
        }

        public static object GetPropertyName(this object obj, string propertyName)
        {
            MemberInfo[] mi = obj.GetType().GetMember(propertyName);

            if (mi != null && mi.Length > 0)
            {
                if (mi[0].MemberType == MemberTypes.Field)
                {
                    FieldInfo fi = mi[0] as FieldInfo;
                    return fi.GetValue(obj) as string;
                }
                else if (mi[0].MemberType == MemberTypes.Property)
                {
                    PropertyInfo pi = mi[0] as PropertyInfo;
                    return pi.GetValue(obj, null) as object;
                }
            }

            return null;
        }
    }
}
