﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Xml.Linq;
using System.Text.RegularExpressions;
using System.Collections;

namespace Expedia.Test.Framework
{
    public class RubyParam
    {
        public RubyParam()
        {
        }

        public string DefaultValue;
        public string DataType;
        public string Name;

    }

    public class JUnitDefaultConfig
    {
        public JUnitDefaultConfig()
        {
        }

        public string DefaultValue;
        public string DataType;
        public string Name;

    }

    public static class PublisherEngine
    {
        #region internal class
        //get Java program output
        internal class GetOutput
        {
            private StreamReader mReader;
            private StringBuilder output = new StringBuilder(4000);

            //check whether current thread has abort or not
            public bool IsAbort { private set; get; }

            public StringBuilder Output
            {
                get { return output; }
            }
            public GetOutput(StreamReader reader)
            {
                this.mReader = reader;
            }
            public void Read()
            {
                int a = -1;
                while ((a = mReader.Read()) > 0)
                {
                    output.Append(((char)a).ToString());
                }
                IsAbort = true;
                Thread.CurrentThread.Abort();
                return;
            }
        }

        #endregion

        public static string xmlFullPath = String.Empty;

        public static object[] List(string moduleFullName)
        {
            string extension = Path.GetExtension(moduleFullName);

            switch (extension)
            {
                case ".dll":
                    return Driver.FlatList(moduleFullName);

                case ".jar":
                    return PublisherEngine.ListJunitTestCases(moduleFullName, PublisherEngine.xmlFullPath);
               
                case ".rb":
                    return PublisherEngine.ListRubyTestCases(moduleFullName);

                default:
                    return null;
            }
        }

        #region Junit Functionality

        private static object[] ListJunitTestCases(string moduleFullName, string xmlFullPath)
        {
            if (!File.Exists(PublisherEngine.xmlFullPath))
            {
                //Get the list of test cases by calling the JunitDriver.jar
                return PublisherEngine.Lister(moduleFullName, xmlFullPath);
            }

            //The file alreay exists so return the test cases. list is called only once and it will all
            //test cases for the jar files in the folder
            return PublisherEngine.ParseXML(Path.GetFileName(moduleFullName), xmlFullPath);
        }

        public static object[] ParseXML(string moduleName, string xmlFullPath)
        {
            XDocument doc = XDocument.Load(xmlFullPath);

            if (doc != null)
            {
                var testCaseNames = (from moduleElement in doc.Descendants("Module")
                                     from testElements in moduleElement.Descendants("Test")
                                     where moduleElement.Attribute("moduleName").Value == moduleName
                                     select new
                                     {
                                         TestFullName = testElements.Attribute("testName").Value,
                                         ConfigList = GetJUnitDefaultConfigList(testElements.Attribute("parameterName").Value,
                                         testElements.Attribute("parameterValue").Value)
                                     }
                                     ).ToArray();

                return testCaseNames;
            }

            return null;
        }


        private static object[] GetJUnitDefaultConfigList(string name, string value)
        {
            Dictionary<string, JUnitDefaultConfig> defaultConfigList = new Dictionary<string, JUnitDefaultConfig>();

            string[] names = name.Split(',');
            string[] values = value.Split('-');

            if (names.Length != values.Length)
            {
                return null;
            }

            for (int i = 0; i < names.Length; i++)
            {
                JUnitDefaultConfig defaultConfig = new JUnitDefaultConfig();

                defaultConfig.Name = names[i];
                defaultConfig.DataType = "System.String";
                defaultConfig.DefaultValue = values[i];

                defaultConfigList.Add(names[i], defaultConfig);
            }

            foreach (var config in defaultConfigList.Values)
            {
                Console.WriteLine("DefaultConfigName:  {0}, Config Type: {1}, ConfigValue: {2}", config.Name, config.DataType, config.DefaultValue);
                Console.WriteLine();
            }

            var configPublishingList = from config in defaultConfigList.Values
                                      select new { Name = config.Name, DataType = config.DataType, DefaultValue = config.DefaultValue };

            return configPublishingList.ToArray();
        }

        //Call the list function and pass the xml full path
        private static object[] Lister(string moduleFullName, string xmlFullPath)
        {
            //Call the JunitDriver.jar which is located in the build folder
            string directoryName = Path.GetDirectoryName(moduleFullName);

            string tempXmlFileName = "List_" + Guid.NewGuid() + ".xml";

            string tempXmlFullPath = Path.Combine(directoryName, tempXmlFileName);

            if (File.Exists(Path.Combine(directoryName, "JunitDriver.jar")))
            {
                string buildClassPath = BuildClassPath(directoryName);
                string param = string.Format("-Xms64m -Xmx1024m -classpath \"{0}\" junitdriver.Main list \"{1}\" \"{2}\"", buildClassPath, tempXmlFullPath, directoryName);

                RunExternalProgramResult result = PublisherEngine.Run(directoryName, "java.exe", param, null);

                if (result.ExitCode == 0)
                {
                    //The file will be copied to the primary build folder
                    File.Copy(tempXmlFullPath, xmlFullPath);
                    return PublisherEngine.ParseXML(Path.GetFileName(moduleFullName), xmlFullPath);
                }
                else
                {
                    Logger.Instance.WriteError("Error occured when trying to publish junit test case {0}", result.Output);
                    throw new TFxException(result.Output);
                }
            }
            else
            {
                string errorMessage = String.Format("JunitDriver does not exists in {0}", Path.Combine(directoryName, "JunitDriver.jar"));
                Logger.Instance.WriteError(errorMessage);
                throw new TFxException(errorMessage);
            }
        }

        //build class path for junitdriver.jar 
        public static string BuildClassPath(string buildPath)
        {
            StringBuilder buildClassPath = new StringBuilder();
            AddPath(buildPath, buildClassPath);
            return buildClassPath.ToString();
        }

        public static void AddPath(string buildPath, StringBuilder buildClassPath)
        {
            string[] getDirectories = Directory.GetDirectories(buildPath);
            buildClassPath.Append(buildPath + "\\*;");

            for (int j = 0; j < getDirectories.Length; j++)
            {
                AddPath(getDirectories[j], buildClassPath);
            }
        }

        public static RunExternalProgramResult Run(string workingfolder, string program, string param, Dictionary<string, string> env)
        {
            RunExternalProgramResult result = new RunExternalProgramResult();

            try
            {
                Process p = null;
                ProcessStartInfo ps = new ProcessStartInfo(program, param);
                ps.WorkingDirectory = workingfolder;
                ps.ErrorDialog = false;
                ps.UseShellExecute = false;
                ps.RedirectStandardOutput = true;
                ps.RedirectStandardError = true;
                if (env != null)
                {
                    foreach (string key in env.Keys)
                    {
                        if (ps.EnvironmentVariables.ContainsKey(key))
                        {
                            ps.EnvironmentVariables[key] = env[key];
                        }
                        else
                        {
                            ps.EnvironmentVariables.Add(key, env[key]);
                        }
                    }
                }

                p = Process.Start(ps);

                GetOutput output = new GetOutput(p.StandardOutput);
                GetOutput error = new GetOutput(p.StandardError);
                Thread thread1 = new Thread(new ThreadStart(output.Read));
                Thread thread2 = new Thread(new ThreadStart(error.Read));
                thread1.Start();
                thread2.Start();

                //wait for child process terminates
                while (!error.IsAbort || !output.IsAbort)
                {
                    System.Threading.Thread.Sleep(new TimeSpan(0, 0, 1));
                }

                result.Output = output.Output.ToString();
                result.Error = error.Output.ToString();
                result.ExitCode = p.ExitCode;
            }
            catch (Exception e)
            {
                result.Error = e.Message;
                result.Output = e.StackTrace;
                result.ExitCode = -1;
            }

            return result;
        }

        public class RunExternalProgramResult
        {
            public RunExternalProgramResult()
            {
            }

            public string Output;
            public string Error;
            public int ExitCode;
        }

        #endregion

        #region Ruby Functionality


        /// <summary>
        /// List all the ruby test cases in moduleFullName
        /// All Test Cases that start with #TestCase are listed.
        /// </summary>
        /// <param name="moduleFullName"></param>
        /// <returns></returns>
        public static object[] ListRubyTestCases(string moduleFullName)
        {

            string fileName = String.Empty;
            string directoryName = String.Empty;
            string testCaseName = String.Empty;
            Hashtable cacheParamList = new Hashtable();


            fileName = Path.GetFileNameWithoutExtension(moduleFullName);
            directoryName = Path.GetDirectoryName(moduleFullName);

            //We get the moduleFullName as "TFxTest.rb" or "EStar.rb". We need to remove 
            //the extension at the end
            moduleFullName = Path.Combine(directoryName, fileName);

            //List all the files in the module that end with .rb
            var filesList = (from file in Directory.GetFiles(moduleFullName, "*.rb", SearchOption.AllDirectories)
                             select file);

            //List all the test Methods that have #TestCase in comments
            var testMethods = (from file in filesList
                               where isRubyTestCase(file, "TestCase", out testCaseName)
                               select new
                               {
                                   TestFullName = GetTestFullName(testCaseName,file, moduleFullName),
                                   ParamList = GetParamList(file, moduleFullName, cacheParamList)

                               }).ToList();

            return testMethods.ToArray();

        }

        /// <summary>
        /// This function is responsible to get the full fileName including namespace
        /// </summary>
        /// <param name="fileFullName">Example ->\\chelsqlins01\\Builds\\ETTTest\\ETT_20090727\\Ruby\\Tests\\TFxTest\\lib\\TestFail.rb</param>
        /// <param name="moduleFullName">Example ->\\chelsqlins01\\Builds\\ETTTest\\ETT_20090727\\Ruby\\Tests\\TFxTest</param>
        /// <returns>Example -> TFxTest.lib.TestFail</returns>
        private static string GetTestFullName(string testCaseName,string fileFullName, string moduleFullName)
        {
            string fileName = Path.GetFileNameWithoutExtension(moduleFullName);
            string testFullName = fileFullName.Substring(moduleFullName.Length);
            string[] tokens = testFullName.Split('.');
            string tempTestFullName = string.Empty;
            
            if (tokens.Length > 0)
            {
                testFullName = fileName + tokens[0];
            }
            testFullName = testFullName.Replace('\\', '.');

            //Now we have to make sure that we add the class name not the fileName
            tokens = testFullName.Split('.');
            for (int i = 0; i < tokens.Length - 1; i++)
            {
                if (i == 0)
                {
                    tempTestFullName = tokens[i];
                }
                else
                {
                    tempTestFullName = tempTestFullName + "." + tokens[i];
                }                
            }

            //Now add the test case name at the end
            tempTestFullName = tempTestFullName + "." + testCaseName;

            testFullName = tempTestFullName;

            Console.WriteLine(testFullName);
            return testFullName;
        }

        /// <summary>
        /// Return true if the ruby test case starts with comments #TestCase 
        /// </summary>
        /// <param name="fileFullName"></param>
        /// <param name="stringToParse"></param>
        /// <returns></returns>
        private static bool isRubyTestCase(string fileFullName, string stringToParse, out string testCaseName)
        {

            Regex paramNameRegex = new Regex("#*Name::", RegexOptions.IgnoreCase);

            StreamReader sr = new StreamReader(fileFullName);
            string fileLine = String.Empty;
            string patternToMatch = "#" + stringToParse;
            testCaseName = String.Empty;
            bool testCaseFound = false;
            string pattern = @"class[\s]+[\d|\w]";
            Regex testCaseRegex = new Regex(patternToMatch, RegexOptions.IgnoreCase);
            Regex testCaseNameRegex = new Regex(pattern, RegexOptions.IgnoreCase);
            string tempFileName = null;           


            while ((fileLine = sr.ReadLine()) != null)
            {
                if (testCaseRegex.IsMatch(fileLine))
                {
                    testCaseFound = true;
                }

                //Get the testcase name 
                if (fileLine.Contains("class") && testCaseNameRegex.IsMatch(fileLine) && !fileLine.Contains('#'))
                {
                    if (testCaseFound)
                    {
                        //Get the fileName and then return
                        string[] tokens = fileLine.Split('<');
                        if (tokens.Length >= 1)
                        {
                            string[] tempTokens = tokens[0].Split(" ".ToCharArray());
                            if (tempTokens.Length >= 2)
                            {
                                tempFileName = tempTokens[1];
                            }
                        }
                        testCaseName = tempFileName;
                        break;
                    }                   
                }
            }

            return testCaseFound;

        }

        /// <summary>
        /// This is the first function that will be called to get the ParamList
        /// This will call the string fileFullName, string moduleFullName,Dictionary<string,RubyParam> childList,Hashtable cacheParamList
        /// </summary>
        /// <param name="fileFullName"></param>
        /// <param name="moduleFullName"></param>
        /// <param name="cacheParamList"></param>
        /// <returns></returns>
        private static object[] GetParamList(string fileFullName, string moduleFullName, Hashtable cacheParamList)
        {
            Dictionary<string, RubyParam> list;
            GetParamsList(fileFullName, moduleFullName, cacheParamList);
            list = cacheParamList[fileFullName] as Dictionary<string, RubyParam>;

            var paramValues = from param in list.Values
                              select new { Name = param.Name, DataType = param.DataType, DefaultValue = param.DefaultValue };

            foreach (var param in list.Values)
            {
                Console.WriteLine("ParamName:  {0}, Param Type: {1}, ParamValue: {2}", param.Name, param.DataType, param.DefaultValue);
                Console.WriteLine();
            }

            return paramValues.ToArray();
        }

         //<summary>
         //Get the list of params for the fileName. This method is responsible to get the param list for this file 
         //and also from the files it inherits from
         //</summary>
         //<param name="fileFullName"></param>
         //<param name="moduleFullName"></param>
         //<param name="cacheParamList">This will contain the list of params for each file. If the file is repeated then its gets the list
         //from the cache</param>
         //<returns></returns>
        private static Dictionary<string, RubyParam> GetParamsList(string fileFullName, string moduleFullName, Hashtable cacheParamList)
        {
            string baseClassFullName = String.Empty;
            Dictionary<string, RubyParam> childList = new Dictionary<string, RubyParam>();
            Dictionary<string, RubyParam> masterList = new Dictionary<string, RubyParam>();
                     
            if((baseClassFullName = fileFullName.GetBaseClass(moduleFullName)) != null)
            {
                childList = GetParamsList(baseClassFullName, moduleFullName,cacheParamList);
            }

            if (!cacheParamList.ContainsKey(fileFullName))
            {
                masterList = GetParamList(fileFullName);
                ResolveParameters(masterList, childList);
                childList = masterList;
                cacheParamList.Add(fileFullName, masterList);
                return childList;
            }

            return cacheParamList[fileFullName] as Dictionary<string, RubyParam>;
        }
               
       
        /// <summary>
        /// If the masterlist does not contain the paramName then add to the list
        /// or else ignore the param
        /// </summary>
        /// <param name="masterList"></param>
        /// <param name="p"></param>
        private static void ResolveParameters(Dictionary<string, RubyParam> masterList, Dictionary<string, RubyParam> childList)
        {
            if (childList != null)
            {
                foreach (string paramName in childList.Keys)
                {
                    if (!masterList.ContainsKey(paramName))
                    {
                        masterList.Add(paramName, childList[paramName]);
                    }
                }
            }
        }

        /// <summary>
        /// Returns the base class full name if the file inherits from another class
        /// </summary>
        /// <param name="fileFullName"></param>
        /// <param name="moduleFullName"></param>
        /// <returns></returns>
        public static string GetBaseClass(this string fileFullName, string moduleFullName)
        {
            StreamReader sr = new StreamReader(fileFullName);
            string baseLocationFileName = null;
            string fileLine = String.Empty;
            string tempBaseClassLocation = String.Empty;
            string pattern = @"class[\s]+[\d|\w]+[\s]+<";
            string skipPattern = @"class[\s]+[\d|\w]";

            Regex classRegex = new Regex(pattern, RegexOptions.IgnoreCase);
            Regex skipRegex = new Regex(skipPattern, RegexOptions.IgnoreCase);

            while ((fileLine = sr.ReadLine()) != null)
            {
                if (classRegex.IsMatch(fileLine))
                {
                    string[] tokens = fileLine.Split('<');
                    if (tokens.Length >= 2)
                    {
                        tempBaseClassLocation = GetBaseClassLocation(moduleFullName, tokens[tokens.Length - 1].Trim());
                        baseLocationFileName = tempBaseClassLocation;
                    }

                    return baseLocationFileName;
                }

                //Instead of going through the entire file break when 
                //in the class TestCase
                if (skipRegex.IsMatch(fileLine))
                {
                    return null;
                }
            }

            return null;
        }

        /// <summary>
        /// We need to find the base class entire file path location. If the base class location does not
        /// exists then we are going to get the 
        /// </summary>
        /// <param name="moduleFullName"></param>
        /// <param name="baseClassName">The name of the base class</param>
        /// <returns></returns>
        private static string GetBaseClassLocation(string moduleFullName, string actualBaseClassName)
        {
            DirectoryInfo dir = new DirectoryInfo(moduleFullName);
            FileInfo[] fileInfos = dir.GetFiles("*.rb",SearchOption.AllDirectories);

            //First we need to name of the baseClassFileName
            string baseClassFileName = GetBaseClassFileName(actualBaseClassName);

            foreach(FileInfo file in fileInfos)
            {
                //Matches either the baseClassName after changing it to ruby naming convention or the actualBaseClassName. 
                //They might be test cases that don't follow the ruby naming convention.
                if ((String.Compare(file.Name, baseClassFileName) == 0) || (String.Compare(file.Name, actualBaseClassName) == 0))
                {
                    return file.FullName;
                }
            }
           
            return null;
        }

        /// <summary>
        /// This class will take the baseClassName and find the fileName. In ruby
        /// if we have a class name as BaseClass then the file name will be something 
        /// like base_class.rb
        /// </summary>
        /// <param name="baseClassName"></param>
        /// <returns></returns>
        private static string GetBaseClassFileName(string baseClassName)
        {
            string tempBaseClassName = String.Empty;

            for (int i = 0; i < baseClassName.Length; i++)
            {
                if (Char.IsUpper(baseClassName[i]))
                {
                    if (i == 0)
                    {
                        tempBaseClassName = tempBaseClassName + Char.ToLower(baseClassName[i]);
                    }
                    else
                    {
                        tempBaseClassName = tempBaseClassName + "_" + Char.ToLower(baseClassName[i]);
                    }
                }
                else
                {
                    tempBaseClassName = tempBaseClassName + baseClassName[i];
                }

            }
            return tempBaseClassName + ".rb";
        }
              
        /// <summary>
        /// Get the param List for the fileName. Or Parse the file to see if the file inherits from
        /// any other class.
        /// </summary>
        /// <param name="fileFullName"></param>
        /// <param name="moduleFullName"></param>
        /// <param name="baseLocationFileName"></param>
        /// <returns></returns>
        private static Dictionary<string, RubyParam> GetParamList(string fileFullName)
        {
            StreamReader sr = new StreamReader(fileFullName);
            string fileLine = String.Empty;
            List<RubyParam> paramList = new List<RubyParam>();
            List<string> inheritedClassList = new List<string>();
            Dictionary<string, RubyParam> allParamsList = new Dictionary<string, RubyParam>();

            while ((fileLine = sr.ReadLine()) != null)
            {
                string paramName = String.Empty;
                string paramType = String.Empty;
                string paramDefaultValue = String.Empty;

                Regex paramNameRegex = new Regex("#*Name::", RegexOptions.IgnoreCase);
                Regex paramTypeName = new Regex("#*Type::", RegexOptions.IgnoreCase);
                Regex paramDefaultValueRegex = new Regex("#*Default Value::", RegexOptions.IgnoreCase);


                RubyParam rubyParam = new RubyParam();               

                //If the line starts with #Name:: then its the name of the param
                if (paramNameRegex.IsMatch(fileLine))
                {
                    string[] tokens = fileLine.Split("::".ToCharArray());
                    if (tokens.Length >= 2)
                    {
                        paramName = tokens[tokens.Length - 1];
                        paramName = paramName.Trim();
                        //Add the ruby param name 
                        rubyParam.Name = paramName;

                    }

                    //If the line starts with #Type:: then its the name of the param
                    while (fileLine != null && !paramTypeName.IsMatch(fileLine))
                    {
                        fileLine = sr.ReadLine();
                    }

                    if (fileLine != null)
                    {
                        string[] tokens1 = fileLine.Split("::".ToCharArray());
                        if (tokens1.Length >= 2)
                        {
                            paramType = tokens1[tokens1.Length - 1].Trim().ToLower();
                            //Add the ruby param typeoh yea
                            rubyParam.DataType = paramType;
                        }
                    }

                    //If the line starts with # Default Value:: : then its the default value of the param
                    while (fileLine != null && !paramDefaultValueRegex.IsMatch(fileLine))
                    {
                        fileLine = sr.ReadLine();
                    }

                    if (fileLine != null)
                    {
                        string[] tokens2 = fileLine.Split("::".ToCharArray());
                        if (tokens2.Length >= 2)
                        {
                            paramDefaultValue = tokens2[tokens2.Length - 1].Trim().ToLower();
                            //Add the ruby param type
                            rubyParam.DefaultValue = paramDefaultValue;
                        }
                    }


                }
                if (rubyParam.Name != null && rubyParam.DataType != null)
                {
                    if (!allParamsList.ContainsKey(rubyParam.Name))
                    {
                        allParamsList.Add(rubyParam.Name, rubyParam);
                    }
                }
                else
                {
                    ////ADD THE WARNING TO LOG
                }
            }
            return allParamsList;

            //var paramValues = from param in allParamsList.Values
            //                  select new { Name = param.Name, DataType = param.DataType, DefaultValue = param.DefaultValue };

            //return paramValues.ToArray();


        }
        #endregion



    }
}
