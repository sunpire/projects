using System.Collections.Generic;
using System.Text;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for PublishResut.
    /// </summary>
    public class PublishResult
    {
        public PublishResult()
        {
            ModuleResult = new List<PublishModuleResult>();
        }

        public PublishResult(string failureReason)
        {
            ModuleResult = new List<PublishModuleResult>(); ;
        }

        public List<PublishModuleResult> ModuleResult;


        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(string.Format("{0} of published modules'\n'", ModuleResult.Count));
            sb.AppendLine();

            foreach (PublishModuleResult moduleResult in ModuleResult)
            {
                if (moduleResult.isPublished)
                {
                    sb.AppendLine(string.Format("{0} module is published sucessfully'\n'", moduleResult.ModuleName));

                    if (moduleResult.Added.Count > 0)
                    {
                        sb.AppendLine(string.Format("List of test cases Added ({0})'\n'", moduleResult.Added.Count));
                        foreach (var modName in moduleResult.Added)
                        {
                            sb.AppendLine(modName);
                        }
                    }

                    if (moduleResult.Deleted.Count > 0)
                    {
                        sb.AppendLine(string.Format("List of test cases Deleted ({0})'\n'", moduleResult.Deleted.Count));
                        foreach (var modName in moduleResult.Deleted)
                        {
                            sb.AppendLine(modName);
                        }
                    }
                }
                else
                {
                    sb.AppendLine(string.Format("{0} module is not published because {1}'\n'", moduleResult.ModuleName, moduleResult.FailureReason));
                }
            }
            sb.AppendLine();
            return sb.ToString();
        }
    }


    /// <summary>
    /// Summary description for PublishModuleResult
    /// </summary>
    public class PublishModuleResult
    {
        public PublishModuleResult(string moduleName)
            : this()
        {
            ModuleName = moduleName;
        }

        public PublishModuleResult()
        {
            Added = new List<string>();
            Deleted = new List<string>();
        }

        public string ModuleName;
        public List<string> Added;
        public List<string> Deleted;
        public string FailureReason;
        public bool isPublished = false;
        public int ElaspedTime = 0;
    }
}
