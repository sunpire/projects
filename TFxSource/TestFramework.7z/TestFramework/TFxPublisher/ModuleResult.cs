﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Expedia.Test.Framework
{
    public static class ModuleResult
    {
        public static string Added;
        public static string Deleted;
        public static string FailureReason;
        public static string ModuleName;
    }
}
