﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Expedia.Test.Framework
{
    public static class PublisherDBExtension
    {
        #region PublicMethods

        public static PublishModuleResult UpdateModule(this PublisherDBDataContext db, List<TestMethodInfo> moduleMethods, List<TestMethod> dbMethods, Module dbModule, Branch dbBranch)
        {
            PublishModuleResult moduleResult = new PublishModuleResult();

            var parameterTypes = from paramTypes in db.ParameterTypes select paramTypes;

            var dataTypes = from data in db.DataTypes select data;

            var methodsToDelete = dbMethods.Except(moduleMethods, (dbMethod, moduleMethod) => String.Compare(dbMethod.fullName, moduleMethod.TestFullName, true) == 0);
            db.TestMethods.DeleteAllOnSubmit(methodsToDelete);

            var methodsToAdd = (from method in moduleMethods.Except(dbMethods, (moduleMethod, dbMethod) => String.Compare(moduleMethod.TestFullName, dbMethod.fullName, true) == 0)
                                select CreateDBTestMethod(dbModule, dbBranch, parameterTypes, dataTypes, method)).ToList();

            methodsToAdd.ForEach((method) => db.TestMethods.InsertOnSubmit(method));

            var commonMethodsInDb = dbMethods.Except(methodsToDelete, (dbMethod, methodToDelete) => dbMethod.fullName.IsEqualNoCase(methodToDelete.fullName));
            var commonMethodsInModule = moduleMethods.Except(methodsToAdd, (moduleMethod, methodToAdd) => String.Compare(moduleMethod.TestFullName, methodToAdd.fullName, true) == 0);

            SyncMethodParameters(db, dbBranch, parameterTypes, dataTypes, commonMethodsInDb, commonMethodsInModule);

            return moduleResult;
        }

        public static List<TestMethod> GetTestMethods(this PublisherDBDataContext db, Branch branch, Module mod)
        {
            var methods =
                (from method in db.TestMethods
                 where (method.moduleId == mod.id
                 && method.branchId == branch.id)
                 select method).ToList();
            return methods;
        }

        /// <summary>
        /// Get the modules from db,get the modules locally and add the missing modules to the DB
        /// </summary>
        /// <param name="db"></param>
        /// <param name="moduleNames"></param>
        /// <returns></returns>
     
        public static List<Module> SyncModules(this PublisherDBDataContext db, List<FileInfo> moduleNames)
        {
            IEnumerable<string> fileNames =
                from file in moduleNames
                select file.Name.ToLower();

            var modulesInDb =
                (from mod in db.Modules
                 where fileNames.Contains(mod.name.ToLower())
                 select mod).ToList();

            var moduleinDbNames = from mod in modulesInDb select mod.name.ToLower();
            var modulesToAdd =
                from file in fileNames
                where !(moduleinDbNames.Contains(file))
                select new Module
                {
                    name = ((from fileTempNames in moduleNames
                             where fileTempNames.Name.Equals(file, StringComparison.InvariantCultureIgnoreCase)
                             select fileTempNames.Name).FirstOrDefault()),
                    driverTypeId = GetDriverTypeId(db, file)


                };

            foreach (Module module in modulesToAdd)
            {
                db.Modules.InsertOnSubmit(module);
            }
          
            return modulesToAdd.Union(modulesInDb).ToList();
        }

        /// <summary>
        /// To add new modules to the DB we need to have the drivertypeId also
        /// </summary>
        /// <param name="db"></param>
        /// <param name="file"></param>
        /// <returns></returns>
        private static int GetDriverTypeId(PublisherDBDataContext db, string file)
        {
             FileInfo fileInfo = new FileInfo(file);
            switch (fileInfo.Extension)
            {
                case ".dll":
                    return (from driverType in db.DriverTypes
                            where String.Compare(driverType.name, ".NETDriver", true) == 0
                            select driverType.id).First();
                   
                case ".rb":
                    return (from driverType in db.DriverTypes
                            where String.Compare(driverType.name, "RubyDriver", true) == 0
                            select driverType.id).First();
                  
                case ".jar":
                    return (from driverType in db.DriverTypes
                            where String.Compare(driverType.name, "JavaDriver", true) == 0
                            select driverType.id).First();               
                default:
                    return 0;
                   
            }
        }

     

     

        

        public static List<Module> GetModules(this PublisherDBDataContext db, List<FileInfo> moduleNames)
        {
            IEnumerable<string> fileNames =
                from file in moduleNames
                select file.Name.ToLower();

            var modulesInDb =
                (from mod in db.Modules
                 where fileNames.Contains(mod.name.ToLower())
                 select mod).ToList();

            return modulesInDb.ToList();
        }

        public static Branch GetBranch(this PublisherDBDataContext db, string name)
        {
            return
                (from branch in db.Branches
                 where string.Compare(branch.name, name, true) == 0
                 select branch).FirstOrDefault();
        }

        #endregion

        #region PrivateMethods

        private static void SyncMethodParameters(PublisherDBDataContext db, Branch dbBranch, IQueryable<ParameterType> parameterTypes, IQueryable<DataType> dataTypes, IEnumerable<TestMethod> commonMethodsInDb, IEnumerable<TestMethodInfo> commonMethodsInModule)
        {
            foreach (TestMethod methodInDb in commonMethodsInDb)
            {
                var methodInModule = FindModuleMethod(commonMethodsInModule, methodInDb);

                if (methodInModule != null)
                {
                    DeleteParams(db, methodInDb, methodInModule);
                    UpdateParams(parameterTypes, dataTypes, methodInDb, methodInModule);
                    AddParams(dbBranch, parameterTypes, dataTypes, methodInDb, methodInModule);
                }
                else
                {
                    Logger.Instance.WriteError(String.Format("{0} does not exists", methodInDb.fullName));
                }
            }
        }

        private static TestMethodInfo FindModuleMethod(IEnumerable<TestMethodInfo> commonMethodsInModule, TestMethod methodInDb)
        {
            return (from modMethod in commonMethodsInModule
                    where modMethod.TestFullName == methodInDb.fullName
                    select modMethod).SingleOrDefault();
        }

        private static void DeleteParams(PublisherDBDataContext db, TestMethod methodInDb, TestMethodInfo methodInModule)
        {
            var parmsTobeDeleted = methodInDb.TestMethodParameters.Except(methodInModule.FullParamList, (dbParam, moduleParam) => dbParam.name.IsEqualNoCase(moduleParam.Name)).ToList();

            foreach (TestMethodParameter param in parmsTobeDeleted)
            {
                db.TestMethodParameters.DeleteOnSubmit(param);
            }
        }

        private static void AddParams(Branch dbBranch, IQueryable<ParameterType> parameterTypes, IQueryable<DataType> dataTypes, TestMethod methodInDb, TestMethodInfo methodInModule)
        {
            var paramsToAdd = (from modParam in methodInModule.FullParamList.Except(methodInDb.TestMethodParameters, (modParam, param) => param.name.IsEqualNoCase(modParam.Name))
                               select CreateTestMethodParameter(dbBranch, parameterTypes, dataTypes, modParam)).ToList();

            foreach (TestMethodParameter param in paramsToAdd)
            {
                param.TestMethod = methodInDb;
                param.Branch = methodInDb.Branch;
                methodInDb.TestMethodParameters.Add(param);
            }
        }

        private static void UpdateParams(IQueryable<ParameterType> parameterTypes, IQueryable<DataType> dataTypes, TestMethod methodInDb, TestMethodInfo methodInModule)
        {
            var parmsTobeUpdated = methodInDb.TestMethodParameters.Except(methodInModule.FullParamList, (methodParam, param) => param.Name.IsEqualNoCase(methodParam.name) &&
                                    (
                                        param.ParameterType.ToString().IsNotEqualNoCase(methodParam.ParameterType.name) ||
                                        param.DataType.IsNotEqualNoCase(methodParam.DataType.name) ||
                                        param.DefaultValue.IsNotEqualNoCase(methodParam.defaultValue)
                                    ));

            foreach (var paramList in parmsTobeUpdated)
            {
                var moduleParam = (from modParam in methodInModule.FullParamList
                                   where modParam.Name.IsEqualNoCase(paramList.name)
                                   select modParam).FirstOrDefault();

                if (moduleParam != null)
                {
                    paramList.DataType = GetDataType(dataTypes, paramList.DataType.name);
                    paramList.defaultValue = moduleParam.DefaultValue;
                    paramList.ParameterType = GetParameterType(parameterTypes, moduleParam.ParameterType);
                }
            }
        }

        private static Module GetModule(this PublisherDBDataContext db, string moduleName)
        {
            return
                (from mod in db.Modules
                 where string.Compare(mod.name, moduleName, true) == 0
                 select mod).FirstOrDefault();
        }

        private static bool IsEqualNoCase(this string str, string compareTo)
        {
            return string.Compare(str, compareTo, true) == 0;
        }

        private static bool IsNotEqualNoCase(this string str, string compareTo)
        {
            return string.Compare(str, compareTo, true) != 0;
        }

        private static DataType GetDataType(IQueryable<DataType> dataTypes, string dataTypeValue)
        {
            var dataTypeName = (from dataType in dataTypes
                                where dataTypeValue == dataType.name
                                select dataType).FirstOrDefault();

            if (dataTypeName == null)
            {
                dataTypeName = (from dataType in dataTypes
                                where dataType.name == "string"
                                select dataType).FirstOrDefault();
            }
            return dataTypeName;
        }

        private static ParameterType GetParameterType(IQueryable<ParameterType> parameterTypes, ParameterTypeType paramTypeValue)
        {
            return (from paramType in parameterTypes
                    where string.Compare(paramType.name, paramTypeValue.ToString(), true) == 0
                    select paramType).FirstOrDefault();
        }

        private static TestMethod CreateDBTestMethod(Module dbModule, Branch dbBranch, IQueryable<ParameterType> parameterTypes, IQueryable<DataType> dataTypes, TestMethodInfo method)
        {
            return new TestMethod
            {
                fullName = method.TestFullName,
                Module = dbModule,
                Branch = dbBranch,
                TestMethodParameters = (from param in method.FullParamList
                                        select CreateTestMethodParameter(dbBranch, parameterTypes, dataTypes, param)).ToEntitySet()
            };
        }

        private static TestMethodParameter CreateTestMethodParameter(Branch dbBranch, IQueryable<ParameterType> parameterTypes, IQueryable<DataType> dataTypes, Param param)
        {
            return new TestMethodParameter
            {
                name = param.Name,
                DataType = GetDataType(dataTypes, param.DataType),
                ParameterType = GetParameterType(parameterTypes, param.ParameterType),
                Branch = dbBranch,
                defaultValue = param.DefaultValue
            };
        }

        #endregion
    }
}
