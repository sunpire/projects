namespace Expedia.Test.Framework
{

    partial class PublisherDBDataContext
    {
        partial void OnCreated()
        {
            this.Log = new DebugWriter();
        }




    }
}
