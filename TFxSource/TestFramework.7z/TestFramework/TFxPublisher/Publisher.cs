using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Diagnostics;

namespace Expedia.Test.Framework
{
    public class Publisher
    {
        string DBServer_default = "chsxsqltfx001.idx.expedmz.com,1433";
        string DBName_default = "TFx2009";
        string DBServerMirror_default = "chsxsqltfx003.idx.expedmz.com,1433";
        string PrimaryFolder_default = "\\\\chelsqltfx01.idx.expedmz.com\\builds";
        string Email_default = "tfxbuild@expedia.com";

        string serverName = null;
        string dbName = null;
        string serverMirrorName = null;
        string email = "tfxbuild@expedia.com";
        string primaryFolder = null;
        string errorMessage = String.Empty;

        string localTempFolder = Path.GetTempPath();
        string branchName;

        public string ErrorMessage
        {
            get
            {
                return this.errorMessage;
            }
        }

        public Publisher()
        {
            this.serverName = DBServer_default;
            this.dbName = DBName_default;
            this.serverMirrorName = DBServerMirror_default;
            this.primaryFolder = PrimaryFolder_default;
            this.email = Email_default;
        }

        public Publisher(string primaryFolder)
        {
            this.serverName = DBServer_default;
            this.dbName = DBName_default;
            this.serverMirrorName = DBServerMirror_default;
            this.primaryFolder = primaryFolder;
            this.email = Email_default;
        }

        public Publisher(string serverName, string dbName, string ServerMirrorName, string primaryFolder)
            : this(serverName, dbName, ServerMirrorName, primaryFolder, null)
        {
        }

        public Publisher(string serverName, string dbName, string ServerMirrorName, string primaryFolder, string email)
        {
            this.serverName = serverName;
            this.dbName = dbName;
            this.serverMirrorName = ServerMirrorName;
            this.primaryFolder = primaryFolder;
            this.email = email;
        }

        public bool BuildFolderIsValid(string path)
        {
            if (!Directory.Exists(path))
            {
                errorMessage = string.Format("Build folder {0} does not exist", path);
            }
            else if (Path.GetPathRoot(path.ToLower()) != PrimaryFolder_default)
            {
                errorMessage = string.Format("Build must be placed in the folder: {0}\\[Release]\\[Build]", PrimaryFolder_default);
            }
            else
            {
                DirectoryInfo dir = new DirectoryInfo(path);

                if (dir.Parent == null || dir.Parent.Parent == null ||
                    !dir.Parent.Parent.FullName.ToLower().Equals(PrimaryFolder_default))
                    errorMessage = string.Format("Build must be placed in the folder: {0}\\[Release]\\[Build]", PrimaryFolder_default);
            }

            return true;
        }

        /// <summary>
        /// Publish the tests in the build folder
        /// </summary>
        /// <returns>publish errors</returns>
        public PublishResult Publish(string primaryFolder, string testBitsLocation,string branchName, string[] testDllList)
        {

            PublisherDBDataContext dbContext;
            Branch branch;
            Logger.Instance.WriteInfo("Start publishing");

            string connectionString = string.Format(CultureInfo.InvariantCulture,
                        "Data Source={0};Failover Partner={1};Initial Catalog={2};Integrated Security=SSPI",
                        this.serverName, this.serverMirrorName, this.dbName);

            string xmlFileName = "List_" + Guid.NewGuid() + ".xml";
            string xmlDirectory = Path.Combine(Environment.CurrentDirectory, "JunitResults");

            if (!Directory.Exists(xmlDirectory))
            {
                Directory.CreateDirectory(xmlDirectory);
            }

            string xmlFilePath = Path.Combine(xmlDirectory, xmlFileName);

            Logger.Instance.WriteInfo("XML Full Path {0}", xmlFilePath);

            PublisherEngine.xmlFullPath = xmlFilePath;

            this.branchName = branchName;
         
            var moduleFiles = (ListCSharpModules(primaryFolder)).Union
                               (ListJavaModules(primaryFolder)).Union
                               (ListRubyModules(primaryFolder)).ToList();

            dbContext = new PublisherDBDataContext(connectionString);

           // branchName = "main";
            branch = dbContext.GetBranch(branchName);         

            if (branch == null)
            {
                throw new TFxException(String.Format("Release {0} does not exists in the DB", branchName));
            }

            //Sync the modules locally to the DB

            var modules = from m in dbContext.SyncModules(moduleFiles) orderby m.name select m;

            dbContext.SubmitChanges();

            var modulesList = from m in dbContext.GetModules(moduleFiles) orderby m.name select m;

            List<string> notListModules = new List<string>();
            notListModules.Add("JunitDriver.jar");
            notListModules.Add("sqljdbc.jar");
            notListModules.Add("TestData.dll");
            notListModules.Add("ossxapi.dll");
            notListModules.Add("ossxcstrain.dll");
            notListModules.Add("ossxdmem.dll");
            notListModules.Add("ossxsoedapi.dll");
            notListModules.Add("ossxsoedfi.dll");
            notListModules.Add("ossxsoedxml.dll");

            PublishResult publishResult = new PublishResult();

            List<string> generatedDlls = new List<string>();

            foreach (Module module in modulesList)
            {
                Stopwatch timer = Stopwatch.StartNew();

                if (notListModules.Contains(module.name))
                {
                    continue;
                }

                //if (!module.name.Contains(".rb"))
                //{
                //    continue;
                //}

                PublishModuleResult moduleResult = new PublishModuleResult();
                moduleResult.isPublished = false;

                int moduleTestMethodsCount = 0;
                int dbTestMethodsCount = 0;
                

                try
                {
                    moduleResult.ModuleName = module.name;

                    var moduleFullName = (from m in moduleFiles
                                          where String.Compare(m.Name, module.name, true) == 0
                                          select m.FullName).FirstOrDefault();

                    Logger.Instance.WriteInfo("Publishing module : {0}", moduleFullName);

                    var localTestMethods = PublisherEngine.List(moduleFullName);

                    if (localTestMethods == null || localTestMethods.Length == 0)
                    {
                        continue;
                    }

                    //For jar files we return the list of test names not TestMethod class
                    if(module.name.Contains(".jar"))
                    {
                        var dupTestMethods = (from testMethod in localTestMethods
                                          group testMethod by testMethod into g
                                          where g.Count() > 1
                                          select g.Key);

                        if (dupTestMethods.Count() > 0)
                        {
                            throw new Exception(String.Format("Method {0} is repeated in {1}", dupTestMethods.ToList()[0], moduleFullName));
                        }

                    }
                    else
                    {
                        var dupTestMethods = (from testMethod in localTestMethods
                                          group testMethod by testMethod.GetPropertyName("TestFullName") into g
                                          where g.Count() > 1
                                          select g.Key);

                        if (dupTestMethods.Count() > 0)
                        {
                            throw new Exception(String.Format("Method {0} is repeated in {1}", dupTestMethods.ToList()[0], moduleFullName));
                        }
                    }               
                                   
                    var dllTestMethods = (from testObj in localTestMethods
                                          select new TestMethodInfo(testObj)).ToList();                  

                    var dbTestMethods = dbContext.GetTestMethods(branch, module);

                    dbContext.UpdateModule(dllTestMethods, dbTestMethods, module, branch);

                    moduleTestMethodsCount = dllTestMethods.Count;
                    dbTestMethodsCount = dbTestMethods.Count;

                    moduleResult.isPublished = true;

                    timer.Stop();

                    moduleResult.ElaspedTime = timer.Elapsed.Seconds;
                }
                catch (Exception e)
                {
                    moduleResult.isPublished = false;
                    moduleResult.FailureReason = string.Format("Exception while loading {0}\n{1}", module.name, e.ToString());
                }

                //Add the module to the publish result only it will has any test cases or it has published correctly
                if (((moduleTestMethodsCount != 0) || (dbTestMethodsCount != 0)) || (!moduleResult.isPublished))
                {
                    generatedDlls.Add(module.name);
                    publishResult.ModuleResult.Add(moduleResult);
                }
            }

            dbContext.SubmitChanges();

            Logger.Instance.WriteInfo("End of publishing");

            //Update the branches table with the buildFolder and the last publish date

            branch.publishedBuildPath = testBitsLocation;
            branch.lastPublishDate = DateTime.Now;
            branch.publishedBuildName = testBitsLocation.Substring(testBitsLocation.LastIndexOf('\\') + 1);

            dbContext.SubmitChanges();

            if (testDllList != null)
            {
                foreach (string dll in testDllList)
                {
                    if (!generatedDlls.Contains(dll))
                    {
                        PublishModuleResult moduleResult = new PublishModuleResult();
                        moduleResult.ModuleName = dll;
                        moduleResult.isPublished = false;
                        moduleResult.FailureReason = null;
                        publishResult.ModuleResult.Add(moduleResult);
                    }
                }
            }
            return publishResult;
        }

        /// <summary>
        /// List all the Ruby Modules in the primary folder.
        /// The primary folder is going to have Ruby\Tests folder that will 
        /// have all the ruby test cases. So Ruyb\Tests will have EStar, TFxTest etc which a
        /// are the modules. After we get the directory names we add .rb in the end
        /// for the module names
        /// </summary>
        /// <param name="primaryFolder"></param>
        /// <returns></returns>
        private static System.Collections.Generic.IEnumerable<FileInfo> ListRubyModules(string primaryFolder)
        {
            string rubyFolder = Path.Combine(primaryFolder, "Ruby\\Tests");

            if (!Directory.Exists(rubyFolder))
            {
                Logger.Instance.WriteInfo("Total number of Ruby Modules : {0}", "0");
                return new List<FileInfo>();
            }

            var directories = (from dir in Directory.GetDirectories(primaryFolder, "Ruby\\Tests", SearchOption.AllDirectories)
                               select dir).FirstOrDefault();

            var moduleFiles = (from subDir in Directory.GetDirectories(directories)
                               select new FileInfo(subDir + ".rb")).ToList();

            Logger.Instance.WriteInfo("Total number of Ruby Modules : {0}", moduleFiles.Count);

            return moduleFiles;
        }

        /// <summary>
        /// List all the Java Modules in the Primary Folder.
        /// </summary>
        /// <param name="primaryFolder"></param>
        /// <returns></returns>
        private static System.Collections.Generic.IEnumerable<FileInfo> ListJavaModules(string primaryFolder)
        {
            var modules = (from file in System.IO.Directory.GetFiles(primaryFolder, "*.jar")
                           select new FileInfo(file)).ToList();

            Logger.Instance.WriteInfo("Total number of Java Modules : {0}", modules.Count);

            return modules;           
        }

        /// <summary>
        /// List all the Java Modules in the Primary Folder.
        /// </summary>
        /// <param name="primaryFolder"></param>
        /// <returns></returns>
        private static System.Collections.Generic.IEnumerable<FileInfo> ListCSharpModules(string primaryFolder)
        {
            var modules = (from file in System.IO.Directory.GetFiles(primaryFolder, "*.dll")
                           select new FileInfo(file)).ToList();

            Logger.Instance.WriteInfo("Total number of C# Modules: {0} ", modules.Count);
            return modules;
        }

        /// <summary>
        /// This is not used by system task, just for command line testing
        /// </summary>
        /// <param name="email"></param>
        public void SendEmail(StringBuilder message)
        {
            TFxMail mail = new TFxMail();
            mail.Send("TFxReport@expedia.com", this.email, string.Format("TFxBuild {0} publish summmary", this.primaryFolder), message.ToString());
        }

        public StringBuilder BuildMessage(PublishResult result)
        {
            StringBuilder mailMessage = new StringBuilder("<HTML><font size=2>");
            mailMessage.Append("<B><U>Publish Build</U></B><BR>");
            mailMessage.AppendFormat("Primary Folder:    {0}<BR>", this.primaryFolder);
            mailMessage.AppendFormat("ServerName:    {0}<BR>", this.serverName);
            mailMessage.AppendFormat("DBName:    {0}<BR>", this.dbName);
            mailMessage.AppendFormat("ServerMirrorName:    {0}<BR>", this.serverMirrorName);

            string emailSummaryMessage = "<TABLE><TR><TD><B><font size=2>ModuleName</font></B></TD><TD width=50></TD><TD><B><font size=2>Status</font></B></TD><TD width=30><TD><B><font size=2>Time Taken in seconds</font></B></TD></TR>";
            
            Logger.Instance.WriteInfo("{0} of published modules", result.ModuleResult.Count);

            //To make not published message be on the top
            foreach (PublishModuleResult moduleResult in result.ModuleResult)
            {
                if (!moduleResult.isPublished && moduleResult.FailureReason == null)
                {
                    emailSummaryMessage += String.Format("<TR><TD><font size=2>{0}</font></TD><TD width=50></TD><TD><font size=2 color=red>Not Exist</font></TD><TD width=50></TD><TD><font size=2>{1}</font></TD><TD width=50></TD></TR>", moduleResult.ModuleName, moduleResult.ElaspedTime.ToString());
                    Logger.Instance.WriteInfo("{0} module is not published", moduleResult.ModuleName);
                }
            }

            foreach (PublishModuleResult moduleResult in result.ModuleResult)
            {
                if (moduleResult.isPublished)
                {
                    emailSummaryMessage += String.Format("<TR><TD><font size=2>{0}</font></TD><TD width=50></TD><TD><font size=2 color=green>Published</font></TD><TD width=50></TD><TD><font size=2>{1}</font></TD><TD width=50></TD></TR>", moduleResult.ModuleName, moduleResult.ElaspedTime.ToString());
                    Logger.Instance.WriteInfo("{0} module is published sucessfully", moduleResult.ModuleName);
                    Logger.Instance.WriteInfo("{0} of Test Cases are Added", moduleResult.Added.Count);
                    Logger.Instance.WriteInfo("{0} of Test Cases are Deleted", moduleResult.Deleted.Count);
                }
                else
                {
                    if (moduleResult.FailureReason != null)
                    {
                        Logger.Instance.WriteInfo("{0} module is not published because {1}", moduleResult.ModuleName, moduleResult.FailureReason);
                        emailSummaryMessage += String.Format("<TR><TD><font size=2>{0}</font></TD><TD width=50></TD><TD><font size=2 color=red>{1}</font></TD><TD><font size=2>{2}</font></TD><TD width=50></TD></TR>", moduleResult.ModuleName, moduleResult.FailureReason, moduleResult.ElaspedTime);
                    }
                }
            }

            mailMessage.Append("</font></HTML>");

            return mailMessage.Append(emailSummaryMessage + "</TABLE><BR>");
        }
    }
}

