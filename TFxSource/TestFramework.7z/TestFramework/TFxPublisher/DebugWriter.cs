﻿using System.Diagnostics;
using System.IO;
using System.Text;

namespace Expedia.Test.Framework
{
    public class DebugWriter : TextWriter
    {
        public override Encoding Encoding
        {
            get { return Encoding.UTF8; }
        }

        public override void WriteLine(string value)
        {
            Debug.WriteLine(value);
        }

        public override void Write(string value)
        {
            Debug.Write(value);
        }
    }
}
