﻿using System.Linq;

namespace Expedia.Test.Framework
{
    public class TestMethodInfo
    {
        object m_testMethodInfo;

        public TestMethodInfo(object testMethodInfo)
        {
            m_testMethodInfo = testMethodInfo;
        }

        public string TestFullName
        {
            get
            {
                object testFullName = m_testMethodInfo.GetPropertyName("TestFullName");

                if (testFullName != null)
                {
                    return testFullName.ToString();
                }

                return m_testMethodInfo.ToString();
            }
        }

        public Param[] FullParamList
        {
            get
            {
                return ParamList.Union(ConfigList).ToArray();
            }
        }

        public Param[] ParamList
        {
            get
            {
                object param = m_testMethodInfo.GetPropertyName("ParamList");

                if (param != null)
                {
                    var paramList = from paramObj in ((object[])param)
                                    select new Param
                                    {
                                        Name = paramObj.GetPropertyName("Name").ToString(),
                                        DataType = paramObj.GetPropertyName("DataType").ToString(),
                                        DefaultValue = paramObj.GetPropertyName("DefaultValue") == null
                                           ? null
                                           : paramObj.GetPropertyName("DefaultValue").ToString(),
                                        ParameterType = ParameterTypeType.Function
                                    };
                    return paramList.ToArray();
                }

                return new Param[0];
            }
        }

        public Param[] ConfigList
        {
            get
            {
                object config = m_testMethodInfo.GetPropertyName("ConfigList");

                if (config != null)
                {
                    var configList = from paramObj in ((object[])config)
                                     select new Param
                                     {
                                         Name = paramObj.GetPropertyName("Name").ToString(),
                                         DataType = "System.String",
                                         DefaultValue = paramObj.GetPropertyName("DefaultValue") == null
                                            ? null
                                            : paramObj.GetPropertyName("DefaultValue").ToString(),
                                         ParameterType = ParameterTypeType.Config,
                                     };

                    return configList.ToArray();
                }

                return new Param[0];
            }
        }
    }

    public class Param
    {
        string m_name;
        string m_dataType;

        public Param()
        {
        }

        public string Name
        {
            get
            {
                return m_name;
            }
            set
            {
                m_name = value;
            }
        }

        public string DataType
        {
            get
            {
                return m_dataType.Replace("System.","").ToLower();
            }
            set
            {
                m_dataType = value;
            }
        }

        public string DefaultValue;
        public ParameterTypeType ParameterType;
    }

    public enum ParameterTypeType
    {
        Function,
        Config
    }
}
