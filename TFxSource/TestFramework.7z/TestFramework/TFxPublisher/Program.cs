using System;
using System.Text;

namespace Expedia.Test.Framework
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length < 1)
            {
                Console.Write("Usage: TFxPublisher [BuildFolder] [DBServer(opt)] [DBName(opt)] [Email(opt)]");
                return;
            }

            Publisher publisher;
            if (args.Length > 1)
            {
                publisher = new Publisher(args[1], args[2], args[0], args[3]);
            }
            else
            {
                //Use the default values for the servername and dbname
                publisher = new Publisher();
            }

            PublishResult result = publisher.Publish(args[0],null,null,null);
            StringBuilder message = publisher.BuildMessage(result);

            publisher.SendEmail(message);
        }
    }
}
