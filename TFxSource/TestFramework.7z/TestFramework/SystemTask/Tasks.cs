using System;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Globalization;
using System.Text;
using Expedia.Test.Framework;

namespace Expedia.System.Task
{
    /// <summary>
    /// Tasks
    /// </summary>
    public class Tasks
    {
        /// <summary>
        /// Tasks
        /// </summary>
        public Tasks()
        {
        }

        /// <summary>
        /// Comments: changed labrunid to GUID labrungid
        /// </summary>
        [Test]
        public void SmokeNotification()
        {
            // Can we delete this test?  Does anything rely on it?
        }

        /// <summary>
        /// EmailNotification
        /// </summary>
        [Test]
        public void EmailNotification()
        {
            if (!string.IsNullOrEmpty(TestContext.Runtime.LabRunName)
                && !string.IsNullOrEmpty(TestContext.Runtime.Email)
                && TestContext.Runtime.LabRunId != -1)
            {
                StringBuilder message = new StringBuilder();

                using (TFxMail mail = new TFxMail())
                {
                    using (SqlConnection connection = Tasks.GetConnection())
                    {
                        DataRow labrun = Tasks.GetLabrun(TestContext.Runtime.LabRunId, connection).Rows[0];

                        message.Append(string.Format(
                            @"<HTML><style type=""text/css""> 
                                        body {{ font-family: ""Lucida Sans Unicode"", Verdana, Sans-Serif; 
                                                font-size: 8pt; }}
                                        td {{ font-size: 8pt;}}
                                        th {{ font-size: 10pt; text-align: left; }}
                                        h1 {{ font-size: 14pt; }}
                                        table {{ border-collapse: collapse; }}
                                        #quickstats {{ font-size: 10pt; margin-bottom: 4px;}}
                                        .labruntable {{ border-top: 1px solid black; }}
                                        .labruntable td {{ padding-right: 8px;}}
                                        .assignmenttable {{ width: 100%; }}
                                        .assignmenttable td {{ border-top: 1px solid black; padding-top: 4px; padding-bottom: 4px; }}
                                        .labrunInfo {{ color: #4682b4; padding-right: 4px; }}
                                        .failed {{ color: #F00; font-weight: normal; }}
                                        .passed {{ color: green; font-weight: normal; }}
                                        .warning {{ color: #C29B00; font-weight: normal; }}
                                        .warningErrorFont {{ color: #000000; font-weight: normal; }}
                                    </style>
                                <BODY><H1>{0} ({1})</H1>
									<div id=""quickstats"">Pass: {2} | Fail: {3} | Total: {4}</div>
									<div id=""comments"">{5}</div>
                                    <A href=""http://tfx/labrunmanager/LabRunReport.aspx?labrunid={1}&Refresh=true"">View Labrun</a> | 
                                    <A href=""http://tfx/labrunmanager/LabRunReport.aspx?labrunid={1}&Refresh=true&onlyFailed=true"">View Failed</a><BR>
                                    <TABLE class=""labruntable"">
                                        <TR>
                                            <TD>Branch</TD><TD class=""labrunInfo"">{6}</TD>
                                            <TD>Manager</TD><TD class=""labrunInfo"">{7}</TD>
                                        </TR>
                                        <TR>
                                            <TD>Start Time</TD><TD class=""labrunInfo"">{8}</TD>
                                            <TD>End Time</TD><TD class=""labrunInfo"">{9}</TD>
                                        </TR>
                                        <TR>
                                            <TD>Ran By</TD><TD class=""labrunInfo"">{10}</TD>
                                        </TR>
                                    </TABLE>
                                    <TABLE class=""assignmenttable"">
                                        <TR>
                                            <TH>ID</TH>
                                            <TH>Test Name</TH>
                                            <TH>Result</TH>
                                            <TH>Start Time</TH>
                                            <TH>End Time</TH>
                                            <TH>Site</TH>
                                        </TR>
                            ",
                            TestContext.Runtime.LabRunName,
                            TestContext.Runtime.LabRunId,
                            labrun["passCount"],
                            labrun["failCount"],
                            labrun["totalTests"],
                            labrun["comments"],
                            labrun["branchName"],
                            labrun["managerName"],
                            labrun["startDate"],
                            labrun["endDate"],
                            labrun["ranBy"]));

                        DataTable assignments = Tasks.GetAssignments(TestContext.Runtime.LabRunId, connection);

                        StringBuilder failedAssignments = new StringBuilder();
                        StringBuilder passedAssignments = new StringBuilder();

                        if (assignments != null && assignments.Rows.Count > 0)
                        {
                            foreach (DataRow row in assignments.Rows)
                            {
                                if (row["status"].ToString() != "Pass" && row["status"].ToString() != "Pass Manually")
                                {
                                    failedAssignments.AppendLine(string.Format(
                                        @"<TR>
                                            <TD class=""failed"">{0}</TD>
                                            <TD class=""failed""><a href=""http://tfx/labrunmanager/assignmentlog.aspx?LogView=Long&assignmentid={0}&labrunid={6}"">{1}</a></TD>
                                            <TD class=""failed"">{2}</TD>
                                            <TD class=""failed"">{3}</TD>
                                            <TD class=""failed"">{4}</TD>
                                            <TD class=""failed"">{5}</TD>
                                         </TR>",
                                    row["assignmentId"],
                                    row["testName"],
                                    row["failurereason"],
                                    row["startDate"],
                                    row["endDate"],
                                    row["Site"],
                                    TestContext.Runtime.LabRunId));
                                }
                                else if (row["status"].ToString() == "Pass Manually")
                                {
                                    passedAssignments.AppendLine(string.Format(
                                        @"<TR>
                                            <TD class=""warning"">{0}</TD>
                                            <TD class=""warning""><a href=""http://tfx/labrunmanager/assignmentlog.aspx?LogView=Long&assignmentid={0}&labrunid={6}"">{1}</a></TD>
                                            <TD class=""warning"">{2}</TD>
                                            <TD class=""warning"">{3}</TD>
                                            <TD class=""warning"">{4}</TD>
                                            <TD class=""warning"">{5}</TD>
                                         </TR>",
                                    row["assignmentId"],
                                    row["testName"],
                                    string.Format("[{0}]<BR/><font class='warningErrorFont'>{1}</font>", row["status"], row["failurereason"]),
                                    row["startDate"],
                                    row["endDate"],
                                    row["Site"],
                                    TestContext.Runtime.LabRunId));
                                }
                                else
                                {
                                    passedAssignments.AppendLine(string.Format(
                                        @"<TR>
                                            <TD class=""passed"">{0}</TD>
                                            <TD class=""passed""><a href=""http://tfx/labrunmanager/assignmentlog.aspx?LogView=Long&assignmentid={0}&labrunid={6}"">{1}</a></TD>
                                            <TD class=""passed"">{2}</TD>
                                            <TD class=""passed"">{3}</TD>
                                            <TD class=""passed"">{4}</TD>
                                            <TD class=""passed"">{5}</TD>
                                         </TR>",
                                    row["assignmentId"],
                                    row["testName"],
                                    row["status"],
                                    row["startDate"],
                                    row["endDate"],
                                    row["Site"],
                                    TestContext.Runtime.LabRunId));
                                }
                            }
                        }

                        string subject = TestContext.Runtime.LabRunName + "(" + TestContext.Runtime.LabRunId + ")" + " has ";
                        subject += (labrun["passPercent"].ToString() == "100") ? "PASSED" : string.Format("{0}% Passed, {1}% Failed", labrun["passPercent"], labrun["failPercent"]);
                        message.Append(failedAssignments.ToString());
                        message.Append(passedAssignments.ToString());
                        message.Append("</TABLE></BODY></HTML>");

                        if (TestContext.Runtime.EmailOnlyOnFailure == "false" || !string.IsNullOrEmpty(failedAssignments.ToString()))
                        {
                            mail.Send("TFxReport@expedia.com", TestContext.Runtime.Email, subject, message.ToString());

                        }
                    }
                }
            }
        }

        /// <summary>
        /// Get Connection
        /// </summary>
        /// <returns></returns>
        private static SqlConnection GetConnection()
        {
            // TODO: AT.exe should provide __lrmserver, __lrmdb configs.  
            // Then we can remove hardcoded information
            // Intent is to remove dependency on tfxdb.config for test code


            SqlConnection con = new SqlConnection(
                string.Format(

                    "Data Source={0};Failover Partner={1};Initial Catalog={1};Integrated Security=SSPI",
                    TestContext.Runtime.LRMDBServer,
                    TestContext.Runtime.LRMDBName,
                    TestContext.Runtime.LRMDBServerMirror
                    )
            );
            return con;
        }

        /// <summary>
        /// Get Lab Run
        /// </summary>
        /// <param name="labrunId">Lab Run Id</param>
        /// <param name="connection">Connection</param>
        /// <returns></returns>
        private static DataTable GetLabrun(int labrunId, SqlConnection connection)
        {
            using (SqlCommand command = new SqlCommand())
            {
                command.CommandText = string.Format(
                    @"SELECT    * 
                      FROM      [dbo].[TFx_EmailNotification_Labrun]
                      WHERE     [id] = {0}",
                    labrunId);
                command.CommandType = CommandType.Text;
                command.Connection = connection;

                DataTable labrun = Tasks.ExecuteCommand(command, connection);

                return labrun;
            }
        }

        /// <summary>
        /// Get Assignments
        /// </summary>
        /// <param name="labrunId">Lab Run Id</param>
        /// <param name="connection">SqlConneciton</param>
        /// <returns></returns>
        private static DataTable GetAssignments(int labrunId, SqlConnection connection)
        {
            using (SqlCommand command = new SqlCommand())
            {
                command.CommandText = string.Format(
                    @"SELECT    * 
                      FROM      [dbo].[TFx_EmailNotification_Assignments]
                      WHERE     [labrunId] = {0}
                            AND [assignmentId] != {1}
                      ORDER BY  [assignmentId] ASC",
                    labrunId,
                    int.MaxValue);
                command.CommandType = CommandType.Text;
                command.Connection = connection;

                DataTable labrun = Tasks.ExecuteCommand(command, connection);

                return labrun;
            }
        }

        /// <summary>
        /// Execute Command
        /// </summary>
        /// <param name="command">Command</param>
        /// <param name="con">SQL Connection</param>
        /// <returns></returns>
        private static DataTable ExecuteCommand(SqlCommand command, SqlConnection con)
        {
            try
            {
                if (con.State == global::System.Data.ConnectionState.Closed)
                {
                    con.Open();
                }
                command.CommandTimeout = 3600;
                command.Connection = con;

                using (SqlDataAdapter dataAdapter = new SqlDataAdapter(command))
                {
                    DataTable resultSet = new DataTable();
                    resultSet.Locale = CultureInfo.InvariantCulture;
                    dataAdapter.Fill(resultSet);

                    return resultSet;
                }
            }
            catch (Exception e)
            {
                EventLog.WriteEntry("Application",
                    String.Format("Error occurred while executing query\nException Details:\n{0}", e.ToString()),
                    EventLogEntryType.Warning);
                throw;
            }
        }
    }
}


