using System;
using System.Collections.Specialized;
using System.Security.Principal;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.XPath;

using Expedia.Test.Framework;

namespace Expedia.System.Task.FxCop
{
    /// <summary>
    /// FxCop
    /// </summary>
    public class FxCop
    {        
        /// <summary>
        /// FxCop
        /// </summary>
        public FxCop()
        {
        }

        /// <summary>
        /// This run the FxCopCmd and send the result through email
        /// </summary>
        [Test]
        public void RunCodeAnalysis()
        {
            int startIndex, endIndex;

            bool passAllAnalysis = true;
            string numberOfMessages = "";
            string analysisResultFilePath = "";

            string basePath = TestContext.Instance.GetConfig<string>("SourceFolder");
            string path = Path.Combine(basePath, "Automation");
            string executable = Path.Combine(basePath, "Tools\\FxCop\\FxCopCmd");

            string param = "/p:\"ExpWebCheckin.FxCop\" /o:ExpWebFxCopResult.xml /outxsl:http://tfx/FxCop/FxCopReport.xsl /s /sf /fo";

            ExternalProgram prog = new ExternalProgram();

            TFxMail mail = new TFxMail();
            StringBuilder mailBody = new StringBuilder();
            StringBuilder mailSubject = new StringBuilder();

            //
            // Run the FxCop
            //
            RunExternalProgramResult result = prog.Run(path, executable, param, null);
            if (result != null)
            {
                Logger.Instance.WriteInfo(result.Output);
            }

            //
            // Check whether the analysis succeed or not
            //
            if (result.Output.Contains("\r\nMessages  : 0"))
            {
                passAllAnalysis = true;
                numberOfMessages = "0";
            }
            else
            {
                passAllAnalysis = false;
                startIndex = result.Output.IndexOf("\r\nMessages  : ");
                startIndex = startIndex + ("\r\nMessages  : ").Length;
                endIndex = result.Output.IndexOf("(", startIndex);
                numberOfMessages = result.Output.Substring(startIndex, endIndex - startIndex - 1);
            }

            //
            // Find the analysis report location
            //
            startIndex = result.Output.IndexOf("Writing report to ");
            startIndex = startIndex + ("Writing report to ").Length;
            endIndex = result.Output.IndexOf("...", startIndex);
            analysisResultFilePath = result.Output.Substring(startIndex, endIndex - startIndex);

            //
            // Send the report
            //
            mailSubject.Append("FxCop Daily Report (" + DateTime.Now.ToShortDateString() + ") - ");
            mailBody.Append("<B>FxCop Analysis Summary on ExpWeb.dll (" + DateTime.Now.ToShortDateString() + ")</B><BR><BR>");
            mailBody.Append("<u>Analysis Summary</u><br>");

            mail.AddAttachment(analysisResultFilePath);

            if (passAllAnalysis)
            {
                mailSubject.Append("Passed");
                mailBody.Append("ExpWeb.dll <font color=green>passed</font> all FxCop rules.<br><br>");
            }
            else
            {
                mailSubject.Append("Failed");
                mailBody.Append("ExpWeb.dll <font color=red>failed</font> on <font color=red>" + numberOfMessages + "</font> FxCop rules.<br><br>");

                //
                // read the list of namespaces that have broken FxCop rules
                //
                mailBody.Append("<u>List of namespaces that has broken FxCop rules:</u><br>");

                XPathDocument Doc = new XPathDocument(analysisResultFilePath);
                XPathNavigator nav = Doc.CreateNavigator();
                string xPathSearchString = "/FxCopReport/Targets/Target/Modules/Module/Namespaces/Namespace";
                XPathNodeIterator Iterator = nav.Select(xPathSearchString);

                while (Iterator.MoveNext())
                {
                    // find the number of message in that namespace
                    XPathNodeIterator IteratorMessages = Iterator.Current.SelectDescendants("Message", "", false);

                    // Get the name of the namespace
                    Iterator.Current.MoveToAttribute("Name", "");
                    mailBody.Append(Iterator.Current.Value);

                    // Get the message count
                    mailBody.Append(" <font color=red>(" + Convert.ToString(IteratorMessages.Count) + ")</font><br>");
                }

                mailBody.Append("<BR>");
            } // if

            mailBody.Append("Please see attached \"ExpWebFxCopResult.xml\" file for more details about the code analysis (You need to save it first before you can view it).<br>");

            //
            // Send the email
            //
            mail.Send("TFxReport@expedia.com", TestContext.Instance.Email, mailSubject.ToString(), mailBody.ToString());
        }
    }
}
