using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Security.Principal;
using System.Text;
using System.Threading;
using Expedia.Test.Framework;
using LRM;
using Microsoft.VisualBasic.Devices;
using SystemIO = System.IO;


namespace Expedia.System.Task.Build
{
    #region internal class
    internal class CopyBuildThread
    {
        public CopyBuildThread(RunExternalProgramResult result, string zipFileFullName, string destinationFolder, string sourceFolder,
        StringBuilder mailMessage)
        {
            this.Result = result;
            this.ZipFileFullName = zipFileFullName;
            this.DestinationFolder = destinationFolder;
            this.SourceFolder = sourceFolder;
            this.MailMessage = mailMessage;
        }

        public bool IsAbort { get; private set; }

        public RunExternalProgramResult Result;

        public string ZipFileFullName;

        public string DestinationFolder;

        public string SourceFolder;

        public StringBuilder MailMessage;

        public void RunExternalProgram()
        {
            Stopwatch timer = Stopwatch.StartNew();

            Logger.Instance.WriteInfo("Copying zip folder from {0} to folder {1}", ZipFileFullName, DestinationFolder);

            ExternalProgram prog = new ExternalProgram();
            string param = string.Format(" /C xcopy /Y /E {0}\\*.zip {1}\\*.zip", SourceFolder, DestinationFolder);
            Logger.Instance.WriteInfo("Starting {0} in {1} with {2} Environment<BR>", "cmd", SourceFolder, param);
            
            Result = prog.Run(SourceFolder, "cmd", param, null);

            if (Result != null)
            {
                Logger.Instance.Write(LogLevelType.Test, Result.Output);
            }

            if (Result.ExitCode != 0)
            {
                this.MailMessage.Append("<font color=Red><B>Status:    " + "Fail: " + Result.Error + "</B></font><BR><BR><BR>");
                Logger.Instance.WriteError(Result.Error);
                throw new Exception(Result.Error);
            }
            IsAbort = true;
            this.MailMessage.Append("Copying to " + DestinationFolder + " Elapsed Time in seconds" + ":    " + timer.Elapsed.Seconds.ToString() + "<BR>");
            this.MailMessage.Append("<font color=Green><B>Status:    " + "Pass" + "</B></font><BR><BR><BR>");
            Thread.CurrentThread.Abort();
        }
    }

    #endregion

    /// <summary>
    /// This class contains Tasks to build 
    /// </summary>
    public class Build
    {
        /// <summary>
        /// Build
        /// </summary>
        public Build()
        {
            mail = new TFxMail();
            mailMessage = new StringBuilder("<HTML><font size=2>");
        }

        #region Fields

        TFxMail mail;
        StringBuilder mailMessage;

        /// <summary>
        /// For ex: c:\AutomationTools\TFxServices\TFxBuilder. 
        /// </summary>
        private string sourceFolder = null;

        /// <summary>
        /// C:\AutomationTools\TFxServices\TFxBuilder\main\test\TFx
        /// </summary>
        private string buildFolder = null;

        private string primaryFolder = null;
        
        private string secondaryFolder = null;

        private string binDebugFolder = null;

        private string zipFilesTempFolder = Path.Combine("C:\\", "zipFilesTempFolder");

        private bool hasFailures = true;

        #endregion

        #region Configs

        /// <summary>
        /// P4Folder
        /// </summary>
        protected string P4Folder
        {
            get
            {
                return TestContext.Instance.GetConfig<string>("P4Folder");
            }
        }

        /// <summary>
        /// Branch Name
        /// </summary>
        protected string BranchName
        {
            get
            {
                return TestContext.Instance.GetConfig<string>("BranchName", null);
            }
        }

        /// <summary>
        /// Build Name
        /// </summary>
        protected string BuildName
        {
            get
            {
                return TestContext.Instance.GetConfig<string>("BuildName");
            }
        }

        /// <summary>
        /// Primary Build Folder
        /// </summary>
        protected string PrimaryBuildFolder
        {
            get
            {
                return TestContext.Instance.GetConfig<string>("PrimaryBuildFolder", null);
            }
        }

        /// <summary>
        /// Secondary Build Folder
        /// </summary>
        protected string SecondaryBuildFolder
        {
            get
            {
                return TestContext.Instance.GetConfig<string>("SecondaryBuildFolder", null);
            }
        }

        /// <summary>
        /// Zip Folder Location
        /// </summary>
        protected string ZipFolderLocation
        {
            get
            {
                return TestContext.Instance.GetConfig<string>("ZipFolderLocation", null);
            }
        }

        /// <summary>
        /// Pathch Bits Folder
        /// </summary>
        protected string PatchBitsFolder
        {
            get
            {
                return TestContext.Instance.GetConfig<string>("PatchBitsFolder", null);
            }
        }

        /// <summary>
        /// Enlistment Path
        /// </summary>
        protected string EnlistmentPath
        {
            get
            {
                return TestContext.Instance.GetConfig<string>("EnlistmentPath");
            }
        }

        /// <summary>
        /// Server Name
        /// </summary>
        protected string ServerName
        {
            get
            {
                return TestContext.Instance.GetConfig<string>("ServerName", null);
            }
        }

        /// <summary>
        /// Server Mirror Name
        /// </summary>
        protected string ServerMirrorName
        {
            get
            {
                return TestContext.Instance.GetConfig<string>("ServerMirrorName", null);
            }
        }

        /// <summary>
        /// DB Name
        /// </summary>
        protected string DBName
        {
            get
            {
                return TestContext.Instance.GetConfig<string>("DBName", null);
            }
        }

        /// <summary>
        /// Dll List
        /// </summary>
        protected string DllList
        {
            get
            {
                return TestContext.Instance.GetConfig<string>("DllList",null);
            }
        }

        #endregion

        #region Public Functions



        /// <summary>
        /// (i)     This function uses the client TFxBuilder_Root to sync the appropriate enlistment
        /// (ii)    Use the following command to see TFxBuilder_Root client specification 
        ///         "p4 -Cutf16le-bom -Qwinansi -HTFxBuilder -cTFxBuilder_Root -pperforce:1967 client" 
        /// (iii)   TFxBuilder_Root is mapped to the entire depot.
        /// (iv)    Configs required -> enlistmentpath(//depot/main/tfx/... etc)
        ///                          -> programFolder(c:\src\Tools)        ///                          
        /// (v)     Refresh Source in AutomationTools\TFxService\TFxBuilder folder
        ///                         
        /// /// </summary>
        [Test]
        public void SyncSource()
        {
            Stopwatch timer = Stopwatch.StartNew();

            string tfxServicesFolderPath = null;
            string tfxBuilderFolderPath = null;
            bool directoryCreated = false;
            string p4Command = " -Cutf16le-bom -Qwinansi -HTFxBuilder -cTFxBuilder_Root -pperforce:1967 -uperforcereader sync -f";
            RunExternalProgramResult runResult = null;
            Dictionary<string, string> environmentVariables = new Dictionary<string, string>();
            string tempP4Folder = null;

            TestContext.Instance.Scenario("Sync Source");
            Logger.Instance.WriteInfo("Sync Source");
            this.AddHeading("Sync Source");

            Logger.Instance.WriteInfo("Verify if AutomationTools\\TFxServices\\TFxBuilder folder exists");

            //Get all the drives in the machines
            DriveInfo[] drives = DriveInfo.GetDrives();

            foreach (DriveInfo drive in drives)
            {
                if (drive.DriveType.ToString() == DriveType.Fixed.ToString())
                {
                    //Search for the AutomationTools\TFxServices folder
                    tfxServicesFolderPath = Path.Combine(drive.Name, "AutomationTools\\TFxServices");

                    if (Directory.Exists(tfxServicesFolderPath))
                    {
                        tfxBuilderFolderPath = Path.Combine(tfxServicesFolderPath, "TFxBuilder");

                        //Search for the AutomationTools\TFxServices\TFxBuilder folder
                        if (Directory.Exists(tfxBuilderFolderPath))
                        {
                            Logger.Instance.WriteInfo("Folder {0} exists", tfxBuilderFolderPath);
                        }
                        else
                        {
                            //Create the TFxBuilder folder if it does not exists
                            Logger.Instance.WriteInfo("Create {0} folder", tfxBuilderFolderPath);
                            Directory.CreateDirectory(tfxBuilderFolderPath);
                        }

                        this.sourceFolder = tfxBuilderFolderPath;
                        directoryCreated = true;
                        break;
                    }
                }
            }

            if (!directoryCreated)
            {
                this.AddFailEntry("\\AutomationTools\\TFxServices folder does not exists. Is the machine manager installed on this box");
                throw new TFxException("\\AutomationTools\\TFxServices folder does not exists. Is the machine manager installed on this box");
            }

            //Login into perforce before sync

            this.PerforceLogin(this.sourceFolder, this.P4Folder + @"\p4");

            Logger.Instance.WriteInfo("Enlistment path {0}", this.EnlistmentPath);
            Logger.Instance.WriteInfo("Source Folder {0}", this.sourceFolder);

            p4Command = String.Concat(p4Command, " ", this.EnlistmentPath);
            Logger.Instance.WriteInfo("P4Command {0}", p4Command);

            //Make sure that the P4folder contains p4.exe
            tempP4Folder = Path.Combine(this.P4Folder, "p4.exe");
            if (!File.Exists(tempP4Folder))
            {
                this.AddFailEntry(String.Format("Make sure {0} contains p4.exe", this.P4Folder));
                throw new TFxException(String.Format("Make sure {0} contains p4.exe", this.P4Folder));
            }

            //Make sure Ruby files are deleted before sync
            string rubyTestFolder = Path.Combine(Path.Combine(this.sourceFolder, this.BranchName), "TFx\\Automation\\Ruby");
            string rubyDriverFolder = Path.Combine(Path.Combine(this.sourceFolder, this.BranchName), "TFx\\Framework\\TestFramework\\RubyDriver\\lib");
            try
            {
                if (Directory.Exists(rubyTestFolder))
                {
                    Directory.Delete(rubyTestFolder);
                }
                if (Directory.Exists(rubyDriverFolder))
                {
                    Directory.Delete(rubyDriverFolder);
                }
            }
            catch (Exception e)
            {
                Logger.Instance.WriteError(e.Message);
            }
            

            runResult = RunExternalProgram(this.sourceFolder, this.P4Folder + @"\p4", p4Command, environmentVariables);

            timer.Stop();
            this.AddEntry("Total Elapsed Time in minutes", timer.Elapsed.Minutes.ToString());

            if (runResult.ExitCode != 0)
            {
                this.AddFailEntry(runResult.Error);
                TestContext.Instance.TestFail(runResult.Error);
            }
            else
            {
                this.AddPassEntry();
            }

            Logger.Instance.WriteInfo("Total Elasped Time in Sync Source Solution function: {0}", timer.Elapsed.Minutes.ToString());

            Logger.Instance.WriteInfo("End of sync source");
        }

        /// <summary>
        /// Build the enlistment path using build.bat
        /// Required Configs -> EnlistmentPath
        /// </summary>

        [Test]
        public void BuildSolution()
        {
            Stopwatch timer = Stopwatch.StartNew();

            string tempNetDotFrameworkFolder = "Microsoft.NET\\Framework\\v3.5";
            string dotNetFrameworkFolder = null;
            RunExternalProgramResult runResult = null;
            string tempBuildFolder = null;
            Dictionary<string, string> environmentVariables = new Dictionary<string, string>();

            TestContext.Instance.Scenario("Build Solution");
            this.AddHeading("Build Solution Summary");
            Logger.Instance.WriteInfo("Build Solution");

            //Get the buildFolder
            this.buildFolder = GetBuildFolder();

            Logger.Instance.WriteInfo("BuildFolder: {0}", this.buildFolder);

            //Get the .NET folder path
            dotNetFrameworkFolder = Path.Combine(Environment.GetEnvironmentVariable("SystemRoot"), tempNetDotFrameworkFolder);
            string pathFolder = dotNetFrameworkFolder + ";" + Environment.GetEnvironmentVariable("SystemRoot") + ";" + "C:\\Program Files\\Microsoft Visual Studio 9.0\\VC\\vcpackages";
            Logger.Instance.WriteInfo("DotNetFrameworkFolder: {0}", dotNetFrameworkFolder);
            Logger.Instance.WriteInfo("PathFolder: {0}", pathFolder);
            if (!Directory.Exists(dotNetFrameworkFolder))
            {
                this.AddFailEntry(String.Format("Please make sure that VS2008 is installed,directory {0} does not exists", dotNetFrameworkFolder));
                throw new TFxException(String.Format("Please make sure that VS2008 is installed,directory {0} does not exists", dotNetFrameworkFolder));
            }

            //Delete all the files in bin\Debug
            this.binDebugFolder = Path.Combine(buildFolder, "bin\\debug");
            Logger.Instance.WriteInfo("BinDebugFolder: {0}", binDebugFolder);
            if (Directory.Exists(binDebugFolder))
            {
                Directory.Delete(binDebugFolder, true);
            }

            //Run build.bat 
            tempBuildFolder = Path.Combine(this.buildFolder, "build.bat");
            if (!File.Exists(tempBuildFolder))
            {
                this.AddFailEntry(String.Format("build.bat does not exists in {0}", this.buildFolder));
                throw new TFxException(String.Format("build.bat does not exists in {0}", this.buildFolder));
            }

            environmentVariables.Add("Path", pathFolder);

            runResult = RunExternalProgram(this.buildFolder, this.buildFolder + @"\build.bat", null, environmentVariables);

            timer.Stop();
            this.AddEntry("Total Elapsed Time in minutes", timer.Elapsed.Minutes.ToString());

            if (runResult.ExitCode != 0)
            {
                this.AddFailEntry(runResult.Error);
                TestContext.Instance.TestFail(runResult.Error);
            }
            else
            {
                this.AddPassEntry();
            }

            Logger.Instance.WriteInfo("Total Elasped Time in Build Solution function: {0}", timer.Elapsed.Minutes.ToString());
            Logger.Instance.WriteInfo("End of Build Solution");

        }

        /// <summary>
        /// Verify that the required dll's are present in the bin\debug folder of the release
        /// Required Configs -> RequiredDlls(comma separated list)
        /// Required Fields -> binDebugFolder
        /// Ex Config : TFxCore.dll,TFxLogger.dll,TFxAppCore.dll,Exptestdriver.dll,microsoft.mshtml.dll,
        ///             TFxTest.dll, TFxRunner.exe, TFxPublisher.dll,webautomation.dll
        /// </summary>
        [Test]
        public void VerifyDlls()
        {
            Stopwatch timer = Stopwatch.StartNew();

            string requiredDlls = null;
            string[] dllNames = null;

            TestContext.Instance.Scenario("Verify Dll's");
            Logger.Instance.WriteInfo("Verify Dll's");
            this.AddHeading("Verify Dll's");

            //*******Remove this line before checkin ********
            //this.binDebugFolder = @"D:\src\softtest\bin\debug";

            if (String.IsNullOrEmpty(this.binDebugFolder))
            {
                AddFailEntry("Bin Debug folder for the enlistment is null or empty");
                throw new TFxException("Bin Debug folder for the enlistment is null or empty");
            }

            Logger.Instance.WriteInfo("BinDebugFolder: {0}", binDebugFolder);

            requiredDlls = TestContext.Instance.GetConfig<string>("RequiredDlls", null);


            if (requiredDlls == null)
            {
                AddFailEntry("Please specify the required dll config");
                throw new TFxException("Please specify the required dll config");
            }

            dllNames = requiredDlls.Split(',');

            foreach (string name in dllNames)
            {
                string tempDllName = Path.Combine(binDebugFolder, name);

                if (!File.Exists(tempDllName))
                {
                    AddFailEntry(String.Format("File {0} does not exists in {1}", name, binDebugFolder));
                    throw new TFxException(String.Format("File {0} does not exists in {1}", name, binDebugFolder));
                }
            }

            timer.Stop();
            this.AddEntry("Total Elapsed Time in minutes", timer.Elapsed.Minutes.ToString());

            this.AddPassEntry();

            Logger.Instance.WriteInfo("Total Elasped Time in Verify Dll's function: {0}", timer.Elapsed.Minutes.ToString());
            Logger.Instance.WriteInfo("Verify Dll's complete");
        }

        /// <summary>
        /// The Ruby files are in Automation\Ruby. We need to copy all the files to bin\Debug\Ruby folder.
        /// Then we need to copy Framework\TestFramework\RubyDriver\lib\RubyDriver. rb to the common folder
        /// </summary>
        [Test]
        public void CopyRubyBits()
        {
            //*******Remove this line before checkin ********
            //this.binDebugFolder = @"D:\src\RubyDriver\TFx\bin\Debug";
            //this.buildFolder = @"D:\src\RubyDriver\TFx";

            Stopwatch timer = Stopwatch.StartNew();
            RunExternalProgramResult copyResult;
            string rubyFolder = Path.Combine(Path.Combine(this.buildFolder, "Automation"), "Ruby");
            string rubyBinDebugFolder = Path.Combine(this.binDebugFolder, "Ruby");

            //rubyDriverFolder = Framework\TestFramework
            string rubyDriverFolder = Path.Combine(this.buildFolder, "TFx\\RubyLib");
            if (!Directory.Exists(rubyDriverFolder))
            {
                rubyDriverFolder = Path.Combine(this.buildFolder, "Framework\\TestFramework\\RubyDriver\\lib");
            }

            Logger.Instance.WriteInfo("Folder where RubyDriver.rb exists -> {0}", rubyDriverFolder);

            TestContext.Instance.Scenario("Copy Ruby Files");
            Logger.Instance.WriteInfo("Copy Ruby Files");
            this.AddHeading("Copy Ruby Files");

            //Make sure that the binFolder + Automation\Ruby Tests exists
            if (!Directory.Exists(rubyFolder))
            {
                Logger.Instance.WriteError("Location to Ruby Folder {0} does not exists", rubyFolder);
                return;
            }

            Logger.Instance.WriteInfo("Location to Ruby Folder {0}", rubyFolder);

            //Copy the bits to bin\Debug folder
            try
            {
                if (Directory.Exists(rubyBinDebugFolder))
                {
                     Directory.Delete(rubyBinDebugFolder, true);
                }
                Directory.CreateDirectory(rubyBinDebugFolder);
            }
            catch (Exception e)
            {
                 Logger.Instance.WriteError("Fail to delete old ruby bits : " + rubyBinDebugFolder);
                 Logger.Instance.WriteError(e.Message);
            }

            Logger.Instance.WriteInfo("Copying Ruby Files from {0} -> {1}", rubyFolder, this.binDebugFolder);
            copyResult = RunExternalProgram(rubyFolder, "cmd", string.Format(" /C xcopy /Y /E {0}\\*.* {1}\\*.*", rubyFolder, rubyBinDebugFolder));

            if (copyResult.ExitCode != 0)
            {
                this.AddFailEntry(copyResult.Error);
                this.TestFailLocal(copyResult.Error);
            }
            else
            {
                //Add the RubyDriver.rb in Framework\TestFramewrok\RubyDriver\lib to bin\Debug\Ruby\Common
                string rubyCommonFolder = Path.Combine(rubyBinDebugFolder, "Common");
                if (!Directory.Exists(rubyCommonFolder))
                {
                    Directory.CreateDirectory(rubyCommonFolder);
                }
                Logger.Instance.WriteInfo("Copying Files from {0} -> {1}", rubyDriverFolder, rubyCommonFolder);
                copyResult = RunExternalProgram(rubyFolder, "cmd", string.Format(" /C xcopy /Y /E {0}\\*.* {1}\\*.*", rubyDriverFolder, rubyCommonFolder));

                if (copyResult.ExitCode != 0)
                {
                    this.AddFailEntry(copyResult.Error);
                    this.TestFailLocal(copyResult.Error);
                }
                else
                {
                    this.AddPassEntry();
                }

            }
            Logger.Instance.WriteInfo("Total Elasped Time in Copy Ruby Files function: {0}", timer.Elapsed.Minutes.ToString());
            Logger.Instance.WriteInfo("End of Copy Ruby Files");

        }

        /// <summary>
        /// RequirdConfigs-> PrimaryBuildFolder
        /// </summary>
        [Test]
        public void CopyBitsToNetwork()
        {
            //*******Remove this line before checkin ********
            //this.binDebugFolder = @"D:\src\1967\Projects\branches\Apple\TFx\bin\debug";
            //this.buildFolder = @"D:\src\1967\Projects\branches\Apple\TFx";
            
            Stopwatch timer = Stopwatch.StartNew();
            RunExternalProgramResult result = new RunExternalProgramResult();
            string fileName = "TestBits.zip";
            string tempPrimaryFolder = null;
            string tempSecondaryFolder = null;
            string tempZipDirLocation = null;
            string tempFilesLocation = null;

            this.AddHeading("Copy bits to network");
            TestContext.Instance.Scenario("Copy bits to network");
            Logger.Instance.WriteInfo("Copy bits to network");

            if (String.IsNullOrEmpty(this.PrimaryBuildFolder))
            {
                AddFailEntry("Primary build folder config is null or empty");
                throw new TFxException("Primary build folder config is null or empty");
            }

            if (String.IsNullOrEmpty(this.SecondaryBuildFolder))
            {
                AddFailEntry("Secondary build folder config is null or empty");
                throw new TFxException("Secondary build folder config is null or empty");
            }

            if (String.IsNullOrEmpty(this.BranchName))
            {
                AddFailEntry("BranchName config is null or empty");
                throw new TFxException("BranchName config is null or empty");
            }

            if (String.IsNullOrEmpty(this.BuildName))
            {
                AddFailEntry("BuildName config is null or empty");
                throw new TFxException("BuildName config is null or empty");
            }

            if (String.IsNullOrEmpty(this.binDebugFolder))
            {
                AddFailEntry("BinDebug is null or empty");
                throw new TFxException("BinDebug config is null or empty");
            }

            tempPrimaryFolder = Path.Combine(PrimaryBuildFolder, BranchName);
            this.primaryFolder = Path.Combine(tempPrimaryFolder, BuildName);

            //this.primaryFolder = @"\\CHELSQLINS01.karmalab.net\Builds\ETTTest\ETT_20090811";
            
            if (SystemIO.Directory.Exists(primaryFolder))
            {
                SystemIO.Directory.Delete(primaryFolder, true);
            }

            SystemIO.Directory.CreateDirectory(primaryFolder);

            if (!string.IsNullOrEmpty(this.SecondaryBuildFolder))
            {
                tempSecondaryFolder = Path.Combine(SecondaryBuildFolder, BranchName);
                this.secondaryFolder = Path.Combine(tempSecondaryFolder, BuildName);

                if (SystemIO.Directory.Exists(secondaryFolder))
                {
                    SystemIO.Directory.Delete(secondaryFolder, true);
                }

                SystemIO.Directory.CreateDirectory(secondaryFolder);
            }

            tempZipDirLocation = Path.Combine(this.buildFolder, "zipFolder_" + BuildName);

            if (Directory.Exists(tempZipDirLocation))
            {
                Directory.Delete(tempZipDirLocation, true);
            }

            Directory.CreateDirectory(tempZipDirLocation);

            //We need to copy files from binDebug to temporary folder
            tempFilesLocation = Path.Combine(this.buildFolder, "temp");

            //Make sure old ruby files are deleted.
            try
            {
                if (Directory.Exists(tempFilesLocation))
                {
                    Directory.Delete(tempFilesLocation);
                }
                Directory.CreateDirectory(tempFilesLocation);
            }
            catch (Exception e)
            {
                Logger.Instance.WriteError(e.Message);
            }

            Logger.Instance.WriteInfo("Copying files temporarily from {0} to {1}", binDebugFolder, tempFilesLocation);

            //Copy all the files from binDebug to the new folder to zip them
            result = RunExternalProgram(binDebugFolder, "cmd", string.Format(" /C xcopy /Y /E {0}\\*.* {1}\\*.*", binDebugFolder, tempFilesLocation), null);

            if (result.ExitCode != 0)
            {
                this.AddFailEntry(result.Error);
                this.TestFailLocal(result.Error);
            }

            string zipFileFullName = Path.Combine(tempZipDirLocation, fileName);

            Logger.Instance.WriteInfo("Zipping files from {0} to following {1}", tempFilesLocation, zipFileFullName);

            ICSharpCode.SharpZipLib.Zip.FastZip zip = new ICSharpCode.SharpZipLib.Zip.FastZip();
            //files in d:\\tests will be zipped into d:\\ruby.zip           
            zip.CreateZip(zipFileFullName, tempFilesLocation, true, "");

            timer.Stop();
            this.AddEntry("Elapsed Time in seconds", timer.Elapsed.Seconds.ToString());

            //Copy TestBits to primary build folder
            CopyBuildThread copyBuildThread_Primary = new CopyBuildThread(result, zipFileFullName, this.primaryFolder, tempZipDirLocation, mailMessage);
            Thread thread1 = new Thread(new ThreadStart(copyBuildThread_Primary.RunExternalProgram));
            thread1.Start();

            //Copy TestBits to secondary build folder
            CopyBuildThread copyBuildThread_Secondary = new CopyBuildThread(result, zipFileFullName, this.secondaryFolder, tempZipDirLocation, mailMessage);
            Thread thread2 = new Thread(new ThreadStart(copyBuildThread_Secondary.RunExternalProgram));
            thread2.Start();

            //Make sure both threads are finished
            while (!copyBuildThread_Primary.IsAbort || !copyBuildThread_Secondary.IsAbort)
            {
                Thread.Sleep(new TimeSpan(0, 0, 5));
            }

            if (Directory.Exists(tempFilesLocation))
            {
                Directory.Delete(tempFilesLocation, true);
            }
            if (Directory.Exists(tempZipDirLocation))
            {
                Directory.Delete(tempZipDirLocation, true);
            }

            Logger.Instance.WriteInfo("Total Elasped Time in Copy bits to network function: {0}", timer.Elapsed.Minutes.ToString());
            Logger.Instance.WriteInfo("End of Copy bits to network");
        }

        /// <summary>
        /// RequiredConfigs->PrimaryBuildFolder, ServerName, DBName , ServerMirrorName and Email
        /// </summary>
        [Test]
        public void Publish()
        {
            string branchFolder = "\\" + this.BranchName + "\\";
            string testBitsLocation = this.PrimaryBuildFolder + branchFolder + this.BuildName;

            //Use the local folder instead of the network share
            this.primaryFolder = this.binDebugFolder;

            PublishBuild(this.primaryFolder, testBitsLocation, false);
        }

        /// <summary>
        /// PublishBuild
        /// </summary>
        /// <param name="primaryFolder">Primary Folder</param>
        /// <param name="testBitsLocation">Test Bit Location</param>
        /// <param name="standaloneEmail">Standalone Email</param>
        public void PublishBuild(string primaryFolder, string testBitsLocation, bool standaloneEmail)
        {
            //primaryFolder = @"D:\R38";

            Stopwatch timer = Stopwatch.StartNew();

            StringBuilder message = null;
            string email = TestContext.Instance.GetConfig<string>("Email", "tfxbuild@expedia.com");
            try
            {
                TestContext.Instance.Scenario("Publish Build");
                Logger.Instance.WriteInfo("Start Pubishing Build");

                if (String.IsNullOrEmpty(ServerName) || String.IsNullOrEmpty(DBName))
                {
                    this.AddFailEntry("Invalid Server and DBName");
                    throw new TFxException("Please check ServerName and DatabaseName");
                }

                Logger.Instance.WriteInfo("ServerName: {0}", ServerName);
                Logger.Instance.WriteInfo("DBName: {0}", DBName);
                Logger.Instance.WriteInfo("ServerMirrorName: {0}", ServerMirrorName);
                Logger.Instance.WriteInfo("PrimaryFolder: {0}", primaryFolder);

                Publisher publisher = new Publisher(ServerName, DBName, ServerMirrorName, primaryFolder);

                Logger.Instance.WriteInfo("Validate the primary folder", primaryFolder);
                if (!publisher.BuildFolderIsValid(primaryFolder))
                {
                    this.AddFailEntry(publisher.ErrorMessage);
                    throw new TFxException(publisher.ErrorMessage);
                }

                string[] dllList = null;
                if (this.DllList != null)
                {
                    dllList = this.DllList.Split(',');
                }

                PublishResult result = publisher.Publish(primaryFolder, testBitsLocation, this.BranchName, dllList);

                Logger.Instance.WriteInfo("Format Mail Message");
                message = publisher.BuildMessage(result);

                this.hasFailures = false;
                foreach (PublishModuleResult moduleResult in result.ModuleResult)
                {
                    if (!moduleResult.isPublished && moduleResult.FailureReason == null)
                    {
                        this.hasFailures = true;
                        break;
                    }
                }

                if (!standaloneEmail)
                {
                    //Append the previous messages since this is not a request for private build
                    this.mailMessage.Append(message);
                }
                else
                {
                    //request for private build
                    this.mailMessage = message;
                    this.SendEmail(email);
                }

                timer.Stop();
                this.AddEntry("Total Elapsed Time in minutes", timer.Elapsed.Minutes.ToString());
                Logger.Instance.WriteInfo("Total Elasped Time in Publish Build function: {0}", timer.Elapsed.Minutes.ToString());
                this.AddPassEntry();
            }
            catch (Exception e)
            {
                Logger.Instance.WriteError(e.ToString());
                throw;
            }
        }

        /// <summary>
        /// Run tests to make sure that the framework is working as expected
        /// Tests -> (i)SmokeFlights
        /// </summary>
        [Test]
        public void RunTests()
        {
            if (!TestContext.Instance.GetConfig<bool>("runtests", false))
            {
                return;
            }

            Stopwatch timer = Stopwatch.StartNew();

            TestContext.Instance.Scenario("Run Tests");
            Logger.Instance.WriteInfo("Run Tests");
            this.AddHeading("Run Tests");

            //*******Remove this line before checkin ********
            //this.binDebugFolder = @"D:\src\softtest\bin\debug";

            RunExternalProgramResult runResult;

            if (String.IsNullOrEmpty(this.binDebugFolder))
            {
                AddFailEntry("Bin Debug folder for the enlistment is null or empty");
                throw new TFxException("Bin Debug folder for the enlistment is null or empty");
            }

            Logger.Instance.WriteInfo("BinDebugFolder: {0}", binDebugFolder);

            //Run the smoke flights test
            runResult = RunExternalProgram(binDebugFolder, binDebugFolder + @"\TFxRunner.exe", "commontest.dll Expedia.Automation.Test.Common.US.Smoke.SearchFlights -c site www.expedia.com");

            timer.Stop();
            this.AddEntry("Total Elapsed Time  in minutes", timer.Elapsed.Minutes.ToString());

            if (runResult.ExitCode != 0)
            {
                this.AddFailEntry(runResult.Error);
                TestContext.Instance.TestFail(runResult.Error);
            }
            else
            {
                this.AddPassEntry();
            }

            Logger.Instance.WriteInfo("Total Elasped Time in RunTests function: {0}", timer.Elapsed.Minutes.ToString());
            Logger.Instance.WriteInfo("Run Tests complete");
        }

        /// <summary>
        /// RequiredConfigs->BVTTemplateId
        /// </summary>
        [Test]
        public void RunBVT()
        {
            Stopwatch timer = Stopwatch.StartNew();

            int labrunId;
            TestContext.Instance.Scenario("Run BVT");
            Logger.Instance.WriteInfo("Run BVT");
            this.AddHeading("Run BVT");

            int templateId = TestContext.Instance.GetConfig<int>("BVTTemplateId", -1);

            if (templateId == -1)
            {
                throw new TFxException("Template Id is not defined in the config");
            }

            Logger.Instance.WriteInfo("Run BVT Template ID {0}", templateId);

            LabRunService lrmService = new LabRunService();
            labrunId = lrmService.CreateLabRunFromTemplate(templateId, this.BranchName, WindowsIdentity.GetCurrent().Name, null);

            Logger.Instance.WriteInfo("LabRun Id created: {0}", labrunId);

            lrmService.StartLabRun(labrunId);

            timer.Stop();
            this.AddEntry("Total Elapsed Time  in minutes:", timer.Elapsed.Minutes.ToString());

            Logger.Instance.WriteInfo("Total Elasped Time in RunBVT function: {0}", timer.Elapsed.Minutes.ToString());

            this.AddPassEntry();
        }

        /// <summary>
        /// Full Build
        /// </summary>
        [Test]
        public void FullBuild()
        {
            try
            {
                this.SyncSource();
                this.BuildSolution();
                this.VerifyDlls();
                this.RunTests();
                this.CopyRubyBits();
                this.CopyBitsToNetwork();
                this.Publish();
            }
            finally
            {
                this.AddSummary();
                SendEmail(TestContext.Instance.GetConfig<string>("Email", "tfxbuild@expedia.com"));
            }
        }




        /// <summary>
        /// get junit test case jar file
        /// </summary>
        [Test]
        public void FullBuild_Junit()
        {
            try
            {
                Guid newGuid = Guid.NewGuid();
                this.zipFilesTempFolder = this.zipFilesTempFolder + "_" + newGuid;

                //unzip files
                string[] zipFiles = this.ZipFolderLocation.Split(';');

                TestContext.Instance.Scenario("Unzip Files");
                Logger.Instance.WriteInfo("Unzip Files");
                this.AddHeading("Unzip Files");

                for (int i = 0; i < zipFiles.Length; i++)
                {
                    this.UnZipFiles(zipFiles[i]);
                }

                Logger.Instance.WriteInfo("End of unzip files function");

                Stopwatch timer = Stopwatch.StartNew();

                //Patch Bits
                TestContext.Instance.Scenario("Patch Bits");
                Logger.Instance.WriteInfo("Patch Bits to: " + zipFilesTempFolder);
                this.AddHeading("Patch Bits");
                this.AddEntry("Patch Bits to: ", zipFilesTempFolder);

                this.PatchBits(PatchBitsFolder, this.zipFilesTempFolder);

                timer.Stop();
                this.AddEntry("Total Elapsed Time in minutes", timer.Elapsed.Minutes.ToString());
                Logger.Instance.WriteInfo("Total Elasped Time in patch bits function: {0}", timer.Elapsed.Minutes.ToString());
                Logger.Instance.WriteInfo("End of patch bits");

                this.AddPassEntry();

                //Copy Junit Bits
                this.CopyJunitBits();

                this.PublishBuild(this.zipFilesTempFolder, primaryFolder, false);
            }
            finally
            {
                if (Directory.Exists(this.zipFilesTempFolder))
                {
                    this.DeleteTempFolder(this.zipFilesTempFolder);
                }

                if (Directory.Exists(this.zipFilesTempFolder + "_zipFolder"))
                {
                    this.DeleteTempFolder(this.zipFilesTempFolder + "_zipFolder");
                }

                this.AddSummary();
                SendEmail(TestContext.Instance.GetConfig<string>("Email", "tfxbuild@expedia.com"));
            }
        }

        /// <summary>
        /// Copies an already-published build from the primary build folder to an alternate build folder
        /// </summary>
        [Test]
        [Config(Name = "alternatebuildfolder")]
        public void CopyBuildToAlternateShare()
        {
            //
            // Load Configs
            //
            string primaryBuilderFolder = TestContext.Instance.GetConfig("primarybuildfolder");
            string alternateBuildFolder = TestContext.Instance.GetConfig("alternatebuildfolder");
            string branchName = TestContext.Instance.GetConfig("branchname");
            string buildName = TestContext.Instance.GetConfig("buildname");

            if (string.IsNullOrEmpty(primaryBuilderFolder))
            {
                TestContext.Instance.TestFail("PrimaryBuildFolder config is missing");
            }

            if(string.IsNullOrEmpty(alternateBuildFolder))
            {
                TestContext.Instance.TestFail("AlternateBuildFolder config is missing");
            }

            if (string.IsNullOrEmpty(branchName))
            {
                TestContext.Instance.TestFail("BranchName config is missing");
            }

            if (string.IsNullOrEmpty(buildName))
            {
                TestContext.Instance.TestFail("BuildName config is missing");
            }

            //
            // Build paths, verify existance
            //

            string buildPath = Path.Combine(branchName, buildName);
            string primaryPath = Path.Combine(primaryBuilderFolder, buildPath);
            string alternatePath = Path.Combine(alternateBuildFolder, buildPath);

            if(!Directory.Exists(primaryPath))
            {
                TestContext.Instance.TestFail("Primary build path not found: " + primaryPath);
            }

            new Computer().FileSystem.CopyDirectory(primaryPath, alternatePath, true);
        }

        #endregion

        #region Helper Function

        private void PerforceLogin(string sourceFolder, string program)
        {
            Logger.Instance.WriteInfo("Perforce Login");
            ExternalProgram prog = new ExternalProgram();
            string p4Command = " -Cutf16le-bom -Qwinansi -HTFxBuilder -cTFxBuilder_Root -pperforce:1967 -u perforcereader login";
            string p4PerforcePassword = "p4perforcereaderp4";

            Logger.Instance.WriteInfo("Starting {0} in {1} with {2} Environment<BR>", program, sourceFolder, p4Command);
            Logger.Instance.WriteInfo("Perforce password {0}", p4PerforcePassword);

            RunExternalProgramResult runResult = prog.RunCommandwithInput(sourceFolder, program, p4Command, null, p4PerforcePassword);

            if (runResult.ExitCode != 0)
            {
                this.AddFailEntry(runResult.Error);
                TestContext.Instance.TestFail(runResult.Error);
            }
            else
            {
                this.AddPassEntry();
                Logger.Instance.WriteInfo(runResult.Output);
            }

        }

        /// <summary>
        /// Send Email
        /// </summary>
        /// <param name="email">Email</param>
        public void SendEmail(string email)
        {
            this.mailMessage.Append("</font></HTML>");

            string mailTitle;
            if (!this.hasFailures)
            {
                mailTitle = string.Format("TFxBuild <Pass> {0} publish summary", BuildName);
            }
            else
            {
                mailTitle = string.Format("TFxBuild <Fail> {0} publish summary", BuildName);
            }

            this.mail.Send("TFxReport@expedia.com", email, mailTitle, this.mailMessage.ToString());
        }

        /// <summary>
        /// Test Fail Local
        /// </summary>
        /// <param name="error">Error</param>
        public void TestFailLocal(string error)
        {
            Logger.Instance.WriteError(error);
            throw new Exception(error);
        }

        RunExternalProgramResult RunExternalProgram(string folder, string program, string param)
        {
            return RunExternalProgram(folder, program, param, null);
        }

        RunExternalProgramResult RunExternalProgram(string folder, string program, string param, Dictionary<string, string> env)
        {
            ExternalProgram prog = new ExternalProgram();

            Logger.Instance.WriteInfo("Starting {0} in {1} with {2} Environment<BR>", program, folder, param);


            if (env != null && env.Keys != null)
            {
                foreach (string key in env.Keys)
                {
                    Logger.Instance.WriteInfo("Config Key={0}, Value={1}<BR>", key, env[key]);
                }
            }

            RunExternalProgramResult result = prog.Run(folder, program, param, env);

            if (result != null)
            {
                Logger.Instance.Write(LogLevelType.Test, result.Output);
            }

            return result;
        }


        private string GetBuildFolder()
        {
            string tempEnlistmentPath = null;
            string tempBuildFolder = String.Empty;
            tempEnlistmentPath = this.EnlistmentPath.Trim('/');
            string[] tokens = tempEnlistmentPath.Split('/');

            if (tokens.Length <= 1)
            {
                throw new TFxException(String.Format("Please check your enlistmentpath {0}", this.EnlistmentPath));
            }

            tempBuildFolder = this.sourceFolder;

            for (int i = 1; i < tokens.Length - 1; i++)
            {
                tempBuildFolder = String.Concat(tempBuildFolder, "\\", tokens[i]);
            }

            return tempBuildFolder;
        }

        private void UnZipFiles(string location)
        {
            Stopwatch timer = Stopwatch.StartNew();

            this.AddEntry("Unzip Files in :", location);

            if (!Directory.Exists(location))
            {
                AddFailEntry("Could not find a part of the path: " + this.ZipFolderLocation);
                throw new TFxException("Could not find a part of the path: " + this.ZipFolderLocation);
            }

            if (String.IsNullOrEmpty(location))
            {
                AddFailEntry("Zip Folder Location is null or empty");
                throw new TFxException("Zip Folder Location is null or empty");
            }

            Directory.CreateDirectory(this.zipFilesTempFolder);
            Logger.Instance.WriteInfo("Create zipFilesTempFolder complete");

            string[] zipfiles = Directory.GetFiles(location);
            if (zipfiles.Length == 0)
            {
                AddFailEntry("No zip files in " + this.ZipFolderLocation);
                throw new TFxException("No zip files in " + this.ZipFolderLocation);
            }

            for (int i = 0; i < zipfiles.Length; i++)
            {
                if (zipfiles[i].EndsWith(".zip"))
                {
                    try
                    {
                        ICSharpCode.SharpZipLib.Zip.FastZip zip = new ICSharpCode.SharpZipLib.Zip.FastZip();
                        zip.ExtractZip(zipfiles[i], this.zipFilesTempFolder, "");
                    }
                    catch (Exception e)
                    {
                        string errorMessage = "Unzip failed: " + zipfiles[i];
                        Logger.Instance.WriteError("Details:" + e.Message);
                        Logger.Instance.WriteError("StackTrace:" + e.StackTrace);
                        AddFailEntry(errorMessage);
                        throw new TFxException(errorMessage);
                    }
                }
            }
            string[] arrayDirectories = Directory.GetDirectories(this.zipFilesTempFolder);
            string[] arrayFiles = Directory.GetFiles(this.zipFilesTempFolder);
            if (arrayDirectories.Length == 0 && arrayFiles.Length == 0)
            {
                AddFailEntry("No files inside " + this.ZipFolderLocation);
                throw new TFxException("No files inside " + this.ZipFolderLocation);
            }

            for (int i = 0; i < arrayFiles.Length; i++)
            {
                string jarName = arrayFiles[i].Substring(arrayFiles[i].LastIndexOf(@"\") + 1, arrayFiles[i].Length - arrayFiles[i].LastIndexOf(@"\") - 1);
                //remove the version info from the jar file names
                string[] tokens = jarName.Split('-');
                if (tokens.Length >= 2)
                {
                    string newJarName = jarName.Substring(0, jarName.LastIndexOf("-"));
                    string newJarNameFullPath = Path.Combine(this.zipFilesTempFolder, newJarName + ".jar");
                    if (!File.Exists(newJarNameFullPath))
                    {
                        File.Move(arrayFiles[i], newJarNameFullPath);
                    }
                    else
                    {
                        File.Delete(arrayFiles[i]);
                    }
                }
            }

            timer.Stop();
            this.AddEntry("Total Elapsed Time in minutes", timer.Elapsed.Minutes.ToString());
            Logger.Instance.WriteInfo("Total Elasped Time in unzip files function: {0}", timer.Elapsed.Minutes.ToString());
            this.AddPassEntry();
        }

        private void PatchBits(string patchBitsFolder, string zipFilesTempFolder)
        {
            try
            {
                if (String.IsNullOrEmpty(this.PatchBitsFolder))
                {
                    AddFailEntry("Patch bits folder config is null or empty");
                    throw new TFxException("Patch bits folder config is null or empty");
                }

                string[] arrayDirectories = Directory.GetDirectories(patchBitsFolder);
                string[] arrayFiles = Directory.GetFiles(patchBitsFolder);

                if (arrayFiles.Length != 0)
                {
                    for (int i = 0; i < arrayFiles.Length; i++)
                    {
                        {
                            //don't overwrite if the file exists
                            if (!File.Exists(Path.Combine(zipFilesTempFolder, Path.GetFileName(arrayFiles[i]))))
                            {
                                File.Copy(Path.Combine(patchBitsFolder, Path.GetFileName(arrayFiles[i])),
                                    Path.Combine(zipFilesTempFolder, Path.GetFileName(arrayFiles[i])), false);
                            }
                        }

                    }
                }

                //copy child folders
                if (arrayDirectories.Length != 0)
                {
                    for (int i = 0; i < arrayDirectories.Length; i++)
                    {
                        //if the folder don't exists, create it
                        if (!Directory.Exists(Path.Combine(zipFilesTempFolder, Path.GetFileName(arrayDirectories[i]))))
                        {
                            Directory.CreateDirectory(Path.Combine(zipFilesTempFolder, Path.GetFileName(arrayDirectories[i])));
                        }

                        //copy files
                        PatchBits(Path.Combine(patchBitsFolder, Path.GetFileName(arrayDirectories[i])),
                              Path.Combine(zipFilesTempFolder, Path.GetFileName(arrayDirectories[i])));

                    }
                }
            }
            catch (Exception e)
            {
                Logger.Instance.WriteError(e.ToString());
                throw;
            }
        }

        private void CopyJunitBits()
        {
            Stopwatch timer = Stopwatch.StartNew();

            TestContext.Instance.Scenario("Copy Junit Bits");
            Logger.Instance.WriteInfo("Copy Junit Bits");
            this.AddHeading("Copy Junit Bits");

            this.primaryFolder = PrimaryBuildFolder;
            if (String.IsNullOrEmpty(this.primaryFolder))
            {
                AddFailEntry("Primary folder is null or empty");
                throw new TFxException("Primary folder config is null or empty");
            }

            String tempPrimaryFolder = null;
            string tempSecondaryFolder = null;

            tempPrimaryFolder = Path.Combine(PrimaryBuildFolder, BranchName);
            this.primaryFolder = Path.Combine(tempPrimaryFolder, BuildName);

            tempSecondaryFolder = Path.Combine(SecondaryBuildFolder, BranchName);
            this.secondaryFolder = Path.Combine(tempSecondaryFolder, BuildName);

            if (!Directory.Exists(primaryFolder.ToString()))
            {
                Directory.CreateDirectory(primaryFolder.ToString());
                Logger.Instance.WriteInfo(primaryFolder.ToString() + "  doesn't exist , Create it ");
            }
            if (!Directory.Exists(secondaryFolder.ToString()))
            {
                Directory.CreateDirectory(secondaryFolder.ToString());
                Logger.Instance.WriteInfo(secondaryFolder.ToString() + "  doesn't exist , Create it ");
            }

            string tempZipDirLocation = zipFilesTempFolder + "_zipFolder";
            string zipFileFullName = Path.Combine(tempZipDirLocation, "TestBits.zip");

            if (!Directory.Exists(tempZipDirLocation.ToString()))
            {
                Directory.CreateDirectory(tempZipDirLocation.ToString());
                Logger.Instance.WriteInfo(tempZipDirLocation.ToString() + "  doesn't exist , Create it ");
            }

            Logger.Instance.WriteInfo("Zipping files from {0} to following {1}", zipFilesTempFolder, zipFileFullName);

            ICSharpCode.SharpZipLib.Zip.FastZip zip = new ICSharpCode.SharpZipLib.Zip.FastZip();
            zip.CreateZip(zipFileFullName, zipFilesTempFolder, true, "");

            RunExternalProgramResult result = new RunExternalProgramResult();
            //Copy TestBits to primary build folder
            CopyBuildThread copyBuildThread_Primary = new CopyBuildThread(result, zipFileFullName, this.primaryFolder, tempZipDirLocation, mailMessage);
            Thread thread1 = new Thread(new ThreadStart(copyBuildThread_Primary.RunExternalProgram));
            thread1.Start();

            //Copy TestBits to secondary build folder
            CopyBuildThread copyBuildThread_Secondary = new CopyBuildThread(result, zipFileFullName, this.secondaryFolder, tempZipDirLocation, mailMessage);
            Thread thread2 = new Thread(new ThreadStart(copyBuildThread_Secondary.RunExternalProgram));
            thread2.Start();

            //Make sure both threads are finished
            while (!copyBuildThread_Primary.IsAbort || !copyBuildThread_Secondary.IsAbort)
            {
                Thread.Sleep(new TimeSpan(0, 0, 5));
            }

            timer.Stop();
            this.AddEntry("Total Elapsed Time in minutes", timer.Elapsed.Minutes.ToString());

            Logger.Instance.WriteInfo("Total Elasped Time in copy junit bits function: {0}", timer.Elapsed.Minutes.ToString());
            Logger.Instance.WriteInfo("End of copy junit bits");
            this.AddPassEntry();
        }

        private void DeleteTempFolder(string zipFilesTempFolder)
        {
            Stopwatch timer = Stopwatch.StartNew();

            TestContext.Instance.Scenario("Delete Temp Folder");
            Logger.Instance.WriteInfo("Delete Temp Folder");
            this.AddHeading("Delete Temp Folder");

            try
            {
                Directory.Delete(zipFilesTempFolder, true);
                this.AddPassEntry();
            }
            catch (Exception e)
            {
                Logger.Instance.WriteError(e.ToString());
            }

            timer.Stop();
            this.AddEntry("Total Elapsed Time in minutes", timer.Elapsed.Minutes.ToString());

            Logger.Instance.WriteInfo("Total Elasped Time in delete temp folder function: {0}", timer.Elapsed.Minutes.ToString());
            Logger.Instance.WriteInfo("End of delete temp folder");
        }

        private void AddSummary()
        {
            this.AddHeading("Publish Summary:");
            if (!this.hasFailures)
            {
                this.AddPassEntry();
            }
            else
            {
                this.AddFailEntry();
            }
        }

        private void AddHeading(string headingName)
        {
            this.mailMessage.Append("<B><U>" + headingName + "</U></B><BR>");
        }

        private void AddEntry(string configName, string configValue)
        {
            this.mailMessage.Append(configName + ":    " + configValue + "<BR>");
        }

        private void AddPassEntry()
        {
            this.mailMessage.Append("<font color=Green><B>Status:    " + "Pass" + "</B></font><BR><BR><BR>");
        }

        private void AddFailEntry()
        {
            this.mailMessage.Append("<font color=Red><B>Status:    " + "Fail" + "</B></font><BR><BR><BR>");
        }

        private void AddFailEntry(string error)
        {
            this.mailMessage.Append("<font color=Red><B>Status:    " + "Fail: " + error + "</B></font><BR><BR><BR>");
        }

        #endregion


    }
}
