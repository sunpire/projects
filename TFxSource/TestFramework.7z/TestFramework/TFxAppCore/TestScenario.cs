using System;
using System.Collections.Generic;
using System.Text;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Comments:	Changed Scenarios id from int to GUID
    /// </summary>
    public class TestScenario : ICloneable
    {
        private Guid m_scenarioId;
        private string m_description;

        public TestScenario()
        {
        }

        public Guid ScenarioId
        {
            get
            {
                return m_scenarioId;
            }
            set
            {
                m_scenarioId = value;
            }
            

        }

        public string Description 
        {
            get
            {
                return m_description;
            }
            set
            {
                m_description = value;
            }

        }

        #region ICloneable Members

        public object Clone()
        {
            TestScenario newScenario = new TestScenario();
            newScenario.Description = this.Description;
            newScenario.ScenarioId = this.ScenarioId;

            return newScenario;
        }

        #endregion
    }
}
