using System;
using System.Xml.Serialization;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TestRelease.
    /// Comments:   Changed releaseid to releasegid type GUID
	/// </summary>
	/// 
	[Serializable]
	public class TestRelease
	{
		private Guid m_releasegid;
		private string m_releaseName;
		private string m_enlistmentName;
		private string m_enlistmentFolderName;


		public TestRelease()
		{			
		}

        public Guid ReleaseGid
		{
			get
			{
                return m_releasegid;
			}
			set
			{
                m_releasegid = value;
			}
		}

		public string ReleaseName
		{
			get
			{
				return m_releaseName;
			}
			set
			{
				m_releaseName = value;
			}
		}


		public string EnlistmentName
		{
			get
			{
				return m_enlistmentName;
			}
			set
			{
				m_enlistmentName = value;
			}
		}


		public string EnlistmentFolderName
		{
			get
			{
				return m_enlistmentFolderName;
			}
			set
			{
				m_enlistmentFolderName = value;
			}
		}

	}
}
