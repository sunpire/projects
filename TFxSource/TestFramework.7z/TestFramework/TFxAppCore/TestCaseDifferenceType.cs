//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: TestCaseDifferenceType.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TestCaseDifferenceType.
	/// </summary>
	public enum TestCaseDifferenceType
	{
		NotValidDifference = 0,
		NoMatchFound = 1,
		NameDifference = 2,
		CategoryDifference = 3,
		OwnerDifference=4,
		NoDifference = 5,
		Rename =6
	}
}
