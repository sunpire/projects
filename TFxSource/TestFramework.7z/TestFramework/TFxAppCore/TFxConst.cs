using System;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for SystemVariables.
    /// </summary>
    public class TFxConst
    {
        public TFxConst()
        {
        }

        private StringConfig m_config = new StringConfig();

        /// <summary>
        /// Readonly consts
        /// </summary>
        private readonly static string c_envPrefix = "__";
        public readonly static string c_LogType = c_envPrefix + "LogType";
        public readonly static string c_LogInfo = c_envPrefix + "LogInfo";
        public readonly static string c_LogLevel = c_envPrefix + "LogLevel";
        public readonly static string c_SeverityType = c_envPrefix + "SeverityType";
        public readonly static string c_AssignmentTimeout = c_envPrefix + "AssignmentTimeout";
        public readonly static string c_FileLog = "FileLog";
        public readonly static string c_DBLog = "DBLog";

        public readonly static string c_Email = c_envPrefix + "Email";
        public readonly static string c_LabRunName = c_envPrefix + "LabRunName";
        public readonly static string c_AssignmentName = c_envPrefix + "AssignmentName";
        public readonly static string c_LabRunGID = c_envPrefix + "LabRunGid";
        public readonly static string c_Manager = c_envPrefix + "Manager";
        public readonly static string c_ReleaseInfo = c_envPrefix + "ReleaseInfo";

        public IConfig Config
        {
            get
            {
                return m_config;
            }
        }

        /// <summary>
        ///  Email
        /// </summary>
        public string Email
        {
            get
            {
                return GetVar(c_Email);
            }
            set
            {
                SetVar(c_Email, value);
            }
        }


        /// <summary>
        ///  Manager Name
        /// </summary>
        public string Manager
        {
            get
            {
                return GetVar(c_Manager);
            }
            set
            {
                SetVar(c_Manager, value);
            }
        }

        /// <summary>
        ///  Lab Run Name
        /// </summary>
        public string LabRunName
        {
            get
            {
                return GetVar(c_LabRunName);
            }
            set
            {
                SetVar(c_LabRunName, value);
            }
        }

        public TimeSpan AssignmentTimeout
        {
            get
            {
                return TimeSpan.Parse(GetVar(c_AssignmentTimeout));
            }
            set
            {
                SetVar(c_AssignmentTimeout, value.ToString());
            }
        }

        /// <summary>
        ///  Lab Run Guid
        /// </summary>
        public Guid LabRunGid
        {
            get
            {
                return new Guid(GetVar(c_LabRunGID));
            }
            set
            {
                SetVar(c_LabRunGID, value.ToString());
            }
        }

        /// <summary>
        ///  Assignment Name
        /// </summary>
        public string AssignmentName
        {
            get
            {
                return GetVar(c_AssignmentName);
            }
            set
            {
                SetVar(c_AssignmentName, value);
            }
        }

        /// <summary>
        /// LogType variable
        /// </summary>
        public string LogType
        {
            get
            {
                return GetVar(c_LogType);
            }
            set
            {
                SetVar(c_LogType, value);
            }
        }

        /// <summary>
        ///  LogLevel variable
        /// </summary>
        public LogLevelType LogLevel
        {
            get
            {
                return (LogLevelType)Enum.Parse(typeof(LogLevelType), GetVar(c_LogLevel));
            }
            set
            {
                SetVar(c_LogLevel, value.ToString());
            }
        }

        /// <summary>
        ///  SeverityType variable
        /// </summary>
        public SeverityType SeverityType
        {
            get
            {
                return (SeverityType)Enum.Parse(typeof(SeverityType), GetVar(c_SeverityType));
            }
            set
            {
                SetVar(c_SeverityType, value.ToString());
            }
        }

        /// <summary>
        ///  LogInfo variable
        /// </summary>
        public string LogInfo
        {
            get
            {
                return GetVar(c_LogInfo);
            }
            set
            {
                SetVar(c_LogInfo, value);
            }
        }

        /// <summary>
        /// Determine whether variable type is a TFxConst Variable
        /// </summary>
        /// <param name="var"></param>
        /// <returns></returns>
        public static bool IsSystemVar(string var)
        {
            return (var != null && var.StartsWith(c_envPrefix));
        }

        /// <summary>
        /// Get Variables from IConfig
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        string GetVar(string name)
        {
            if (m_config.IsDefined(name))
            {
                return m_config[name];
            }
            return null;
        }

        /// <summary>
        /// Set Variable into IConfig
        /// </summary>
        /// <param name="name"></param>
        /// <param name="value"></param>
        void SetVar(string name, string value)
        {

            if (m_config.IsDefined(name))
            {
                m_config[name] = value;
            }
            else
            {
                m_config.Add(name, value);
            }
        }
    }
}
