//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: TestCaseChange.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TestCaseChange.
	/// </summary>
	public class TestCaseChange : RepositoryRequest
	{
		private TestCase m_oldTC = null;
		private TestCase m_newTC = null;

		/// <summary>
		/// Use this constructor for creating or deleting a test case in a repository.
		/// </summary>
		/// <param name="type">The type of change, either RepositoryChangeType.Create or
		/// RepositoryChangeType.Delete.</param>
		/// <param name="testCase">The TestCase to create or delete.</param>
		public TestCaseChange(RepositoryRequestType type, TestCase testCase) : base(type)
		{
			switch(type)
			{
				case RepositoryRequestType.Create:
					this.m_newTC = testCase;
					break;
				case RepositoryRequestType.Delete:
					this.m_oldTC = testCase;
					break;
				case RepositoryRequestType.Update:
					this.m_newTC = testCase;
					break;
				default:
                    throw new Exception("Invalid RepositoryChangeType! Type cannot be Update if only one test case is provided.");
			}
		}

		/// <summary>
		/// Use this constructor to move or update a test case in a repository.
		/// </summary>
		/// <param name="oldTestCase">The original test case to update.</param>
		/// <param name="newTestCase">The new updated test case.</param>
		public TestCaseChange(TestCase oldTestCase, TestCase newTestCase) : base(RepositoryRequestType.Update)
		{
			this.m_oldTC = oldTestCase;
			this.m_newTC = newTestCase;
		}

		public TestCase OldTestCase
		{
			get
			{
				return this.m_oldTC;
			}
		}

		public TestCase NewTestCase
		{
			get
			{
				return this.m_newTC;
			}
		}

		public override string ToString()
		{
			switch(this.RequestType)
			{
				case RepositoryRequestType.Create:
					return String.Format("Create test case <{0}>", this.m_newTC.FullName);
				case RepositoryRequestType.Delete:
					return String.Format("Delete test case <{0}>", this.m_oldTC.FullName);
				case RepositoryRequestType.Update:
					return String.Format("Move test case from <{0}> to <{1}>", this.m_oldTC.FullName, this.m_newTC.FullName);
				default:
					return String.Format("Unknown RepositoryChangeType");
			}
		}
	}
}
