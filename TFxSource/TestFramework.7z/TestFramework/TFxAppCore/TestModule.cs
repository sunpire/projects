using System;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for TestModule.
    /// </summary>
    [Serializable]
    public class TestModule
    {
        string m_fullName;
        string m_testName;

        public string FullName
        {
            get { return m_fullName; }
        }

        public string Name
        {
            get { return m_testName; }
        }

        private TestArea suite;

        public TestArea RootTestArea
        {
            get
            {
                return suite;
            }
        }

        public TestModule(string moduleName)
        {
            this.m_fullName = this.m_testName = moduleName;
            this.suite = new TestArea(this.Name);
        }

        public TestInfo FindTest(string fullPath)
        {
            return this.GetAllTestInfo().FindTest(fullPath);
        }

        public TestArea GetAllTestInfo()
        {
            return this.RootTestArea;
        }
    }
}
