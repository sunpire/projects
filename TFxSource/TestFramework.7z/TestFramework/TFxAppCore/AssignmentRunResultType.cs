//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: AssignmentRunResultType.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for AssignmentResultType.
	/// </summary>
	public enum AssignmentRunResultType
	{
		Pass=0,
		ModuleNotFound=1,
		FailToFindTest=2,
		BuildNotInstalled=3,
		ExecutionError=4,
		UnknownError=5,
		FailToLoad = 6,
		NoResults = 7,
		Timeout = 8

	}
}
