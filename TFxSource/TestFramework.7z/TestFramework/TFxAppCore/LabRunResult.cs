//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: AssignmentResult.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for AssignmentResult.
    /// </summary>
    [Serializable]
    public class LabRunResult
    {
        private int m_pass = 0;
        private int m_failToLoad = 0;
        private int m_failToFindTest = 0;
        private int m_buildNotInstalled = 0;
        private int m_executionError = 0;
        private int m_unknownError = 0;

        public int Pass
        {
            get
            {
                return m_pass;
            }
            set
            {
                m_pass = value;
            }
        }

        public int FailToLoad
        {
            get
            {
                return m_failToLoad;
            }
            set
            {
                m_failToLoad = value;
            }
        }

        public int FailToFindTest
        {
            get
            {
                return m_failToFindTest;
            }
            set
            {
                m_failToFindTest = value;
            }
        }

        public int BuildNotInstalled
        {
            get
            {
                return m_buildNotInstalled;
            }
            set
            {
                m_buildNotInstalled = value;
            }
        }

        public int ExecutionError
        {
            get
            {
                return m_executionError;
            }
            set
            {
                m_executionError = value;
            }
        }

        public int UnknownError
        {
            get
            {
                return m_unknownError;
            }
            set
            {
                m_unknownError = value;
            }
        }
    }
}
