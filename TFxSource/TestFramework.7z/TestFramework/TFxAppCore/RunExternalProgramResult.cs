﻿
namespace Expedia.Test.Framework
{
    public class RunExternalProgramResult
    {
        public RunExternalProgramResult()
        {
        }

        public string Output;
        public string Error;
        public int ExitCode;
    }
}
