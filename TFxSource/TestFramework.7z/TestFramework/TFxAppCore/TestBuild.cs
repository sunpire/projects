//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: TestBuild.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;
using System.IO;
using System.Collections;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for TestBuild.
    /// Comments: Changed m_id to m_buildgid and type to int
    /// </summary>
    [Serializable]
    public class TestBuild
    {
        public TestRelease m_testRelease;

        public Guid BuildGid { get; set; }

        public string Name { get; set; }

        public string RootFolder { get; set; }

        public string AlternateRootFolder { get; set; }

        protected TestBuildModule[] m_modules;

        public virtual TestBuildModule[] Modules
        {
            get
            {
                return this.m_modules;
            }
            set
            {
                if (value != null)
                {
                    ArrayList modules = new ArrayList();
                    modules.AddRange(value);
                    this.m_modules = (TestBuildModule[])modules.ToArray(typeof(TestBuildModule));
                }
            }
        }

        public TestBuildModule GetModule(string modulename)
        {
            if (m_modules != null)
            {
                foreach (TestBuildModule module in m_modules)
                {
                    if (module.Name.Equals(modulename, StringComparison.OrdinalIgnoreCase))
                    {
                        return module;
                    }
                }
            }

            return null;
        }

        public TestRelease TestRelease
        {
            get
            {
                return m_testRelease;
            }
            set
            {
                m_testRelease = value;
            }
        }

        private int m_bitAvailable = 0;

        public int BitAvailable
        {
            get
            {
                return m_bitAvailable;
            }
            set
            {
                m_bitAvailable = value;
            }
        }

        public override string ToString()
        {
            return Name;
        }

        public TestBuild()
        {
        }
    }
}
