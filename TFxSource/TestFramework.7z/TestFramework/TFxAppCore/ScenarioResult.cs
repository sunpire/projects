using System;
using System.Xml.Serialization;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// ScenarioResult used by TestStudio ONLY.
    /// </summary>
    [Serializable]
    public sealed class ScenarioResult
    {
        public ScenarioResult() { }
        public ScenarioResult(string scenarioName)
        {
            this.ScenarioName = scenarioName;
        }

        public string ScenarioName { get; set; }

        [XmlIgnore]
        public bool IsFailure { get { return !this.Status.Equals("Pass", StringComparison.InvariantCultureIgnoreCase); } }

        public string FailureDetail { get; set; }

        public string FailureReason { get; set; }

        public string ID { get; set; }

        public string Status { get; set; }
    }
}