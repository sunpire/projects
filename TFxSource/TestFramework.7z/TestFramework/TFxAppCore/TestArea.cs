//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: TestArea.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;
using System.Collections;
using System.Reflection;
using System.IO;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TestSuite.
	/// </summary>
	[Serializable]
	public class TestArea : TestInfo
	{
		System.Collections.Hashtable	tests;

		protected TestArea(string pathName, string testName) : base(pathName, testName) 
		{ 
		}
		public TestArea(string name) : base(name)
		{
		}

		public TestArea(string pathName, string testName,string owner):base(pathName, testName, owner)
		{
		}

		public TestArea(TestInfo parent, string pathName, string testName, string owner): base(parent,pathName, testName,owner)
		{
		}

		public System.Collections.Hashtable Tests
		{
			get
			{
				if (this.tests  == null)
				{
					this.tests = new System.Collections.Hashtable();
				}
				return this.tests;
			}
		}

		public ArrayList GetAllTestCases()
		{
			ArrayList al = new ArrayList();

			foreach (TestInfo ti in this.Tests.Values)
			{
				if ((ti.GetType() == typeof(TestArea) ||(ti.GetType().IsSubclassOf(typeof(TestArea)))))
				{
					al.AddRange(((TestArea)ti).GetAllTestCases());
				}
				else
				{
					al.Add(ti as TestCase);
				}
			}
			return al;
		}

		public override TestInfo FindTest(string fullPath)
		{
			int firstPart = fullPath.IndexOf(pathSeprator);
			if (firstPart > 0)
			{
				string firstPartName = fullPath.Substring(0, firstPart);
				TestArea tests = this.FindTestSuite(firstPartName);
				if(tests != null || this.Name == firstPartName)
				{
					int start = firstPart + 1;
					int remaingPathLength = fullPath.Length - start;
					string remainingPath = fullPath.Substring(start, remaingPathLength);
					if(tests == null)
					{
						return this.FindTest(remainingPath);
					}
					else
					{
						return tests.FindTest(remainingPath);
					}
				}
			}
			else if(firstPart < 0)
			{
				if(this.Tests.ContainsKey(fullPath))
				{
					return this.Tests[fullPath] as TestInfo;
				}
				return null;
			}
			return null; //incomplete test name //TODO should throw
		}

		public TestArea FindTestSuite(string name)
		{
			if(this.Tests.ContainsKey(name))
			{
				return this.Tests[name] as TestArea;
			}
			return null;
		}

		string CatString(string []parts, char join, int len)
		{
			string x=parts[0];
			for(int i=1; i <= len && i < parts.GetLength(0); i++)
			{
				x += join + parts[i];
			}
			return x;
		}

		public TestArea CreateFindTestSuite(string fullName)
		{
			if(fullName == null || fullName == string.Empty) return null;
			string[] name=fullName.Split('.');
			TestArea suite = null;
			for(int i=0; i < name.GetLength(0); i++)
			{
				if(suite == null)
				{
					suite = this.FindTestSuite( name[i] );
					if(suite == null)
					{
						if(this.Name == name[i])
						{
							suite = this;
						}
						else
						{
							suite = CreateTestArea(CatString(name, '.', i));
							this.Tests.Add( name[i], suite);
						}
					}
				}
				else
				{
					TestArea child =  suite.FindTest( name[i]) as TestArea;
					if(child == null)
					{
						child = CreateTestArea(CatString(name, '.', i));
						suite.Tests.Add(name[i], child);
					}
					suite = child;
				}
			}
			return suite;
		}

		public TestArea CreateTestArea(string areaName)
		{
			int i = areaName.LastIndexOf('.');
			if(i > 0)
			{
				string path="";
				string name=null;

				path = areaName.Substring(0, i);
				name = areaName.Substring(i+1, areaName.Length - i - 1);
				return new TestArea(path, name);
			}

			return new TestArea(areaName);
		}



		public override TestDiff Diff(TestInfo testInfoObject)
		{
			TestDiff diff = new TestDiff();
			if(testInfoObject is TestArea)
			{
				TestInfoCollection testCases1 = new TestInfoCollection(this.GetAllTestCases());
				TestInfoCollection testCases2 = new TestInfoCollection(((TestArea)testInfoObject).GetAllTestCases());
				diff.Differences.AddRange(this.GetDifferences(testCases1, testCases2).Differences);
			}
			else if (testInfoObject == null)
			{	
				TestInfoCollection testCases1 = new TestInfoCollection(this.GetAllTestCases());
				diff.Differences.AddRange(this.GetDifferences(testCases1, null).Differences);
			}
			else
			{
				throw new ArgumentException("Type mismatch: testInfoObject must be of type TestArea!");
			}

			return diff;
		}

		/// <summary>
		/// Applies a RepositoryChangelist to this TestArea. Note that currently, only TestCaseChange objects
		/// are supported.
		/// </summary>
		/// <param name="changes">List of changes to apply.</param>
		public void ApplyChange(RepositoryChangelist changes)
		{
			foreach(RepositoryRequest change in changes)
			{
				if(change is TestCaseChange)
				{
					this.ApplyChange((TestCaseChange)change);
				}
				else
				{
					throw new Exception("Only TestCaseChanges may be applied to a TestArea!");
				}
			}
		}
		
		/// <summary>
		/// Reverses a RepositoryChangelist applied to this TestArea. Note that currently,
		/// only TestCaseChange objects are supported.
		/// </summary>
		/// <param name="changes">List of changes to undo.</param>
		public void UndoChange(RepositoryChangelist changes)
		{
			foreach(RepositoryRequest change in changes)
			{
				if(change is TestCaseChange)
				{
					this.UndoChange((TestCaseChange)change);
				}
				else
				{
					throw new Exception("Only TestCaseChanges may be applied to a TestArea!");
				}
			}
		}
		
		/// <summary>
		/// Applies a test case repository change to this TestArea.
		/// </summary>
		/// <param name="change">The change to apply.</param>
		public void ApplyChange(TestCaseChange change)
		{
			switch(change.RequestType)
			{
				case RepositoryRequestType.Create:
				{
					// Check that the test case does not already exist
					if(this.FindTest(change.NewTestCase.FullName) == null)
					{
						TestArea parentArea = this.CreateFindTestSuite(change.NewTestCase.Path);
						parentArea.Tests.Add(change.NewTestCase.Name, change.NewTestCase);
					}
					else
					{
						throw new Exception(String.Format("Error executing create: Test case {0} already exists!", change.NewTestCase.FullName));
					}
					break;
				}
				case RepositoryRequestType.Delete:
				{
					TestArea parentArea = this.FindTest(change.OldTestCase.Path) as TestArea;
			
					// Check that the parent test area exists
					if(parentArea == null)
					{
						throw new Exception(String.Format("Error executing delete: Test area {0} does not exist!", change.OldTestCase.Path));
					}
					else
					{
						// Check that the test case exists
						if(parentArea.Tests.ContainsKey(change.OldTestCase.Name))
						{
							parentArea.Tests.Remove(change.OldTestCase.Name);
						}
						else
						{
							throw new Exception(String.Format("Error executing delete: Test case {0} does not exist!", change.OldTestCase.Name));
						}
					}
					break;
				}
				case RepositoryRequestType.Update:
				{
					TestArea sourceParentArea = this.FindTest(change.OldTestCase.Path) as TestArea;
			
					// Check that the source parent test area exists
					if(sourceParentArea == null)
					{
						throw new Exception(String.Format("Error executing update: Test area {0} does not exist!", change.OldTestCase.Path));
					}
					else
					{
						// Check that the source test case exists
						if(sourceParentArea.Tests.ContainsKey(change.OldTestCase.Name))
						{
							// Check that the destination case does not exist
							TestCase destCase = this.FindTest(change.NewTestCase.FullName) as TestCase;
//							if(destCase != null)
//							{
//								TestCaseDifference diff = new TestCaseDifference(change.NewTestCase, change.OldTestCase);
//								if(!(change.OldTestCase.FullName == change.NewTestCase.FullName &&
//									(diff.DifferenceType == TestCaseDifferenceType.CategoryDifference ||
//									 diff.DifferenceType == TestCaseDifferenceType.OwnerDifference) ))
//								{
//									throw new Exception(String.Format("Error executing update: Test case {0} already exists!", change.NewTestCase.FullName));
//								}
//							}

							// Create the destination parent test area
							TestArea destParentArea = this.CreateFindTestSuite(change.NewTestCase.Path);
					
							// Remove the source test case and add the destination test case
							sourceParentArea.Tests.Remove(change.OldTestCase.Name);
							destParentArea.Tests.Add(change.NewTestCase.Name, change.NewTestCase);
						}
						else
						{
							throw new Exception(String.Format("Error executing update: Test case {0} does not exist!", change.OldTestCase.FullName));
						}
					}
					break;
				}
				default:
					throw new Exception(String.Format("Error executing TestCaseChange: Unknown change type <{0}>", change.RequestType));
			}
		}

		/// <summary>
		/// Reverses the repository change applied to this TestArea.
		/// </summary>
		/// <param name="change">The change to undo.</param>
		public void UndoChange(TestCaseChange change)
		{
			switch(change.RequestType)
			{
				case RepositoryRequestType.Create:
				{
					this.ApplyChange(new TestCaseChange(RepositoryRequestType.Delete, change.OldTestCase));
					break;
				}
				case RepositoryRequestType.Delete:
				{
					this.ApplyChange(new TestCaseChange(RepositoryRequestType.Create, change.NewTestCase));
					break;
				}
				case RepositoryRequestType.Update:
				{
					this.ApplyChange(new TestCaseChange(change.NewTestCase, change.OldTestCase));
					break;
				}
				default:
					throw new Exception(String.Format("Error executing TestCaseChange: Unknown change type <{0}>", change.RequestType));
			}
		}
	}
}
