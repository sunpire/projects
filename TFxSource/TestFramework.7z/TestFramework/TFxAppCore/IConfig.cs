//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: IConfig.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;
using System.Collections;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TestConfig.
	/// </summary>
	public interface IConfig
	{
		string Name { get; }
        string this[string varName]
        {
            get;
            set;
        } 
		bool IsDefined(string name);

		//for logging and debug 
		ICollection ListNames();

	}
/*
	public interface ITypedConfig : IConfig
	{
		/// <summary>
		/// Parses value as TimeSpan
		/// </summary>
		/// <param name="varName">Variable to look for</param>
		/// <returns>TimeSpan</returns>
		/// <exception cref="FormatException"></exception>
		TimeSpan GetTimeSpan(string varName);

		/// <summary>
		/// Parses value as integer
		/// </summary>
		/// <param name="varName">Variable to look for</param>
		/// <returns>returns integer</returns>
		/// <exception cref="FormatException"></exception>
		int		 GetInteger(string varName);
	}
	
*/
}
