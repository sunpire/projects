//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: UserAlreadyExistsException.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;
using Expedia.Test.Framework;
namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for UserAlreadyExistsException.
	/// </summary>
	public class UserAlreadyExistsException : System.Exception
	{
		public UserAlreadyExistsException(string message): base(message)
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
