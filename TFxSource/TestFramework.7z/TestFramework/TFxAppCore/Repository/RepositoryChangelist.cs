//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: RepositoryChangelist.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//==========================================================================
using System;
using System.Collections;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for RepositoryChangelist.
	/// </summary>
	public class RepositoryChangelist : IList
	{
		ArrayList m_changes;

		public RepositoryChangelist()
		{
			m_changes = new ArrayList();
		}

		#region IListProperties

		public bool IsReadOnly
		{
			get
			{
				return m_changes.IsReadOnly; 
			}
		}

		bool IList.IsReadOnly
		{
			get
			{
				return m_changes.IsReadOnly;		
			}
		}
		
		bool IList.IsFixedSize
		{
			get
			{
				return m_changes.IsFixedSize;
			}
		}

		public bool IsFixedSize
		{
			get
			{
				return m_changes.IsFixedSize; 
			}
		}

		public RepositoryRequest this[int index]
		{
			get
			{
				return (RepositoryRequest)m_changes[index];
			}
			set
			{
				if(value != null)
				{
					m_changes[index]=value;
				}
				
				throw new ArgumentNullException("value","Collection does not accept null changes"); 
				
			}
		}

		object IList.this[int index]
		{
			get
			{
				return (RepositoryRequest)m_changes[index];		
			}
			set
			{
				if(value != null)
				{
					RepositoryRequest change=value as RepositoryRequest;
					if(change==null)
					{	
						throw new ArgumentException("Collection member must be of type RepositoryChange","value"); 					}
					else
					{
						m_changes[index]=change;
					}
				}
				else
				{
					throw new ArgumentNullException("value","Collection does not accept null changes");
				}
				
			}
		}
		#endregion

		#region IList Methods

		int IList.Add(object obj)
		{
			if(obj.GetType() != typeof(RepositoryRequest))
			{
				throw new ArgumentException("Collection member must be of type RepositoryChange","value"); 
				
			}
			else
			{
				
				return m_changes.Add((RepositoryRequest)obj);
			}

					
		}

		public int Add(RepositoryRequest change)
		{
			return m_changes.Add((object)change);
		}

		void IList.Clear()
		{
			m_changes.Clear(); 
		}

		public void Clear()
		{
			m_changes.Clear(); 
		}

		
		bool IList.Contains(object value)
		{
			if(value==null)
			{
				return false;
			}

			RepositoryRequest change=value as RepositoryRequest;
			if(change==null)
			{
				return false;
			}

			return m_changes.Contains(change);
		}

		public bool Contains(RepositoryRequest value)
		{
			if(value==null)
			{
				return false;
			}

			return m_changes.Contains(value); 
		}

		int IList.IndexOf(object value)
		{
			if(value==null)
			{
				return -1;
			}

			RepositoryRequest change=value as RepositoryRequest;
			if(change==null)
			{
				return -1;
			}

			return m_changes.IndexOf(value);

		}

		public int IndexOf(RepositoryRequest value)
		{
			if(value==null)
			{
				return -1;
			}

			return m_changes.IndexOf(value); 
		}

		void IList.Insert(int index, object value)
		{
			if(value==null)
			{
				throw new ArgumentNullException("value","Collection does not accept null changes");
			}

			RepositoryRequest change=value as RepositoryRequest;
			if(change==null)
			{
				throw new ArgumentException("Collection member must be of type RepositoryChange","value"); 
			}
				
			m_changes.Insert(index,change);
			
		}

		public void Insert(int index,RepositoryRequest value)
		{
			if(value==null)
			{
				throw new ArgumentNullException("value","Collection does not accept null changes");
			}

			m_changes.Insert(index,value); 		
		}

		void IList.RemoveAt(int index)
		{
			m_changes.RemoveAt(index);
		}

		public void RemoveAt(int index)
		{
			m_changes.RemoveAt(index); 	
		}

		void IList.Remove(object value)
		{
			if(value==null)
			{
				throw new ArgumentNullException("value","You cannot remove collection member using null reference"); 
			}

			RepositoryRequest p=value as RepositoryRequest;
			if(p==null)
			{
				throw new ArgumentNullException("value","You can remove only an object of type Person"); 
			}

			m_changes.Remove(value); 
		}

		public void Remove(RepositoryRequest value)
		{
			if(value==null)
			{
				throw new ArgumentNullException("value","You cannot remove collection member using null reference"); 
			}
			m_changes.Remove(value); 
		}
		#endregion

		#region ICollection Members

		public bool IsSynchronized
		{
			get
			{
				return this.m_changes.IsSynchronized;
			}
		}

		public object SyncRoot
		{
			get
			{
				return this.m_changes.SyncRoot;
			}
		}

		public int Count
		{
			get
			{
				return this.m_changes.Count;
			}
		}

		public void CopyTo(Array array, int index)
		{
			m_changes.CopyTo(array,index); 
		}

		#endregion

		#region IEnumerable Members
		
		public IEnumerator GetEnumerator()
		{
			return m_changes.GetEnumerator(); 
		}

		#endregion
	}
}
