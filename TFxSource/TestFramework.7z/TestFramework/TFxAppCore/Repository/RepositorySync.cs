using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for RepositorySync.
	/// </summary>
    public class RepositorySync : RepositoryRequest
    {
        public Repository RightRepository = null;

        public RepositorySync(RepositoryRequestType requestType)
            : base(requestType)
        {
        }
    }
}
