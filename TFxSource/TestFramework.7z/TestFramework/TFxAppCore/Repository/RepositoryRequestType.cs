using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for RepositoryRequestType.
	/// </summary>
	public enum RepositoryRequestType
	{
		/// <summary>
		/// 
		/// </summary>
		Get,
		
		/// <summary>
		/// Sync to destination repository only (left to right)
		/// </summary>
		Sync_Echo,

		/// <summary>
		/// Fully Syncronize object in both repositories
		/// </summary>
		Sync_Both,

		/// <summary>
		/// Sync to current repository only (right to left)
		/// </summary>
		Sync_Subscribe,

		/// <summary>
		/// 
		/// </summary>
		Create,
		
		/// <summary>
		/// 
		/// </summary>
		Update,
		
		/// <summary>
		/// 
		/// </summary>
		Delete,
		
	}
}
