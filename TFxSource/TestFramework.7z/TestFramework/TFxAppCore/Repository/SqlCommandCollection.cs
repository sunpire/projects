using System;
using System.Text;
using System.Collections;
using System.Data.SqlClient;

namespace Expedia.Test.Framework
{

	/// <summary>
	/// Summary description for SqlCommandCollection.
	/// </summary>
	public class SqlCommandCollection : IList, IDisposable
	{
		private ArrayList m_SqlCommandsList;
		private ArrayList m_SqlCommandTextList;
				
		public SqlCommandCollection()
		{
			this.m_SqlCommandsList = new ArrayList();
			this.m_SqlCommandTextList = new ArrayList();
		}

		public SqlCommand GetSqlComplexCommand()
		{
			if (m_SqlCommandTextList.Count != m_SqlCommandsList.Count)
			{
				BuildSqlCommand(true);
			}

			string [] commandList = (string []) m_SqlCommandTextList.ToArray(typeof(string));

			SqlCommand complexSqlCommand = new SqlCommand();
			complexSqlCommand.CommandText = string.Join(";", commandList);
			
			
			return complexSqlCommand;
		}

		private void BuildSqlCommand(bool rebuild)
		{
			if (rebuild)
			{
				m_SqlCommandTextList.Clear();
			}

			for (int i=0; i < m_SqlCommandsList.Count; i++)
			{
				AppendSqlCommand(m_SqlCommandsList[i] as SqlCommand);
			}
		}


		private string ReplaceSpeicalCharacters(string input)
		{
			string output = input;

			if (input != null)
			{
				output = output.Replace("'", "''");
				output = output.Replace("\"", "\\\"");
			}


			return output;
		}


		private void AppendSqlCommand(SqlCommand cmd)
		{

			if (cmd !=null)
			{			
				switch(cmd.CommandType)
				{
					case System.Data.CommandType.StoredProcedure:
						string spCommand = null;
						foreach (SqlParameter parm in cmd.Parameters)
						{
							if (spCommand !=null)
							{
								spCommand += ",";
							}

							spCommand += " '" + ReplaceSpeicalCharacters(parm.Value.ToString())  + "'";
						}

						spCommand = "exec " + cmd.CommandText + " " + spCommand;
						m_SqlCommandTextList.Add(spCommand);
						break;
					case System.Data.CommandType.Text:
						string textCommand = null;
						foreach (SqlParameter parm in cmd.Parameters)
						{
							if (textCommand !=null)
							{
								textCommand += ",";
							}

							textCommand += parm.ParameterName + "='" + ReplaceSpeicalCharacters(parm.Value.ToString()) + "' ";

						}

						textCommand = string.Format(cmd.CommandText + " " + textCommand);
						m_SqlCommandTextList.Add(textCommand);
						break;

					default:
						break;
				}
			}
		}

		public void Dispose()
		{
			m_SqlCommandsList.Clear();
			m_SqlCommandTextList.Clear();
		}


		public bool IsReadOnly
		{
			get
			{
				return m_SqlCommandsList.IsReadOnly; 
			}
		}

		bool IList.IsReadOnly
		{
			get
			{
				return m_SqlCommandsList.IsReadOnly;		
			}
		}
		
		bool IList.IsFixedSize
		{
			get
			{
				return m_SqlCommandsList.IsFixedSize;
			}
		}

		public bool IsFixedSize
		{
			get
			{
				return m_SqlCommandsList.IsFixedSize; 
			}
		}

		public SqlCommand this[int index]
		{
			get
			{
				return (SqlCommand)m_SqlCommandsList[index];
			}
			set
			{
				if(value != null)
				{
					m_SqlCommandsList[index]=value;
				}
				
				throw new ArgumentNullException("value","Collection does not accept null members"); 
				
			}
		}

		object IList.this[int index]
		{
			get
			{
				return (SqlCommand)m_SqlCommandsList[index];		
			}
			set
			{
				if(value != null)
				{
					SqlCommand member=value as SqlCommand;
					if(member==null)
					{	
						throw new ArgumentException("Collection member must be of type TeamMember","value"); 					}
					else
					{
						m_SqlCommandsList[index]=member;
					}
				}
				else
				{
					throw new ArgumentNullException("value","Collection does not accept null members");
				}
				
			}
		}
	

	

		int IList.Add(object obj)
		{
			if(obj.GetType() != typeof(SqlCommand))
			{
				throw new ArgumentException("Collection member must be of type TeamMember","value"); 
				
			}
			else
			{
				int result = m_SqlCommandsList.Add((SqlCommand)obj);
				AppendSqlCommand((SqlCommand)obj);
				return result;
			}

					
		}

		public int Add(SqlCommand member)
		{
			int result = m_SqlCommandsList.Add((object)member);
			AppendSqlCommand(member);
			return result;
		}

		void IList.Clear()
		{
			m_SqlCommandsList.Clear(); 
			m_SqlCommandTextList.Clear();
		}

		public void Clear()
		{
			m_SqlCommandsList.Clear(); 
			m_SqlCommandTextList.Clear();
		}

		
		bool IList.Contains(object value)
		{
			if(value==null)
			{
				return false;
			}

			SqlCommand member=value as SqlCommand;
			if(member==null)
			{
				return false;
			}

			return m_SqlCommandsList.Contains(member);
		}

		public bool Contains(SqlCommand value)
		{
			if(value==null)
			{
				return false;
			}

			return m_SqlCommandsList.Contains(value); 
		}

		int IList.IndexOf(object value)
		{
			if(value==null)
			{
				return -1;
			}

			SqlCommand member=value as SqlCommand;
			if(member==null)
			{
				return -1;
			}

			return m_SqlCommandsList.IndexOf(value);

		}

		public int IndexOf(SqlCommand value)
		{
			int index = 0;

			if(value==null)
			{
				return -1;
			}
			
			foreach(SqlCommand tm in this.m_SqlCommandsList)
			{
				index++;

				if(tm != null)
				{					
					if(String.Compare(tm.CommandText, value.CommandText) == 0)
					{
						return index;
					}					
										
				}
			}

			return -1; 
		}

		void IList.Insert(int index, object value)
		{
			if(value==null)
			{
				throw new ArgumentNullException("value","Collection does not accept null members");
			}

			SqlCommand member=value as SqlCommand;
			if(member==null)
			{
				throw new ArgumentException("Collection member must be of type TeamMember","value"); 
			}
				
			m_SqlCommandsList.Insert(index,member);
			BuildSqlCommand(true);
			
		}

		public void Insert(int index,SqlCommand value)
		{
			if(value==null)
			{
				throw new ArgumentNullException("value","Collection does not accept null members");
			}

			m_SqlCommandsList.Insert(index,value); 	
			BuildSqlCommand(true);
		}

		void IList.RemoveAt(int index)
		{
			m_SqlCommandsList.RemoveAt(index);
			BuildSqlCommand(true);
		}

		public void RemoveAt(int index)
		{
			m_SqlCommandsList.RemoveAt(index); 	
			BuildSqlCommand(true);
		}

		void IList.Remove(object value)
		{
			if(value==null)
			{
				throw new ArgumentNullException("value","You cannot remove collection member using null reference"); 
			}

			SqlCommand p=value as SqlCommand;
			if(p==null)
			{
				throw new ArgumentNullException("value","You can remove only an object of type Person"); 
			}

			m_SqlCommandsList.Remove(value); 
			BuildSqlCommand(true);
		}

		public void Remove(SqlCommand value)
		{
			if(value==null)
			{
				throw new ArgumentNullException("value","You cannot remove collection member using null reference"); 
			}
			m_SqlCommandsList.Remove(value); 
			BuildSqlCommand(true);
		}
	

		

		public bool IsSynchronized
		{
			get
			{
				return this.m_SqlCommandsList.IsSynchronized;
			}
		}

		public object SyncRoot
		{
			get
			{
				return this.m_SqlCommandsList.SyncRoot;
			}
		}

		public int Count
		{
			get
			{
				return this.m_SqlCommandsList.Count;
			}
		}

		public void CopyTo(Array array, int index)
		{
			m_SqlCommandsList.CopyTo(array,index); 
		}

			
		
		public IEnumerator GetEnumerator()
		{
			return m_SqlCommandsList.GetEnumerator(); 
		}		

	}
}

