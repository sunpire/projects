//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: RepositoryChangeType.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//==========================================================================
using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for RepositoryChangeType.
	/// </summary>
	public enum RepositoryChangeType
	{
		Create=1,
		Update=2,
		Delete=4
	}
}
