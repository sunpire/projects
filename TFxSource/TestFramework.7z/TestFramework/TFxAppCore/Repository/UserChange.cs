//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: UserChange.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;

namespace Expedia.Test.Framework
{

	/// <summary>
	/// Summary description for UserChange.
	/// </summary>
	/// <example>Create User with all user info </example>
	/// <example>Delete User with all user info </example>
	/// <example>Update User's manager </example> 
	public class UserChange : RepositoryRequest
	{
		public object User;

		public UserChange(RepositoryRequestType type, object user) : base(type)
		{
			this.User = user;
		}

		public override string ToString()
		{
			return string.Format("{0} {1}", base.ToString(), "this.User.Name");
			
		}
	}
}
