using System;
using System.Collections;
namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for MultiRepository.
	/// </summary>
	public class MultiRepository : Repository
	{
		protected Repository []m_respositories;

		public MultiRepository(Repository [] repositories)
		{
			this.m_respositories = repositories;
		}

		public override bool IsSupportedRequest(Expedia.Test.Framework.RepositoryRequest request)
		{
			if(base.IsSupportedRequest(request))
			{
				return true;
			}
			foreach(Repository rep in m_respositories)
			{
				if(rep.IsSupportedRequest(request))
				{
					return true;
				}
			}
			return false;
		}

		public override void ExecuteRequest(Expedia.Test.Framework.RepositoryRequest request)
		{
			if(base.IsSupportedRequest(request))
			{
				base.ExecuteRequest(request);
				return;
			}

			foreach(Repository rep in m_respositories)
			{
				if(rep.IsSupportedRequest(request))
				{
					rep.ExecuteRequest(request);
					return;
				}
			}
			//TODO: create new exception type
			throw new ApplicationException("Request not supported in this repository");
		}
	}
}
