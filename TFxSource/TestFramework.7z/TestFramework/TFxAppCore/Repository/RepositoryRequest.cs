//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: RepositoryRequest.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//==========================================================================
using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for RepositoryRequest.
	/// </summary>
	public abstract class RepositoryRequest 
	{
		RepositoryRequestType m_requestType;
		private string m_message = null;

		public RepositoryRequestType RequestType
		{
			get
			{
				return m_requestType;
			}
		}

		public RepositoryRequest(RepositoryRequestType type)
		{
			m_requestType = type;
		}

		public string Message
		{
			get
			{
				return m_message;
			}
			set
			{
				m_message = value;
			}
		}
	}
}
