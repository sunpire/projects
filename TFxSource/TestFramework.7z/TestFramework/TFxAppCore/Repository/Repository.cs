//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: Repository.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//==========================================================================
using System;
using System.Reflection;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for Repository.
	/// </summary>
	public abstract class Repository
	{
		public Repository()
		{
		}

		//TODO: we can cache this info to increase speed
		MethodInfo GetMethod(string name, Type paramType)
		{
			MethodInfo []mi = this.GetType().GetMethods(BindingFlags.Public|BindingFlags.Instance);
			foreach(MethodInfo m in mi)
			{
				if(m.Name == name)
				{
					ParameterInfo []pis = m.GetParameters();
					if(pis.GetLength(0) >= 1)
					{
						if(paramType == pis[0].ParameterType || paramType.IsSubclassOf(pis[0].ParameterType))
						{
							return m;
						}
					}
				}
			}
			return null;
		}

		const string c_ProcessRequestMethodName = "ProcessRequest";
		
		public virtual void ExecuteRequest(RepositoryRequest request)
		{
			MethodInfo mi = GetMethod(c_ProcessRequestMethodName, request.GetType());
			if (mi != null)
			{
                try
                {
                    mi.Invoke(this, new object[] { request });
                }
                catch (Exception e)
                {
                    throw new Exception(e.InnerException.ToString(),e);
                }
			}
		}

		public virtual bool IsSupportedRequest(RepositoryRequest request)
		{
			MethodInfo mi = GetMethod(c_ProcessRequestMethodName, request.GetType());
			return (mi != null);
		}

	
		public virtual void ApplyChange(RepositoryChangelist changes)
		{
			try
			{
				StartTransaction();
				foreach(RepositoryRequest change in changes)
				{
					ExecuteRequest(change);
				}
				CompleteTransaction();
			}
			catch(Exception)
			{
				AbortTransaction();
				return;
			}
		}

		public virtual void StartTransaction()
		{
		}

		public virtual void CompleteTransaction()
		{
		}

		public virtual void AbortTransaction()
		{
		}
	}
}
