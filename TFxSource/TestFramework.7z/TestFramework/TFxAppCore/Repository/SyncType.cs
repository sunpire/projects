using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for SyncType.
	/// </summary>
	public enum SyncType
	{
		/// <summary>
		/// New and updated objects are copied both ways. 
		/// </summary>
		Synchronize=1,

		/// <summary>
		///  New and updated objects are copied into to right. 
		///  deletes from left are deleted from rigt
		///  Renames on the left are deleted from right and added again with correct name unless marked to rename. 
		/// </summary>
		Echo,
	
		/// <summary>
		/// Updated objects on the right are copied to the left if the objects name already exists on the left. 
	    /// </summary>
		Subscribe,

		/// <summary>
		///  New and updated objects are copied left to right. Renames on the left are repeated on the right. No deletions. 
		/// </summary>
		Contribute,

		/// <summary>
		/// New and updated objects are copied both ways. Nothing happens to renamed and deleted objects.  
		/// </summary>
		Combine
	}
}
