//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: TFxTestArea.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;
using System.Collections;
using Expedia.Test.Framework;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TFxTestArea.
	/// </summary>
	[Serializable]
	public class TFxTestArea: TestArea
	{


		private int m_areaid;


		public int AreaId
		{
			get
			{
				return m_areaid;
			}
			set
			{
				m_areaid = value;
			}
		}


		private TFxUser m_owner;


		//Need to delete it in the future to use the getOwner Function
		public TFxUser TestOwner
		{
			get 
			{ 
				return m_owner; 
			}
			set
			{
				this.m_owner = value;
			}
		}

		private TFxTestArea m_parentTestArea;
		//Need to delete it in the future to use the getOwner Function
		public TFxTestArea ParentArea
		{
			get
			{
				return m_parentTestArea;
			}
			set
			{
				m_parentTestArea = value;
			}
		}
			
		private ArrayList m_config;

		public ArrayList Config
		{
			get
			{
				if (m_config == null)
				{
					m_config = new ArrayList();
					Hashtable ht = new Hashtable();
					m_config.Add(ht);

				}
				return m_config;
			}	

			set
			{
				m_config = value;
			}

		}

		public override string ToString()
		{
			return Name;
		}


		protected TFxTestArea(string pathName, string testName) : base(pathName, testName) 
		{ 
		}

		public TFxTestArea(string name) : base(name)
		{
		}

		public TFxTestArea(TFxTestArea parent, string pathName, string areaName, int areaid, string owner): base(pathName, areaName)
		{
			//
			// TODO: Add constructor logic here
			//

			m_areaid = areaid;
			m_parentTestArea = parent;
			m_owner = new TFxUser();
			m_owner.Name = owner;

		}
	}
}
