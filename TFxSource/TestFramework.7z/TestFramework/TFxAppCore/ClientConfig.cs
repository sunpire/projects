//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: ClientConfig.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;
using System.Collections;
using System.Xml;

namespace Expedia.Test.Framework.Config
{
	/// <summary>
	/// Summary description for Configs.
	/// </summary>
	public class ClientConfig
	{
		
		
		Hashtable m_configs = new Hashtable();

		public const string defaultConfigName = "default";

		public ClientConfig()
		{
			
		}

		public XmlConfig GetConfig(string name)
		{
			if (m_configs.Contains(name))
				return m_configs[name] as XmlConfig;
			else
				return null;

		}

		public Hashtable AllConfigs
		{
			get
			{
				return m_configs;
			}
		}


		public void Load(string filename)
		{


			XmlReader reader = null;
			
			try
			{
				reader = new XmlTextReader(filename);
			
				while(reader.Read())
				{
					if(reader.NodeType == XmlNodeType.Element && reader.Name == "config")
					{
						string systemMachineName = System.Environment.MachineName;
						string configMachineName = reader.GetAttribute("machinename");
						string configName = reader.GetAttribute("configname");

						if (configName == null || configName == "")
							configName = ClientConfig.defaultConfigName;
											


						// only load configs specified for the current machine
						if (configMachineName == string.Empty ||
							configMachineName == null ||
							string.Compare(systemMachineName, configMachineName, true)==0)
						{
							XmlConfig config = new XmlConfig(reader);
							m_configs.Add(configName, config);
						}
					}
				}
			}
			finally 
			{
				if (reader !=null)
				{
					reader.Close();
				}
			}
		}

	}
}
