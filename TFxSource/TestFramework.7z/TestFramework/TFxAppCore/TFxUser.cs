//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: TeamMember.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;
using System.Collections;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TeamMember.
    /// Comments:	Changed UserId from Int to GUID
	/// </summary>
	[Serializable]
	public class TFxUser
	{
		string name;
		protected Guid gid = Guid.Empty;
        protected int id = -1;
		TFxUser m_manager;
		bool m_isManager;
        int m_concurrencysize;
		
		string m_machineName;
		string m_userName;
		string m_processId;

        public int concurrencysize
        {
            get
            {
                return m_concurrencysize;
            }
            set
            {
                m_concurrencysize = value;
            }
        }

		public string MachineName
		{
			get 
			{
				return m_machineName;
			}
			set
			{
				m_machineName = value;
			}
		}

		public string UserName
		{
			get 
			{
				return m_userName;
			}
			set
			{
				m_userName = value;
			}
		}

		public string ProcessId
		{
			get 
			{
				return m_processId;
			}
			set
			{
				m_processId = value;
			}
		}


		public override string ToString()
		{
            if (this.Manager != null)
            {
                return name;// +"(" + this.Manager.userid + ")"; In the usermanager, aren't the only ones that are shown the ones with no manager?..
            }

            return name;
               
          
			
		}

		public virtual Guid usergid
		{
			get
			{
                return gid;
			}
			set
			{
                this.gid = value;
			}
		}

        public virtual int userid
        {
            get
            {
                return id;
            }
            set
            {
                this.id = value;
            }
        }

		public string Name
		{
			get
			{
				return name;
			}
			set
			{
				name = value;
			}
		}

		public bool IsManager
		{
			get
			{
				return m_isManager;
			}
			set
			{
				m_isManager = value;
			}
		}

		public TFxUser Manager
		{
			get
			{
				return m_manager;
			}
			set
			{
				m_manager = value;
			}
		}

		DateTime m_lastTalkTime;

		public DateTime LastTalkTime
		{
			get
			{
				return m_lastTalkTime;

			}
			set
			{
				m_lastTalkTime = value;

			}
		}


		public TFxUser()
		{
		}

	}
}
