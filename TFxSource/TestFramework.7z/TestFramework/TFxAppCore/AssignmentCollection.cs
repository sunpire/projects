using System;
using System.Collections;
using System.Collections.Generic;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Wrapper for a List of Assignments.
    /// </summary>
    [Serializable]
    public class AssignmentCollection : List<Assignment>, ICloneable
    {
        public AssignmentCollection()
        {
        }

        public AssignmentCollection(IEnumerable<Assignment> collection)
            : base(collection)
        {
        }

        /// <summary>
        /// Creates a new object that is a copy of the current instance.
        /// </summary>
        /// <returns>A new object that is a copy of this instance.</returns>   
        public object Clone()
        {
            AssignmentCollection newCollection = new AssignmentCollection();

            foreach (Assignment assignment in this)
            {
                newCollection.Add(assignment.Clone() as Assignment);
            }

            return newCollection;
        }

        public void UpdateAssignments(bool changed)
        {
            this.ForEach(assignment => assignment.Changed = changed);
        }
    }
}
