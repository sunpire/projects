//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: XmlConfig.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;
using System.Xml;
using System.IO;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ClientConfig.
	/// </summary>
	[Serializable]
	public class XmlConfig : StringConfig
	{
		string m_configName;
		string m_machineName;

		public string ConfigName
		{
			get
			{
				return m_configName;
			}

		}

		public string MachineName
		{
			get
			{
				return m_machineName;
			}

		}

		public XmlConfig(XmlReader reader)
		{
			Load(reader);
		}
		
		void Load(XmlReader reader)
		{
			m_configName = reader["configname"];
			m_machineName = reader.GetAttribute("machinename");

			while(reader.Read() && reader.NodeType != XmlNodeType.EndElement)
			{
				if(reader.NodeType == XmlNodeType.Element && reader.Name == "var")
				{
					if(reader["name"] != null && reader["value"] != null)
					{
						this[reader["name"]] = reader["value"];
					}
					else
					{
						throw new ApplicationException("Configration format error");
					}
				}
			}
		}


	}
}
