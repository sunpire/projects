using System;
using System.IO;
using System.Xml.Serialization;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for ExecutingTestModule.
    /// </summary>

    [Serializable]
    public class ExecuteTestModule : TestBuildModule
    {
        string m_installedFolder;

        public ExecuteTestModule()
        {
            InstalledFolder = "";
        }

        public ExecuteTestModule(string fullPath)
            : base()
        {
            ParseFullName(fullPath);
        }

        public ExecuteTestModule(string installedfolder, string path)
            : base()
        {
            InstalledFolder = installedfolder;
            this.Name = path;
        }

        public override string DllFullName
        {
            get
            {
                return Path.Combine(InstalledFolder, base.DllFullName);
            }
        }

        public string InstalledFolder
        {
            get
            {
                return m_installedFolder;
            }
            set
            {
                m_installedFolder = value;
            }
        }

        void ParseFullName(string fullPath)
        {
            try
            {
                FileInfo info = new FileInfo(fullPath);

                this.InstalledFolder = info.Directory.FullName;
                this.ModuleFolder = null;
                this.Name = info.Name;
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e);
            }
        }
    }
}
