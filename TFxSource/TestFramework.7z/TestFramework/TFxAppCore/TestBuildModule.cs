using System;
using System.Diagnostics;
using System.IO;
using System.Xml.Serialization;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Contains all necessory information to install a module from build
    /// Comments:   Changed ModuleId to ModuleGid type GUID
    /// </summary>
    [Serializable]
    [XmlInclude(typeof(ExecuteTestModule))]
    public class TestBuildModule
    {
        public Guid ModuleGuid { get; set; }

        public string Name { get; set; }

        public string BuildName { get; set;}

        public string ModuleFolder { get; set; }

        public virtual string DllFullName
        {
            get
            {
                return Path.Combine(
                    this.ModuleFolder ?? string.Empty, 
                    this.Name ?? string.Empty);
            }
        }

        public TestBuildModule()
        {
            this.Name = string.Empty;
            this.BuildName = string.Empty;
            this.ModuleFolder = string.Empty;
        }

    }
}