//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: StringConfig.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;
using System.Collections;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for StringConfig.
	/// </summary>
	[Serializable]
	public class StringConfig : IConfig
	{
		Hashtable m_config;
		string	  m_name;

		public StringConfig()
		{
		}

		public Hashtable Config
		{
			get
			{
				if(m_config == null)
				{
					m_config = new Hashtable(StringComparer.Create(System.Globalization.CultureInfo.CurrentCulture, true));
				}
				return m_config;
			}
		}


		public void Add(object key, object value)
		{
			Config.Add(key,value);
		}

		public string Name
		{
			set { m_name = value; }
			get { return m_name; }
		}

		public bool IsDefined(string varName)
		{
			return Config.ContainsKey(varName);			
		}

		public string this[string varName]
		{
			get
			{
				return Config[varName] as string;		
			}
			set
			{
				if(IsDefined(varName))
				{
					Config[varName] = value;
				}
				else
				{
					Config.Add(varName, value);
				}
			}
		}

		public ICollection ListNames()
		{
			return this.Config.Keys;
		}
	}
}
