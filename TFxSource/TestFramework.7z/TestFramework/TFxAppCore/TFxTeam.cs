using System.Collections.Generic;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for TFxTeam.
    /// </summary>
    public class TFxTeam
    {

        public TFxUser Manager;
        public ClientCollection Clients;
        //private Logger m_logger;

        //public TFxTeam(Logger logger)
        //{
        //    //
        //    // TODO: Add constructor logic here
        //    //
        //    m_logger = logger;

        //}

        public TFxTeam()
        {

        }

        //void WriteLog(LogLevelType type, string message)
        //{
        //    if (m_logger !=null)
        //    {
        //        m_logger.Write(type, message);
        //    }
        //}

        public int GetAvailability()
        {
            int i = 0;

            for (int j = 0; j < Clients.Count; j++)
            {
                Client cli = Clients[j];

                if (cli.Available)
                {
                    i = i + cli.GetAvailability();
                }
            }

            return i;
        }

        Client GetNextClientToRunAssignment()
        {
            Client cl = null;
            int availability = 0;
            foreach (Client client in Clients)
            {
                if (cl == null)
                {
                    cl = client;
                    availability = client.GetAvailability();
                }
                else
                {
                    int currAvail = client.GetAvailability();
                    if (availability < currAvail)
                    {
                        cl = client;
                        availability = currAvail;
                    }
                }
            }

            if (availability <= 0)
            {
                cl = null;
            }

            return cl;
        }

        /// <summary>
        /// Comments:	Changed UserId from Int to GUID
        /// </summary>
        /// <param name="col"></param>
        /// <returns></returns>
        public int RunAssignment(List<Assignment> assignments)
        {
            int assigned = 0;

            foreach (Assignment assignment in assignments)
            {
                Client client = GetNextClientToRunAssignment();
                if (client == null)
                {
                    return assigned;
                }
                else
                {
                    assignment.AssignedTo = client.Tester;
                    //WriteLog(LogLevelType.TFxClient, string.Format("Assignment id= {0} is assigned to {1}", col[i].AssignmentId, client.Name));
                    client.RunAssignment(assignment);
                }
            }

            return assigned;
        }
    }
}
