using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;

namespace Expedia.Test.Framework
{
    public enum ExecutionManagerState
    {
        Start = 0,
        Assigning,
        WaitAssignmentComplete,
        WaitForGroupComplete,		// these two states will be use when implementing Groups
        GroupComplete,
        WaitForTestRunComplete, //equvlint to WaitForlastGrouptocomplete
        TestRunComplete,
        TestRunStop
    }

    //Create the Event Handler
    public delegate void ExecutionManagerLabRunHandler(LabRun run);

    //public delegate void LabRunEventHandler(TestRun labRun);

    /// <summary>
    /// Summary description for ExecutionManager.
    /// </summary>
    [Serializable]
    public class ExecutionManager
    {
        ExecutionManagerState m_state = ExecutionManagerState.Start;
        TFxTeam m_team;
        public LabRun ExecutingLabRun;
        int m_currentGroupIndex;

        public event ExecutionManagerLabRunHandler WaitForTestRunComplete;
        public event ExecutionManagerLabRunHandler TestRunComplete;

        public AutoResetEvent ProcessEvents = new AutoResetEvent(false);
        public bool ContinueProcess = true;

        private DateTime m_stateChangeTime;

        public DateTime StateChangeTime
        {
            get { return m_stateChangeTime; }
            private set { m_stateChangeTime = value; }
        }

        public ExecutionManagerState State
        {
            get
            {
                return m_state;
            }
            private set
            {
                StateChangeTime = DateTime.Now;
                m_state = value;
                NotifyStateChange();
            }
        }


        public bool IsWaiting()
        {
            return (m_state == ExecutionManagerState.WaitForTestRunComplete
                    || m_state == ExecutionManagerState.TestRunComplete
                    || ((m_state == ExecutionManagerState.WaitForGroupComplete || m_state == ExecutionManagerState.GroupComplete)
                        && !IsThereAnyAssignmentGroupToBeRun()));
        }

        void AssignAssignments()
        {
            lock (m_team)
            {
                int avail = m_team.GetAvailability();

                List<Assignment> assigningCollection = GetUnassignedAssignments(avail);

                if (assigningCollection.Count > 0)
                {
                    m_team.RunAssignment(assigningCollection);
                }
            }
        }

        AssignmentCollection GetUnassignedAssignments(int j)
        {
            AssignmentCollection unassignedAssignments = new AssignmentCollection();
            AssignmentCollection cur = ExecutingLabRun.AssignmentsGroup[m_currentGroupIndex];

            for (int i = 0; i < cur.Count; i++)
            {
                Assignment assignment = cur[i];

                if (unassignedAssignments.Count == j)
                {
                    return unassignedAssignments;
                }

                if (IsUnAssigned(assignment))
                {
                    unassignedAssignments.Add(assignment);
                }
            }

            return unassignedAssignments;
        }

        bool IsUnAssigned(Assignment assignment)
        {
            if (assignment.AssignedTo == null || assignment.AssignedTo.Name == ExecutingLabRun.Manager.Name) // it is assigning the manager
            {
                return true;
            }
            return false;
        }

        bool IsThereAnyAssignmentLeftToBeAssigned()
        {
            AssignmentCollection cur = ExecutingLabRun.AssignmentsGroup[m_currentGroupIndex];

            return cur.Exists(a => IsUnAssigned(a));
        }

        public List<Assignment> GetPendingAssignments()
        {
            List<Assignment> pending = new List<Assignment>();
            List<Assignment> cur = ExecutingLabRun.AssignmentsGroup[m_currentGroupIndex];
            foreach (Assignment a in cur)
            {
                if (a.RunStatus == AssignmentStatusType.Executing || a.RunStatus == AssignmentStatusType.Assigned)
                {
                    if (!IsUnAssigned(a))
                    {
                        pending.Add(a);
                    }
                }
            }
            return pending;
        }

        bool IsThereAnyPendingRunningAssignment()
        {
            AssignmentCollection cur = ExecutingLabRun.AssignmentsGroup[m_currentGroupIndex];

            for (int i = 0; i < cur.Count; i++)
            {
                Assignment assignment = cur[i];

                if (assignment.IsTimedOut)
                {
                    //TODO: mark assignment stoped
                    //other things we can do is that mark client dead if its was still in assigned state and 
                    //reassign to other clients etc
                    continue;
                }

                if (assignment.RunStatus == AssignmentStatusType.Executing)
                {
                    return true;
                }

                if (assignment.RunStatus == AssignmentStatusType.Assigned)
                {
                    if (IsUnAssigned(assignment))  //bug: Assignment is still assigned to Manager
                        State = ExecutionManagerState.Assigning;

                    return true;
                }
            }

            return false;
        }

        bool IsThereAnyAssignmentGroupToBeRun()
        {
            if (m_currentGroupIndex < ExecutingLabRun.AssignmentsGroup.Count - 1)
            {
                return true;
            }

            return false;
        }

        void NotifyStateChange()
        {
            switch (m_state)
            {
                case ExecutionManagerState.Start:
                    break;
                case ExecutionManagerState.Assigning:
                    break;
                case ExecutionManagerState.WaitForGroupComplete:
                    if (WaitForTestRunComplete != null && !IsThereAnyAssignmentGroupToBeRun())
                    {
                        WaitForTestRunComplete(ExecutingLabRun);
                    }
                    break;
                case ExecutionManagerState.GroupComplete:
                    break;
                case ExecutionManagerState.TestRunComplete:
                    if (TestRunComplete != null)
                    {
                        TestRunComplete(ExecutingLabRun);
                    }
                    break;
            }
        }

        public ExecutionManager()
        {
            m_state = ExecutionManagerState.Start;
        }

        public void Execute(TFxTeam team, LabRun labRun)
        {
            m_team = team;
            ExecutingLabRun = labRun;

            StartProcessStateThread();
        }

        private void StartProcessStateThread()
        {
            ThreadStart myThreadDelegate = new ThreadStart(ProcessState);
            Thread myThread = new Thread(myThreadDelegate);
            myThread.Priority = ThreadPriority.Normal;
            myThread.Start();
        }

        private void StopProcessStateThread()
        {
            this.ContinueProcess = false;
            ProcessEvents.Set();
        }

        public void ProcessState()
        {
            while (ContinueProcess)
            {
                switch (m_state)
                {
                    case ExecutionManagerState.Start:
                        //do all kind of inits
                        m_currentGroupIndex = 0;
                        State = ExecutionManagerState.Assigning;
                        goto case ExecutionManagerState.Assigning;
                    case ExecutionManagerState.Assigning:
                        // should we rerun assignment in here?
                        AssignAssignments();
                        if (!IsThereAnyAssignmentLeftToBeAssigned())
                        {
                            State = ExecutionManagerState.WaitForGroupComplete;
                            goto case ExecutionManagerState.WaitForGroupComplete;
                        }
                        break;
                    //case ExecutionManagerState.WaitAssignmentComplete:

                    case ExecutionManagerState.WaitForGroupComplete:
                        if (!IsThereAnyPendingRunningAssignment())
                        {
                            State = ExecutionManagerState.GroupComplete;
                            goto case ExecutionManagerState.GroupComplete;
                        }
                        break;
                    case ExecutionManagerState.GroupComplete:
                        if (this.IsThereAnyAssignmentGroupToBeRun())
                        {
                            m_currentGroupIndex++;
                            State = ExecutionManagerState.Assigning;
                            goto case ExecutionManagerState.Assigning;
                        }
                        else
                        {
                            State = ExecutionManagerState.TestRunComplete;
                            goto case ExecutionManagerState.TestRunComplete;
                        }
                    case ExecutionManagerState.TestRunComplete:
                        //Make sure that the assignments list is done
                        if (!IsThereAnyAssignmentLeftToBeAssigned())
                        {
                            StopProcessStateThread();
                        }
                        else
                        {
                            State = ExecutionManagerState.Assigning;
                            goto case ExecutionManagerState.Assigning;
                        }

                        break;
                    case ExecutionManagerState.TestRunStop:
                        StopProcessStateThread();
                        break;
                }

                ProcessEvents.WaitOne(500, true);
                System.Windows.Forms.Application.DoEvents();
            }
        }

        public void PauseLabRun()
        {
            m_state = ExecutionManagerState.TestRunStop;
        }
    }
}
