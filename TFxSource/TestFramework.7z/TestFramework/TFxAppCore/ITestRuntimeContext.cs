//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: ITestRuntimeContext.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ITestRuntimeContext.
	/// </summary>
	public interface ITestRuntimeContext
	{
		IConfig Config {get;}
		Logger Logger {get;}
		//StressRecorder StressLog{get;}
		
	}
}
