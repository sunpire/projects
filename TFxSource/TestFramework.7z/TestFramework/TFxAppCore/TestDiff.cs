//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: TestDiff.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 

using System;
using System.Collections;
using Expedia.Test.Framework;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// The TFxDifferenceObject class encapsulates a set of differences between
	/// two TestInfo classes.
	/// </summary>
	public class TestDiff
	{
		private ArrayList m_differences = null;

		public TestDiff()
		{
		}

		public TestDiff(ArrayList differences)
		{
			this.Differences.AddRange(differences);
		}

		/// <summary>
		/// Returns the differences between the two TestInfo objects in this diff object.
		/// </summary>
		public ArrayList Differences
		{
			get
			{
				if(this.m_differences == null)
				{
					this.m_differences = new ArrayList();
				}

				return this.m_differences;
			}
		}

		/// <summary>
		/// Returns true if there are no differences between the TestInfo objects in this diff object.
		/// </summary>
		public bool IsResolved
		{
			get
			{
				foreach(TestCaseDifference diff in this.Differences)
				{
					if(diff.DifferenceType != TestCaseDifferenceType.NoDifference)
					{
						return false;
					}
				}
				return true;
			}
		}
	}
}
