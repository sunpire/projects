using System;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Text;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for DB.
    /// </summary>

    public class TFx : IDisposable
    {
        SqlConnection m_connection;
        ConnectionType m_connectType;

        #region TFx Database

        public static bool Retry = true;

        private static String c_ServerName = String.Empty;

        public static String ServerName
        {
            get { return c_ServerName; }
            set { c_ServerName = value; }
        }

        private static String c_DatabaseName = String.Empty;

        public static String DatabaseName
        {
            get { return c_DatabaseName; }
            set { c_DatabaseName = value; }
        }

        private static String c_ServerMirrorName = String.Empty;

        public static String ServerMirrorName
        {
            get { return c_ServerMirrorName; }
            set { c_ServerMirrorName = value; }
        }

        /// <summary>
        /// Summary description for DBConnectionType.
        /// </summary>
        public enum ConnectionType
        {
            AutoCloseConnection = 0,
            CacheConnection
        }

        public static void InitTFx()
        {
            InitTFx(null);
        }

        public static void InitTFx(string appFolder)
        {
            try
            {
                TFxApplicationConfig appConfig = new TFxApplicationConfig();
                ServerName = appConfig.ServerName;
                DatabaseName = appConfig.DBName;
                ServerMirrorName = appConfig.ServerMirrorName;
            }
            catch (Exception e)
            {
                throw new Exception("Problem reading config for database information: " + e.ToString());
            }
        }

        protected SqlConnection Connection
        {
            get
            {
                Exception exp = null;
                int tries = 0;
                do
                {
                    try
                    {
                        if (m_connection == null)
                        {
                            m_connection = GetConnection();
                            if (m_connectType == ConnectionType.AutoCloseConnection)
                            {
                                m_connection.Open();
                            }
                        }

                        return m_connection;
                    }
                    catch (Exception e)
                    {
                        tries++;
                        string message = String.Format("Error occurred while trying to open connection,\n Connection String:{2}\n number of attempts {1}\n exception details:\n {0}", e, tries.ToString(), m_connection.ConnectionString);
                        exp = e;
                        EventLog.WriteEntry("Application", message, EventLogEntryType.Warning);
                        System.Threading.Thread.Sleep(15000);
                    }
                }
                while (TFx.Retry && tries < 100);

                EventLog.WriteEntry("Application", "Error occurred while opening a connection, gave up at last, number of attempts" + tries.ToString(), EventLogEntryType.Error);
                throw exp;
            }
        }

        public TFx()
            : this(ConnectionType.AutoCloseConnection)
        {
            // default connection type is AutoCloseConnection
        }

        public TFx(ConnectionType type)
        {
            this.m_connectType = type;
        }

        public void Dispose()
        {
            if (m_connection != null)
            {
                m_connection.Dispose();
            }
            GC.SuppressFinalize(this);
        }

        protected SqlConnection GetConnection()
        {
            //TODO: get connection info from application config
            SqlConnection con = new SqlConnection();
            if (string.IsNullOrEmpty(TFx.ServerName) || string.IsNullOrEmpty(TFx.DatabaseName))
            {
                TFx.InitTFx();
            }
            con.ConnectionString = string.Format("Data Source={0};Failover Partner={1};Initial Catalog={2};Integrated Security=SSPI", TFx.ServerName, TFx.ServerMirrorName, TFx.DatabaseName);
            return con;
        }

        /// <summary>
        /// Convert SqlCommand to string, including the parameter names and values
        /// </summary>
        public static string GetSqlString(SqlCommand cmd)
        {
            StringBuilder sqlcmd = new StringBuilder(cmd.CommandText);
            foreach (SqlParameter param in cmd.Parameters)
            {
                sqlcmd.AppendFormat(", {0}={1}", param.ParameterName, param.Value);
            }
            return sqlcmd.ToString();
        }

        protected DataTable ExecuteQuery(string sql, SqlConnection conn)
        {
            Exception exp = null;
            int tries = 0;
            do
            {
                try
                {
                    if (conn.State == System.Data.ConnectionState.Closed)
                    {
                        conn.Open();
                    }
                    using (SqlDataAdapter da = new SqlDataAdapter(sql, conn))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        if (m_connectType == ConnectionType.AutoCloseConnection)
                        {
                            conn.Close();
                        }

                        return dt;
                    }
                }
                catch (Exception e)
                {
                    tries++;
                    string message = String.Format("Error occurred while executing query\n query={0}\n number of attempts {1}\n exception details:\n{2}", sql, tries.ToString(), e);
                    exp = e;
                    EventLog.WriteEntry("Application", message, EventLogEntryType.Warning);
                    System.Threading.Thread.Sleep(15000);
                }
            }
            while (TFx.Retry && tries < 100);

            EventLog.WriteEntry("Application", "Error occurred while executing query, gave up at last, number of attempts:" + tries.ToString(), EventLogEntryType.Error);
            throw exp;
        }

        protected DataTable ExecuteQuery(SqlCommand cmd, SqlConnection conn)
        {
            Exception exp = null;
            int tries = 0;
            do
            {
                try
                {
                    if (conn.State == System.Data.ConnectionState.Closed)
                    {
                        conn.Open();
                    }
                    cmd.CommandTimeout = 3600;
                    cmd.Connection = conn;

                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        if (m_connectType == ConnectionType.AutoCloseConnection)
                        {
                            conn.Close();
                        }

                        return dt;
                    }
                }
                catch (Exception e)
                {
                    tries++;
                    string message = String.Format("Error occurred while executing query\n query={2}\n number of attempts {1}\n exception details:\n{0}", e, tries.ToString(), TFx.GetSqlString(cmd));
                    exp = e;
                    EventLog.WriteEntry("Application", message, EventLogEntryType.Warning);
                    System.Threading.Thread.Sleep(15000);
                }
            }
            while (TFx.Retry && tries < 100);

            EventLog.WriteEntry("Application", "Error occurred while executing query, gave up at last, number of attempts:" + tries.ToString(), EventLogEntryType.Error);
            throw exp;
        }

        protected void ExecuteNonQuery(SqlCommand cmd, SqlConnection conn)
        {
            Exception exp = null;
            int tries = 0;
            do
            {
                try
                {
                    if (conn.State == System.Data.ConnectionState.Closed)
                    {
                        conn.Open();
                    }
                    cmd.CommandTimeout = 3600;
                    cmd.Connection = conn;
                    cmd.ExecuteNonQuery();

                    if (m_connectType == ConnectionType.AutoCloseConnection)
                    {
                        conn.Close();
                    }

                    return;
                }
                catch (Exception e)
                {
                    tries++;
                    string message = String.Format("Error occurred while executing query\n query={2}\n number of attempts {1}\n exception details:\n{0}", e, tries.ToString(), TFx.GetSqlString(cmd));
                    exp = e;
                    EventLog.WriteEntry("Application", message, EventLogEntryType.Warning);
                    System.Threading.Thread.Sleep(15000);
                }
            }
            while (TFx.Retry && tries < 100);

            EventLog.WriteEntry("Application", "Error occurred while executing query, gave up at last, number of attempts:" + tries.ToString(), EventLogEntryType.Error);

            if (m_connectType == ConnectionType.AutoCloseConnection)
            {
                conn.Close();
            }
            throw exp;
        }

        protected object ExecuteScalar(SqlCommand cmd, SqlConnection conn)
        {
            Exception exp = null;
            int tries = 0;
            do
            {
                try
                {
                    //if(m_connectType==ConnectionType.CacheConnection && conn.State == System.Data.ConnectionState.Closed)
                    if (conn.State == System.Data.ConnectionState.Closed)
                    {
                        conn.Open();
                    }
                    cmd.Connection = conn;
                    cmd.CommandTimeout = 3600;

                    object obj = cmd.ExecuteScalar();

                    if (m_connectType == ConnectionType.AutoCloseConnection)
                    {
                        conn.Close();
                    }

                    return obj;
                }
                catch (Exception e)
                {
                    tries++;
                    string message = String.Format("Error occurred while executing query\n query={2}\n number of attempts {1}\n exception details:\n{0}", e, tries.ToString(), TFx.GetSqlString(cmd));
                    exp = e;
                    EventLog.WriteEntry("Application", message, EventLogEntryType.Warning);
                    System.Threading.Thread.Sleep(15000);
                }
            }
            while (TFx.Retry && tries < 100);

            EventLog.WriteEntry("Application", "Error occurred while executing query, gave up at last, number of attempts:" + tries.ToString(), EventLogEntryType.Error);

            if (m_connectType == ConnectionType.AutoCloseConnection)
            {
                conn.Close();
            }

            throw exp;
        }

        #endregion
    }
}
