using System;
using System.Collections.Generic;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Comments: 	Changed the related test id from int to GUID
    /// </summary>
    [Serializable]
    //[XmlInclude(typeof(TFxCase))]
    public class TestCase : TestInfo
    {
        protected long m_testCategory;

        private bool m_isVisible;
        private TestScenario[] m_scenarios = null;

        protected TestDataInfo[] m_testDataInfo;

        /// <summary>
        /// Dictionary of Parameter for the test
        /// </summary>
        private Dictionary<string, string> m_Parameters = null;

        /// <summary>
        /// Dictionary of test configs for the test
        /// </summary>
        private Dictionary<string, string> m_TestConfigs = null;

        public TestCase()
        { }

        public TestCase(string methodName)
            : base(methodName)
        {
            m_testCategory = 0;
        }

        public TestCase(string pathName, string methodName)
            : base(pathName, methodName)
        {
            m_testCategory = 0;
        }

        public TestCase(string pathName, string methodName, string owner, TestBuildModule module, long testCategory)
            : base(pathName, methodName, owner)
        {
            m_testCategory = testCategory;
            this.Module = module;
        }

        public TestCase(TestArea parent, string pathName, string methodName, string owner, long testCategory)
            : base(parent, pathName, methodName, owner)
        {
            m_testCategory = testCategory;
        }

        public int SoftTestId { get; set; }

        public string SoftTestName { get; set; }        

        public Guid TestGuid { get; set; }

        public Guid RelatedTestGid { get; set; }

        public TestBuildModule Module { get; set; }

        public Dictionary<string, string> Parameters
        {
            get
            {
                if (m_Parameters == null)
                    m_Parameters = new Dictionary<string, string>();

                return m_Parameters;
            }
        } // Parameters

        public Dictionary<string, string> TestConfigs
        {
            get
            {
                if (m_TestConfigs == null)
                    m_TestConfigs = new Dictionary<string, string>();

                return m_TestConfigs;
            }
        } // TestConfigs

        public virtual TestDataInfo[] TestData
        {
            get
            {
                //				if(m_testDataInfo == null)
                //				{
                //					m_testDataInfo = GetTestDataInfo();
                //				}

                return m_testDataInfo;
            }
        }

        //		public abstract TestDataInfo[] GetTestDataInfo();

        public virtual long TestCategory
        {
            get
            {
                return m_testCategory;
            }
            set
            {
                m_testCategory = value;
            }
        }

        public bool IsVisible
        {
            get
            {
                return m_isVisible;
            }
            set
            {
                m_isVisible = value;
            }
        }

        //		public abstract long GetTestCategory();

        //		public abstract TestResult Run(ITestRuntimeContext context);

        public override TestInfo FindTest(string fullPath)
        {
            int firstPart = fullPath.IndexOf(pathSeprator);
            if (firstPart > 0)
            {
                return null; //should throw 

            }
            else if (firstPart < 0 && this.Name == fullPath)
            {
                return this;
            }
            return null; //incomplete test name //TODO should throw
        }

        public override TestDiff Diff(TestInfo testInfoObject)
        {
            TestDiff diff = new TestDiff();
            if (testInfoObject is TestCase)
            {
                TestCaseDifference difference = new TestCaseDifference(this, (TestCase)testInfoObject);
                if (difference.DifferenceType != TestCaseDifferenceType.NoDifference)
                {
                    diff.Differences.Add(difference);
                }
            }
            else
            {
                throw new ArgumentException("Type mismatch: testInfoObject must be of type TestCase!");
            }

            return diff;
        }

        public TestScenario[] Scenarios
        {
            get
            {
                return m_scenarios;
            }
            set
            {
                m_scenarios = value;
            }
        }

        public override object Clone()
        {
            TestCase testCase = new TestCase(this.Path,this.Name,this.Owner,this.Module,this.TestCategory);
            testCase.SoftTestName = this.SoftTestName;
            testCase.SoftTestId = this.SoftTestId;

            testCase.Parameters.Clear();
            foreach (KeyValuePair<string, string> item in this.Parameters)
            {
                testCase.Parameters.Add(item.Key, item.Value);
            } // Parameters

            testCase.TestConfigs.Clear();
            foreach (KeyValuePair<string, string> item in this.TestConfigs)
            {
                testCase.TestConfigs.Add(item.Key, item.Value);
            } // TestConfigs

            testCase.Description = this.Description;
            testCase.Disabled = this.Disabled;
            testCase.DisabledReason = this.DisabledReason;
            testCase.IsVisible = this.IsVisible;

            if (this.Scenarios != null)
            {
                testCase.Scenarios = new TestScenario[this.Scenarios.Length];
                for (int i = 0; i < this.Scenarios.Length; i++)
                {
                    testCase.Scenarios[i] = testCase.Scenarios[i].Clone() as TestScenario;
                } // for
            }

            return testCase;       
         
        }
    }
}
