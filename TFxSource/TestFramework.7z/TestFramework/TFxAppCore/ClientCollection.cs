using System;
using System.Collections;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ClientCollection.
	/// </summary>
	[Serializable]
	public class ClientCollection : IList
	{
		private ArrayList m_clientList;
		
		
		public ClientCollection()
		{
			this.m_clientList = ArrayList.Synchronized(new ArrayList());
		}

	

		public bool IsReadOnly
		{
			get
			{
				return m_clientList.IsReadOnly; 
			}
		}

		bool IList.IsReadOnly
		{
			get
			{
				return m_clientList.IsReadOnly;		
			}
		}
		
		bool IList.IsFixedSize
		{
			get
			{
				return m_clientList.IsFixedSize;
			}
		}

		public bool IsFixedSize
		{
			get
			{
				return m_clientList.IsFixedSize; 
			}
		}

		public Client this[int index]
		{
			get
			{
				return (Client)m_clientList[index];
			}
			set
			{
				if(value != null)
				{
					m_clientList[index]=value;
				}
				
				throw new ArgumentNullException("value","Collection does not accept null clients"); 
				
			}
		}

		object IList.this[int index]
		{
			get
			{
				return (Client)m_clientList[index];		
			}
			set
			{
				if(value != null)
				{
					Client client=value as Client;
					if(client==null)
					{	
						throw new ArgumentException("Collection client must be of type Client","value"); 					}
					else
					{
						m_clientList[index]=client;
					}
				}
				else
				{
					throw new ArgumentNullException("value","Collection does not accept null clients");
				}
				
			}
		}
		int IList.Add(object obj)
		{
			if(obj.GetType() != typeof(Client))
			{
				throw new ArgumentException("Collection client must be of type Client","value"); 
				
			}
			else
			{
				
				return m_clientList.Add((Client)obj);
			}

					
		}

		public int Add(Client client)
		{
			return m_clientList.Add((object)client);
		}

		void IList.Clear()
		{
			m_clientList.Clear(); 
		}

		public void Clear()
		{
			m_clientList.Clear(); 
		}

		
		bool IList.Contains(object value)
		{
			if(value==null)
			{
				return false;
			}

			Client client=value as Client;
			if(client==null)
			{
				return false;
			}

			return m_clientList.Contains(client);
		}

		public bool Contains(Client value)
		{
			if(value==null)
			{
				return false;
			}

			return m_clientList.Contains(value); 
		}

		int IList.IndexOf(object value)
		{
			if(value==null)
			{
				return -1;
			}

			Client client=value as Client;
			if(client==null)
			{
				return -1;
			}

			return m_clientList.IndexOf(value);

		}

		public int IndexOf(Client value)
		{
			int index = 0;

			if(value==null)
			{
				return -1;
			}
			
			foreach(Client client in this.m_clientList)
			{
				index++;

				if(client != null)
				{					
//					if(String.Compare(client.TestName, value.TestName) == 0)
//					{
//						return index;
//					}					
										
				}
			}

			return -1; 
		}

		void IList.Insert(int index, object value)
		{
			if(value==null)
			{
				throw new ArgumentNullException("value","Collection does not accept null clients");
			}

			Client client=value as Client;
			if(client==null)
			{
				throw new ArgumentException("Collection client must be of type Client","value"); 
			}
				
			m_clientList.Insert(index,client);
			
		}

		public void Insert(int index,Client value)
		{
			if(value==null)
			{
				throw new ArgumentNullException("value","Collection does not accept null clients");
			}

			m_clientList.Insert(index,value); 		
		}

		void IList.RemoveAt(int index)
		{
			m_clientList.RemoveAt(index);
		}

		public void RemoveAt(int index)
		{
			m_clientList.RemoveAt(index); 	
		}

		void IList.Remove(object value)
		{
			if(value==null)
			{
				throw new ArgumentNullException("value","You cannot remove collection client using null reference"); 
			}

			Client p=value as Client;
			if(p==null)
			{
				throw new ArgumentNullException("value","You can remove only an object of type Person"); 
			}

			m_clientList.Remove(value); 
		}

		public void Remove(Client value)
		{
			if(value==null)
			{
				throw new ArgumentNullException("value","You cannot remove collection client using null reference"); 
			}
			m_clientList.Remove(value); 
		}		

		public bool IsSynchronized
		{
			get
			{
				return this.m_clientList.IsSynchronized;
			}
		}

		public object SyncRoot
		{
			get
			{
				return this.m_clientList.SyncRoot;
			}
		}

		public int Count
		{
			get
			{
				return this.m_clientList.Count;
			}
		}

		public void CopyTo(Array array, int index)
		{
			m_clientList.CopyTo(array,index); 
		}		
		
		public IEnumerator GetEnumerator()
		{
			return m_clientList.GetEnumerator(); 
		}


        public void Sort()
        {
            m_clientList.Sort(new ClientComparer());

        }

        private class ClientComparer : IComparer
        {
            public int Compare(object x, object y)
            {
                Client c1 = x as Client;
                Client c2 = y as Client;
                return (new CaseInsensitiveComparer().Compare(
                    c1.Name, c2.Name));

            }
        }

	}
}
