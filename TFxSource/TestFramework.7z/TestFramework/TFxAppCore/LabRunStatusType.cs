//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: LabRunStatusType.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for LabRunStatusType.
	/// </summary>
	public enum LabRunStatusType
	{
		Created = 0,
        //ToBeRun = 1,
        Running = 2,
        Complete = 3,
        ToBePaused = 4,
		Paused = 5, 
		//Assigned = 6
        Queued = 7
	}
}
