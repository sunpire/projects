using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for BuildType.
	/// </summary>
	public enum BuildType
	{
		/// <summary>
		/// Latest good one
		/// </summary>
		Latest, 

		/// <summary>
		/// Specified by name
		/// </summary>
		Specific,
		/// <summary>
		/// Latest good or bad
		/// </summary>
		Newest

	}
}
