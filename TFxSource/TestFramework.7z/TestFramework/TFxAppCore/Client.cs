using System;
using System.Threading;

namespace Expedia.Test.Framework
{
    //Create the Event Handler
    public delegate void AssignmentEventHandler(Assignment assignment, AssignmentResult result);

    public enum ClientStatusType
    {
        Available,
        Full
    }

    public delegate void ClientAssignmentEventHandler(Client client, Assignment assignment, AssignmentResult result);

    /// <summary>
    /// Summary description for Client.
    /// </summary>
    public abstract class Client
    {

        public event ClientAssignmentEventHandler ClientAssignmentCompleted;
        public event ClientAssignmentEventHandler ClientAssignmentRunning;
        //public AssignmentExecProgressHandler ExecuteProgress;

        public Client(int QSize, Repository repository)
        {
            //
            // TODO: Add constructor logic here
            //

            AssignmentQSize = QSize;
            currentSize = 0;
            m_Repository = repository;
            Available = true;
        }

        public int AssignmentQSize;
        public int currentSize;
        public ClientStatusType State;
        protected Repository m_Repository;
        public bool Available;

        public TFxUser Tester;
        public string Name;

        public void SetQSize(int newSize)
        {
            if (AssignmentQSize < newSize)
            {
                AssignmentQSize = newSize;
            }
        }

        public abstract void RunAssignment(Assignment assignment);

        public void RunAssignment(Assignment assignment, ClientThread clientThread)
        {

            lock (this)
            {
                currentSize++;
                if (currentSize == AssignmentQSize) State = ClientStatusType.Full;
            }

            assignment.StartDate = DateTime.Now;
            lock (assignment)
            {
                assignment.ClientThread = clientThread;
            }
            assignment.RunStatus = AssignmentStatusType.Executing;
            if (ClientAssignmentRunning != null)
            {
                ClientAssignmentRunning(this, assignment, assignment.Result);
            }
            clientThread.OnThreadAssignmentCompleted += new AssignmentEventHandler(
                this.AssignmentCompleted);
            ThreadStart myThreadDelegate = new ThreadStart(clientThread.ThreadWorker);
            Thread myThread = new Thread(myThreadDelegate);
            myThread.Priority = ThreadPriority.AboveNormal;
            myThread.SetApartmentState(ApartmentState.STA);
            clientThread.thread = myThread;
            clientThread.timeout = assignment.AssignmentTimeout;
            clientThread.Start();
        }

        public virtual int GetAvailability()
        {
            int avail = (AssignmentQSize - currentSize);
            if (avail <= 0)
            {
                avail = 0;
            }
            return avail;
        }

        public void AssignmentCompleted(Assignment assignment, AssignmentResult result)
        {
            lock (this)
            {
                --currentSize;
                State = ClientStatusType.Available;
            }
            if (ClientAssignmentCompleted != null)
            {
                ClientAssignmentCompleted(this, assignment, result);
            }
        }
    }

    public abstract class ClientThread
    {
        protected Client m_client;
        protected Assignment m_assignment;
        public Thread thread;
        public TimeSpan timeout;
        public event AssignmentEventHandler OnThreadAssignmentCompleted;

        public ClientThread(Client client, Assignment assignment)
        {
            m_client = client;
            m_assignment = assignment;
            // m_handler = handler;
        }

        public virtual void Start()
        {
            if (thread != null)
            {
                try
                {
                    thread.Start();
                }
                catch (ThreadAbortException)
                {
                    //TODO: needs to mark it aborted
                    Console.WriteLine("************** Aborted ***************************");
                }
            }
        }

        public void Stop()
        {
            if (thread != null)
            {
                thread.Abort();
            }
        }

        public virtual void ThreadWorker()
        {
            m_assignment.RunStatus = AssignmentStatusType.Completed;
            if (OnThreadAssignmentCompleted != null)
            {
                OnThreadAssignmentCompleted(m_assignment, m_assignment.Result);
            }
        }
    }
}
