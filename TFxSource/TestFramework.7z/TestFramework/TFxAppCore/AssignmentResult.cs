using System;
using System.Collections;
using System.Xml.Serialization;
using System.Collections.Generic;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for AssignmentResult.
    /// </summary>
    [Serializable]
    public class AssignmentResult
    {
        public AssignmentRunResultType Status;
        public AssignmentStatusType RunStatus;

        public string ErrorTypeName;
        public string FailureReason;

        private List<ScenarioResult> scenarios;
        private ILog m_runLog;

        public List<ScenarioResult> Scenarios
        {
            get
            {
                if (this.scenarios == null)
                {
                    this.scenarios = new List<ScenarioResult>();
                }
                return this.scenarios;
            }
            set {
                this.scenarios = value;
            }
        }

        [XmlIgnore]
        public ILog Log
        {
            get
            {
                return m_runLog;
            }
            set
            {
                m_runLog = value;
            }
        }

        public AssignmentResult(AssignmentRunResultType status, string reason)
        {
            this.Status = status;
            this.FailureReason = reason;
        }

        public AssignmentResult(AssignmentRunResultType status)
        {
            this.Status = status;
        }

        public AssignmentResult()
        {
        }
    }
}
