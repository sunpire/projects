//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: AssignmentStatusType.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for AssignmentStatusType.
	/// </summary>
	public enum AssignmentStatusType
	{
		None        = 0,
		Assigned    = 1,
		Installing  = 2,
		Loading     = 3,
		Executing   = 4,
		Executed    = 5,
		Completed   = 6,
		Rerun       = 7,
        ToBeStopped = 8,
        Stopped     = 9,
        Queued      = 10
	}
}
