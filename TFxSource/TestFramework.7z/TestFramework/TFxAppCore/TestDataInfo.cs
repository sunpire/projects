//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: TestDataInfo.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TestDataInfo.
	/// </summary>
	[Serializable]
	public class TestDataInfo
	{
		string m_dataAttribute;
		string m_value;

		public TestDataInfo()
		{
		}

 		public TestDataInfo(string dataAttribute, string @value)
		{
			m_dataAttribute = dataAttribute;
			m_value = @value;
		}

		public string DataAttribute
		{
			get
			{
				return m_dataAttribute;
			}
			set
			{
				m_dataAttribute = value;
			}
		}

		public string Value
		{
			get
			{
				return m_value;
			}
			set
			{
				m_value = value;
			}
		}

	}
}
