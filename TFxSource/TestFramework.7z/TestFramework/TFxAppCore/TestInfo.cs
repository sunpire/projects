//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: TestInfo.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;
using System.Collections;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Lifetime;
using Expedia.Test.Framework;

namespace Expedia.Test.Framework
{
	public delegate ArrayList ResolverCallback(ArrayList testCases1, ArrayList testCases2);

	/// <summary>
	/// Summary description for Test.
	/// </summary>
	[Serializable]
	public abstract class TestInfo : ICloneable
    {
		string		m_fullName;
		string		m_testName;
		string		m_pathName;
		string		m_owner;
		bool		m_shouldRun;
		string		m_disabledReason;
		string		m_description;
		//TestResult	m_lastRunResult;
		string m_oldTestName;
		bool		m_disabled;
		

		public const char pathSeprator='.';

        public TestInfo() { }

		protected TestInfo(string pathName, string testName) 
		{ 
			if(pathName == null)
			{
				m_fullName = testName;
			}
			else
			{
				m_fullName = pathName + pathSeprator + testName;
			}
			this.m_pathName = pathName;
			this.m_testName = testName;
			m_shouldRun = true;
		}

		public TestInfo(string name)
		{
			m_fullName = m_testName = name;
		}

		public TestInfo(string pathName, string testName,string owner):this(pathName, testName)
		{
			m_owner = owner;		

		}

		public TestInfo(TestInfo parent, string pathName, string testName, string owner):this(pathName, testName)
		{
			m_parentTest = parent;				
			m_owner = owner;

		}

		public string OldTestName
		{
			get
			{
				return m_oldTestName;
			}
			set
			{
				m_oldTestName = value;
			}

		}

		public string DisabledReason
		{
			get { return m_disabledReason; }
			set { m_disabledReason = value; }
		}

		public bool ShouldRun
		{
			get { return m_shouldRun; }
			set { m_shouldRun = value; }
		}

		public bool Disabled
		{
			get { return m_disabled;}
			set { m_disabled = value;}
		}



		public string FullName 
		{
			get { return m_fullName; }
		}

		public string Name
		{
			get { return m_testName; }
		}

		public string Path
		{
			get { return m_pathName; }
		}
		
		public string Owner
		{
			get 
			{ 
				return this.m_owner;
			}
			set
			{
				this.m_owner = value;
			}
		}

		public string Description
		{
			get
			{
				return m_description;

			}
			set
			{
				m_description = value;
			}
		}

         
		private TestInfo m_parentTest;

		public TestInfo ParentTest
		{
			get
			{
				return m_parentTest;
			}
			set
			{
				m_parentTest = value;
			}
		}

        private Guid _SoftTestGuid = Guid.Empty;
        public Guid SoftTestGuid
        {
            get
            {
                if (_SoftTestGuid == Guid.Empty)
                {
                    _SoftTestGuid = Guid.NewGuid();
                }
                return _SoftTestGuid;
            }            
        }

//		public abstract TestResult Run(ITestRuntimeContext context);	



	

		public abstract TestInfo FindTest(string fullPath);
 
		/// <summary>
		/// Performs a difference check between this object and the specified TestInfo object.
		/// </summary>
		/// <param name="testInfoObject">The specified TestInfo object to diff against.</param>
		/// <param name="includeNoDifference">If set to true, differences of type NoDifference will be
		/// included in the returned list.</param>
		/// <returns>An ArrayList of TestCaseDifference objects, each representing a single difference
		/// between two TestCase objects.</returns>
		public abstract TestDiff Diff(TestInfo testInfoObject);
//		public TestDiff Diff(TestInfo testInfoObject)
//		{
//			return this.Diff(testInfoObject);
//		}
		
		/// <summary>
		/// Compares two lists of test cases and returns a list of TestCaseDifference classes.
		/// </summary>
		/// <param name="testCases1">List 1 of test cases.</param>
		/// <param name="testCases2">List 2 of test cases.</param>
		/// <param name="includeNoDifference">If set to true, test cases that have no differences will be included
		/// in the returned list. That is, the returned list will contain TestCaseDifference objects with a
		/// DifferenceType of TestCaseDifferenceType.NoDifference if two test cases are the same.</param>
		/// <returns>An ArrayList of TestCaseDifference objects, representing the differences between testCases1
		/// and testCases2.</returns>
		protected TestDiff GetDifferences(TestInfoCollection testCases1, TestInfoCollection testCases2)
		{
			TestDiff differences = new TestDiff();
			TestCase testCaseRelated = null;
			int relatedCount = 0;

			// Sort ArrayLists
			if (testCases1 != null)	testCases1.Sort();
			if (testCases2 != null)	testCases2.Sort();

			foreach (TestCase testCase1 in testCases1)
			{
				testCaseRelated = null;

				if (testCases2 !=null)
				{
					foreach (TestCase testCase2 in testCases2)
					{
						if (testCase2.FullName == testCase1.FullName)
						{
							testCaseRelated = testCase2;
						}
					}
				}

				// a rename attribute is found
				if (testCaseRelated == null && testCase1.OldTestName != testCase1.FullName)
				{

					if (testCases2 !=null)
					{
						foreach (TestCase testCase2 in testCases2)
						{
							if (testCase1.OldTestName !=null)
							{
								int index = testCase1.OldTestName.LastIndexOf(".");
								string testArea = testCase1.OldTestName.Substring(0, index);
								string newTestArea = testCase1.FullName.Substring(0, testCase1.FullName.LastIndexOf("."));
								string testName = testCase1.OldTestName.Substring(index+1, testCase1.OldTestName.Length - index-1);

								if (testCase1.OldTestName == testCase2.FullName ||
									(testArea + "." + testCase1.Name) == testCase2.FullName ||
									(newTestArea + "." + testName) == testCase2.FullName 	)
								{
									testCaseRelated = testCase2;
								}
							}
						}
					}
				}

				if (testCaseRelated !=null)  relatedCount++;

				differences.Differences.Add(new TestCaseDifference(testCase1, testCaseRelated));
			}

			if (testCases2 !=null && relatedCount < testCases2.Count)
			{

				foreach (TestCase testCase2 in testCases2)
				{
					TestCase diffRelated = null;

					foreach (TestCaseDifference diff in differences.Differences)
					{
						if (diff.TestCase2 !=null && diff.TestCase2 == testCase2)
						{
							diffRelated = testCase2;
						}
					}

					if (diffRelated ==null)
					{
						// Test Case is deleted
						differences.Differences.Add(new TestCaseDifference(null, testCase2));
					}
				}
				
			}

			return differences;
		}



        #region ICloneable Members

        public virtual object Clone()
        {
            return this;
        }
       

        #endregion
    }
}
