using System;
using System.Collections.Generic;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// LabRun object.  
    /// </summary>
    [Serializable]
    public class LabRun
    {
        public LabRun()
        {
            this.Assignments = new AssignmentCollection();
            this.Result = new LabRunResult();
        }

        public Version Version { get; set; }

        public int Id { get; set; }

        public Guid LabRunGid { get; set; }

        public TFxUser AssignedTo { get; set; }

        public AssignmentCollection Assignments { get; set; }
        public AssignmentCollection SystemTasks { get; set; }

        public List<AssignmentCollection> AssignmentsGroup
        {
            get
            {
                List<AssignmentCollection> groups = new List<AssignmentCollection>();
                groups.Add(this.Assignments);

                if (this.SystemTasks != null && this.SystemTasks.Count > 0)
                {
                    groups.Add(this.SystemTasks);
                }

                return groups;
            }
            set
            {
                if (value != null && value.Count >= 1)
                {
                    this.Assignments = value[0];

                    if (value.Count >= 2)
                    {
                        this.SystemTasks = value[1];
                    }
                }
            }
        }

        public TestBuild Build { get; set; }

        public TFxUser Manager { get; set; }

        public string Name { get; set; }

        public LabRunResult Result { get; set; }

        public LabRunStatusType Status { get; set; }

        public string TemplateName { get; set; }

        public DateTime Start { get; set; }

        public DateTime End { get; set; }
    }
}
