using System;
using System.Collections;
using System.Data;
using System.Xml.Serialization;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for ConfigData.
	/// </summary>
	[Serializable]
	public class ConfigData
	{
        [XmlIgnore]
		public IConfig[] m_config;

		private DataTable m_configTable;
		
		public ConfigData()
		{			
		}

		public DataTable ConfigTable
		{

			get
			{
				return m_configTable;
			}

			set
			{
				if(value != null)
				{
					this.m_configTable = value;
				}
						
			}
		}

		public string GetValue(string columnName)
		{
			return GetValue(0, columnName);
		}

		public string GetValue(int row, string columnName)
		{
			if (row < ConfigTable.Rows.Count && row >= 0 && ConfigTable.Columns.Contains(columnName) &&
				ConfigTable.Rows[row][columnName] != DBNull.Value)
			{
				return (string)ConfigTable.Rows[row][columnName];
			}

			return null;
		}


		public void SetValue(string columnName, string columnValue)
		{
			SetValue(0,columnName, columnValue);
		}


		public void SetValue(int row, string columnName, string columnValue)
		{
			if (row < ConfigTable.Rows.Count && row >= 0 && ConfigTable.Columns.Contains(columnName))
			{
				ConfigTable.Rows[row][columnName] = columnValue;
			}
		}

		IConfig GetAsConfig(DataRow row)
		{
			StringConfig strConfig = new StringConfig();
			foreach(DataColumn col in row.Table.Columns)
			{
				if(!strConfig.Config.ContainsKey(row[col.ColumnName]))
				{
					object obj = row[col];
					string val= string.Empty;
					if(!(obj is DBNull))
					{
						val = obj.ToString();
					}
					strConfig.Config.Add(col.ColumnName,val);
				}
			}
			return strConfig;
		}

		IConfig GetConfig(int rowNumber)
		{
			if(this.m_configTable != null && this.m_configTable.Rows.Count > rowNumber)
			{
				DataRow row = this.m_configTable.Rows[rowNumber];
				return GetAsConfig(row);
			}
			StringConfig strConfig = new StringConfig();
			return strConfig;
		}

		public IConfig GetIConfig(int row)
		{
			if(this.m_configTable != null && row < this.m_configTable.Rows.Count)
			{
				DataRow configRow = this.m_configTable.Rows[row];

				StringConfig strConfig = new StringConfig();

				foreach(DataColumn col in this.m_configTable.Columns)
				{
					strConfig.Config.Add(col.ColumnName,configRow[col]);
				}
				return (IConfig)strConfig;
			}
			return null;
		}



		public IConfig[] GetAllConfigs()
		{
			int arrayIndex = 0;
			IConfig[] configList;	

			if(this.m_configTable != null)
			{
				configList = new IConfig[this.m_configTable.Rows.Count];

				for(int i=0; i < this.m_configTable.Rows.Count; i++)
				{
					configList[arrayIndex] = GetIConfig(i);
					arrayIndex++;
				}

				this.m_config = (IConfig [])configList;
				return m_config;
			}
			return null;
		}

		void MergeColumns(ICollection names)
		{
			if (m_configTable == null)
			{
				m_configTable = new DataTable("config");
			}
			foreach(string col in names)
			{
				if(!this.m_configTable.Columns.Contains(col))
				{
					this.m_configTable.Columns.Add( new DataColumn(col));	
				}
			}
		}

		void UpdateData(DataRow rowSource, DataRow dest, ArrayList exceptCols)
		{
			if(rowSource != null && dest != null)
			{
				foreach(DataColumn col in rowSource.Table.Columns)
				{
					if(exceptCols == null || !exceptCols.Contains(col.ColumnName))
					{
						if(dest.Table.Columns.Contains(col.ColumnName))
						{
							dest[col.ColumnName] = rowSource[col.ColumnName];	
						}
					}
				}
			}
		}

		

		public void UpdateData(DataRow rowSource, DataRow dest)
		{
			UpdateData(rowSource, dest, null);
		}

		public void UpdateData(DataRow rowSource)
		{
			UpdateData(rowSource,this.ConfigTable.Rows[0], null);
			GetAllConfigs();
		}

		


		DataRow DuplicateRow(DataTable table, int row)
		{
			if(table != null && row < table.Rows.Count)
			{
				DataRow source = table.Rows[row];
				DataRow dest = table.NewRow();
				UpdateData(source, dest);
				return dest;
			}
			return null;
		}

		void UpdateData(IConfig config, DataRow dest)
		{
			if(config != null && dest != null)
			{
				foreach(string col in config.ListNames())
				{
					if(config[col] != null)
					{
						dest[col] = config[col];
					}
				}
			}
		}

		void UpdateData(int rowNum, IConfig config)
		{
			if(this.m_configTable.Rows.Count > rowNum)
			{
				DataRow row = this.m_configTable.Rows[rowNum];
				UpdateData(config, row);
			}
		}

		ArrayList GetSharedColumns(IConfig config)
		{
			ArrayList list = new ArrayList();
			if(this.m_configTable != null && config != null)
			{
				foreach(string col in config.ListNames())
				{
					if(m_configTable.Columns.Contains(col))
					{
						list.Add(col);
					}
				}
			}
			return list;
		}

		DataRow[] GetMatchingChildRows(int baseRow, ICollection colls, ConfigData data)
		{
			if(this.m_configTable != null && this.m_configTable.Rows.Count > baseRow)
			{
				string select=string.Empty;
				foreach(string col in colls)
				{
					object obj = this.m_configTable.Rows[baseRow][col];
					if(!(obj is DBNull))
					{
						string val = obj.ToString();
						string str = string.Format("{0} = '{1}' ", col, val);
						if(select.Length > 0)
						{
							select = select + " And " + str;
						}
						else
						{
							select = str;
						}
					}
				}
				DataRow[] rows = data.m_configTable.Select(select);
				return rows;
			}
			return new DataRow[0];
		}

		IConfig GetConfigToMerge(int baseRow, ICollection colls, ConfigData data)
		{
			DataRow[] rows = GetMatchingChildRows(baseRow, colls, data);
			if(rows != null && rows.GetLength(0) > 0)
			{
				return this.GetAsConfig(rows[0]);
			}
			return data.m_config[0];
		}

		bool IsMergeable(ConfigData data, ArrayList sharedColumns)
		{
			if(sharedColumns.Count < data.m_configTable.Columns.Count)
			{
				return true;
			}
			else
			{
				foreach(DataColumn col in data.m_configTable.Columns)
				{
					if(!sharedColumns.Contains(col.ColumnName))
					{
						return true;
					}
				}
			}
			return false;
		}

		public bool IsMergable(ConfigData data)
		{
			if(data != null && data.m_configTable != null)
			{		
				ArrayList sharedColumns = GetSharedColumns(data.m_config[0]);
				return IsMergeable(data, sharedColumns);
			}
			return false;
		}

		public void OldMerge(ConfigData data)
		{
			if(data != null && data.m_configTable != null && data.m_configTable.Rows.Count > 0)
			{
				data.GetAllConfigs();
				ArrayList sharedColumns = GetSharedColumns(data.m_config[0]);
				if(IsMergeable(data, sharedColumns))
				{
					MergeColumns(data.m_config[0].ListNames());
					for(int i=0; i < m_configTable.Rows.Count; i++)
					{
						UpdateData(i, GetConfigToMerge(i, sharedColumns, data));
					}
				}
				GetAllConfigs();
			}
		}



//		public void Merge(ConfigData data)
//		{
//			Merge(data, false);
//		}

		public void Merge(ConfigData data, bool corssMerge)
		{
			if(data != null && data.m_configTable != null && data.m_configTable.Rows.Count > 0)
			{
				data.GetAllConfigs();
				ArrayList sharedColumns = GetSharedColumns(data.m_config[0]);
				if(IsMergeable(data, sharedColumns))
				{
					MergeColumns(data.m_config[0].ListNames());
					ArrayList rowList = new ArrayList();
					for(int i=0; i < m_configTable.Rows.Count; i++)
					{
						DataRow[] rows = GetMatchingChildRows(i, sharedColumns, data);
						if(rows != null && rows.GetLength(0) > 0)
						{
							if(corssMerge)
							{
								for(int j=0; j < rows.GetLength(0); j++)
								{
									DataRow row = null;
									if(j==0)
									{
										row = this.m_configTable.Rows[i];
										UpdateData(rows[j], row, sharedColumns);
									}
									else
									{
										row = DuplicateRow(this.m_configTable, i);
										UpdateData(rows[j], row, sharedColumns);
										rowList.Add(row);
									}
				 
								}
							}
							else
							{
								UpdateData(rows[0], m_configTable.Rows[i], sharedColumns);
							}
						}
					}
					foreach(DataRow r in rowList)
					{
						this.m_configTable.Rows.Add(r);
					}
				}
				GetAllConfigs();
			}
		}

		public void Append(IConfig config)
		{
			if(config != null)
			{
				MergeColumns(config.ListNames());
				DataRow newRow = m_configTable.NewRow();
				UpdateData(config, newRow);
				m_configTable.Rows.Add(newRow);
			}
		}

		ArrayList GetColNames(DataTable table)
		{
			ArrayList list = new ArrayList();
			if( table != null)
			{
				foreach(DataColumn col in table.Columns)
				{
					list.Add(col.ColumnName);
				}
			}
			return list;
		}

		public void Append(DataTable table)
		{
			if(table != null)
			{
				MergeColumns(GetColNames(table));
				for(int i=0; i < table.Rows.Count; i++)
				{
					DataRow newRow = m_configTable.NewRow();
					UpdateData(table.Rows[i], newRow);
					m_configTable.Rows.Add(newRow);
				}
			}
		}

		public void Append(ConfigData data)
		{
			if(data != null)
			{
				Append(data.m_configTable);
			}
		}
	}
}
