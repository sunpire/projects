using System;
using System.Xml.Serialization;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for Assignment.
    /// </summary>
    [Serializable]
    public class Assignment : ICloneable
    {
        private TFxUser m_assignedTo;

        public ClientThread ClientThread { get; set; }

        //public Event
        public event ClientAssignmentEventHandler OnAssignmentCompleted;
        public event ClientAssignmentEventHandler OnAssignmentAborted;

        public bool IsTimedOut
        {
            get
            {
                return (DateTime.Now - this.StartDate > this.AssignmentTimeout);
            }
        }

        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public void RaiseAssignmentCompletedEvent(Client client, Assignment assignment, AssignmentResult result)
        {
            if (OnAssignmentCompleted != null)
            {
                OnAssignmentCompleted(client, assignment, result);
                OnAssignmentCompleted = null;
            }
        }

        public void RaiseAssignmentAbortedEvent(Client client, Assignment assignment, AssignmentResult result)
        {
            if (OnAssignmentAborted != null)
            {
                OnAssignmentAborted(client, assignment, result);
                OnAssignmentAborted = null;
            }
        }

        public TFxUser AssignedTo
        {
            get
            {
                return this.m_assignedTo;
            }
            set
            {
                this.StartDate = DateTime.Now;
                this.m_assignedTo = value;
            }
        }

        public int AssignmentId { get; set; }

        public AssignmentStatusType RunStatus { get; set; }

        public TestCase TestCase { get; set; }

        public ConfigData ConfigData { get; set; }

        [XmlIgnore]
        public LabRun LabRun { get; set; }

        public AssignmentResult Result { get; set; }

        public TimeSpan AssignmentTimeout { get; set; }

        public bool Disabled { get; set; }

        public bool Changed { get; set; }

        public Assignment()
        {
        }

        /// <summary>
        /// Clone an assignment.
        /// </summary>
        /// <returns></returns>
        public object Clone()
        {
            Assignment clone = new Assignment();
            clone.AssignedTo = this.AssignedTo;
            clone.AssignmentId = this.AssignmentId;
            clone.AssignmentTimeout = this.AssignmentTimeout;
            clone.Changed = this.Changed;
            clone.ConfigData = this.CloneAssignmentConfig();
            clone.Disabled = this.Disabled;
            clone.LabRun = this.LabRun;
            clone.Result = this.Result;
            clone.RunStatus = this.RunStatus;
            clone.TestCase = this.TestCase;
            return clone;
        }

        public ConfigData CloneAssignmentConfig()
        {
            if (ConfigData != null)
            {
                ConfigData data = new ConfigData();

                IConfig assignmentConfig = ConfigData.GetIConfig(0);
                if (assignmentConfig != null)
                {
                    StringConfig newConfig = new StringConfig();
                    foreach (string key in assignmentConfig.ListNames())
                    {
                        newConfig.Add(key, assignmentConfig[key]);
                    }

                    data.Append(newConfig);
                }
                return data;
            }
            return null;
        }

        /// <summary>
        /// Update the assignment config data.
        /// Any config values defined in existing config will be overwritten by new config values
        /// </summary>
        /// <param name="config">new configs to be used with test assignment</param>
        /// <param name="addNewValues">whether or not to add new values from new config. false means update value only if the existing config has this variable</param>
        public void UpdateConfigData(IConfig config, bool addNewValues)
        {
            if (config != null && ConfigData != null)
            {
                StringConfig newConfig = (StringConfig)ConfigData.GetIConfig(0);
                if (newConfig == null)
                {
                    newConfig = new StringConfig();
                }

                foreach (string key in config.ListNames())
                {
                    if (newConfig.IsDefined(key))
                    {
                        newConfig[key] = config[key];
                    }
                    //only add new config values if specified
                    else if (addNewValues)
                    {
                        newConfig.Add(key, config[key]);
                    }
                }

                ConfigData data = new ConfigData();
                data.Append(newConfig);
                ConfigData = data;
            }
        }
    }
}
