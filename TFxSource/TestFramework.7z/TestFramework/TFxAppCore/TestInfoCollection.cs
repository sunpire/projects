//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: TestInfoCollection.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//==========================================================================
using System;
using System.Collections;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Represents a collection of TestInfo objects.
	/// </summary>
	public class TestInfoCollection : ICollection
	{
		private ArrayList m_testInfoList;
		
		public TestInfoCollection()
		{
			this.m_testInfoList = new ArrayList();
		}

		public TestInfoCollection(ICollection c)
		{
			this.m_testInfoList = new ArrayList(c);
		}

		#region ICollection Interface
		public int Count
		{
			get
			{
				return this.m_testInfoList.Count;
			}
		}

		public bool IsSynchronized
		{
			get
			{
				return this.m_testInfoList.IsSynchronized;
			}
		}

		public object SyncRoot
		{
			get
			{
				return this.m_testInfoList.SyncRoot;
			}
		}

		public void CopyTo(Array array, int index)
		{
			this.m_testInfoList.CopyTo(array, index);
		}

		public IEnumerator GetEnumerator() 
		{
			return this.m_testInfoList.GetEnumerator();
		}
		#endregion

		#region Properties
		public TestInfo this[int index]
		{
			get
			{
				return (TestInfo)this.m_testInfoList[index];
			}
			set
			{
				this.m_testInfoList[index] = value;
			}
		}
		#endregion

		#region Public Methods

		/// <summary>
		/// Adds the TestInfo object to this collection.
		/// </summary>
		/// <param name="ti">The TestInfo object to add.</param>
		/// <returns>The index of the TestInfo object.</returns>
		public int Add(TestInfo ti)
		{
			return this.m_testInfoList.Add(ti);
		}

		/// <summary>
		/// Adds all TestInfo objects in c to this collection.
		/// </summary>
		/// <param name="c">The collection to add.</param>
		public void AddRange(ICollection c)
		{
			foreach(TestInfo ti in c)
			{
				this.Add(ti);
			}
		}

		/// <summary>
		/// Deletes all TestInfo objects in this collection.
		/// </summary>
		public void Clear()
		{
			this.m_testInfoList.Clear();
		}		

		/// <summary>
		/// Determines whether ti exists in this collection.
		/// </summary>
		/// <param name="ti">The TestInfo object in question.</param>
		/// <returns>true if ti exists in this collection, false otherwise.</returns>
		public bool Contains(TestInfo ti)
		{
			foreach(TestInfo tiObj in this.m_testInfoList)
			{
                if (tiObj.SoftTestGuid == ti.SoftTestGuid)
				{
					return true;
				}
			}

			return false;
		}

		/// <summary>
		/// Determines the index of ti in this collection.
		/// </summary>
		/// <param name="ti">The TestInfo object in question.</param>
		/// <returns>The index of ti if it exists in this collection, -1 otherwise.</returns>
		public int IndexOf(TestInfo ti)
		{
			for(int i = 0;i < this.m_testInfoList.Count;i++)
			{
				if(((TestInfo)this.m_testInfoList[i]).Diff(ti).IsResolved)
				{
					return i;
				}
			}
			return -1;
		}

		private class TestInfoComparer : IComparer
		{
			public int Compare(object x, object y)
			{
				TestInfo tc1 = x as TestInfo;
				TestInfo tc2 = y as TestInfo;
				return((new CaseInsensitiveComparer()).Compare(
					tc1 == null ? null : tc1.FullName,
					tc2 == null ? null : tc2.FullName));
			}
		}
		
		/// <summary>
		/// Sorts this collection by the FullName of each TestInfo object.
		/// </summary>
		public void Sort()
		{
			this.m_testInfoList.Sort(new TestInfoComparer());
		}

		/// <summary>
		/// Sorts this collection using the specified IComparer.
		/// </summary>
		/// <param name="comparer">An IComparer object used to sort this collection.</param>
		public void Sort(IComparer comparer)
		{
			this.m_testInfoList.Sort(comparer);
		}

		/// <summary>
		/// Sorts the specified section of this collection using the specified IComparer.
		/// </summary>
		/// <param name="index">The starting index to begin sorting.</param>
		/// <param name="count">The number of TestInfo objects to sort.</param>
		/// <param name="comparer">An IComparer object used to sort this collection.</param>
		public void Sort(int index, int count, IComparer comparer)
		{
			this.m_testInfoList.Sort(index, count, comparer);
		}

		/// <summary>
		/// Inserts a TestInfo object into this collection at the specified index.
		/// </summary>
		/// <param name="index">The index to insert the TestInfo object into.</param>
		/// <param name="ti">The TestInfo object to insert.</param>
		public void Insert(int index, TestInfo ti)
		{
			this.m_testInfoList.Insert(index, ti);
		}

		/// <summary>
		/// Removes the first occurrence of the specified TestInfo object from this collection.
		/// </summary>
		/// <param name="ti">The TestInfo object to remove.</param>
		public void Remove(TestInfo ti)
		{
			foreach(TestInfo tiObj in this.m_testInfoList)
			{
				if(tiObj.Diff(ti).IsResolved)
				{
					this.m_testInfoList.Remove(tiObj);
					return;
				}
			}
		}

		/// <summary>
		/// Removes the TestInfo object at the specified index from this collection.
		/// </summary>
		/// <param name="index">The index of the TestInfo object to remove.</param>
		public void RemoveAt(int index)
		{
			this.m_testInfoList.RemoveAt(index);
		}

		/// <summary>
		/// Clone the list
		/// </summary>
		/// <returns></returns>
		public TestInfoCollection Clone()
		{
			TestInfoCollection tests = new TestInfoCollection();
			ArrayList obj = this.m_testInfoList.Clone() as ArrayList;
			tests.m_testInfoList = obj;			
			return tests;
		}	
	
		public TestInfoCollection ValidTestCases()
		{
			TestInfoCollection tests = new TestInfoCollection();

			foreach(TestInfo testInfo in this.m_testInfoList)
			{
				if(!testInfo.Disabled)
				{
					tests.Add(testInfo);
				}
			}

			return tests;
		}

		/// <summary>
		/// Applies a RepositoryChangelist to this collection. Note that currently, only TestCaseChange objects
		/// are supported.
		/// </summary>
		/// <param name="changes">List of changes to apply.</param>
		public void ApplyChange(RepositoryChangelist changes)
		{
			foreach(RepositoryRequest change in changes)
			{
				if(change is TestCaseChange)
				{
					this.ApplyChange((TestCaseChange)change);
				}
				else
				{
					throw new Exception("Only TestCaseChanges may be applied to a TestInfoCollection!");
				}
			}
		}

		/// <summary>
		/// Reverses a RepositoryChangelist applied to this collection. Note that currently,
		/// only TestCaseChange objects are supported.
		/// </summary>
		/// <param name="changes">List of changes to undo.</param>
		public void UndoChange(RepositoryChangelist changes)
		{
			foreach(RepositoryRequest change in changes)
			{
				if(change is TestCaseChange)
				{
					this.UndoChange((TestCaseChange)change);
				}
				else
				{
					throw new Exception("Only TestCaseChanges may be applied to a TestInfoCollection!");
				}
			}
		}

		/// <summary>
		/// Applies a test case repository change to this collection.
		/// </summary>
		/// <param name="change">The change to apply.</param>
		public void ApplyChange(TestCaseChange change)
		{
			switch(change.RequestType)
			{
				case RepositoryRequestType.Create:
					this.Add(change.NewTestCase);
					break;
				case RepositoryRequestType.Delete:
					this.Remove(change.OldTestCase);
					break;
				case RepositoryRequestType.Update:
					int srcIndex = this.IndexOf(change.OldTestCase);
					int destIndex = this.IndexOf(change.NewTestCase);

					// Check that the source test case exists, and that the destination test case does not exist
					if(srcIndex < 0)
					{
						throw new Exception(String.Format("Error executing update: Test case {0} does not exist!", change.OldTestCase.FullName));
					}
					else if(destIndex >= 0)
					{
						throw new Exception(String.Format("Error executing update: Test case {0} already exists!", change.NewTestCase.FullName));
					}
					else
					{
						this[srcIndex] = change.NewTestCase;
					}
					break;
				default:
					throw new Exception(String.Format("Error executing test case change: Unknown change type <{0}>", change.RequestType));
			}
		}

		/// <summary>
		/// Reverses the repository change applied to this collection.
		/// </summary>
		/// <param name="change">The change to undo.</param>
		public void UndoChange(TestCaseChange change)
		{
			switch(change.RequestType)
			{
				case RepositoryRequestType.Create:
					this.Remove(change.NewTestCase);
					break;
				case RepositoryRequestType.Delete:
					this.Add(change.OldTestCase);
					break;
				case RepositoryRequestType.Update:
					int srcIndex = this.IndexOf(change.NewTestCase);
					int destIndex = this.IndexOf(change.OldTestCase);

					// Check that the source test case exists, and that the destination test case does not exist
					if(srcIndex < 0)
					{
						throw new Exception(String.Format("Error executing update undo: Test case {0} does not exist!", change.NewTestCase.FullName));
					}
					else if(destIndex >= 0)
					{
						throw new Exception(String.Format("Error executing update undo: Test case {0} already exists!", change.OldTestCase.FullName));
					}
					else
					{
						this[srcIndex] = change.NewTestCase;
					}
					break;
				default:
					throw new Exception(String.Format("Error executing test case change: Unknown change type <{0}>", change.RequestType));
			}
		}


		
		public TestInfoCollection DiffTestCases(TestInfoCollection newTestCases)
		{
			
			TestInfoCollection existingTestCases = this.Clone();

			if(existingTestCases != null && newTestCases != null)
			{
				foreach(TestInfo test in newTestCases)
				{
					if(existingTestCases.Contains(test))
					{
						existingTestCases.Remove(test);

					}
				}
				return existingTestCases;
			}

			return null;
		}	
			

		
		#endregion
	}
}
