//========================================================================== 
// 
// Copyright (C) 2005, Expedia, Inc.  All rights reserved. 
// 
// File: TestCaseDifference.cs 
// 
// Desc:  
// 
// Note:     
// 
// History: 
// 
//========================================================================== 
using System;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Represents a difference between two lists of test cases.
	/// </summary>
	public class TestCaseDifference
	{
		private TestCase m_testCase1 = null;
		private TestCase m_testCase2 = null;
		private TestCaseDifferenceType m_differenceType = TestCaseDifferenceType.NotValidDifference;

		public TestCaseDifference()
		{
		}

		public TestCaseDifference(TestCase testCase1, TestCase testCase2)
		{
			this.m_testCase1 = testCase1;
			this.m_testCase2 = testCase2;
			this.CalculateDifferenceType();
		}

		public TestCase TestCase1
		{
			get
			{
				return this.m_testCase1;
			}
			set
			{
				this.m_testCase1 = value;
				this.CalculateDifferenceType();
			}
		}

		public TestCase TestCase2
		{
			get
			{
				return this.m_testCase2;
			}
			set
			{
				this.m_testCase2 = value;
				this.CalculateDifferenceType();
			}
		}

		public TestCaseDifferenceType DifferenceType
		{
			get
			{
				return this.m_differenceType;
			}
		}


		private void CalculateDifferenceType()
		{
			if(this.m_testCase1 == null && this.m_testCase2 == null)
			{
				this.m_differenceType = TestCaseDifferenceType.NotValidDifference;
			}
			else if(this.m_testCase1 == null || this.m_testCase2 == null)
			{
				this.m_differenceType = TestCaseDifferenceType.NoMatchFound;
			}
			else if(this.m_testCase1.FullName != this.m_testCase2.FullName)
			{
				if (m_testCase1.OldTestName !=null)
				{
					int index = m_testCase1.OldTestName.LastIndexOf(".");
					string testArea = m_testCase1.OldTestName.Substring(0, index);
					string newTestArea = m_testCase1.FullName.Substring(0, m_testCase1.FullName.LastIndexOf("."));
					string testName = m_testCase1.OldTestName.Substring(index+1, m_testCase1.OldTestName.Length - index-1);

					if (m_testCase1.OldTestName == m_testCase2.FullName ||
						(testArea + "." + m_testCase1.Name) == m_testCase2.FullName ||
						(newTestArea + "." + testName) == m_testCase2.FullName 	)
					{
						this.m_differenceType = TestCaseDifferenceType.Rename;
					}				
				}
				else
				{
					this.m_differenceType = TestCaseDifferenceType.NameDifference;
				}
			}
			else if(this.m_testCase1.TestCategory != this.m_testCase2.TestCategory)
			{
				this.m_differenceType = TestCaseDifferenceType.CategoryDifference;
			}
			else if (this.m_testCase1.Owner !=null && this.m_testCase1.Owner != this.m_testCase2.Owner)
			{
				this.m_differenceType = TestCaseDifferenceType.OwnerDifference;
			}
			else
			{
				this.m_differenceType = TestCaseDifferenceType.NoDifference;
			}
		}
	}
}
