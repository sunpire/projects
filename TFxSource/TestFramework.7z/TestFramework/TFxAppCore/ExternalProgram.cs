using System;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Expedia.Test.Framework
{
    /// <summary>
    /// Summary description for ExternalProgram.
    /// </summary>
    public class ExternalProgram
    {
        public ExternalProgram()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public RunExternalProgramResult Run(string folder, string program, string param, Dictionary<string,string> env)
        {
            RunExternalProgramResult result = new RunExternalProgramResult();

            try
            {
                Process p = null;
                ProcessStartInfo ps = new ProcessStartInfo(program, param);
                ps.WorkingDirectory = folder;
                ps.ErrorDialog = false;
                ps.UseShellExecute = false;
                ps.RedirectStandardOutput = true;
                ps.RedirectStandardError = true;
                if (env != null)
                {
                    foreach (string key in env.Keys)
                    {
                        if (ps.EnvironmentVariables.ContainsKey(key))
                        {
                            ps.EnvironmentVariables[key] = String.Concat(ps.EnvironmentVariables[key],";", env[key]);
                        }
                        else
                        {
                            ps.EnvironmentVariables.Add(key, env[key]);
                        }
                    }
                }

                // Reference: http://msdn.microsoft.com/en-us/library/system.diagnostics.process.standardoutput.aspx
                StringBuilder output = new StringBuilder();
                p = new Process();
                p.StartInfo = ps;
                p.OutputDataReceived += (s, e) => output.AppendLine(e.Data);
                p.Start();
                p.BeginOutputReadLine();
                string error = p.StandardError.ReadToEnd();
                p.WaitForExit();

                result.Output = output.ToString();
                result.Error = error;
                result.ExitCode = p.ExitCode;
            }
            catch (Exception e)
            {
                result.Error = e.Message;
                result.Output = e.StackTrace;
                result.ExitCode = -1;
            }

            return result;
        }

        public RunExternalProgramResult RunCommandwithInput(string folder, string program, string param, Dictionary<string, string> env, string inputValue)
        {
            RunExternalProgramResult result = new RunExternalProgramResult();

            try
            {
                Process p = null;
                ProcessStartInfo ps = new ProcessStartInfo(program, param);
                ps.WorkingDirectory = folder;
                ps.ErrorDialog = false;
                ps.UseShellExecute = false;
                ps.RedirectStandardInput = true;
                ps.RedirectStandardOutput = true;
                ps.RedirectStandardError = true;
                if (env != null)
                {
                    foreach (string key in env.Keys)
                    {
                        if (ps.EnvironmentVariables.ContainsKey(key))
                        {
                            ps.EnvironmentVariables[key] = env[key];
                        }
                        else
                        {
                            ps.EnvironmentVariables.Add(key, env[key]);
                        }
                    }
                }

                p = Process.Start(ps);

                StreamWriter sw = p.StandardInput;
                sw.WriteLine(inputValue);


                string output = p.StandardOutput.ReadToEnd();
                string error = p.StandardError.ReadToEnd();
                p.WaitForExit();

                result.Output = output;
                result.Error = error;
                result.ExitCode = p.ExitCode;
            }
            catch (Exception e)
            {
                result.Error = e.Message;
                result.Output = e.StackTrace;
                result.ExitCode = -1;
            }

            return result;
        }
    }
}
