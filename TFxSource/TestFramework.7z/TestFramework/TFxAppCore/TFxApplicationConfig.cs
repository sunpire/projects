using System;
using System.Xml;

namespace Expedia.Test.Framework
{
	/// <summary>
	/// Summary description for TFxApplicationConfig.
	/// </summary>
	public class TFxApplicationConfig
	{

        private readonly static string c_defaultFolderToWatch = @"\\chelsqltfx01.idx.expedmz.com\Builds\Latest";
        private readonly static string c_defaultManagerName = "TFxExecutionManager";
       
        public static String ConfigFile = "TFxDB.config";

		public TFxApplicationConfig()
		{
			//
			// TODO: Add constructor logic here
			//

            m_folderToWatch = c_defaultFolderToWatch;
            m_managerName = c_defaultManagerName;

            if (System.IO.File.Exists(ConfigFile))
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(ConfigFile);
                XmlNodeList nodeList = doc.GetElementsByTagName("TFxConfig");

                // read nodes from TFxConfig
                if (nodeList.Count > 0)
                {
                    nodeList = nodeList[0].ChildNodes;
                    foreach (XmlNode node in nodeList)
                    {
                        if (node.Attributes["key"].Value == "TFxServerName")
                            m_serverName = node.Attributes["value"].Value;
                        else if (node.Attributes["key"].Value == "TFxDBName")
                            m_dbName = node.Attributes["value"].Value;
                        else if (node.Attributes["key"].Value == "TFxDBServerMirror")
                            m_serverMirrorName = node.Attributes["value"].Value;
                        else if (node.Attributes["key"].Value == "TFxLogServerName")
                            m_logServerName = node.Attributes["value"].Value;
                        else if (node.Attributes["key"].Value == "TFxLogDBName")
                            m_logDbName = node.Attributes["value"].Value;
                    }
                }

                //Read the TFxAutoUpdateConfig
                nodeList = doc.GetElementsByTagName("TFxAutoUpdateConfig");

                // read nodes from TFxConfig
                if (nodeList.Count > 0)
                {
                    nodeList = nodeList[0].ChildNodes;
                    foreach (XmlNode node in nodeList)
                    {
                        if (node.Attributes["key"].Value == "FolderToWatch")
                            m_folderToWatch = node.Attributes["value"].Value;
                    }
                }

                //Read the TFxMachineManagerConfig
                nodeList = doc.GetElementsByTagName("TFxMachineManagerConfig");

                // read nodes from TFxConfig
                if (nodeList.Count > 0)
                {
                    nodeList = nodeList[0].ChildNodes;
                    foreach (XmlNode node in nodeList)
                    {
                        if (node.Attributes["key"].Value == "ManagerName")
                            m_managerName = node.Attributes["value"].Value;
                        if (node.Attributes["key"].Value == "PollingInterval")
                            this.m_pollingInterval = int.Parse(node.Attributes["value"].Value);
                        if (node.Attributes["key"].Value == "Concurrency")
                            this.m_concurrency = ushort.Parse(node.Attributes["value"].Value);
                    }
                }
            }
            else
            {
                System.Diagnostics.EventLog.WriteEntry("Application", 
                    string.Format("Config file does not exist: {0}", System.IO.Path.GetFullPath(ConfigFile)));
            }

            if (string.IsNullOrEmpty(m_serverName) || string.IsNullOrEmpty(m_dbName)
                || string.IsNullOrEmpty(m_serverMirrorName)||string.IsNullOrEmpty(m_logDbName) || string.IsNullOrEmpty(m_logServerName))
            {
                //throw new Exception("Can't Read TfxDB.config for server name, db name, log server name, db name");
                m_serverName = "chsxsqltfx001.idx.expedmz.com,1433";
                m_dbName = "TFx2009";
                m_serverMirrorName = "chsxsqltfx003.idx.expedmz.com,1433";
                m_logServerName = "chexsqltfx002";
                m_logDbName = "TFxLog";
            }
		}

		string m_serverName;
		string m_dbName;

        string m_serverMirrorName;

        string m_logServerName;
        string m_logDbName;


        string m_folderToWatch;

        string m_managerName;
        int m_pollingInterval;
        ushort m_concurrency;
     


		public string ServerName
		{
			get
			{
				return m_serverName;
			}
			set
			{
				m_serverName = value;
			}
		}

		public string DBName
		{
			get
			{
				return m_dbName;
			}
			set
			{
				m_dbName = value;
			}
		}

        public string ServerMirrorName
        {
            get
            {
                return m_serverMirrorName;
            }
            set
            {
                m_serverMirrorName = value;
            }
        }


        public string LogServerName
        {
            get
            {
                return m_logServerName;
            }
            set
            {
                m_logServerName = value;
            }
        }

        public string LogDBName
        {
            get
            {
                return m_logDbName;
            }
            set
            {
                m_logDbName = value;
            }
        }


        public string FolderToWatch
        {
            get
            {
                return m_folderToWatch;
            }
            set
            {
                m_folderToWatch = value;
            }
        }

        public string ManagerName
        {
            get
            {
                return m_managerName;
            }
            set 
            {
                m_managerName = value;
            }
        }

        /// <summary>
        /// Number of milliseconds to wait between MM polls
        /// </summary>
        public int PollingInterval
        {
            get
            {
                return this.m_pollingInterval;
            }
            set
            {
                this.m_pollingInterval = value;
            }
        }

        /// <summary>
        /// Number of concurrent users that automation can run on
        /// </summary>
        public ushort Concurrency
        {
            get
            {
                return this.m_concurrency;
            }
            set
            {
                this.m_concurrency = value;
            }
        }

	}
}
