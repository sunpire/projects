﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Expedia.Test.Framework.TFxCore.Tests
{
    /// <summary>
    /// Summary description for TFxCoreResourceTest
    /// </summary>
    [TestClass]
    public class TFxCoreResourceTest
    {
        public TFxCoreResourceTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion
        
        #region Assert

        [TestMethod]
        public void GetMessageFromResTest_NotExistsResourceFile()
        {
            string a = Expedia.Test.Framework.TFxCoreResourceManager.GetMessageFromRes("TFxCore_Common_Resource_FileNotExists");
        }
        [TestMethod]
        public void AssertEquals()
        {
            //Expedia.Test.Framework.Assert.Equals((object)"", (object)"");
            //string resourceString = Expedia.Test.Framework.TFxCoreResourceManager.GetMessageFromRes("TFxCore_Common_Operation_NotBeUsed", "Assert.Equals");
            //Assert.IsFalse(Expedia.Test.Framework.TFxCoreResourceManager.IsError);
            //Assert.IsNotNull(resourceString);
        }
        [TestMethod]
        public void AssertFail()
        {
            //Expedia.Test.Framework.Assert.Fail();
            CommonAssertWithResource("TFxCore_Assert_MethodCalled", "Assert.Fail()");
        }
        [TestMethod]
        public void AssertInconclusive()
        {
            try
            {
                Expedia.Test.Framework.Assert.Inconclusive();
            }
            catch (Expedia.Test.Framework.AssertInconclusiveException)
            { }
            string resourceString = Expedia.Test.Framework.TFxCoreResourceManager.GetMessageFromRes("TFxCore_Assert_MethodCalled", "Assert.Inconclusive()");
            Assert.IsFalse(string.IsNullOrEmpty(resourceString.Substring(resourceString.IndexOf(']')+1).Trim()));
            Assert.IsFalse(Expedia.Test.Framework.TFxCoreResourceManager.IsError);
        }
        [TestMethod]
        public void AssertAreEqual()
        {
            //string expected = "expected";
            //string actual = "actual";
            //Expedia.Test.Framework.Assert.AreEqual<string>(expected, actual);
            //IComparer<string> ic1 = new Expedia.Test.Framework.AssertComparer<string>();
            //IComparer<object> ic2 = new Expedia.Test.Framework.AssertComparer<object>();

            //double expectedDouble = 1;
            //double actualDouble = 3;
            //double deltaDouble = 1;

            //Expedia.Test.Framework.Assert.AreEqual<string>(expected, actual,ic1);
            //Expedia.Test.Framework.Assert.AreEqual<object>(expected, actual);
            //Expedia.Test.Framework.Assert.AreEqual<object>(expected, actual, ic2);
            //Expedia.Test.Framework.Assert.AreEqual(expectedDouble, actualDouble, deltaDouble);
            //Expedia.Test.Framework.Assert.AreEqual((float)expectedDouble, (float)actualDouble, (float)deltaDouble);
            //Expedia.Test.Framework.Assert.AreEqual(expected, actual, true);
            //Expedia.Test.Framework.Assert.AreEqual(expected, actual, true,System.Globalization.CultureInfo.CurrentCulture );

            //string resourceString = Expedia.Test.Framework.TFxCoreResourceManager.GetMessageFromRes("TFxCore_Common_Operation_NotEqual", expected, actual);
            //Assert.IsNotNull(resourceString);
            //Assert.IsFalse(Expedia.Test.Framework.TFxCoreResourceManager.IsError);
            //resourceString = Expedia.Test.Framework.TFxCoreResourceManager.GetMessageFromRes("TFxCore_Common_Operation_MoreThanDelta", expectedDouble, actualDouble, deltaDouble);            
            //Assert.IsNotNull(resourceString);
            //Assert.IsFalse(Expedia.Test.Framework.TFxCoreResourceManager.IsError);
            //resourceString = Expedia.Test.Framework.TFxCoreResourceManager.GetMessageFromRes("TFxCore_Common_Operation_NotEqual_IgnoreCase", expected, actual, true,System.Globalization.CultureInfo.CurrentCulture);
            //Assert.IsNotNull(resourceString);
            //Assert.IsFalse(Expedia.Test.Framework.TFxCoreResourceManager.IsError);
        }

        [TestMethod]
        public void AssertAreNotEqual()
        {
            //string expected = "expected";
            //string actual = "actual";
            //Expedia.Test.Framework.Assert.AreNotEqual<string>(expected, actual);
            //IComparer<string> ic1 = new Expedia.Test.Framework.AssertComparer<string>();
            //IComparer<object> ic2 = new Expedia.Test.Framework.AssertComparer<object>();

            //double expectedDouble = 1;
            //double actualDouble = 3;
            //double deltaDouble = 1;

            //Expedia.Test.Framework.Assert.AreNotEqual<string>(expected, actual, ic1);
            //Expedia.Test.Framework.Assert.AreNotEqual<object>(expected, actual);
            //Expedia.Test.Framework.Assert.AreNotEqual<object>(expected, actual, ic2);
            //Expedia.Test.Framework.Assert.AreNotEqual(expectedDouble, actualDouble, deltaDouble);
            //Expedia.Test.Framework.Assert.AreNotEqual((float)expectedDouble, (float)actualDouble, (float)deltaDouble);
            //Expedia.Test.Framework.Assert.AreNotEqual(expected, actual, true);
            //Expedia.Test.Framework.Assert.AreNotEqual(expected, actual, true, System.Globalization.CultureInfo.CurrentCulture);

            //string resourceString = Expedia.Test.Framework.TFxCoreResourceManager.GetMessageFromRes("TFxCore_Common_Operation_Equal", expected, actual);
            //Assert.IsNotNull(resourceString);
            //Assert.IsFalse(Expedia.Test.Framework.TFxCoreResourceManager.IsError);
            //resourceString = Expedia.Test.Framework.TFxCoreResourceManager.GetMessageFromRes("TFxCore_Common_Operation_LessThanDelta", expectedDouble, actualDouble, deltaDouble);
            //Assert.IsNotNull(resourceString);
            //Assert.IsFalse(Expedia.Test.Framework.TFxCoreResourceManager.IsError);
            //resourceString = Expedia.Test.Framework.TFxCoreResourceManager.GetMessageFromRes("TFxCore_Common_Operation_Equal_IgnoreCase", expected, actual, true, System.Globalization.CultureInfo.CurrentCulture);
            //Assert.IsNotNull(resourceString);
            //Assert.IsFalse(Expedia.Test.Framework.TFxCoreResourceManager.IsError);
        }
        [TestMethod]
        public void BuildNotFoundExceptionTest()
        {
            Expedia.Test.Framework.BuildNotFoundException bnf = new Expedia.Test.Framework.BuildNotFoundException();
        }
        #endregion

        #region Assert
        [TestMethod]
        public void AssertSummaryTest()
        {
            // needs update
            // Equals
            CommonAssertWithResource("TFxCore_Assert_MethodNotBeUsed", "Assert.Equals");
            // Fail
            CommonAssertWithResource("TFxCore_Assert_MethodCalled", "Assert.Fail()");
            // Inconclusive
            CommonAssertWithResource("TFxCore_Assert_MethodCalled", "Assert.Inconclusive()");

        }
        #endregion

        #region AssertAreEqual
        [TestMethod]
        public void AssertAreEqualSummaryTest()
        {
            // needs update
            // AreEqual
            CommonAssertWithResource("TFxCore_Assert_NotEqual", "expected", "actual");
            CommonAssertWithResource("TFxCore_Assert_MoreThanDelta", "expected", "actual", "delta");
            CommonAssertWithResource("TFxCore_Assert_NotEqual_IgnoreCase", "expected", "actual", true, "CultureInfo.CurrentCulture");
        }
        #endregion

        #region AssertAreNotEqual
        [TestMethod]
        public void AssertAreNotEqualSummaryTest()
        {
            // needs update
            // AreNotEqual
            CommonAssertWithResource("TFxCore_Assert_Equal", "notExpected", "actual");
            CommonAssertWithResource("TFxCore_Assert_LessThanDelta", "notExpected", "actual", "delta");
            CommonAssertWithResource("TFxCore_Assert_Equal_IgnoreCase", "notExpected", "actual", true, "CultureInfo.CurrentCulture");
        }
        #endregion

        #region AssertAreNotSame
        [TestMethod]
        public void AssertAreNotSameSummaryTest()
        {
            // needs update
            // AreNotSame
            CommonAssertWithResource("TFxCore_Assert_SameRef", "notExpected", "actual");
        }
        #endregion

        #region AssertAreSame
        [TestMethod]
        public void AssertAreSameSummaryTest()
        {
            // needs update
            // AreSame
            CommonAssertWithResource("TFxCore_Assert_NotSameRef", "expected", "actual");
        }
        #endregion

        #region AssertIsInstanceOfType
        [TestMethod]
        public void AssertIsInstanceOfTypeSummaryTest()
        {
            // needs update
            // IsInstanceOfType
            CommonAssertWithResource("TFxCore_Assert_TypeNotFound", "expectedType");
            CommonAssertWithResource("TFxCore_Assert_TypeFound", "wrongType");

        }
        #endregion

        #region AssertIsNull
        [TestMethod]
        public void AssertIsNullSummaryTest()
        {
            // needs update
            // IsNull
            CommonAssertWithResource("TFxCore_Assert_NotNull", "value");
            // IsNotNull
            CommonAssertWithResource("TFxCore_Assert_Null");

        }
        #endregion

        #region AssertIsTrue
        [TestMethod]
        public void AssertIsTrueSummaryTest()
        {
            // needs update
            // IsFalse
            CommonAssertWithResource("TFxCore_Assert_True");
            // IsTrue
            CommonAssertWithResource("TFxCore_Assert_False");
        }
        #endregion

        #region AssertLog
        [TestMethod]
        public void AssertLogSummaryTest()
        {
            // needs update
            // LogInconclusive
            CommonAssertWithResource("TFxCore_Assert_Info", "Inconclusive", "message");
            // LogFailure
            CommonAssertWithResource("TFxCore_Assert_Info", "Failed", "message");
        }
        #endregion

        #region AssertThrows
        [TestMethod]
        public void AssertThrowsSummaryTest()
        {
            // needs update
            // Throws
            CommonAssertWithResource("TFxCore_Assert_NoException");
            CommonAssertWithResource("TFxCore_Assert_ExceptionNotExpected", "typeof(T).Name");
            // DoesNotThrow
            CommonAssertWithResource("TFxCore_Assert_Exception", "e.GetType().Name");
        }
        #endregion

        #region AssertComparer
        [TestMethod]
        public void AssertComparerSummaryTest()
        {
            // needs update
            // Compare
            CommonAssertWithResource("TFxCore_Assert_MultiDimArray");
        }
        #endregion

        #region BuildNotFoundException
        [TestMethod]
        public void BuildNotFoundExceptionSummaryTest()
        {
            // needs update
            // BuildNotFoundException
            CommonAssertWithResource("TFxCore_Build_NotFound");
        }
        #endregion

        #region EnvironmentLookup
        [TestMethod]
        public void EnvironmentLookupSummaryTest()
        {
            // needs update
            // GetQueryableSites
            CommonAssertWithResource("TFxCore_Arg_Name", "environmentName");
            // GetEnvironment
            CommonAssertWithResource("TFxCore_Arg_Name", "site");
            CommonAssertWithResource("TFxCore_Env_SiteNotFound", "site");
            // GetSites
            CommonAssertWithResource("TFxCore_Env_SiteNotMatched","environmentName", "tpid", "eap", "langid", "flags");
            // GetHIMSSite
            CommonAssertWithResource("TFxCore_Env_SiteNotMatched","", "20001", "", "", "HIMS");
            // GetHAWISite
            CommonAssertWithResource("TFxCore_Env_SiteNotMatched", "", "20002", "", "", "");
            // GetLRMEnvironment
            CommonAssertWithResource("TFxCore_Env_NotFound", "environmentName");

        }
        #endregion

        #region TestContext
        [TestMethod]
        public void TestContextSummaryTest()
        {
            // needs update
            // Instance
            CommonAssertWithResource("TFxCore_Context_Init_NotInit");
            // Initialize
            CommonAssertWithResource("TFxCore_Context_Init_Initialized");
            // InitializeTestData
            CommonAssertWithResource("TFxCore_Context_Init_DBNotSpecified");
            CommonAssertWithResource("TFxCore_Context_Init_TestData", "assignmentId", "labrunId", "ns", "branchName", "serverName", "dbName", "serverMirrorName");
            CommonAssertWithResource("TFxCore_Context_Init_TestDataFailed");
            // Cleanup
            CommonAssertWithResource("TFxCore_Context_Cleaner_Failed", "e");
        }
        #endregion

        #region TestContextData
        [TestMethod]
        public void TestContextDataSummaryTest()
        {
            // needs update
            // Environment
            CommonAssertWithResource("TFxCore_Context_NoEnvNoSite");
            CommonAssertWithResource("TFxCore_Context_NoEnv");
            // HimsSite
            CommonAssertWithResource("TFxCore_Context_NotFound", "HimsSite");
            // GetDynamicVar
            CommonAssertWithResource("TFxCore_Context_DTD_Using", "GetDynamicVar()");
            CommonAssertWithResource("TFxCore_Context_DTD_NotFound", "name");
            // GetRandomVar
            CommonAssertWithResource("TFxCore_Context_DTD_UsingFor", "GetRandomVar()");
            // GetRandomConfig
            CommonAssertWithResource("TFxCore_Context_NotDefined", "name");
            // GetConfigArray
            CommonAssertWithResource("TFxCore_Context_UsingOverride", "name", "this.GetConfigDisplayValue(name, value)", "typeof(T).Name", "_");
            CommonAssertWithResource("TFxCore_Context_DTD_Loading", "name", "this.GetConfigDisplayValue(name, convertedValue)", "typeof(T).Name", 1000);
            CommonAssertWithResource("TFxCore_Context_Loading", "name", "this.GetConfigDisplayValue(name, convertedValue)", "typeof(T).Name", 1000);
            CommonAssertWithResource("TFxCore_Context_LoadingDefault", "name", "this.GetConfigDisplayValue(name, convertedValue)", "typeof(T).Name", 1000);

            CommonAssertWithResource("TFxCore_Context_TestDataNotFound", "name");
            CommonAssertWithResource("TFxCore_Context_TestDataNoDependent", "name", "t");
            CommonAssertWithResource("TFxCore_Context_UsingDefault", "name", "defaultValue");
            CommonAssertWithResource("TFxCore_Context_SetFailed", "name", "value");
            CommonAssertWithResource("TFxCore_Context_RefusedChanging", "name", "value", "this.configs.FindVariable(name)");
            CommonAssertWithResource("TFxCore_Context_SetToNull", "name");
            CommonAssertWithResource("TFxCore_Context_Set", "name", "value");
            CommonAssertWithResource("TFxCore_PSW");
            CommonAssertWithResource("TFxCore_Null");
            CommonAssertWithResource("TFxCore_DateTimeConverted", "value", "this.LangID", "cultureInfo.DateTimeFormat.FullDateTimePattern");
            CommonAssertWithResource("TFxCore_Context_TypeConvertedFailed","name", "defaultType.Name", "value");
            CommonAssertWithResource("TFxCore_Context_Site_RefusedExit");
            CommonAssertWithResource("TFxCore_ContextTest_Scenario","descr");
        }
        #endregion

        #region TFxDBConfig
        [TestMethod]
        public void TFxDBConfigSummaryTest()
        {
            // needs update
            // TFxDBConfig
            CommonAssertWithResource("TFxCore_DBConfig_FileNotExisted", "System.IO.Path.GetFullPath(ConfigFile)");            
        }
        #endregion

        #region base
        private void CommonAssert(string resourceString)
        {
            Assert.IsFalse(string.IsNullOrEmpty(resourceString.Substring(resourceString.IndexOf(']') + 1).Trim()));
            Assert.IsFalse(Expedia.Test.Framework.TFxCoreResourceManager.IsError);
        }
        private string CommonAssertWithResource(string resourceId, params object[] args)
        {
            string resourceString = Expedia.Test.Framework.TFxCoreResourceManager.GetMessageFromRes(resourceId, args);
            CommonAssert(resourceString);
            return resourceString;
        }
        #endregion
    }
}
