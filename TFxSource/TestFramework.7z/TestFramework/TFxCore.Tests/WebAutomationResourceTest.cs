﻿#define BROWSERDEBUG

using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Expedia.Automation.WebFramework;

namespace Expedia.Test.Framework.TFxCore.Tests
{
    /// <summary>
    /// Summary description for WebAutomation
    /// </summary>
    [TestClass]
    public class WebAutomationResourceTest
    {
        public WebAutomationResourceTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        #region Control
        [TestMethod]
        public void FindElementTest()
        {
            string resourceString = string.Empty;
            try
            {
                Control c = new Control();
                HtmlElement he;
                //FindElement(string pattern, FindByType findByType, FilterType filterType, string attName, string tagName, VisibleType visibleType, IncludeType includeType, int index, HtmlParsedObject searchUsing, FieldType requireType)
                he = c.FindElement("pat", FindByType.Text, FilterType.RegX, "att", "", VisibleType.InVisible, IncludeType.AllChildren, -1, null, FieldType.Optional);

            }
            catch (Exception e)
            {
                string message = e.Message;
                Assert.IsFalse(string.IsNullOrEmpty(message.Substring(message.IndexOf(']') + 1).Trim()));
                Assert.IsFalse(Expedia.Test.Framework.TFxCoreResourceManager.IsError);
                resourceString = Expedia.Test.Framework.TFxCoreResourceManager.GetMessageFromRes("WebAutomation_C_NotImplemented", "Find VisibleType");
                Assert.IsFalse(string.IsNullOrEmpty(resourceString.Substring(resourceString.IndexOf(']') + 1).Trim()));
                Assert.IsFalse(Expedia.Test.Framework.TFxCoreResourceManager.IsError);
                Assert.AreEqual(message, resourceString);
            }
            try
            {
                Control c = new Control();
                HtmlElement he;
                //FindElement(string pattern, FindByType findByType, FilterType filterType, string attName, string tagName, VisibleType visibleType, IncludeType includeType, int index, HtmlParsedObject searchUsing, FieldType requireType)
                he = c.FindElement("pat", FindByType.Text, FilterType.RegX, "att", "", VisibleType.DoNotCare, IncludeType.CurrentChildren, -1, null, FieldType.Optional);

            }
            catch (Exception e)
            {
                string message = e.Message;
                Assert.IsFalse(string.IsNullOrEmpty(message.Substring(message.IndexOf(']') + 1).Trim()));
                Assert.IsFalse(Expedia.Test.Framework.TFxCoreResourceManager.IsError);
                resourceString = Expedia.Test.Framework.TFxCoreResourceManager.GetMessageFromRes("WebAutomation_C_NotImplemented", "Find IncludeType");
                Assert.IsFalse(string.IsNullOrEmpty(resourceString.Substring(resourceString.IndexOf(']') + 1).Trim()));
                Assert.IsFalse(Expedia.Test.Framework.TFxCoreResourceManager.IsError);
                Assert.AreEqual(message, resourceString);
            }
            // needs update 
            resourceString = Expedia.Test.Framework.TFxCoreResourceManager.GetMessageFromRes("WebAutomation_C_ElemNotLoaded", 1000, "url");
            Assert.IsFalse(string.IsNullOrEmpty(resourceString.Substring(resourceString.IndexOf(']') + 1).Trim()));
            Assert.IsFalse(Expedia.Test.Framework.TFxCoreResourceManager.IsError);
            // needs update
            resourceString = Expedia.Test.Framework.TFxCoreResourceManager.GetMessageFromRes("WebAutomation_C_ElemNotLoaded", FilterType.RegX.ToString(), "pat", "", "");
            Assert.IsFalse(string.IsNullOrEmpty(resourceString.Substring(resourceString.IndexOf(']') + 1).Trim()));
            Assert.IsFalse(Expedia.Test.Framework.TFxCoreResourceManager.IsError);
        }

        [TestMethod]
        public void FindElementCollectionTest()
        {
            string resourceString = string.Empty;
            try
            {
                Control c = new Control();
                HtmlElementCollection he;
                //FindElementCollection(string pattern, FindByType findByType, FilterType filterType, string attName, string tagName, VisibleType visibleType, IncludeType includeType, int index, int count, HtmlParsedObject searchUsing, FieldType requireType)
                he = c.FindElementCollection("pat", FindByType.Text, FilterType.RegX, "att", "", VisibleType.InVisible , IncludeType.CurrentChildren, -1, 0 ,null, FieldType.Optional);
            }
            catch (Exception e)
            {
                string message = e.Message;
                CommonAssert(message);
                resourceString = CommonAssertWithResource("WebAutomation_C_NotImplemented", "FindCollection VisibleType ");                
                Assert.AreEqual(message, resourceString);
            }
            try
            {
                Control c = new Control();
                HtmlElementCollection he;
                //FindElementCollection(string pattern, FindByType findByType, FilterType filterType, string attName, string tagName, VisibleType visibleType, IncludeType includeType, int index, int count, HtmlParsedObject searchUsing, FieldType requireType)
                he = c.FindElementCollection("pat", FindByType.Text, FilterType.RegX, "att", "", VisibleType.DoNotCare, IncludeType.CurrentChildren, -1, 0, null, FieldType.Optional);
            }
            catch (Exception e)
            {
                string message = e.Message;
                CommonAssert(message);
                resourceString = CommonAssertWithResource("WebAutomation_C_NotImplemented", "FindCollection IncludeType ");
                Assert.AreEqual(message, resourceString);
            }
            try
            {
                Control c = new Control();
                HtmlElementCollection he;
                
                //FindElementCollection(string pattern, FindByType findByType, FilterType filterType, string attName, string tagName, VisibleType visibleType, IncludeType includeType, int index, int count, HtmlParsedObject searchUsing, FieldType requireType)
                he = c.FindElementCollection("pat", FindByType.Text, FilterType.RegX, "att", "", VisibleType.DoNotCare, IncludeType.AllChildren, -1, 0, null, FieldType.Optional);
            }
            catch (Exception e)
            {
                string message = e.Message;
                CommonAssert(message);
                resourceString = CommonAssertWithResource("WebAutomation_C_NotImplemented", "FindCollection Index ");
                Assert.AreEqual(message, resourceString);
            }
            // needs update
            resourceString = CommonAssertWithResource("WebAutomation_C_NotLoaded", FilterType.RegX.ToString(), "pat", "", "");
        }
        #endregion

        #region HtmlElement
        [TestMethod]
        public void setSelectedIndexTest()
        {
            // needs update
            string resourceString = CommonAssertWithResource("WebAutomation_HE_IndexOverflow", 1, "id");
        }        
        [TestMethod]
        public void SelectTest()
        {
            // needs update
            string resourceString = CommonAssertWithResource("WebAutomation_HE_TextNotFound", "text", "id");
        }
        [TestMethod]
        public void SelectByValueTest()
        {
            // needs update
            string resourceString = CommonAssertWithResource("WebAutomation_HE_ValueNotFound", "value", "id");
        }
        #endregion

        #region Window
        [TestMethod]
        public void DumpToLogTest()
        {
            // needs update
            string resourceString = CommonAssertWithResource("WebAutomation_W_Info", "info");
            
            Expedia.Automation.WebFramework.IE.Window w = new Expedia.Automation.WebFramework.IE.Window(new System.IntPtr(245));
            w.DumpToLog();
        }
        #endregion

        #region BrowserControl
        [TestMethod]
        public void HtmlDocumentTest()
        {
            // needs update
            string resourceString = CommonAssertWithResource("WebAutomation_BC_IsNull", "HtmlDocument");
            //Expedia.Automation.WebFramework.IE.BrowserControl bc = new Expedia.Automation.WebFramework.IE.BrowserControl();
            //HtmlDocument hd = bc.HtmlDocument;
        }
        [TestMethod]
        public void BrowserControlSummaryTest()
        {
            // needs update
            // MainDocument
            CommonAssertWithResource("WebAutomation_BC_IsNull", "MainDocument");
            // Quit
            CommonAssertWithResource("WebAutomation_BC_Quit");
            // IsPageComplete
            CommonAssertWithResource("WebAutomation_BC_WaitingOnPage", "HTX_QSREDIR");
            // WaitPagecomplete
            CommonAssertWithResource("WebAutomation_BC_CallingMethod", "WaitPageComplete()", 1000);
            CommonAssertWithResource("WebAutomation_BC_CurrentState", "WaitPageComplete()", DateTime.Now.Subtract(DateTime.Now.AddDays(-1)).TotalMilliseconds, "readyState", "url", true);
            CommonAssertWithResource("WebAutomation_BC_ErrorLoaded", new Exception("lastError"));
            // Wait
            CommonAssertWithResource("WebAutomation_BC_AbortedTest");
            // Navigate
            CommonAssertWithResource("WebAutomation_BC_WaitingLoad","url");
            CommonAssertWithResource("WebAutomation_BC_NavigatingTo", "url");
            // m_browser_NavigateComplete2
            CommonAssertWithResource("WebAutomation_BC_NaviCompletedDetail", "LocationURL", "sReady", "uRL");
            CommonAssertWithResource("WebAutomation_BC_NaviCompleted");
            CommonAssertWithResource("WebAutomation_BC_NaviNotCompleted");
            // m_browser_DocumentComplete
            CommonAssertWithResource("WebAutomation_BC_DocCompleted","typeName", "LocationURL", "sReady", "uRL");
            CommonAssertWithResource("WebAutomation_BC_DocLoaded", "LocationURL");
            CommonAssertWithResource("WebAutomation_BC_DocFinishedLoaded", "url");
            // m_browser_BeforeNavigate2
            CommonAssertWithResource("WebAutomation_BC_NaviBefore");
            CommonAssertWithResource("WebAutomation_BC_WaitingLoad", "url");
            // m_browser_CommandStateChange
            CommonAssertWithResource("WebAutomation_BC_CmdStateChanged");
            // m_browser_DownloadBegin
            CommonAssertWithResource("WebAutomation_BC_DownloadBegin");
            // m_browser_DownloadComplete
            CommonAssertWithResource("WebAutomation_BC_DownloadCompleted");
            // m_browser_NavigateError
            CommonAssertWithResource("WebAutomation_BC_NaviError");
            // m_browser_OnQuit
            CommonAssertWithResource("WebAutomation_BC_OnQuit");
            // m_browser_SetSecureLockIcon
            CommonAssertWithResource("WebAutomation_BC_Method", "m_browser_SetSecureLockIcon()");
            // m_browser_TitleChange
            CommonAssertWithResource("WebAutomation_BC_Method", "m_browser_TitleChange()");
            // m_browser_WindowClosing
            CommonAssertWithResource("WebAutomation_BC_Method", "Browser m_browser_WindowClosing()");
            // WriteToLog
            CommonAssertWithResource("WebAutomation_Descr", "typeName", "message");
            // Dispose
            CommonAssertWithResource("WebAutomation_DisposeStarted");
            CommonAssertWithResource("WebAutomation_DisposeBase");
            CommonAssertWithResource("WebAutomation_DisposeFinished");
        }
        #endregion

        #region BrowserControlEvents
        [TestMethod]
        public void BrowserControlEventsTest()
        {
            // needs update
            // SetupBrowserEvents
            CommonAssertWithResource("WebAutomation_BCE_SettingFrame", 100);
            // CleaupBrowserEvents
            CommonAssertWithResource("WebAutomation_BCE_Cleanup", "doc.title");
            CommonAssertWithResource("WebAutomation_BCE_Cleanup", "null");
            // HandleEvent
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnDataAvailable");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnBeforeActivate");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnActivate");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnBeforeDeactivate");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnDeactivate");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnRowsInserted");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnSelectStart");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnStop");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnHelp");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnPropertyChange");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnCellChange");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnFocusIn");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnFocusOut");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnBeforeEditFocus");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnDragStart");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnControlSelect");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnContextMenu");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnRowEnter");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnRowExit");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnRowsDelete");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnReadyStateChange");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnBeforeUpdate");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnAfterUpdate");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnSelectionChange");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnDatasetChanged");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnDatasetComplete");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnErrorUpdate");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnKeyPress");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnKeyUp");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnKeyDown");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnMouseMove");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnMouseOver");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnMouseOut");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnMouseUp");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnMouseDown");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnMouseWheel");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnClick");
            CommonAssertWithResource("WebAutomation_BCE_Handle", "OnDblClick");
            // RaiseNavigateEvent
            CommonAssertWithResource("WebAutomation_BCE_RaiseEvent", "Navigate");
            // RaiseClickEvent
            CommonAssertWithResource("WebAutomation_BCE_RaiseEvent", "Click");
            // WriteToLog
            CommonAssertWithResource("WebAutomation_Descr", "typeName", "message");
            // Dispose
            CommonAssertWithResource("WebAutomation_DisposeStarted");
            CommonAssertWithResource("WebAutomation_DisposeFinished");
        }
        #endregion

        #region BrowserForm
        [TestMethod]
        public void BrowserFormSummaryTest()
        {
            // needs update
            // BrowserForm_Closed
            CommonAssertWithResource("WebAutomation_BF_ClosedStarted");
            CommonAssertWithResource("WebAutomation_BF_ClosedFinished");
            // BrowserForm_Closing
            CommonAssertWithResource("WebAutomation_BF_ClosingStarted");
            CommonAssertWithResource("WebAutomation_BF_ClosingFinished");
            // Dispose
            CommonAssertWithResource("WebAutomation_DisposeStarted");
            CommonAssertWithResource("WebAutomation_DisposeBase");
            CommonAssertWithResource("WebAutomation_DisposeFinished");
        }
        #endregion

        #region BrowserFormControl
        [TestMethod]
        public void BrowserFormControlSummaryTest()
        {
            // needs update
            // BrowserForm_CommandStateChange
            CommonAssertWithResource("WebAutomation_BFC_CmdStateChanged", "sender.ToString()", "e.command");
            // URL_TextChanged
            CommonAssertWithResource("WebAutomation_BFC_URLTextChanged");
            // btnBack_Click
            CommonAssertWithResource("WebAutomation_BFC_Method", "btnBack_Click");
            // btnForward_Click
            CommonAssertWithResource("WebAutomation_BFC_Method", "btnForward_Click");
            // btnRefresh_Click
            CommonAssertWithResource("WebAutomation_BFC_Method", "btnRefresh_Click");
            // btnStop_Click
            CommonAssertWithResource("WebAutomation_BFC_Method", "btnStop_Click");
            // btnSubmit_Click
            CommonAssertWithResource("WebAutomation_BFC_Method", "btnSubmit_Click");
            // WriteToLog
            CommonAssertWithResource("WebAutomation_Descr", "this.GetType().Name", "message");
        }
        #endregion

        #region BrowserDialogHandler
        [TestMethod]
        public void BrowserDialogHandlerSummaryTest()
        {
            // needs update
            // OnBrowserDialog
            CommonAssertWithResource("WebAutomation_BDH_MatchCurrent", "handler.GetType().FullName");
            CommonAssertWithResource("WebAutomation_BDH_JSError", "e1", "e2");
            CommonAssertWithResource("WebAutomation_BDH_Handled", "handler.GetType().FullName", "JSError");
            CommonAssertWithResource("WebAutomation_JSError");
            CommonAssertWithResource("WebAutomation_BDH_Handled", "handler.GetType().FullName", "");
        }
        #endregion

        #region ScriptErrorDialogHandler
        [TestMethod]
        public void ScriptErrorDialogHandlerSummaryTest()
        {
            // needs update
            // OnDialog
            CommonAssertWithResource("WebAutomation_SEDH_Error");
        }
        #endregion

        #region IEHtmlElement
        [TestMethod]
        public void IEHtmlElementSummaryTest()
        {
            // needs update
            // Text
            CommonAssertWithResource("WebAutomation_IEHE_FileUpload");
            CommonAssertWithResource("WebAutomation_IEHE_FileNotExisted", "value");
            CommonAssertWithResource("WebAutomation_IEHE_Setting", "Text", "GetElementDescription()", "value");
            // Click
            CommonAssertWithResource("WebAutomation_IEHE_Clicking", "GetElementDescription()");
            // Checked
            CommonAssertWithResource("WebAutomation_IEHE_Setting", "Checked", "GetElementDescription()", "value");
            CommonAssertWithResource("WebAutomation_IEHE_SettingExisted", "GetElementDescription()", "value");
            // Value
            CommonAssertWithResource("WebAutomation_IEHE_Setting", "value", "GetElementDescription()", "value");
            // DefaultSelected
            CommonAssertWithResource("WebAutomation_IEHE_Setting", "DefaultSelected", "GetElementDescription()", "value");
            // Selected
            CommonAssertWithResource("WebAutomation_IEHE_Setting", "Selected", "GetElementDescription()", "value");
        }
        #endregion

        #region IEWebApp
        [TestMethod]
        public void IEWebAppSummaryTest()
        {
            // needs update
            // LogJPG
            CommonAssertWithResource("WebAutomation_IEWA_SavingFinalImage");
            // Close
            CommonAssertWithResource("WebAutomation_IEWA_CloseStarting");
            CommonAssertWithResource("WebAutomation_IEWA_CloseFinished");
            // WaitPageLoad
            CommonAssertWithResource("WebAutomation_IEWA_PageLoading");
            CommonAssertWithResource("WebAutomation_IEWA_PageNotLoaded");
            CommonAssertWithResource("WebAutomation_IEWA_PageLoadNotCompleted", 10);
            CommonAssertWithResource("WebAutomation_IEWA_PageLoadTimeOut", 10, "url");
            // InvokeJavascriptMember
            CommonAssertWithResource("WebAutomation_IEWA_JSMemberNotFound", "name");
            CommonAssertWithResource("WebAutomation_IEWA_JSMemberUnknown", "name");
        }
        #endregion

        #region IEWebAppHelpers
        [TestMethod]
        public void IEWebAppHelpersSummaryTest()
        {
            // needs update
            // IEWebApp_PageWaitEvent
            CommonAssertWithResource("WebAutomation_IEWAH_FlashText", "ReadyState", "url");
            // CleanupIETempFiles
            CommonAssertWithResource("WebAutomation_IEWAH_Deleted", "userName", 1000);
            // CheckFiddlerSession
            CommonAssertWithResource("WebAutomation_IEWAH_Info", "non-200");
            CommonAssertWithResource("WebAutomation_IEWAH_Info", "no");
            CommonAssertWithResource("WebAutomation_IEWAH_Info", "200");
            CommonAssertWithResource("WebAutomation_IEWAH_Request", "msg", "Requests[i].fullUrl", "Requests[i].responseCode", "Requests[i].Timers.ClientBeginRequest.ToString()");
            CommonAssertWithResource("WebAutomation_IEWAH_Response", "msg", "Requests[i].Timers.ClientBeginResponse",1000);
            // ShutDownFiddler
            CommonAssertWithResource("WebAutomation_IEWAH_Stopping");
            CommonAssertWithResource("WebAutomation_IEWAH_ShutdownFailed", "ex");
            CommonAssertWithResource("WebAutomation_IEWAH_ShutdownFailed", "");
            // CleanUpBrowserProxySetting
            CommonAssertWithResource("WebAutomation_IEWAH_ProxyClean");
            // StartFiddler
            CommonAssertWithResource("WebAutomation_IEWAH_Start");

        }
        #endregion

        #region IEHTMLDocumentEvents
        [TestMethod]
        public void IEHTMLDocumentEventsSummaryTest()
        {
            // needs update
            // onfocusout
            CommonAssertWithResource("WebAutomation_Descr", "this.GetType().Name", "onfocusout");
            // onclick
            CommonAssertWithResource("WebAutomation_IEHDE_OnClick", "this.GetType().Name");
        }
        #endregion

        #region DialogWindow
        [TestMethod]
        public void DialogWindowSummaryTest()
        {
            // needs update
            // Close
            CommonAssertWithResource("WebAutomation_DW_CloseClick", "this.GetType().Name", "this.Text", "YesButton");
            CommonAssertWithResource("WebAutomation_DW_CloseClick", "this.GetType().Name", "this.Text", "OkButton");
            CommonAssertWithResource("WebAutomation_DW_CloseClick", "this.GetType().Name", "this.Text", "CancelButton");
            CommonAssertWithResource("WebAutomation_DW_Close", "this.GetType().Name", "this.Text");
        }
        #endregion

        #region SelApp
        [TestMethod]
        public void SelAppSummaryTest()
        {
            // needs update
            // Navigate
            CommonAssertWithResource("WebAutomation_ServerNotFound");
            /// WaitPageLoad
            CommonAssertWithResource("WebAutomation_SA_UnexpectedFailure", "seconds", "e");
            CommonAssertWithResource("WebAutomation_SA_WaitStateChange", "str", "thread sleep .5s");
            CommonAssertWithResource("WebAutomation_SA_WaitStateChange", "str", "break");
            CommonAssertWithResource("WebAutomation_SA_WaitStateChange", "return state", "str");
        }
        #endregion

        #region SelHtmlElement
        [TestMethod]
        public void SelHtmlElementSummaryTest()
        {
            // needs update
            // InnerText
            CommonAssertWithResource("WebAutomation_ToBeImplemented");
            
        }
        #endregion

        #region WebApp
        [TestMethod]
        public void WebAppSummaryTest()
        {
            // needs update
            // ReportBrowserVersion
            CommonAssertWithResource("WebAutomation_CurrentBrowser", "Internet Explorer", "version");
            /// WaitForCondition
            CommonAssertWithResource("WebAutomation_WA_AjaxResponseTime", 1000.0);
            // HandleControlNotFound
            CommonAssertWithResource("WebAutomation_IEWA_PageLoadTimeOut", "this.TimeoutSeconds", "this.GetUrl()");
            // HandleWebApplicationError
            CommonAssertWithResource("WebAutomation_SiteDown", "site");
            CommonAssertWithResource("WebAutomation_SiteUnableLoaded", "site", "url");
            CommonAssertWithResource("WebAutomation_PageNotFound", "url", "pageTitle", "expectedPageId");
            CommonAssertWithResource("WebAutomation_SiteBusy","site", "pageTitle", "expectedPageId");
            CommonAssertWithResource("WebAutomation_PageFound","currentPageId", "expectedPageId");
            CommonAssertWithResource("WebAutomation_Info", "other");
            CommonAssertWithResource("WebAutomation_Info", "other");
            CommonAssertWithResource("WebAutomation_Info", "other");
            CommonAssertWithResource("WebAutomation_WA_PageNotExpected", "ex");
            CommonAssertWithResource("WebAutomation_WA_PageError", "pageTitle", "parsedErrorMessage", "foundExpectedMessage");
        }
        #endregion

        #region WebPage
        [TestMethod]
        public void WebPageSummaryTest()
        {
            // needs update
            // Load
            CommonAssertWithResource("WebAutomation_WP_PageValidatedFailed", "this.GetType().Name");
            CommonAssertWithResource("WebAutomation_WP_DocNull");
            // WaitPageLoad
            CommonAssertWithResource("WebAutomation_BeingCalled", "WebPage.WaitPageLoad()");

        }
        #endregion

        #region base
        private void CommonAssert(string resourceString)
        {            
            Assert.IsFalse(string.IsNullOrEmpty(resourceString.Substring(resourceString.IndexOf(']') + 1).Trim()));
            Assert.IsFalse(Expedia.Test.Framework.TFxCoreResourceManager.IsError);
        }
        private string CommonAssertWithResource(string resourceId, params object[] args)
        {
            string resourceString = Expedia.Test.Framework.TFxCoreResourceManager.GetMessageFromRes(resourceId, args);
            CommonAssert(resourceString);
            return resourceString;
        }
        #endregion

    }
}
