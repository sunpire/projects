﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Reflection;

namespace Expedia.Test.Framework.TFxCore.Tests
{
    
    /// <summary>
    /// Summary description for InitializeTest
    /// </summary>
    [TestClass]
    [DeploymentItem(@"..\..\..\TestData.dll")]
    public class InitializeTest
    {
        public InitializeTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        string testFullName = "Expedia.Automation.Test.TFx.Config.GetConfigTest";
        string moduleName = "TFxTest.dll";

        private MethodInfo GetMethodInfo()
        {
            string nameSpace = testFullName.Substring(0, testFullName.LastIndexOf('.'));
            string testName = testFullName.Substring(testFullName.LastIndexOf('.') + 1);
            Assembly assembly = null;

            try
            {
                assembly = Assembly.LoadFrom(@"..\..\..\Bin\Debug\" + moduleName);
            }
            catch (Exception e)
            {
                throw new Exception("Test was not found.");
            }

            // Get all publically visible types and iterate through each one
            Type[] types = assembly.GetExportedTypes();
            foreach (Type type in types)
            {
                // Check for a matching namespace
                if (type.Namespace.Equals(nameSpace, StringComparison.InvariantCultureIgnoreCase))
                {
                    // Try to find test method in type
                    MethodInfo methodInfo = type.GetMethod(
                        testName,
                        BindingFlags.Instance |
                        BindingFlags.Public |
                        BindingFlags.IgnoreCase |
                        BindingFlags.InvokeMethod |
                        BindingFlags.DeclaredOnly);
                    if (methodInfo != null)
                    {
                        return methodInfo;
                    }
                }
            }

            throw new Exception("Test was not found.");
        }

        private void initializeTestContext(Dictionary<string, string> assignmentConfigs, bool isTestDataAvailable)
        {
            TestContext.Initialize(assignmentConfigs, string.Empty, string.Empty, isTestDataAvailable);
        }

        private void initializeTestContextDriverOnly(Dictionary<string, string> assignmentConfigs)
        {
            MethodInfo methodInfo = this.GetMethodInfo();
            TestContext.DriverOnly.Initialize(methodInfo, assignmentConfigs);
        }

        private Dictionary<string, string> getAssignmentConfigList()
        {
            Dictionary<string, string> assignmentConfigs = new Dictionary<string, string>();
            assignmentConfigs.Add("A", "aa");
            assignmentConfigs.Add("B", "bb");
            assignmentConfigs.Add("intType", "20");
            assignmentConfigs.Add("boolType", "true");
            assignmentConfigs.Add("arrayType", "a,b,c,d,e,f");
            assignmentConfigs.Add("__testnamespace", testFullName);
            return assignmentConfigs;
        }


        [TestMethod]
        public void GetSingleConfigWithNoTestDataTest()
        {
            try
            {
                initializeTestContext(getAssignmentConfigList(), false);
                Assert.AreEqual(TestContext.Instance.GetConfig("B"), "bb");
                Assert.AreEqual(20, TestContext.Instance.GetConfig<int>("intType"));
                Assert.AreEqual(true, TestContext.Instance.GetConfig<bool>("boolType"));
                try
                {
                    TestContext.Instance.GetConfig("auth_mode");
                }
                catch (Exception ex)
                {
                    Assert.AreEqual("[TFxCore_Context_NotDefined] The required config auth_mode is not defined.", ex.Message);
                }
                try
                {
                    TestContext.Instance.GetConfig<bool>("not_defined");
                }
                catch (Exception ex)
                {
                    Assert.AreEqual("[TFxCore_Context_NotDefined] The required config not_defined is not defined.", ex.Message);
                }
            }
            finally
            {
                TestContext.DriverOnly.Cleanup();
            }
        }

        [TestMethod]
        public void GetArrayConfigWithNoTestDataTest()
        {
            try
            {
                initializeTestContext(getAssignmentConfigList(), false);
                Assert.AreEqual(TestContext.Instance.GetConfigArray<string>("arrayType").Count(), 6);
                Assert.AreEqual("a,b,c,d,e,f", TestContext.Instance.GetConfig<string>("arrayType"));
                Assert.AreEqual(true, "a,b,c,d,e,f".Contains(TestContext.Instance.GetRandomConfig("arrayType")));
                try
                {
                    TestContext.Instance.GetConfigArray<int>("Flight_Orig_City");
                }
                catch (Exception ex)
                {
                    Assert.AreEqual("[TFxCore_Context_NotDefined] The required config Flight_Orig_City is not defined.", ex.Message);
                }
            }
            finally
            {
                TestContext.DriverOnly.Cleanup();
            }
        }

        [TestMethod]
        public void GetRandomConfigWithNoTestDataTest()
        {
            try
            {
                initializeTestContext(getAssignmentConfigList(), false);
                Assert.AreEqual(true, "a,b,c,d,e,f".Contains(TestContext.Instance.GetRandomConfig("arrayType")));
            }
            finally
            {
                TestContext.DriverOnly.Cleanup();
            }
        }

        [TestMethod]
        public void GetSingleConfigWithTestDataTest()
        {
            try
            {
                initializeTestContext(getAssignmentConfigList(), true);
                Assert.AreEqual(TestContext.Instance.GetConfig("B"), "bb");
                Assert.AreEqual(TestContext.Instance.GetConfig("DDUseDTD20"), "true");
                Assert.AreEqual(true, TestContext.Instance.GetConfig<bool>("DDUseDTD20"));
            }
            finally
            {
                TestContext.DriverOnly.Cleanup();
            }
        }

        [TestMethod]
        public void GetArrayConfigWithTestDataTest()
        {
            try
            {
                initializeTestContext(getAssignmentConfigList(), true);
                Assert.AreEqual(TestContext.Instance.GetConfigArray<string>("arrayType").Count(), 6);
                Assert.AreEqual("a,b,c,d,e,f", TestContext.Instance.GetConfig<string>("arrayType"));
                Assert.AreEqual(true, "a,b,c,d,e,f".Contains(TestContext.Instance.GetRandomConfig("arrayType")));
                Assert.AreEqual(1, TestContext.Instance.GetConfigArray<string>("Flight_Orig_City").Count());
                Assert.AreEqual("SEA", TestContext.Instance.GetConfigArray<string>("Flight_Orig_City")[0]);
                Assert.AreEqual(1, TestContext.Instance.GetConfigArray<bool>("DDUseDTD20").Count());
                Assert.AreEqual(true, TestContext.Instance.GetConfigArray<bool>("DDUseDTD20")[0]);
            }
            finally
            {
                TestContext.DriverOnly.Cleanup();
            }
        }

        [TestMethod]
        public void GetRandomConfigWithTestDataTest()
        {
            try
            {
                initializeTestContext(getAssignmentConfigList(), true);
                Assert.AreEqual(true, "a,b,c,d,e,f".Contains(TestContext.Instance.GetRandomConfig("arrayType")));
            }
            finally
            {
                TestContext.DriverOnly.Cleanup();
            }
        }

        [TestMethod]
        public void GetSingleConfigDriverOnlyTest()
        {
            try
            {
                initializeTestContextDriverOnly(getAssignmentConfigList());
                Assert.AreEqual(TestContext.Instance.GetConfig("intType"), "20");
                Assert.AreEqual(TestContext.Instance.GetConfig("DDUseDTD20"), "true");
                Assert.AreEqual(true, TestContext.Instance.GetConfig<bool>("DDUseDTD20"));
            }
            finally
            {
                TestContext.DriverOnly.Cleanup();
            }
        }

        [TestMethod]
        public void GetArrayConfigDriverOnlyTest()
        {
            try
            {
                initializeTestContextDriverOnly(getAssignmentConfigList());
                Assert.AreEqual(TestContext.Instance.GetConfig("intType"), "20");
                Assert.AreEqual(TestContext.Instance.GetConfig("DDUseDTD20"), "true");
                Assert.AreEqual(true, TestContext.Instance.GetConfig<bool>("DDUseDTD20"));
                Assert.AreEqual("a,b,c,d,e,f", TestContext.Instance.GetConfig<string>("arrayType"));
                Assert.AreEqual(true, "a,b,c,d,e,f".Contains(TestContext.Instance.GetRandomConfig("arrayType")));
                Assert.AreEqual(1, TestContext.Instance.GetConfigArray<string>("Flight_Orig_City").Count());
                Assert.AreEqual("SEA", TestContext.Instance.GetConfigArray<string>("Flight_Orig_City")[0]);
                Assert.AreEqual(1, TestContext.Instance.GetConfigArray<string>("DDUseDTD20").Count());
                Assert.AreEqual(true, TestContext.Instance.GetConfigArray<bool>("DDUseDTD20")[0]);
            }
            finally
            {
                TestContext.DriverOnly.Cleanup();
            }
        }

        [TestMethod]
        public void GetRandomConfigDriverOnlyTest()
        {
            try
            {
                initializeTestContextDriverOnly(getAssignmentConfigList());
                Assert.AreEqual(true, "a,b,c,d,e,f".Contains(TestContext.Instance.GetRandomConfig("arrayType")));
            }
            finally
            {
                TestContext.DriverOnly.Cleanup();
            }
        }
    }
}
