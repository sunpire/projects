﻿using System;
using System.Collections;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml.Linq;
using System.Collections.Generic;

/// <summary>
/// Summary description for TestEnv
/// </summary>
[WebService(Namespace = "http://tfx/", Description = "TFx Test Enviornment service")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class TestEnv : System.Web.Services.WebService
{

    public TestEnv()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public List<ServerSiteData> GetFarmIPs(string farmName)
    {
        using (MIDbDataContext db = new MIDbDataContext())
        {
            var ips =
                from ip in db.ServerSiteDatas
                where string.Compare(ip.ServerFarm, farmName, true) == 0
                orderby ip.ServerFarm, ip.SrvName
                select ip;
            return ips.ToList();
        }
    }

    [WebMethod]
    public List<string> GetFarmNames()
    {
        using (MIDbDataContext db = new MIDbDataContext())
        {
            return (
                    from ip in db.ServerSiteDatas
                    where ip.ServerFarm != null
                    orderby ip.ServerFarm
                    select ip.ServerFarm

                ).Distinct().ToList();
        }
    }
}

